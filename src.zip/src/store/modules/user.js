/**
 * @description 用户基本数据
*/
import { requestRandom, login, logout, getProgramDownloadUrl } from '@/api/login';
import { getCardCode, getCardMac } from '@/api/dynamicLibrary';
import { setSessionStorage, deleteSessionStorage } from '@/utils/storage';
import { TOKEN_KEY } from '@/config/staticVariable';
import store from '@/store'
const user = {
  state: {
    token: '', // 授权token
    oprtId: '', // 操作员id
    regAPPId: 'network_customer_system', // 接入方系统id
    serialNo: '1', // 消息序列号
    timeStamp: 1586336039, // 时间戳
    //channelId: 'phone_front_system',
    regChannelId: '900105',
    operCardId: '', // 操作员卡号
    mac: '', // mac地址
    random: '', // 随机数
    userName: '', // 用户名
    netid: '', // 网点id
    menuIds: '',
    netLevel: '',// 网点级别
    position: '' // 操作员权限
  },

  mutations: {
    SET_TOKEN(state, token) {
      state.token = token
    },
    SET_OPRT_ID(state, oprtId) {
      state.oprtId = oprtId
    },
    SET_REG_APPID(state, regAPPId) {
      state.regAPPId = regAPPId
    },
    SET_SERIAL_NO(state, serialNo) {
      state.serialNo = serialNo
    },
    SET_TIME_STAMP(state, timeStamp) {
      state.timeStamp = timeStamp
    },
    SET_OPER_CARD_ID(state, operCardId) {
      state.operCardId = operCardId
    },
    SET_RANDOM(state, random) {
      state.random = random
    },
    SET_USER_NAME(state, userName) {
      state.userName = userName
    },
    SET_CHANNEL_ID: (state, channelId) => {
      state.channelId = channelId
    },
    SET_REG_CHANNEL_ID: (state, regChannelId) => {
      state.regChannelId = regChannelId
    },
    SET_NET_ID(state, netid) {
      state.netid = netid
    },
    SET_MAC(state, mac) {
      state.mac = mac
    },
    SET_MenuIds(state, menuIds) {
      state.menuIds = menuIds
    },
    SET_NetLevel(state, netLevel) {
      state.netLevel = netLevel
    },
    SET_Position(state, position) {
      state.position = position
    },
  },

  actions: {
    // GetNetId({ commit }) {
    //   commit('SET_NET_ID', '123')
    // },
    GetOperCardId({ commit }) {
      commit('SET_OPER_CARD_ID', getCardCode())
    },
    GetMac({ commit }) {
      commit('SET_MAC', getCardMac())
    },
    async GetToken({ commit }, token) {
      commit('SET_TOKEN', token)
    },
    async GetRandom({ commit }) {
      const res = await requestRandom()
      commit('SET_RANDOM', res.random)
    },
    Login({ commit, dispatch }, { admin, password }) {

      return new Promise((resolve, reject) => {
        commit('SET_OPRT_ID', admin)
        commit('SET_MAC')
        login({
          admin,
          password
        }).then((res) => {

          commit('SET_MenuIds', '');
          commit('SET_NetLevel', '');
          commit('SET_Position', '');
          if (res.token) {
            // if (true) {
            // debugger;
            commit('SET_MenuIds', res.menuIds);
            commit('SET_NetLevel', res.netLevel);
            commit('SET_Position', res.position);
            commit('SET_NET_ID', res.netId);

            // if (res.menuIds.length === 0) {
            //   commit('SET_MenuIds', []);
            //   alert(store.getters.menuIds);
            // }

            // const geturl = getProgramDownloadUrl();
            // if (geturl) {
            //   debugger;
            //   etcdev.upload(
            //     geturl.softListUrl,
            //     geturl.softDownloadUrl,
            //     geturl.authCode,
            //     geturl.softVersion
            //   );
            // }
            commit('SET_TOKEN', res.token)
            setSessionStorage(TOKEN_KEY, res.token)

            // dispatch('GetPermissions', res.menuIds) // 这里返回的是后台管理系统那一套菜单权限，不是这个项目用的
            commit('SET_USER_NAME', admin)
            resolve(res)
          } else {
            reject('登录异常')
          }
        }).catch(e => {
          reject(e)
        })
      })
    },
    GetJumpData({ commit }, { oprtId, token }) {
      return new Promise((resolve, reject) => {
        if (oprtId && token) {
          commit('SET_OPRT_ID', oprtId)
          commit('SET_TOKEN', token)
          setSessionStorage(TOKEN_KEY, token)
          commit('SET_USER_NAME', oprtId)
          resolve(true);
        } else {
          reject(false);
        }
      })
    },
    Logout({ commit, dispatch }) {
      return new Promise((resolve, reject) => {
        logout()
          .then((res) => {
            commit('SET_TOKEN', '')
            deleteSessionStorage(TOKEN_KEY)
            // dispatch('GetPermissions', [])
            commit('SET_USER_NAME', '')
            commit('SET_OPER_CARD_ID', '')
            commit('SET_RANDOM', '')
            commit('SET_MAC', '')
            commit('SET_MenuIds', '')
            commit('SET_NetLevel', '');
            commit('SET_Position', '');
            resolve(res)
          })
          .catch(e => {
            reject(e)
          })
      })
    },
    GetChaennelId({ commit }, channelId) {
      commit('SET_CHANNEL_ID', channelId)
    }
  }
}

export default user
