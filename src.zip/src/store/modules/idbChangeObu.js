/**
 * @description 映射浏览器数据库 换签
 */
import { idb } from '../../utils/indexedDb';
const idbChangeObu = {
  namespaced: true,
  state: {
    agentImg: [],// 换签-上传证件-经办人证件
    otherImg: [],// 换签-上传证件-其他证件
  },
  mutations: {
    SET_AGENT_IMG(state, data) {
      state.agentImg = data;
    },
    SET_OTHER_IMG(state, data) {
      state.otherImg = data;
    },
    // SET_NEWCARD(state, data) {
    //   state.newCard = data
    // }
  },
  actions: {
    // 页面内容修改保存换签-上传证件-经办人证件信息图片
    GetAgentImg({ commit }, data) {
      idb.changeOBU_agentImg.getAll().then(all => {
        if (all.length === 0) {
          idb.changeOBU_agentImg.save({ data })
        } else {
          idb.changeOBU_agentImg.save({ data }, all[0].id);
        }
      });
      commit('SET_AGENT_IMG', data);
    },
    // 从本地存储恢复换签-上传证件-经办人证件信息图片数据
    async RecoveryAgentImg({ commit }) {
      const data = await idb.changeOBU_agentImg.getAll();
      if (data.length > 0) {
        commit('SET_AGENT_IMG', data[0].data);
      } else {
        commit('SET_AGENT_IMG', []);
      }
    },
    // 清空经办人换签-上传证件-经办人证件信息图片数据
    ClearAgentImg({ commit, state }) {
      idb.changeOBU_agentImg.clear();
      commit('SET_AGENT_IMG', []);
    },

    // 页面内容修改保存换签-上传证件-其他证件信息图片
    GetOtherImg({ commit }, data) {
      idb.changeOBU_otherImg.getAll().then(all => {
        if (all.length === 0) {
          idb.changeOBU_otherImg.save({ data })
        } else {
          idb.changeOBU_otherImg.save({ data }, all[0].id);
        }
      });
      commit('SET_OTHER_IMG', data);
    },
    // 从本地存储恢复换签-上传证件-其他证件信息图片数据
    async RecoveryOtherImg({ commit }) {
      const data = await idb.changeOBU_otherImg.getAll();
      if (data.length > 0) {
        commit('SET_OTHER_IMG', data[0].data);
      } else {
        commit('SET_OTHER_IMG', []);
      }
    },
    // 清空经办人换签-上传证件-其他证件信息图片数据
    ClearOtherImg({ commit, state }) {
      idb.changeOBU_otherImg.clear();
      commit('SET_OTHER_IMG', []);
    },
  },
};

export default idbChangeObu;
