/**
 * @description 数据对照表
*/
import { requestDictionary } from '@/api/common'
import { getUserTypes, getBlackStatus, getCardTypes, getMediaTypes, getVehicleTypes } from '@/config/localDictionary'

const dictionary = {
  state: {
    userCertTypes: [], // 证件类型
    vehicleColors: [], // 车牌颜色
    vehicleClasses: [], // 收费车型
    userTypes: [], // 用户类型
    blackStatus: [], // 状态名单
    cardTypes: [], // 卡类型
    mediaTypes: [], // 图片类型
    vehicleTypes: [], // 车辆类型
  },
  mutations: {
    SET_USER_CERT_TYPE(state, userCertTypes) {
      state.userCertTypes = userCertTypes
    },
    SET_VEHICLE_COLOR(state, vehicleColors) {
      state.vehicleColors = vehicleColors
    },
    SET_VEHICLE_CLASSES(state, vehicleClasses) {
      state.vehicleClasses = vehicleClasses
    },
    SET_USER_TYPES(state, userTypes) {
      state.userTypes = userTypes
    },
    SET_BLACK_STATUS(state, blackStatus) {
      state.blackStatus = blackStatus
    },
    SET_CARD_TYPES(state, types) {
      state.cardTypes = types
    },
    SET_MEDIA_TYPES(state, types) {
      state.mediaTypes = types
    },
    SET_VEHICLE_TYPES(state, types) {
      state.vehicleTypes = types
    }
  },
  actions: {
    async GetUserCertTypes({ commit }) {
      const dics = await requestDictionary('userCertType', '证件类型')
      commit('SET_USER_CERT_TYPE', dics && dics.dataDictList || [])
    },
    async GetVehicleColors({ commit }) {
      const dics = await requestDictionary('vehicleColor', '车牌颜色')
      commit('SET_VEHICLE_COLOR', dics && dics.dataDictList || [])
    },
    async GetVehicleClasses({ commit }) {
      const dics = await requestDictionary('vehicleClass', '车牌类型')
      commit('SET_VEHICLE_CLASSES', dics && dics.dataDictList || [])
    },
    GetUserTypes({ commit }) {
      const dics = getUserTypes()
      commit('SET_USER_TYPES', dics)
    },
    GetBlackStatus({ commit }) {
      const dics = getBlackStatus()
      commit('SET_BLACK_STATUS', dics)
    },
    async GetCardTypes({ commit }) {
      const dics = await getCardTypes()
      commit('SET_CARD_TYPES', dics)
    },
    GetMediaTypes({ commit }) {
      const dics = getMediaTypes()
      commit('SET_MEDIA_TYPES', dics)
    },
    async GetCarTypes({ commit }) {
      const dics = await getVehicleTypes()
      commit('SET_VEHICLE_TYPES', dics)
    }
  }
}

export default dictionary
