/**
 * @description 为LoadingButton组件保存按钮状态
*/
const btnState = {
  state: {
    btnMap: new Map(),
    btnArr: [],
    btnPress: false,
  },
  mutations: {
    SET_BTNSTATE(state, btn) {
      state.btnPress = true;
      let btnId = new Date().getTime();
      state.btnMap.set(btnId, btn);
      state.btnArr.push({
        id: btnId,
        count: 0,
      })
    },
    SET_BTNARR(state, btnId) {
      // 设置btnLoading
      let btn = state.btnMap.get(btnId);
      btn.btnLoading = true;
      // 取btnArr最后一项，count+1
      let lastBtn = state.btnArr[state.btnArr.length - 1];
      lastBtn.count++;
    },
    SET_BTNPRESS(state, flag) {
      state.btnPress = flag;
    },
    DELETE_BTNSTATE(state, btnId) {
      state.btnPress = false;
      state.btnMap.delete(btnId);
      state.btnArr.forEach((element, index) => {
        if (element.id === btnId) {
          state.btnArr.splice(index, 1);
        }
      });
    },
    CLEAR_BTNSTATE(state) {
      state.btnMap.clear();
      btnArr = [];
    }
  },
  actions: {
    // GetPermissions({ commit }, permissions) {
    //   commit('SET_PERMISSIONS', permissions)
    // }
  }
}

export default btnState
