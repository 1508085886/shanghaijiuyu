/**
 * @description 映射浏览器数据库 卡片解挂
 */
import { idb } from '../../utils/indexedDb';
const idbUntiedHang = {
  namespaced: true,
  state: {
    userImg: [],// 卡片解挂-上传证件-用户证件
    agentImg: [],// 卡片解挂-上传证件-经办人证件
    otherImg: [],// 卡片解挂-上传证件-其他证件
  },
  mutations: {
    SET_USER_IMG(state, data) {
      state.userImg = data;
    },
    SET_AGENT_IMG(state, data) {
      state.agentImg = data;
    },
    SET_OTHER_IMG(state, data) {
      state.otherImg = data;
    },
  },
  actions: {
    // 页面内容修改保存卡片解挂-上传证件-用户证件信息图片
    GetUserImg({ commit }, data) {
      idb.untiedHang_userImg.getAll().then(all => {
        if (all.length === 0) {
          idb.untiedHang_userImg.save({ data })
        } else {
          idb.untiedHang_userImg.save({ data }, all[0].id);
        }
      });
      commit('SET_USER_IMG', data);
    },
    // 从本地存储恢复卡片解挂-上传证件-用户证件信息图片数据
    async RecoveryUserImg({ commit }) {
      const data = await idb.untiedHang_userImg.getAll();
      if (data.length > 0) {
        commit('SET_USER_IMG', data[0].data);
      } else {
        commit('SET_USER_IMG', []);
      }
    },
    // 清空经办人卡片解挂-上传证件-用户证件信息图片数据
    ClearUserImg({ commit, state }) {
      idb.untiedHang_userImg.clear();
      commit('SET_USER_IMG', []);
    },

    //----------------------------
    // 页面内容修改保存卡片解挂-上传证件-经办人证件信息图片
    GetAgentImg({ commit }, data) {
      idb.untiedHang_agentImg.getAll().then(all => {
        if (all.length === 0) {
          idb.untiedHang_agentImg.save({ data })
        } else {
          idb.untiedHang_agentImg.save({ data }, all[0].id);
        }
      });
      commit('SET_AGENT_IMG', data);
    },
    // 从本地存储恢复卡片解挂-上传证件-经办人证件信息图片数据
    async RecoveryAgentImg({ commit }) {
      const data = await idb.untiedHang_agentImg.getAll();
      if (data.length > 0) {
        commit('SET_AGENT_IMG', data[0].data);
      } else {
        commit('SET_AGENT_IMG', []);
      }
    },
    // 清空经办人卡片解挂-上传证件-经办人证件信息图片数据
    ClearAgentImg({ commit, state }) {
      idb.untiedHang_agentImg.clear();
      commit('SET_AGENT_IMG', []);
    },

    // 页面内容修改保存卡片解挂-上传证件-其他证件信息图片
    GetOtherImg({ commit }, data) {
      idb.untiedHang_otherImg.getAll().then(all => {
        if (all.length === 0) {
          idb.untiedHang_otherImg.save({ data })
        } else {
          idb.untiedHang_otherImg.save({ data }, all[0].id);
        }
      });
      commit('SET_OTHER_IMG', data);
    },
    // 从本地存储恢复卡片解挂-上传证件-其他证件信息图片数据
    async RecoveryOtherImg({ commit }) {
      const data = await idb.untiedHang_otherImg.getAll();
      if (data.length > 0) {
        commit('SET_OTHER_IMG', data[0].data);
      } else {
        commit('SET_OTHER_IMG', []);
      }
    },
    // 清空经办人卡片解挂-上传证件-其他证件信息图片数据
    ClearOtherImg({ commit, state }) {
      idb.untiedHang_otherImg.clear();
      commit('SET_OTHER_IMG', []);
    },
  },
};

export default idbUntiedHang;
