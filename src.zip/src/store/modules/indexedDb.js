/**
 * @description 映射浏览器数据库
 */
import { idb } from '../../utils/indexedDb';

const indexedDb = {
  state: {
    registerUser: {}, // 用户注册
    registerVehicle: [],
    transactorImg: [], // 经办人信息图片
    verifyLicenseImg: [], // 核验证件信息图片
    bankCardImg: [], // 核验证件信息图片
    // agentImg: [],// 换卡-上传证件-经办人证件
    // otherImg: [],// 换卡-上传证件-其他证件
  },
  mutations: {
    SET_REGISTER_USER(state, data) {
      state.registerUser = data;
    },
    SET_REGISTER_VEHICLE(state, data) {
      state.registerVehicle = data;
    },
    SET_TRANSACTOR_IMG(state, data) {
      state.transactorImg = data;
    },
    SET_VERIFYLICENSE_IMG(state, data) {
      state.verifyLicenseImg = data;
    },
    SET_BANKCARD_IMG(state, data) {
      state.bankCardImg = data;
    },
    // SET_AGENT_IMG(state, data) {
    //   state.agentImg = data;
    // },
    // SET_OTHER_IMG(state, data) {
    //   state.otherImg = data;
    // },
  },
  actions: {
    // // 页面内容修改保存换卡-上传证件-经办人证件信息图片
    // GetAgentImg({ commit }, data) {
    //   idb.changeCard_agentImg.getAll().then(all => {
    //     if (all.length === 0) {
    //       idb.changeCard_agentImg.save({ data })
    //     } else {
    //       idb.changeCard_agentImg.save({ data }, all[0].id);
    //     }
    //   });
    //   commit('SET_AGENT_IMG', data);
    // },

    // 页面内容修改保存用户注册信息
    GetRegisterUser({ commit }, data) {
      idb.registerUser.getAll().then(all => {
        if (all.length === 0) {
          idb.registerUser.save({ data })
        } else {
          idb.registerUser.save({ data }, all[0].id);
        }
      });
      commit('SET_REGISTER_USER', data);
    },
    // 清空用户注册信息
    ClearRegisterUser({ commit, state }) {
      // 获取原有车辆注册数据
      idb.registerUser.clear();
      commit('SET_REGISTER_USER', {});
    },
    // 从本地存储恢复用户注册数据
    async RecoveryRegisterUser({ commit }) {
      const all = await idb.registerUser.getAll();
      if (all.length > 0) {
        commit('SET_REGISTER_USER', all[0].data || {});
      } else {
        commit('SET_REGISTER_USER', {});
      }
    },
    // 页面内容修改保存车辆注册信息
    GetRegisterVehicle({ commit, state }, data) {
      // 获取原有车辆注册数据
      let oData = state.registerVehicle;
      if (oData.length > 0 && data.vehicleId && oData.some(value => value.vehicleId === data.vehicleId)) {
        const i = oData.findIndex(value => {
          return value.vehicleId === data.vehicleId;
        });
        if (oData[i]) {
          oData[i] = data
        }
      } else {
        oData = oData.concat(data)
      }
      idb.registerVehicle.getAll().then(all => {
        if (all.length === 0) {
          idb.registerVehicle.save({ data: oData })
        } else {
          idb.registerVehicle.save({ data: oData }, all[0].id);
        }
      })
      commit('SET_REGISTER_VEHICLE', oData);
    },
    // 页面内容修改保存车辆注册信息
    DelRegisterVehicle({ commit, state }, data) {
      // 获取原有车辆注册数据
      let oData = state.registerVehicle;
      if (data.vehicleId) {
        const i = oData.findIndex(value => {
          return value.vehicleId === data.vehicleId;
        });
        oData.splice(i, 1)
        idb.registerVehicle.getAll().then(all => {
          if (all.length === 0) {
            idb.registerUser.save({ data: oData })
          } else {
            idb.registerVehicle.save({ data: oData }, all[0].id);
          }
        })
        commit('SET_REGISTER_VEHICLE', oData);
      }
    },
    // 从本地存储恢复车辆注册数据
    async RecoveryRegisterVehicle({ commit }) {
      const data = await idb.registerVehicle.getAll();
      if (data.length > 0) {
        commit('SET_REGISTER_VEHICLE', data[0].data);
      } else {
        commit('SET_REGISTER_VEHICLE', []);
      }
    },
    // 清空车辆注册信息
    ClearRegisterVehicle({ commit, state }) {
      // 获取原有车辆注册数据
      idb.registerVehicle.clear();
      commit('SET_REGISTER_VEHICLE', []);
    },
    // 页面内容修改保存经办人信息图片
    GetTransactorImg({ commit }, data) {
      idb.transactorImg.getAll().then(all => {
        if (all.length === 0) {
          idb.transactorImg.save({ data })
        } else {
          idb.transactorImg.save({ data }, all[0].id);
        }
      });
      commit('SET_TRANSACTOR_IMG', data);
    },
    // 从本地存储恢复经办人信息图片数据
    async RecoveryTransactorImg({ commit }) {
      const data = await idb.transactorImg.getAll();
      if (data.length > 0) {
        commit('SET_TRANSACTOR_IMG', data[0].data);
      } else {
        commit('SET_TRANSACTOR_IMG', []);
      }
    },
    // 清空经办人信息图片数据
    ClearTransactorImg({ commit, state }) {
      // 获取原有车辆注册数据
      idb.transactorImg.clear();
      commit('SET_TRANSACTOR_IMG', []);
    },

    // 页面内容修改保存核验证件信息图片
    GetVerifyLicenseImg({ commit }, data) {
      idb.verifyLicenseImg.getAll().then(all => {
        if (all.length === 0) {
          idb.verifyLicenseImg.save({ data })
        } else {
          idb.verifyLicenseImg.save({ data }, all[0].id);
        }
      });
      commit('SET_VERIFYLICENSE_IMG', data);
    },
    // 从本地存储恢复核验证件信息图片数据
    async RecoveryVerifyLicenseImg({ commit }) {
      const data = await idb.verifyLicenseImg.getAll();
      if (data.length > 0) {
        commit('SET_VERIFYLICENSE_IMG', data[0].data);
      } else {
        commit('SET_VERIFYLICENSE_IMG', []);
      }
    },
    // 清空经办人核验证件信息图片数据
    ClearVerifyLicenseImg({ commit, state }) {
      // 获取核验证件信息数据
      idb.verifyLicenseImg.clear();
      commit('SET_VERIFYLICENSE_IMG', []);
    },

    // 页面内容修改保存银行卡信息图片
    GetBankCardImg({ commit }, data) {
      idb.bankCardImg.getAll().then(all => {
        if (all.length === 0) {
          idb.bankCardImg.save({ data })
        } else {
          idb.bankCardImg.save({ data }, all[0].id);
        }
      });
      commit('SET_BANKCARD_IMG', data);
    },
    // 从本地存储恢复银行卡信息图片数据
    async RecoveryBankCardImg({ commit }) {
      const data = await idb.bankCardImg.getAll();
      if (data.length > 0) {
        commit('SET_BANKCARD_IMG', data[0].data);
      } else {
        commit('SET_BANKCARD_IMG', []);
      }
    },
    // 清空经办人银行卡信息图片数据
    ClearBankCardImg({ commit, state }) {
      // 获取核验证件信息数据
      idb.bankCardImg.clear();
      commit('SET_BANKCARD_IMG', []);
    },
  },
};

export default indexedDb;
