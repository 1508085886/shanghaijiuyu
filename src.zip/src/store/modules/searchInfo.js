/**
 * @description 主目录左侧搜索后的车辆信息
 */
import { idb } from '../../utils/indexedDb';
const info = {
  state: {
    carInfo: {}, // 车辆信息
    obuInfo: {}, // obu信息
    cardInfo: {}, // 卡片信息
    userInfo: {},
    accountInfo: {},
    departmentInfo: {},
    agentImg: [],// 上传证件-经办人证件
    userImg: [],// 上传证件-用户证件
    otherImg: [],// 上传证件-其他证件
  },
  mutations: {
    SET_SEARCH_CAR_INFO(state, info) {
      state.carInfo = info;
    },
    SET_SEARCH_OBU_INFO(state, info) {
      state.obuInfo = info;
    },
    SET_SEARCH_CARD_INFO(state, info) {
      state.cardInfo = info;
    },
    SET_SEARCH_User_INFO(state, info) {
      state.userInfo = info;
    },
    SET_SEARCH_ACCOUNT_INFO(state, info) {
      state.accountInfo = info;
    },
    SET_SEARCH_DEPARTMENT_INFO(state, info) {
      state.departmentInfo = info;
    },
    SET_SEARCH_AGENT_IMG(state, data) {
      state.agentImg = data;
    },
    SET_SEARCH_USER_IMG(state, data) {
      state.userImg = data;
    },
    SET_SEARCH_OTHER_IMG(state, data) {
      state.otherImg = data;
    },
  },
  actions: {
    GetSearchCarInfo({ commit }, info) {
      commit('SET_SEARCH_CAR_INFO', info);
    },
    GetSearchObuInfo({ commit }, info) {
      commit('SET_SEARCH_OBU_INFO', info);
    },
    GetSearchCardInfo({ commit }, info) {
      commit('SET_SEARCH_CARD_INFO', info);
    },
    GetSearchUserInfo({ commit }, info) {
      commit('SET_SEARCH_User_INFO', info);
    },
    GetSearchAccountInfo({ commit }, info) {
      commit('SET_SEARCH_ACCOUNT_INFO', info);
    },
    GetSearchDepartmentInfo({ commit }, info) {
      commit('SET_SEARCH_DEPARTMENT_INFO', info);
    },

    // 页面内容修改保存上传证件-经办人证件信息图片
    GetSearchAgentImg({ commit }, data) {
      idb.search_agentImg.getAll().then(all => {
        if (all.length === 0) {
          idb.search_agentImg.save({ data })
        } else {
          idb.search_agentImg.save({ data }, all[0].id);
        }
      });
      commit('SET_SEARCH_AGENT_IMG', data);
    },
    // 从本地存储恢复上传证件-经办人证件信息图片数据
    async RecoverySearchAgentImg({ commit }) {
      const data = await idb.search_agentImg.getAll();
      if (data.length > 0) {
        commit('SET_SEARCH_AGENT_IMG', data[0].data);
      } else {
        commit('SET_SEARCH_AGENT_IMG', []);
      }
    },
    // 清空经办人上传证件-经办人证件信息图片数据
    ClearSearchAgentImg({ commit, state }) {
      idb.search_agentImg.clear();
      commit('SET_SEARCH_AGENT_IMG', []);
    },

    // 页面内容修改保存上传证件-用户证件信息图片
    GetSearchUserImg({ commit }, data) {
      idb.search_userImg.getAll().then(all => {
        if (all.length === 0) {
          idb.search_userImg.save({ data })
        } else {
          idb.search_userImg.save({ data }, all[0].id);
        }
      });
      commit('SET_SEARCH_USER_IMG', data);
    },
    // 从本地存储恢复上传证件-用户证件信息图片数据
    async RecoverySearchUserImg({ commit }) {
      const data = await idb.search_userImg.getAll();
      if (data.length > 0) {
        commit('SET_SEARCH_USER_IMG', data[0].data);
      } else {
        commit('SET_SEARCH_USER_IMG', []);
      }
    },
    // 清空经办人上传证件-用户证件信息图片数据
    ClearSearchUserImg({ commit, state }) {
      idb.search_userImg.clear();
      commit('SET_SEARCH_USER_IMG', []);
    },
    //--------------------
    // 页面内容修改保存上传证件-其他证件信息图片
    GetSearchOtherImg({ commit }, data) {
      idb.search_otherImg.getAll().then(all => {
        if (all.length === 0) {
          idb.search_otherImg.save({ data })
        } else {
          idb.search_otherImg.save({ data }, all[0].id);
        }
      });
      commit('SET_SEARCH_OTHER_IMG', data);
    },
    // 从本地存储恢复上传证件-其他证件信息图片数据
    async RecoverySearchOtherImg({ commit }) {
      const data = await idb.search_otherImg.getAll();
      if (data.length > 0) {
        commit('SET_SEARCH_OTHER_IMG', data[0].data);
      } else {
        commit('SET_SEARCH_OTHER_IMG', []);
      }
    },
    // 清空经办人上传证件-其他证件信息图片数据
    ClearSearchOtherImg({ commit, state }) {
      idb.search_otherImg.clear();
      commit('SET_SEARCH_OTHER_IMG', []);
    },
  },
};

export default info;
