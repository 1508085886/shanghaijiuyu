/**
 * @description 映射浏览器数据库 换卡
 */
import { idb } from '../../utils/indexedDb';
const idbChangeCard = {
  namespaced: true,
  state: {
    agentImg: [],// 换卡-上传证件-经办人证件
    otherImg: [],// 换卡-上传证件-其他证件
    // newCard: [],// 新卡数据
  },
  mutations: {
    SET_AGENT_IMG(state, data) {
      state.agentImg = data;
    },
    SET_OTHER_IMG(state, data) {
      state.otherImg = data;
    },
    SET_NEWCARD(state, data) {
      state.newCard = data
    }
  },
  actions: {
    // // 新卡数据
    // GetNewCard({ commit }, data) {
    //   commit('SET_NEWCARD', data)
    // },
    // 页面内容修改保存换卡-上传证件-经办人证件信息图片
    GetAgentImg({ commit }, data) {
      idb.changeCard_agentImg.getAll().then(all => {
        if (all.length === 0) {
          idb.changeCard_agentImg.save({ data })
        } else {
          idb.changeCard_agentImg.save({ data }, all[0].id);
        }
      });
      commit('SET_AGENT_IMG', data);
    },
    // 从本地存储恢复换卡-上传证件-经办人证件信息图片数据
    async RecoveryAgentImg({ commit }) {
      const data = await idb.changeCard_agentImg.getAll();
      if (data.length > 0) {
        commit('SET_AGENT_IMG', data[0].data);
      } else {
        commit('SET_AGENT_IMG', []);
      }
    },
    // 清空经办人换卡-上传证件-经办人证件信息图片数据
    ClearAgentImg({ commit, state }) {
      idb.changeCard_agentImg.clear();
      commit('SET_AGENT_IMG', []);
    },

    // 页面内容修改保存换卡-上传证件-其他证件信息图片
    GetOtherImg({ commit }, data) {
      idb.changeCard_otherImg.getAll().then(all => {
        if (all.length === 0) {
          idb.changeCard_otherImg.save({ data })
        } else {
          idb.changeCard_otherImg.save({ data }, all[0].id);
        }
      });
      commit('SET_OTHER_IMG', data);
    },
    // 从本地存储恢复换卡-上传证件-其他证件信息图片数据
    async RecoveryOtherImg({ commit }) {
      const data = await idb.changeCard_otherImg.getAll();
      if (data.length > 0) {
        commit('SET_OTHER_IMG', data[0].data);
      } else {
        commit('SET_OTHER_IMG', []);
      }
    },
    // 清空经办人换卡-上传证件-其他证件信息图片数据
    ClearOtherImg({ commit, state }) {
      idb.changeCard_otherImg.clear();
      commit('SET_OTHER_IMG', []);
    },
  },
};

export default idbChangeCard;
