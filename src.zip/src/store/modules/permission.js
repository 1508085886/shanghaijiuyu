/**
 * @description 用户主页菜单权限
*/
const permission = {
  state: {
    permissions: [], // 权限操作列表
    elementPermissions: [] // 元素权限列表
  },
  mutations: {
    SET_PERMISSIONS(state, permissions) {
      state.permissions = permissions
    },
    SET_ELEMENTPERMISSIONS(state, elementPermissions) {
      state.elementPermissions = elementPermissions
    }
  },
  actions: {
    GetPermissions({ commit }, permissions) {
      commit('SET_PERMISSIONS', permissions)
    },
    GetElementPermissions({ commit }, elementPermissions) {
      commit('SET_ELEMENTPERMISSIONS', elementPermissions)
    }
  }
}

export default permission
