const getters = {
  btnMap: state => state.btnState.btnMap,// LoadngBtn
  btnArr: state => state.btnState.btnArr,// LoadngBtn
  btnPress: state => state.btnState.btnPress,// LoadngBtn

  channelId: state => state.user.channelId,
  regAPPId: state => state.user.regAPPId,
  regChannelId: state => state.user.regChannelId,
  oprtId: state => state.user.oprtId,
  token: state => state.user.token,
  serialNo: state => state.user.serialNo,
  timeStamp: state => state.user.timeStamp,
  operCardId: state => state.user.operCardId,
  mac: state => state.user.mac,
  netid: state => state.user.netid, // 网点id
  random: state => state.user.random,
  userName: state => state.user.userName, // 用户登录名
  permissions: state => state.permission.permissions, // 菜单权限
  elementPermissions: state => state.permission.elementPermissions, // 元素权限列表
  loading: state => state.permission.loading, // 按钮加载状态
  menuIds: state => state.user.menuIds,// 权限菜单
  netLevel: state => state.user.netLevel,// 网点级别
  position: state => state.user.position,// 操作员权限
  searchCarInfo: state => state.searchInfo.carInfo, // 主界面搜索结果 -- 车辆信息
  searchObuInfo: state => state.searchInfo.obuInfo, // 主界面搜索结果 -- obu信息
  searchCardInfo: state => state.searchInfo.cardInfo, // 主界面搜索结果 -- 卡片信息
  searchUserInfo: state => state.searchInfo.userInfo, // 主界面搜索结果 -- 用户信息
  searchAccountInfo: state => state.searchInfo.accountInfo, // 主界面搜索结果 -- 账户信息
  searchDepartmentInfo: state => state.searchInfo.departmentInfo, // 主界面搜索结果 -- 分支机构信息

  registerUser: state => state.indexedDb.registerUser, // 新办发行 -- 用户注册
  registerVehicle: state => state.indexedDb.registerVehicle, // 新办发行 -- 车辆注册
  transactorImg: state => state.indexedDb.transactorImg, // 新办发行 -- 经办人信息图片
  verifyLicenseImg: state => state.indexedDb.verifyLicenseImg, // 设备注销 -- 核验证件信息图片
  bankCardImg: state => state.indexedDb.bankCardImg, // 账户注销 -- 银行卡信息图片

  reportLossUserImg: state => state.idbReportLoss.userImg,// 卡片挂失-上传证件-用户证件
  reportLossAgentImg: state => state.idbReportLoss.agentImg,// 卡片挂失-上传证件-经办人证件
  reportLossOtherImg: state => state.idbReportLoss.otherImg,// 卡片挂失-上传证件-其他证件

  untiedHangUserImg: state => state.idbUntiedHang.userImg,// 卡片解挂-上传证件-用户证件
  untiedHangAgentImg: state => state.idbUntiedHang.agentImg,// 卡片解挂-上传证件-经办人证件
  untiedHangOtherImg: state => state.idbUntiedHang.otherImg,// 卡片解挂-上传证件-其他证件

  obuReportLossUserImg: state => state.idbObuReportLoss.userImg,// 标签挂失-上传证件-用户证件
  obuReportLossAgentImg: state => state.idbObuReportLoss.agentImg,// 标签挂失-上传证件-经办人证件
  obuReportLossOtherImg: state => state.idbObuReportLoss.otherImg,// 标签挂失-上传证件-其他证件

  obuUntiedHangUserImg: state => state.idbObuUntiedHang.userImg,// 标签解挂-上传证件-用户证件
  obuUntiedHangAgentImg: state => state.idbObuUntiedHang.agentImg,// 标签解挂-上传证件-经办人证件
  obuUntiedHangOtherImg: state => state.idbObuUntiedHang.otherImg,//  标签解挂-上传证件-其他证件 

  changeCardAgentImg: state => state.idbChangeCard.agentImg,// 换卡-上传证件-经办人证件
  changeCardOtherImg: state => state.idbChangeCard.otherImg,// 换卡-上传证件-其他证件

  changeObuAgentImg: state => state.idbChangeObu.agentImg,// 换签-上传证件-经办人证件
  changeObuOtherImg: state => state.idbChangeObu.otherImg,// 换签-上传证件-其他证件

  searchAgentImg: state => state.searchInfo.agentImg,// 搜索框-上传证件-经办人证件
  searchUserImg: state => state.searchInfo.userImg,// 搜索框-上传证件-用户证件
  searchOtherImg: state => state.searchInfo.otherImg,// 搜索框-上传证件-其他证件

  cardReplacementUserImg: state => state.idbCardReplacement.userImg,// 补卡-上传证件-用户证件
  cardReplacementAgentImg: state => state.idbCardReplacement.agentImg,// 补卡-上传证件-经办人证件
  cardReplacementOtherImg: state => state.idbCardReplacement.otherImg,// 补卡-上传证件-其他证件

  obuReplacementUserImg: state => state.idbObuReplacement.userImg,// 补签-上传证件-用户证件
  obuReplacementAgentImg: state => state.idbObuReplacement.agentImg,// 补签-上传证件-经办人证件
  obuReplacementOtherImg: state => state.idbObuReplacement.otherImg,// 补签-上传证件-其他证件
};
export default getters;
