import Vue from 'vue'
import Vuex from 'vuex'
import getters from './getters'
import user from './modules/user'
import permission from './modules/permission'
// import dictionary from './modules/dictionary'
import searchInfo from './modules/searchInfo'
import indexedDb from './modules/indexedDb'
import idbReportLoss from './modules/idbReportLoss'
import idbObuReportLoss from './modules/idbObuReportLoss'
import idbUntiedHang from './modules/idbUntiedHang'
import idbObuUntiedHang from './modules/idbObuUntiedHang'
import idbChangeCard from './modules/idbChangeCard'
import idbChangeObu from './modules/idbChangeObu'
import btnState from './modules/btnState'
import idbCardReplacement from './modules/idbCardReplacement'
import idbObuReplacement from './modules/idbObuReplacement'

Vue.use(Vuex)

export default new Vuex.Store({
  modules: {
    user,
    permission,
    // dictionary,
    searchInfo,
    btnState,
    indexedDb,
    idbChangeCard,
    idbChangeObu,
    idbReportLoss,
    idbUntiedHang,
    idbObuReportLoss,
    idbObuUntiedHang,
    idbCardReplacement,
    idbObuReplacement,
  },
  getters
})
