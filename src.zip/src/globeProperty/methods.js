/**
 * @description 全局方法
*/
import Vue from 'vue'
import ElementUI from 'element-ui'
import { writeLog } from '@/utils/dynamic' // 写本地文件
export default {
    install() {
        Vue.prototype.$loading = function (txt, background, customClass) {//全局loading 
            console.log('LoadingLoadingLoadingLoadingLoading')
            return ElementUI.Loading.service({
                lock: true,
                text: txt || 'Loading',
                spinner: 'el-icon-loading',
                background: background || 'rgba(0, 0, 0, 0.7)',
                customClass,
            })
        }
        Vue.prototype.$writeLog = writeLog // 写本地文件
    }
}