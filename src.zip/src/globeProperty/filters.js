/**
 * @description 注册全局过滤器
*/
import Vue from 'vue'
import { dicKeys, getDicDesByCode } from '@/methods/dics'

/**
 * @description 用户类型
*/
Vue.filter('userTypeDes', async (value) => {
  if (!value) return value
  return await getDicDesByCode(dicKeys.userType, value)
})
