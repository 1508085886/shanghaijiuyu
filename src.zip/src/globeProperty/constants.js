/**
 * @description 全局常量
*/
import Vue from 'vue'
export default {
    install() {
        Vue.prototype.$printIdBefore = '3101';
        Vue.prototype.$padUserAgent = 'Android-Pad';
        Vue.prototype.$isPad = (navigator.userAgent === Vue.prototype.$padUserAgent);
    }
}