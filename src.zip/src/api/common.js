/**
 * @description 公共接口
 */
import request from '@/utils/request';



//黑名单
export const statusQuery = ({ cardId, obuId, etcUserId }) => {
  return request({
    url: '/statusQuery',
    method: 'post',
    data: {
      cardId,
      obuId,
      etcUserId,
    },
  });
};
/**
 * @description 查询字典接口
 * @param { String } fieldCode 查询的字典类型
 * @param { String } fieldName 类型名称
 */
export const requestDictionary = (fieldCode, fieldName = '') => {
  return request({
    // url: '/common/dataDictionary',
    url: '/dataDictionary',
    method: 'POST',
    data: {
      fieldCode,
      fieldName,
    },
  });
};

/**
 * @description 文件上传
 * @param { file | Array } files
 */
export const uploadFile = files => {
  const formData = new FormData();
  if (files instanceof Array) {
    for (let i = 0; i < files.length; i++) {
      formData.append('file', files[i]);
    }
  } else {
    formData.append('file', files);
  }
  let config = {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  };
  return request.post('/upload', formData, config);
};

/**
 * @description base64文件上传
 * @param { String } mediaType 文件类型
 * @param { String } fileType 文件格式
 * @param { String } imageInfo base64格式文件
 * @returns { String } innerImgid 多媒体内部id
 * @returns { String } ownerImgid 多媒体外部id
 */
export const uploadBase64 = ({ mediaType, fileType, imageInfo }) => {
  return request({
    url: '/upload',
    method: 'post',
    data: {
      mediaType,
      fileType,
      imageInfo,
    },
  });
};

/**
 * @description 创建工单   //新办发行专用
 * @param { String } bizCode 业务类型
 */
// export const createOrder = ({ bizCode }) => {
//   return request({
//     url: '/createOrder',
//     method: 'post',
//     data: {
//       bizCode,
//     },
//   });
// };
export const createOrder = data => {
  return request({
    url: '/createOrder',
    method: 'post',
    data,
  });
};
/**
 * @description 网点列表查询
 */
export const getNetInfoList = data => {
  return request({
    url: '/getNetInfoList',
    method: 'post',
    data,
  });
};
/**
 * @description 操作员列表查询
 */
export const getOprtInfoList = data => {
  return request({
    url: '/getOprtInfoList',
    method: 'post',
    data,
  });
};
/**
 * @description 修改工单
 * @param { String } workOrderID 工单号
 * @param { modifyInfo } status 修改内容
 */
export const updateWorkOrder = data => {
  return request({
    url: '/updateWorkOrder',
    method: 'post',
    data,
  });
  // throw 500;
};

/**
 * @description 图片上传
 * @param { String } img 图片
 * @param { String } fileType 文件格式
 */
export const mediaUpload = ({ fileType, img }) => {
  return request({
    url: '/imgUpload',
    method: 'post',
    data: {
      fileType,
      img,
    },
  });
};

/**
 * @description 系统参数查询
*/
export const systemParameterQuery = data => {
  return request({
    url: '/systemParameterQuery',
    method: 'POST',
    data
  })
}
/**
 * @description 查看系统时间
*/
export const systemTime = data => {
  return request({
    url: '/systemTime',
    method: 'POST',
    data
  })
}


/**
 * @description 4.9.	分支机构查询
 */



export const branchQuery = ({ etcUserId,
  departmentName,
  pageNo,
  pageSize }) => {
  return request({
    // url: '/common/dataDictionary',
    url: '/branchQuery',
    method: 'POST',
    data: {
      etcUserId,
      departmentName,
      pageNo,
      pageSize,
    },
  });
};
// 白名单
export const queryWhiteList
  = ({ vehiclelicencePlatenumber,
    vehicleColor,
    pageNo,
    pageSize }) => {
    return request({
      url: '/queryWhiteList',
      method: 'POST',
      data: {
        vehiclelicencePlatenumber,
        vehicleColor,
        pageNo,
        pageSize,
      },
    });
  };
//安装码
export const queryInstallCode = ({ etcUserId
}) => {
  return request({
    url: '/queryInstallCode',
    method: 'POST',
    data: {
      etcUserId,
    },
  });
};
//读取OBU中DFEF01文件内容
export const getdfef01info = ({ regAPPId, token, strRandom, strOprtId
}) => {
  return request({
    data: {
      regAPPId, token, strRandom, strOprtId
    },
  });
};

/**
 * @description 12.18.	开票申请
 * @param {*} param0
 * @returns
 */
export const addBranch = ({ etcUserId }) => {
  return request({
    url: '/addBranch',
    method: 'POST',
    data: {
      etcUserId,
    },
  });
};


export const getVersionInfo = () => {
  return request({
    url: '/queryNewVersionInfo',
    method: 'post'
  })
}

/**
 * @description 14.11.	启用工单
 * @param {*} param0 
 * @returns 
 */
export const startTblWork = (data) => {
  return request({
    url: '/startTblWork',
    method: 'POST',
    data
  });
};
/**
 * @description 12.13.	创建工单 售后发行专用
 * @param {*} param0 
 * @returns 
 */
export const createOrderv = (data) => {
  return request({
    url: '/v1/createOrder',
    method: 'POST',
    data
  });
};
/**
 * @description 3.16.2	操作员修改密码
 * @param {*} param0 
 * @returns 
 */
export const updateOptPwd = ({ oprtId, oprtPasswd
}) => {
  return request({
    url: '/updateOptPwd',
    method: 'POST',
    data: {
      oprtId, oprtPasswd
    },
  });
};
/**
 * @description 3.15上传日志文件查询
 * @param {*} param0 
 * @returns 
 */
export const uploadFileQuery = ({ oprtId, netId
}) => {
  return request({
    url: '/uploadFileQuery',
    method: 'POST',
    data: {
      oprtId, netId
    },
  });
};
/**
 * @description 3.14上传日志文件
 * @param {*} param0 
 * @returns 
 */
export const uploadFile314 = ({ id, fileName, fileContent
}) => {
  return request({
    url: '/uploadFile',
    method: 'POST',
    data: {
      id, fileName, fileContent
    },
  });
};