import request from '@/utils/request'

/**
 * @description ocr识别
*/
export const ocrRequest = ({
  url,
  imgType,
  fileType,
  img
}) => {
  return request({
    url,
    method: 'post',
    data: {
      imgType, fileType, img
    }
  })
}

/**
 * @description 12.4.	身份证件OCR识别
    图片类型	imgType String
    文件格式	fileType String 
    图片	img String

*/
export const idOrcIdentify = ({ imgType, fileType, img }) => {
  return request({
    url: '/idOrcIdentify',
    method: 'post',
    data: {
      imgType, fileType, img
    }
  })
}

/**
 * @description 12.2.	车辆行驶证印章页OCR识别
    图片类型	imgType String
    文件格式	fileType String 
    图片	img String

*/
export const vehicleLicenseSealAutomaticIdentificate = ({ imgType, fileType, img }) => {
  return request({
    url: '/vehicleLicenseSealAutomaticIdentificate',
    method: 'post',
    data: {
      imgType, fileType, img
    }
  })
}

/**
 * @description 12.3.	身份证件OCR识别
    图片类型	imgType String
    文件格式	fileType String 
    图片	img String

*/
export const vehicleLicenseAutomaticIdentificate = ({ imgType, fileType, img }) => {
  return request({
    url: '/vehicleLicenseAutomaticIdentificate',
    method: 'post',
    data: {
      imgType, fileType, img
    }
  })
}

/**
 * 车辆登记证 OCR
 * @param {*} param0 
 * @returns 
 */
export const motorVehicleRegisterOrcIdentify = ({ imgType, fileType, img }) => {
  return request({
    url: '/motorVehicleRegisterOrcIdentify',
    method: 'post',
    data: {
      imgType, fileType, img
    }
  })
}