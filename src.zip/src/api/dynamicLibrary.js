/**
 * @description 动态库模块接口
 */
import request from '@/utils/request';
import store from '@/store'

/**
 * @description 读操作员卡号
*/
export const getCardCode = () => {
  // return 'abc2323'
  const rs = JSON.parse(etcdev.getopercardid());
  if (rs.oprtid) {
    return rs.oprtid;
  }
  alert(rs.msg);
  return null;
  // return JSON.parse(etcdev.getopercardid()).oprtid;
}

/**
 * @description 读取操作员mac
*/
export const getCardMac = () => {
  // return 'abc2323'
  // alert(store.getters.random);
  // alert(etcdev.getopercardmac(store.getters.random));
  return JSON.parse(etcdev.getopercardmac(store.getters.random)).mac;
  // return etcdev.getopercardmac(store.getters.random).mac
}

/**
 * @description 读取卡信息，弃用，详见src\utils\dynamic.js
*/
export const getCpuInfo = () => {
  return {
    code: '0',
    msg: '成功',
    cardid: '0000D3E1D3CED8A90000000000000000000000000000333130313038313938363031313732383539000000000000000000000000000000',
    issueversion: '10'
  }
  return etcdev.getcpuid()
}

/**
 * @description 读取obu信息，弃用，详见src\utils\dynamic.js
*/
export const getObuInfo = () => {
  return {
    code: '0',
    msg: '成功',
    obuid: '0000D3E1D3CED8A90000000000000000000000000000333130313038313938363031313732383539000000000000000000000000000000',
    issueversion: '10'
  }
  return etcdev.getobuid()
}

/**
 * @description 卡二发，弃用，详见src\utils\dynamic.js
*/
export const issueCard = ({
  strCardID, // 卡号
  IssueVersion, // 版本号
  str0016, // 16为写入字符串
  i0016start, // 16位写入起始位
  i0016Length, // 16位写入长度
  str0015, // 15位写入长度
  i0015start, // 15位写入起始位
  i0015Length, // 15位写入长度
  regAPPId = "network_customer_system", // 渠道商编码
  // token = store.getters.token, // 令牌
  // strRandom = store.getters.random, // 操作员随机数
  token = store.getters.token, // 令牌
  strRandom = store.getters.random, // 操作员随机数
}) => {
  // return {
  //   code: '0',
  //   msg: '成功'
  // }
  return etcdev.issuecard(strCardID, IssueVersion, str0016, i0016start, i0016Length, str0015, i0015start, i0015Length, regAPPId, token, strRandom)
}

/**
 * @description obu二发，弃用，详见src\utils\dynamic.js
*/
export const issueObu = ({
  strOBUID, // 卡号
  strMFEF01, // MFEF01写入字符串
  iMFEF0start, // MFEF01写入起始位置
  iMFEF0Length, // MFEF01写入长度
  strDFEF01, // DFEF01写入字符串
  iDFEF01start, // DFEF01写入起始位置
  iDFEF01Length, // DFEF01写入长度
  strIssueVersion, // 卡版本号
  regAPPId = "network_customer_system", // 渠道商编码
  token = store.getters.token, // 令牌
  strRandom = store.getters.random, // 操作员随机数
}) => {
  return {
    code: '0',
    msg: '成功'
  }
  return etcdev.issueobu(strOBUID, strMFEF01, iMFEF0start, iMFEF0Length, strDFEF01, iDFEF01start, iDFEF01Length, strIssueVersion, regAPPId, token, strRandom)
}
