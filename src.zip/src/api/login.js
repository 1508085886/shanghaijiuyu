/**
 * @description 用户状态模块
*/
import store from '@/store'
import request from '@/utils/request'
import { getOperCardId, getRandom, getMac } from '@/methods/account'

/**
 * @description 登录接口
 * @param { string } admin 用户名
 * @param { string } password 密码
*/
export const login = async ({ admin, password }) => {

  // const operCardId = await getOperCardId()
  // if (!operCardId) {
  //   return
  // }
  const operCardId = 'wjq'
  const random = await getRandom()
  // const mac = await getMac()
  const mac = '12345'

  return request({
    url: '/login',
    method: 'post',
    data: {
      admin,
      password: password,
      operCardId,
      mac,
      random
    }
  })
}

/**
 * @description 获取操作员随机数接口
*/
export const requestRandom = async () => {
  const operCardID = await getOperCardId()
  // const operCardID = 'wjq'
  return request({
    url: '/getRandom',
    method: 'post',
    data: {
      operCardID
    }
  })
}

/**
 * @description 登出接口
*/
export const logout = async () => {
  const admin = store.getters.userName
  if (!admin) {
    return;
  }
  return request({
    url: '/logout',
    method: 'POST',
    data: {
      admin
    }
  })
}


/**
 * @description 3.11.	获取程序下载地址
*/
export const getProgramDownloadUrl = async () => {
  return request({
    url: '/getProgramDownloadUrl',
    method: 'POST',
    data: {
    }
  })
}