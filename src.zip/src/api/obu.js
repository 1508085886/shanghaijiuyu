/**
 * @description obu相关接口
 */

/**
 * @description 卡片发行
 */
export const cardIssue = () => {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve('status:true');
    }, 2000);
  });
};
/**
 * @description 标签发行
 */
export const tagIssue = () => {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve('status:true');
    }, 2000);
  });
};
