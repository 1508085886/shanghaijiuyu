/**
 * @description 车主相关接口
 */
import request from '@/utils/request';

/**
 * @description 根据证件信息查询车主信息
 * @param { String } etcUserId 车主注册id
 * @param { String } userCertType 证件类型
 * @param { String } userCode 证件号码
 */
export const loadInfoByCard = ({ userCertType, userCode, etcUserId }) => {
  return request({
    url: '/userQuery',
    method: 'post',
    data: {
      userCertType,
      userCode,
      etcUserId,
    },
  });
};

/**
 * @description 根据证件信息查询用户信息
 * @param { String } userCertType 证件类型
 * @param { String } userCode 证件号码
 * @param { String } userName 用户名称
 */
export const userCheck = ({ userCertType, userCode, userName }) => {
  return request({
    url: '/userCheck',
    method: 'post',
    headers: {
      noMsg: JSON.stringify(['0006']),
    },
    data: {
      userCertType,
      userCode,
      userName,
    },
  });
};

/**
 * @description ETC账户查询
 * @param { String } cardId 用户卡编号
 * @param { String } obuId OBU合同序列号
 * @param { String } userAccountId  账户编号
 * @param { String } vehicleNumber  车牌号码
 * @param { String } vehicleColor  车牌颜色
 */
export const etcAccountQuery = ({ etcUserId }) => {
  return request({
    url: '/queryEtcAcct',
    method: 'post',
    data: {
      etcUserId
    }
  });
};
/**
 * @description 6.1 ETC账户查询
 */
export const queryEtcAcct = (data) => {
  return request({
    url: '/queryEtcAcct',
    method: 'post',
    data,
  });
};

/**
 * @description 账户列表
 */
export const queryUserAccountList = (data) => {
  return request({
    url: '/queryUserAccountList',
    method: 'post',
    data,
  });
};

/**
 * @description 用户实名
 */
export const userNameConfiger = ({ etcUserId, workOrderID, imageList }) => {
  return request({
    url: '/userNameConfiger',
    method: 'post',
    data: {
      etcUserId,
      workOrderID,
      imageList,
    },
  });
};
//系统时间
export const systemTime = ({ }) => {
  return request({
    url: '/systemTime',
    method: 'post',
    data: {

    },
  });
};
/**
 * @description 6.9s.	账户交易明细查询
 */
export const useracctlistQuery = ({ useracctId, etcUserId, queryDateType, startDate, endDate, startRecords, rowNumber }) => {
  return request({
    url: '/useracctlistQuery',
    method: 'post',
    data: {
      useracctId, etcUserId, queryDateType, startDate, endDate, startRecords, rowNumber
    },
  });
};