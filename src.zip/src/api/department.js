/**
 * @description 公共接口
*/
import request from '@/utils/request'

/**
 * @description 6.5.	账户列表
 * @param { String } etcUserId ETC用户ID
*/

export function dataDictionary(etcUserId) {
  const data = {
    etcUserId
  }
  return request({
    url: '/queryUserAccountList',
    method: 'post',
    data: data
  })
}
