/**
 * @description 挂账还款相关接口
 */
import request from '@/utils/request';

/**
 * @description 10.13.	查询挂账明细
 */
export const queryCreditRepaymentList = ({ workOrderId, etcUserId, userAcctid, payStatus, startRecords, rowNumber
}) => {
    return request({
        url: '/queryCreditRepaymentList',
        method: 'POST',
        data: {
            workOrderId, etcUserId, userAcctid, payStatus, startRecords, rowNumber
        },
    });
};


/**
 * @description 10.14.	挂账还款申请
 */
export const creditRepayment = ({ workOrderId, etcUserId, cardId, userAcctId, txAmount, payMode, describe
}) => {
    return request({
        url: '/creditRepayment',
        method: 'POST',
        data: {
            workOrderId, etcUserId, cardId, userAcctId, txAmount, payMode, describe
        },
    });
};

/**
 * @description 10.15.	挂账还款回执查询
 */
export const queryCreditRepayment = ({ workOrderId, etcUserId
}) => {
    return request({
        url: '/queryCreditRepayment',
        method: 'POST',
        data: {
            workOrderId, etcUserId
        },
    });
};

/**
 * @description 10.28.挂账记录查询接口
 */
export const creditRepaymentQuery = ({ workOrderId, etcUserId, useracctId, workOrderStatus, oprtId, netId, startDate, expireDate
}) => {
    return request({
        url: '/creditRepaymentQuery',
        method: 'POST',
        data: {
            workOrderId, etcUserId, useracctId, workOrderStatus, oprtId, netId, startDate, expireDate
        },
    });
};