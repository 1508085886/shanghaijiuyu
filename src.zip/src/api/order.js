/**
 * @description 订单相关接口
*/
import request from '@/utils/request'

/**
 * @description 新办订单申请
*/
export const deviceOrder = data => {
  return request({
    url: '/order/deviceOrder',
    method: 'POST',
    data
  })
}

/**
 * @description 订单查询
*/
export const orderQuery = data => {
  return request({
    url: '/orderQuery',
    method: 'POST',
    data
  })
}
/**
 * @description 订单查询2，只返回工单状态
*/
export const tblStatusQuery = data => {
  return request({
    url: '/tblStatusQuery',
    method: 'POST',
    data
  })
}
/**
 * @description 工单图片下载
*/
export const orderImg = data => {
  return request({
    url: '/orderImg',
    method: 'POST',
    data,
  })
}
/**
 * @description 取消订单
*/
export const cancelWorkOrder = data => {
  return request({
    url: '/cancelWorkOrder',
    method: 'POST',
    data
  })
}
/**
 * @description 换卡查询
*/
export const queryChangeCard = (data) => {
  return request({
    url: '/queryChangeCard',
    method: 'POST',
    data
  })
}
/**
 * @description 换签查询
*/
export const queryChangeObu = (data) => {
  return request({
    url: '/queryChangeObu',
    method: 'POST',
    data
  })
}
