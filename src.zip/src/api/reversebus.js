/**
 * @description 冲正
 */
import request from '@/utils/request';

/**
 * @description 10.23.	可冲正记录查询
 */
export const queryLists = data => {
    return request({
        url: '/queryLists',
        method: 'POST',
        data: data,
    });
};

/**
 * @description 10.24.	冲正扣款校验
 */
export const reverseCPCheck = data => {
    return request({
        url: '/reverseCPCheck',
        method: 'POST',
        data: data,
    });
};

/**
 * @description 10.6.	储值卡圈提申请
 */
export const cardUnLoad = data => {
    return request({
        url: '/cardUnLoad',
        method: 'POST',
        data: data,
    });
};

/**
 * @description 10.7.	储值卡圈提确认
 */
export const cardCircleConfirm = data => {
    return request({
        url: '/cardCircleConfirm',
        method: 'POST',
        data: data,
    });
};

/**
 * @description 10.20.	账户冲正申请
 */
export const accountReversal = data => {
    return request({
        url: '/accountReversal',
        method: 'POST',
        data: data,
    });
};

/**
 * @description 10.16.  圈存账户冲正申请
 */
export const acctCircleRectification = data => {
    return request({
        url: '/acctCircleRectification',
        method: 'POST',
        data: data,
    });
};

/**
 * @description 10.26.  冲正预申请
 */
export const preReversal = data => {
    return request({
        url: '/preReversal',
        method: 'POST',
        data: data,
    });
};

/**
 * @description 10.27.  冲正记录查询
 */
export const reverseRecordQuery = data => {
    return request({
        url: '/reverseRecordQuery',
        method: 'POST',
        data: data,
    });
};

/**
 * @description 10.22.圈存账户冲正业务回执查询
 */
export const reverseReceiptQuery = data => {
    return request({
        url: '/reverseReceiptQuery',
        method: 'POST',
        data: data,
    });
};