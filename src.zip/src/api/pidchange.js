import request from '@/utils/request'

// 
export function query(etcUserId) {
  const data = {
    etcUserId
  }
  return request({
    url: '/userQuery',
    method: 'post',
    data: data
  })
}

// 
export function getifcode(etcUserId, userProperty, userAccountId, department, mobile, openId, accountId) {
  const data = {
    etcUserId,
    userProperty,
    userAccountId,
    department,
    mobile,
    openId,
    accountId
  }
  return request({
    url: '/basicInformationChangeSmsCodeSend',
    method: 'post',
    data: data
  })
}

// 
export function usernamechange(etcUserId, userProperty, userAccountId, userName, phoneNum, code, userId) {
  const data = {
    etcUserId,
    userProperty,
    userAccountId,
    userName,
    phoneNum,
    code,
    userId
  }
  return request({
    url: '/etcUserNameChange',
    method: 'post',
    data: data
  })
}

export function getuserlist(etcUserId) {
  const data = {
    etcUserId
  }
  return request({
    url: '/queryUserAccountList',
    method: 'post',
    data: data
  })
}

export function companynamechange(etcUserId, department, userProperty, userId, userAccountId, userName, phoneNum, code, openId, accountId) {
  const data = {
    department,
    etcUserId,
    userProperty,
    userId,
    userAccountId,
    userName,
    phoneNum,
    code,
    openId,
    accountId
  }
  return request({
    url: '/etcUserNameChange',
    method: 'post',
    data: data
  })
}

