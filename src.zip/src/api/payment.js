/**
 *  支付修改
 */

import request from "../utils/request"

/**
 * 
 * @param {*} param0 
 * @returns 
 *  ETC用户ID	etcUserId	String	64	是	
    工单号	workOrderID	string	10	是	
    支付方式	payMode	String	1	是	参考附录表十二
    支付渠道id	payChannelId	String	32	否	
    受理机构id	subPayChannelId
    String	32	否	

 */
export const changePayment = data => {
    return request({
        url: "/changePayType",
        method: 'post',
        data: data
    })
}