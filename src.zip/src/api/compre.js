/**
 * @description 综合查询
*/
import request from '@/utils/request'

/**
 * @description 综合查询接口
 * @param { code } userCertType 用户证件类型
 * @param { number | string } userCode 用户证件号码
 * @param { string } vehicleNumber 车牌号码
 * @param { code } vehicleColor 车牌颜色
 * @param { string } cardId ETC卡号
*/
export const requestCompre = (data) => {
  return request({
    url: '/multipleQuery',
    method: 'post',
    data
  })
}
