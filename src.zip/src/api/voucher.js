/**
 * @description 业务凭证相关接口
 */
import request from '@/utils/request';

/**
 * @description 业务凭证上传
 */
export const bizVoucherUpload = (data) => {
  return request({
    url: '/bizVoucherUpload',
    method: 'post',
    data,
  });
};