/**
 * @description 车辆相关接口
 */
import request from '@/utils/request';

/**
 * @description 车辆用户类型查询接口
 * @param { String } vehicleType 车辆类型
 * @param { String } vehicleNumber 车牌号码
 * @param { String } vehicleColor 车牌颜色
 */
export const getVehicleUserType = ({
  vehicleType,
  vehicleNumber,
  vehicleColor,
  permittedTowWeight,
}) => {
  return request({
    url: '/vehicle/getVehicleUserType',
    method: 'post',
    data: {
      vehicleType,
      vehicleNumber,
      vehicleColor,
      permittedTowWeight,
    },
  });
};

/**
 * @description 收费车型查询
 * @param { String } vehicleType 车辆类型
 * @param { String } approvedAccount 核定载人数
 * @param { String } viLength 车长
 * @param { String } axleCount 车轴数
 * @param { String } viTotalMass 总质量
 */
export const getVehicleType = ({
  //vehicleType,
  vehicleCategory,
  approvedAccount,
  viLength,
  axleCount,
  viTotalMass,
}) => {
  return request({
    url: '/vehicle/getVehicleType',
    method: 'post',
    data: {
      // vehicleType,
      vehicleCategory,
      approvedAccount,
      viLength,
      axleCount,
      viTotalMass,
    },
  });
};

/**
 * @description 车主信息补采集
 * @param { String } ownerType 车主姓名
 * @param { String } ownerName 车主证件类型
 * @param { String } ownerCertType 车主证件号码
 * @param { String } ownerphoneNum 车主联系方式
 * @param { String } ownerAddress 车主联系地址
 * @param { Object } ownerImageList 车主证件图片
 */
export const vehicleOwnerInfo = ({
  ownerType,
  ownerName,
  ownerCertType,
  ownerCode,
  ownerphoneNum,
  ownerAddress,
  ownerImageList,
}) => {
  return request({
    url: '/vehicle/vehicleOwnerInfo',
    method: 'post',
    data: {
      ownerType,
      ownerName,
      ownerCertType,
      ownerCode,
      ownerphoneNum,
      ownerAddress,
      ownerImageList,
    },
  });
};

/**
 * @description 车辆注册接口
 */
export const registerVehicle = data => {
  return request({
    url: '/vehicle/registerVehicle',
    method: 'post',
    data,
  });
};
/**
 * @description 车辆信息查询
 * @param { String } userCertType 用户证件类型
 * @param { String } userCode 用户证件号码
 * @param { String } vehicleNumber 车牌号码
 * @param { String } vehicleColor 车牌颜色
 * @param { String } cardID ETC卡号
 * @param { String } obuID OBU号
 */
export const getVehicleList = ({
  userCertType,
  userCode,
  vehicleNumber,
  vehicleColor,
  cardID,
  obuID,
}) => {
  return request({
    url: '/vehicle/vehicleList',
    method: 'post',
    data: {
      userCertType,
      userCode,
      vehicleNumber,
      vehicleColor,
      cardID,
      obuID,
    },
  });
};

/**
 * @description 脱绑
 * 
 */
export const vehicleTakeOff = ({ etcUserId, vehicleID, vehicleNumber, vehicleColor, bizCode, imageList }) => {
  return request({
    url: '/vehicle/vehicleTakeOff',
    method: 'post',
    data: {
      etcUserId, vehicleID, vehicleNumber, vehicleColor, bizCode, imageList
    },
  });
};

/**
 * @description 支付渠道绑定
 *  ETC用户ID	etcUserId
    车辆编号	vehicleId
    支付渠道	payChannelId
    受理机构id	subPayChannelId
    用户类型	userType
 */
export const bindVehicle = ({ workOrderID, etcUserId, vehicleId, payChannel, subPayChannelId, userType, vehicleNumber, vehicleColor, discountType }) => {
  return request({
    url: '/vehicle/bindVehicle',
    method: 'post',
    data: {
      workOrderID, etcUserId, vehicleId, payChannel, subPayChannelId, userType, vehicleNumber, vehicleColor, discountType
    },
  });
};

/**
 * @description 根据行驶证车辆类型，查询车种
*/
export const getVehicleClassByVehicleType = vehicleType => {
  return request({
    url: '/vehicleCategoryQuery',
    method: 'post',
    data: {
      vehicleType
    },
  });
}
/**
 * @description 根据行驶证车辆类型，查询车种
*/
export const getVehicleClassByVehicleType2 = data => {
  return request({
    url: '/vehicleCategoryQuery',
    method: 'post',
    data,
  });
}

/**
 * @description 车辆发行资格验证
*/
export const queryVehicleQualification = data => {
  return request({
    url: '/queryVehicleQualification',
    method: 'post',
    data,
  });
}

/**
 * 
 * @param {*} data 
 * @returns 
 */
export const calculateChangeVehInfo = data => {
  return request({
    url: '/calculateChangeVehInfo',
    method: 'post',
    data,
  });
}

/**
 * 变更车型
 * @param {*} data 
 * @returns 
 */
export const changeVehicle = data => {
  return request({
    url: '/vehicle/changeVehicle',
    method: 'post',
    data,
  });
}


/**
 * 设备重置 申请
 * @param {*} data 
 * @returns 
 * 
 */
export const devReset = data => {
  return request({
    url: '/devReset',
    method: 'post',
    data,
  });
}

/**
 * 设备重置 确认
 * @param {*} data 
 * @returns 
 */
export const devResetConfirm = data => {
  return request({
    url: '/devResetConfirm',
    method: 'post',
    data,
  });
}



/**
 * 变更车型回执查询
 * @param {*} data 
 * @returns 
 */
export const queryReceiptChangeVehInfo = data => {
  return request({
    url: '/queryReceiptChangeVehInfo',
    method: 'post',
    data,
  });
}



/**
 * 变更车型工单的状态查询
 * @param {*} data 
 * @returns 
 */
export const queryChangeVehInfo = data => {
  return request({
    url: '/queryChangeVehInfo',
    method: 'post',
    data,
  });
}


/**
 * 变更车型工单的状态查询
 * @param {*} data 
 * @returns 
 */

export const vehicleVerification = ({ etcUserId, vehicleNumber, vehicleColor, payChanne, subPayChannelId
}) => {
  return request({
    url: '/vehicleVerification',
    method: 'POST',
    data: {
      etcUserId, vehicleNumber, vehicleColor, payChanne, subPayChannelId
    },
  });
};

