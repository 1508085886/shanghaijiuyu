/**
 * @description 新办发行模块接口
 */
import request from '@/utils/request';

/**
 * @description 用户注册
 */
export const userRegister = data => {
  return request({
    //url: '/user/register',
    url: '/userRegister',
    method: 'post',
    data,
  });
};

/**
 * @description 签约渠道列表查询
 */
export const getChannelList = (userType) => {
  return request({
    url: '/user/channelList',
    method: 'post',
    data: {
      userType
    }

  });
};

/**
 * @description 签约申请
 * @param { String } etcUserId ETC用户ID
 * @param { String } payChannelId 支付渠道ID
 * @param { String } subPayChannelId 受理机构ID
 */
export const applySign = (data) => {
  return request({
    url: '/user/signSerialNo',
    method: 'post',
    data,
  });
};
// export const applySign = ({ etcUserId, payChannelId, subPayChannelId, vehicleNumber,
//   vehicleColor, workOrderId }) => {
//   return request({
//     url: '/user/signSerialNo',
//     method: 'post',
//     data: {
//       etcUserId,
//       payChannelId,
//       subPayChannelId,
//       vehicleNumber,
//       vehicleColor,
//       workOrderId,
//     },
//   });
// };

/**
 * @description 3.7.查询待发行信息
 * @param { String } etcUserId ETC用户ID
 */
export const queryPendingInfo = ({ etcUserId }) => {
  return request({
    url: '/queryPendingInfo',
    method: 'post',
    data: {
      etcUserId,
    },
  });
};

/**
 * @description 8.1 发行申请
 * @param { String } etcUserId ETC用户ID
 * @param { list } orderList ETC用户ID订单信息
 */
export const deviceOrder = ({ etcUserId, orderList }) => {
  return request({
    url: '/order/deviceOrder',
    method: 'post',
    data: {
      etcUserId,
      orderList
    },
  });
};



/**
 * @description 8.9 查询待发行信息
 * @param { String } etcUserId ETC用户ID
 * @param { list } chargeOrderList ETC用户ID订单信息
 */
export const orderCharge = ({ etcUserId, chargeOrderList }) => {
  return request({
    url: '/orderCharges',
    method: 'post',
    data: {
      etcUserId,
      chargeOrderList
    },
  });
};

/**
 * @description 8.10.	发行订单取消
 * @param { String } etcUserId ETC用户ID
 * @param { String } vehicleNumber 车牌号码
 * @param { String } vehicleColor 车牌颜色
 */
export const issueOrderCancel = ({ etcUserId, vehicleNumber, vehicleColor }) => {
  return request({
    url: '/issueOrderCancel',
    method: 'post',
    data: {
      etcUserId, vehicleNumber, vehicleColor
    },
  });
};




/**
 * @description 8.8.	订单价格预算
 * @param ETC用户ID	etcUserId
 *@param 车牌号码	vehicleNumber
 *@param 车牌颜色	vehicleColor
 *@param 订单类型	orderType
 *@param 售后类型	applyType
 *@param 是否人为损坏	isDamage
 *@param 优惠活动	giver
 *@param 是否特许免费	isFree
 *@param 卡号	cardId
 *@paramOBU 编号	obuId
 * 
 */
export const priceReckon = ({ etcUserId,
  vehicleNumber, vehicleColor, orderType, applyType, isDamage, giver, isFree, cardId, obuId
}) => {
  return request({
    url: '/priceReckon',
    method: 'post',
    data: {
      etcUserId, vehicleNumber, vehicleColor, orderType, applyType, isDamage, giver, isFree, cardId, obuId
    },
  });
};



/**
 * @description 4.9分支机构查询
 * @param ETC用户ID	etcUserId
 *@param 默认标识	defaultFlag
 *@param 分支机构名称	departmentName
 * 
 */
export const branchQuery = ({ etcUserId,
  defaultFlag, departmentName
}) => {
  return request({
    url: '/branchQuery',
    method: 'post',
    data: {
      etcUserId,
      defaultFlag, departmentName
    },
  });
};

/**
 * @description 创建工单
*/
export const createWorkOrder = (bizCode) => {
  return request({
    url: '/createOrder',
    method: 'post',
    data: {
      bizCode
    },
  })
}


/**
 * @description 5.10.	车辆模板查询
*/
export const vehicleModelQuery = ({ vehicleCategory, vehicleClass }) => {
  return request({
    url: '/vehicleModel',
    method: 'post',
    data: {
      vehicleCategory,
      vehicleClass

    },
  })
}


/**
 * @description 5.9.	批量查询车辆发行信息
*/
export const vehicleBatchQuery = ({ etcUserId, vehicleList }) => {
  return request({
    url: '/vehicleBatchQuery',
    method: 'post',
    data: {
      etcUserId, vehicleList
    },
  })
}