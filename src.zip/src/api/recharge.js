/**
 * @description 充值相关接口
 */
import request from '@/utils/request';

/**
 * @description 10.9.	充值记录查询
 */
export const queryPayList = data => {
  return request({
    url: '/queryPayList',
    method: 'post',
    data,
  });
};
/**
 * @description 10.8.	圈存账户充值申请
 */
export const acctCircleRecharge = data => {
  return request({
    url: '/acctCircleRecharge',
    method: 'post',
    data,
  });
};
/**
 * @description 10.5.	卡片圈存确认
 */
export const cardCircleRechargeConfirm = data => {
  return request({
    url: '/cardCircleRechargeConfirm',
    method: 'post',
    data,
  });
};
/**
 * @description 10.12.	验卡接口
 */
export const checkCardServe = data => {
  return request({
    url: '/checkCardServe',
    method: 'post',
    data,
  });
};
/**
 * @description 10.17.	账户充值申请
 */
export const accountRechargeApply = data => {
  return request({
    url: '/accountRechargeApply',
    method: 'post',
    data,
  });
};

