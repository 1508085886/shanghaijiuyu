/**
 * @description 发行模块
*/
import request from '@/utils/request'
/**
 * @description 设备空发
*/
export const devicePublish = ({
  etcUserId,
  msgType,
  orderType, // 订单类型
  vehicleNumber, // 车牌号
  vehicleColor,
  obuId,
  obuSign = "2",
  obuVerNo,
  cardId,
  cardVerNo,
  workOrderID,
}) => {
  // return new Promise((resolve) => {
  //   resolve({
  //     fileContent15: {
  //       fileContent: '0000D3E1D3CED8A90000000000000000000000000000333130313038313938363031313732383539000000000000000000000000000000',
  //       startIndex: '0',
  //       length: '55',
  //       verNo: '10'
  //     },
  //     fileContent16: {
  //       fileContent: '0000D3E1D3CED8A90000000000000000000000000000333130313038313938363031313732383539000000000000000000000000000000',
  //       startIndex: '0',
  //       length: '55',
  //       verNo: '10'
  //     },
  //     fileContentDFEF01: {
  //       fileContent: '0000D3E1D3CED8A90000000000000000000000000000333130313038313938363031313732383539000000000000000000000000000000',
  //       startIndex: '0',
  //       length: '55',
  //       verNo: '10'
  //     },
  //     fileContentMFEF01: {
  //       fileContent: '0000D3E1D3CED8A90000000000000000000000000000333130313038313938363031313732383539000000000000000000000000000000',
  //       startIndex: '0',
  //       length: '55',
  //       verNo: '10'
  //     },
  //   })
  // })
  return request({
    url: '/preIssueApply',
    method: 'post',
    data: {
      etcUserId,
      workOrderID,
      msgType,
      orderType, // 订单类型
      vehicleNumber, // 车牌号
      vehicleColor,
      obuId,
      obuSign,
      obuVerNo,
      cardId,
      cardVerNo
    },
  });
}

/**
 * @description 空发激活确认
*/
export const ensureDevicePublish = ({
  orderType, // 订单类型
  workOrderID,
  vehicleNumber, // 车牌号
  vehicleColor,
  cardId,
  obuId,
  etcUserId,
  msgType,
}) => {
  // return new Promise((resolve) => {
  //   resolve({
  //     result: '1',
  //     description: '成功'
  //   })
  // })
  return request({
    url: '/preIssueConfirm',
    method: 'post',
    data: {
      obuId,
      orderType,
      workOrderID,
      vehicleNumber,
      vehicleColor,
      cardId,
      etcUserId,
      msgType,
    },
  });
}

/**
 * @description 9.1.	设备空发/激活数据申请 换卡换签专用
 * @param {*} param0 
 * @returns 
 */
export const v1PreIssueApply = (data) => {
  return request({
    url: '/v1/PreIssueApply',
    method: 'POST',
    data
  });
};
/**
 * @description 9.2.	设备空发/激活确认 换卡换签专用
 * @param {*} param0 
 * @returns 
 */
export const v1PreIssueConfirm = (data) => {
  return request({
    url: '/v1/PreIssueConfirm',
    method: 'POST',
    data
  });
};
