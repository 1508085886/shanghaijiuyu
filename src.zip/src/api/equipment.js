/**
 * @description 公共接口
 */
import request from '@/utils/request';

/**
 * @description 7.3.	查询卡/OBU一发信息
 * @param {*} obuSysID 
 * @param {*} printID 
 * @returns 
 */
export const queryCardObuOneSendInfo = ({ obuSysID, printID }) => {
  return request({
    url: '/queryCardObuOneSendInfo',
    method: 'POST',
    data: {
      obuSysID,
      printID,
    },
  });
};

/**
 * @description 14.2.	换卡计费
 * @param {*} param0 
 * @returns 
 */
export const calculateCardReplacement = (data) => {
  return request({
    url: '/calculateCardReplacement',
    method: 'POST',
    data,
  });
};
/**
 * @description 14.5.	换签计费
 * @param {*} param0 
 * @returns 
 */
export const calculateObuReplacement = (data) => {
  return request({
    url: '/calculateObuReplacement',
    method: 'POST',
    data,
  });
};
/**
 * @description 6.9.订单收费
 * @param {*} param0 
 * @returns 
 */
export const orderCharges = (data) => {
  return request({
    url: '/orderCharges',
    method: 'POST',
    data,
  });
};
/**
 * @description 14.3 换卡业务
 * @param {*} param0 
 * @returns 
 */
export const changeCard = (data) => {
  return request({
    url: '/changeCard',
    method: 'POST',
    data
  });
};
/**
 * @description 14.6 换签业务
 * @param {*} param0 
 * @returns 
 */
export const changeObu = (data) => {
  return request({
    url: '/changeObu',
    method: 'POST',
    data
  });
  // return false;
};
/**
 * @description 14.21.	换签表面号校验
 * @param {*} param0 
 * @returns 
 */
export const checkSurfaceCode = (data) => {
  return request({
    url: '/checkSurfaceCode',
    method: 'POST',
    data
  });
  // return false;
};
/**
 * @description 14.4.	换卡业务回执查询
 * @param {*} param0 
 * @returns 
 */
export const queryCardReplacement = (data) => {
  return request({
    url: '/queryCardReplacement',
    method: 'POST',
    data
  });
};
/**
 * @description 14.7.	换签业务回执查询
 * @param {*} param0 
 * @returns 
 */
export const queryReceiptChange = (data) => {
  return request({
    url: '/queryReceiptChange',
    method: 'POST',
    data
  });
};
/**
 * @description 14.10.	售后业务办理资格查询
 * @param {*} param0 
 * @returns 
 */
export const checkQualification = (data) => {
  return request({
    url: '/afterSale/checkQualification',
    method: 'POST',
    data
  });
};
/**
 * @description 14.25.	卡挂失计费
 * @param {*} param0 
 * @returns 
 */
export const calculateLostCard = (data) => {
  return request({
    url: '/calculateLostCard',
    method: 'POST',
    data
  });
};
/**
 * @description 14.26.	卡挂失业务申请
 * @param {*} param0 
 * @returns 
 */
export const LostCard = (data) => {
  return request({
    url: '/LostCard',
    method: 'POST',
    data
  });
};
/**
 * @description 14.27.	卡挂失业务回执查询
 * @param {*} param0 
 * @returns 
 */
export const queryReceiptLostCard = (data) => {
  return request({
    url: '/queryReceiptLostCard',
    method: 'POST',
    data
  });
};
/**
 * @description 14.28.	卡挂失业务查询
 * @param {*} param0 
 * @returns 
 */
export const queryLostCard = (data) => {
  return request({
    url: '/queryLostCard',
    method: 'POST',
    data
  });
};

//-----
/**
 * @description 14.30.	卡解挂失业务申请
 * @param {*} param0 
 * @returns 
 */
export const UncouplingCard = (data) => {
  return request({
    url: '/UncouplingCard',
    method: 'POST',
    data
  });
};
/**
 * @description 14.31.	卡解挂失业务回执查询
 * @param {*} param0 
 * @returns 
 */
export const queryReceiptUncouplingCard = (data) => {
  return request({
    url: '/queryReceiptUncouplingCard',
    method: 'POST',
    data
  });
};
/**
 * @description 14.32.	卡解挂失业务查询
 * @param {*} param0 
 * @returns 
 */
export const queryUncouplingCard = (data) => {
  return request({
    url: '/queryUncouplingCard',
    method: 'POST',
    data
  });
};
//----
/**
 * @description 14.34.	obu挂失业务申请
 * @param {*} param0 
 * @returns 
 */
export const LostObu = (data) => {
  return request({
    url: '/LostObu',
    method: 'POST',
    data
  });
};
/**
 * @description 14.35.	obu挂失业务回执查询
 * @param {*} param0 
 * @returns 
 */
export const queryReceiptLostObu = (data) => {
  return request({
    url: '/queryReceiptLostObu',
    method: 'POST',
    data
  });
};
/**
 * @description 14.36.	obu挂失业务查询
 * @param {*} param0 
 * @returns 
 */
export const queryLostObu = (data) => {
  return request({
    url: '/queryLostObu',
    method: 'POST',
    data
  });
};
//-----
/**
 * @description 14.38.	obu解挂失业务申请
 * @param {*} param0 
 * @returns 
 */
export const UncouplingObu = (data) => {
  return request({
    url: '/UncouplingObu',
    method: 'POST',
    data
  });
};
/**
 * @description 14.39.	obu解挂失业务回执查询
 * @param {*} param0 
 * @returns 
 */
export const queryReceiptUncouplingObu = (data) => {
  return request({
    url: '/queryReceiptUncouplingObu',
    method: 'POST',
    data
  });
};
/**
 * @description 14.40.	obu解挂失业务查询
 * @param {*} param0 
 * @returns 
 */
export const queryUncouplingObu = (data) => {
  return request({
    url: '/queryUncouplingObu',
    method: 'POST',
    data
  });
};
/**
 * @description 14.12.	补卡计费
 * @param {*} param0 
 * @returns 
 */
export const calculateCardReissue = (data) => {
  return request({
    url: '/calculateCardReissue',
    method: 'POST',
    data,
  });
};
/**
 * @description 14.13.	补卡业务申请
 * @param {*} param0 
 * @returns 
 */
export const reissueCard = (data) => {
  return request({
    url: '/reissueCard',
    method: 'POST',
    data
  });
};
/**
 * @description 14.14. 补卡业务回执查询
 * @param {*} param0 
 * @returns 
 */
export const queryCardReissue = (data) => {
  return request({
    url: '/queryCardReissue',
    method: 'POST',
    data
  });
};
/**
 * @description 14.18.	补卡业务查询
 * @param {*} param0 
 * @returns 
 */
export const queryReissueCard = (data) => {
  return request({
    url: '/queryReissueCard',
    method: 'POST',
    data
  });
};
/**
 * @description 14.15.	补签计费
 * @param {*} param0 
 * @returns 
 */
export const calculateObuReissue = (data) => {
  return request({
    url: '/calculateObuReissue',
    method: 'POST',
    data,
  });
};
/**
 * @description 14.16.	补签业务申请
 * @param {*} param0 
 * @returns 
 */
export const reissueObu = (data) => {
  return request({
    url: '/reissueObu',
    method: 'POST',
    data
  });
};
/**
 * @description 14.17. 补签业务回执查询
 * @param {*} param0 
 * @returns 
 */
export const queryReceiptReissue = (data) => {
  return request({
    url: '/queryReceiptReissue',
    method: 'POST',
    data
  });
};
/**
 * @description 14.19.	补签业务查询
 * @param {*} param0 
 * @returns 
 */
export const queryReissueObu = (data) => {
  return request({
    url: '/queryReissueObu',
    method: 'POST',
    data
  });
};