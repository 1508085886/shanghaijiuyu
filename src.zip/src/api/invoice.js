/**
 * @description 发票相关接口
*/
import request from '@/utils/request'

/**
 * @description 开票申请接口
*/
export const addBranch = data => {
    return request({
        url: '/addBranch',
        method: 'POST',
        data
    })
}

/**
 * @description 退款接口
*/
export const refund = (data) => {
    return request({
        url: '/refund',
        method: 'POST',
        data
    })
}
