/**
 * @description 注销相关接口
 */
import request from '@/utils/request';

/**
 * @description 设备注销
 */
export const deviceOutHandle = data => {
  return request({
    url: '/deviceOutHandle',
    method: 'post',
    data,
  });
};
/**
 * @description 账户注销
 */
export const accountOutHandle = (data) => {
  return request({
    url: '/accountOutHandle',
    method: 'post',
    data,
  });
};

/**
 * @description 脱绑资格查询
 */
export const unBindQualificationInquiry = ({etcUserId, vehicleNumber, vehicleColor }) => {
  return request({
    url: '/unBindQualificationInquiry',
    method: 'post',
    data: {
      etcUserId,
      vehicleNumber,
      vehicleColor,
    },
  });
};

/**
 * @description 设备注销业务信息查询
 */
export const deviceOutQuery = workOrderID => {
  return request({
    url: '/deviceOutQuery',
    method: 'post',
    data: {
      workOrderID,
    },
  });
};

/**
 * @description 账户注销业务信息查询
 */
export const queryAcctLogout = workOrderID => {
  return request({
    url: '/queryAcctLogout',
    method: 'post',
    data: {
      workOrderID,
    },
  });
};

/**
 * @description 有效期过期申请
 */
export const changeValidityApply = ({
  vehicleNumber,
  vehicleColor,
  obuId,
  obuSign,
  obuVerNo,
  cardId,
  cardVerNo,
}) => {
  return request({
    url: '/changeValidityApply',
    method: 'post',
    data: {
      vehicleNumber,
      vehicleColor,
      obuId,
      obuSign,
      obuVerNo,
      cardId,
      cardVerNo,
    },
  });
};
/**
 * @description 有效期过期申请
 */
export const changeValidityConfrim = ({
  vehicleNumber,
  vehicleColor,
  obuId,
  cardId,
}) => {
  return request({
    url: '/changeValidityConfrim',
    method: 'post',
    data: {
      vehicleNumber,
      vehicleColor,
      obuId,
      cardId,
    },
  });
};
/**
 * @description 有效期续期申请
 */
export const renewalValidity = (data) => {
  return request({
    url: '/renewalValidity',
    method: 'post',
    data,
  });
};
/**
 * @description 有效期续期确认
 */
export const changeValidityRenewalConfrim = (data) => {
  return request({
    url: '/changeValidityRenewalConfrim',
    method: 'post',
    data,
  });
};
/**
 * @description 查询注销资格
 */
export const deviceQuery = (data) => {
  return request({
    url: '/deviceQuery',
    method: 'post',
    data,
  });
};