/**
 * @description 分支机构相关接口
*/
import request from '@/utils/request'

/**
 * @description 分支机构查询接口
*/
export const branchQuery = (data) => {
    return request({
        url: '/branchQuery',
        method: 'POST',
        data
    })
}

/**
 * @description 分支机构新增接口
*/
export const addBranch = (data) => {
    return request({
        url: '/addBranch',
        method: 'POST',
        data
    })
}

/**
 * @description 分支机构修改接口
*/
export const changeDefaultDepartment = (data) => {
    return request({
        url: '/changeDefaultDepartment',
        method: 'POST',
        data
    })
}

/**
 * @description 4.12 完善分支机构
*/
export const perfectVehicleDepartment = (data) => {
    return request({
        url: '/perfectVehicleDepartment',
        method: 'POST',
        data
    })
}