import Vue from 'vue'
import VueRouter from 'vue-router'
import routes from './routes'
import padRoutes from './padRoutes'
import constants from '@/globeProperty/constants' // 常量
Vue.use(constants)// 常量
Vue.use(VueRouter)

//获取原型对象上的push函数
const originalPush = VueRouter.prototype.push
//修改原型对象中的push方法
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}
let router = null;
if (Vue.prototype.$isPad) {
  /*PAD端兼容代码*/
  router = new VueRouter({
    mode: 'hash',
    routes: padRoutes
  })
} else {
  router = new VueRouter({
    mode: 'hash',
    routes
  })
}

export default router
