import Layout from '@/layout';
import Home from '@/views/Home';
import NewPublish from '@/views/NewPublish';
import Pidchange from '@/views/pidchange';
import Cidchange from '@/views/cidchange';

import vehicleChangeRoute from './vehiclechange'; // 车辆信息变更路由信息

const routes = [
  {
    path: '/login',
    component: () => import(/* webpackChunkName:"login" */ '@/views/Login'),
  },
  {
    path: '/changecard',
    component: () => import( /* webpackChunkName:"homeChangeCard" */ '@/views/Home/ChangeCard'),
  },
  {
    path: '/changecard/docupload',
    component: () =>
      import(
        /* webpackChunkName:"homeChangeCardDocUpload" */ '@/views/Home/ChangeCard/DocUpload'
      ),
  },
  {
    path: '/changecard/changecardmain',
    component: () =>
      import(
        /* webpackChunkName:"homeChangeCardDocUpload" */ '@/views/Home/ChangeCard/ChangeCardMain'
      ),
  },
  {
    path: '',
    component: Layout,
    children: [
      {
        path: '',
        component: Home,
        redirect: '/menu',
        children: [
          {
            path: 'menu',
            component: () =>
              import(/* webpackChunkName:"homeMenu" */ '@/views/Home/Menu'),
          },
          {
            path: 'replacecard',
            component: () =>
              import(
                /* webpackChunkName:"homeReplaceCard" */ '@/views/Home/ReplaceCard'
              ),
          },
          // {
          //   path: 'changecard',
          //   component: () =>
          //     import(
          //       /* webpackChunkName:"homeChangeCard" */ '@/views/Home/ChangeCard'
          //     ),
          // },
          // {
          //   path: 'changecard/docupload',
          //   component: () =>
          //     import(
          //       /* webpackChunkName:"homeChangeCardDocUpload" */ '@/views/Home/ChangeCard/DocUpload'
          //     ),
          // },
          // {
          //   path: 'changecard/changecardmain',
          //   component: () =>
          //     import(
          //       /* webpackChunkName:"homeChangeCardDocUpload" */ '@/views/Home/ChangeCard/ChangeCardMain'
          //     ),
          // },
          {
            path: 'changeobu',
            component: () =>
              import(
                /* webpackChunkName:"homeChangeCard" */ '@/views/Home/ChangeOBU'
              ),
          },
          {
            path: 'changeobu/docupload',
            component: () =>
              import(
                /* webpackChunkName:"homeChangeCardDocUpload" */ '@/views/Home/ChangeOBU/DocUpload'
              ),
          },
          {
            path: 'changeobu/changeobumain',
            component: () =>
              import(
                /* webpackChunkName:"homeChangeCardDocUpload" */ '@/views/Home/ChangeOBU/ChangeOBUMain'
              ),
          },
          // 标签挂失
          {
            path: 'obureportloss',
            component: () =>
              import(
                /* webpackChunkName:"homeReportLoss" */ '@/views/Home/ObuReportLoss'
              ),
          },
          {
            path: 'obureportloss/docupload',
            component: () =>
              import(
                /* webpackChunkName:"homeReportLossDocUpload" */ '@/views/Home/ObuReportLoss/DocUpload'
              ),
          },
          // 标签解挂
          {
            path: 'obuuntiedhang',
            component: () =>
              import(
                /* webpackChunkName:"homeReportLoss" */ '@/views/Home/ObuUntiedHang'
              ),
          },
          {
            path: 'obuuntiedhang/docupload',
            component: () =>
              import(
                /* webpackChunkName:"homeReportLossDocUpload" */ '@/views/Home/ObuUntiedHang/DocUpload'
              ),
          },
          // 卡片挂失
          {
            path: 'reportloss',
            component: () =>
              import(
                /* webpackChunkName:"homeReportLoss" */ '@/views/Home/ReportLoss'
              ),
          },
          {
            path: 'reportloss/docupload',
            component: () =>
              import(
                /* webpackChunkName:"homeReportLossDocUpload" */ '@/views/Home/ReportLoss/DocUpload'
              ),
          },
          // 卡片解挂
          {
            path: 'untiedhang',
            component: () =>
              import(
                /* webpackChunkName:"homeReportLoss" */ '@/views/Home/UntiedHang'
              ),
          },
          {
            path: 'untiedhang/docupload',
            component: () =>
              import(
                /* webpackChunkName:"homeReportLossDocUpload" */ '@/views/Home/UntiedHang/DocUpload'
              ),
          },
          {
            path: 'changecard-old',
            component: () =>
              import(
                /* webpackChunkName:"homeChangeCard" */ '@/views/Home/ChangeCard-old'
              ),
          },
          {
            path: 'devicewriteoff',
            component: () =>
              import(
                /* webpackChunkName:"homeDeviceWriteoff" */ '@/views/Home/DeviceWriteoff'
              ),
          },
          {
            path: 'accountwriteoff',
            component: () =>
              import(
                /* webpackChunkName:"homeAccountWriteoff" */ '@/views/Home/AccountWriteoff'
              ),
          },
          {
            path: 'fixowner',
            component: () =>
              import(
                /* webpackChunkName:"homeMenu" */ '@/views/Home/FixCarOwnernfo'
              ),
          },
          {
            path: 'fixuser',
            component: () =>
              import(
                /* webpackChunkName:"homeMenu" */ '@/views/Home/FixUserinfo'
              ),
          },
          {
            path: 'equipmentissuance',
            component: () =>
              import(
                /* webpackChunkName:"homeEquipmentIssuance" */ '@/views/Home/EquipmentIssuance'
              ),
          },
          {
            path: '/pidchange',
            component: Pidchange,
            redirect: '/pidchange/pchange',
            children: [
              {
                path: 'pchange',
                component: () => import('@/views/pidchange/pchange'),
              },
            ],
          },
          {
            path: '/cidchange',
            component: Cidchange,
            redirect: '/cidchange/cchange',
            children: [
              {
                path: 'cchange',
                component: () => import('@/views/cidchange/cchange'),
              },
            ],
          },
          {
            path: '/test1',
            component: () =>
              import(
                /* webpackChunkName:"spcardquery" */ '@/views/readcardobu'
              ),
          },
          {
            path: '/purchaserecord',
            component: () =>
              import(
                /* webpackChunkName:"spcardquery" */ '@/views/purchaserecord'
              ),
          },
          {
            path: '/vehicleinfochange',  // 主页菜单 车辆业务-车辆信息变更
            component: () => import('@/views/vehicleInfoChange/pages/Category'),
          },
          {
            path: 'jumpBlankPage',
            component: () =>
              import(
                /* webpackChunkName:"JumpBlankPage" */ '@/views/Home/JumpBlankPage'
              ),
          },
          {
            path: 'branchManage',
            component: () =>
              import(
                /* webpackChunkName:"BranchManage" */ '@/views/Home/BranchManage'
              ),
          },
          {
            path: 'improvebranch',
            component: () =>
              import(
                /* webpackChunkName:"improvebranch" */ '@/views/Home/ImproveBranch'
              ),
          },
          {
            path: 'cardReplacement',
            component: () =>
              import(
                /* webpackChunkName:"cardReplacement" */ '@/views/Home/CardReplacement'
              ),
          },
          {
            path: 'cardReplacement/doUpload',
            component: () =>
              import(
                /* webpackChunkName:"homeCardReplacementMain" */ '@/views/Home/CardReplacement/DoUpload'
              ),
          },
          {
            path: 'cardReplacement/cardReplacementMain',
            component: () =>
              import(
                /* webpackChunkName:"homeCardReplacementMain" */ '@/views/Home/CardReplacement/CardReplacementMain'
              ),
          },
          {
            path: 'obuReplacement',
            component: () =>
              import(
                /* webpackChunkName:"obuReplacement" */ '@/views/Home/ObuReplacement'
              ),
          },
          {
            path: 'obuReplacement/doUpload',
            component: () =>
              import(
                /* webpackChunkName:"obuReplacementdoUpload" */ '@/views/Home/ObuReplacement/DoUpload'
              ),
          },
          {
            path: 'obuReplacement/obuReplacementMain',
            component: () =>
              import(
                /* webpackChunkName:"obuReplacementobuReplacementMain" */ '@/views/Home/ObuReplacement/ObuReplacementMain'
              ),
          },
          // 储值卡充值
          {
            path: 'storagecardrecharge',
            component: () =>
              import(
                /* webpackChunkName:"StorageCardRecharge" */ '@/views/Home/StorageCardRecharge'
              ),
          },
          // 储值卡挂账还款
          {
            path: 'storagecardrepayment',
            component: () =>
              import(
                /* webpackChunkName:"StorageCardRecharge" */ '@/views/Home/StorageCardRepayment'
              ),
          },
        ],
      },
      {
        path: '/spcardquery',
        component: () =>
          import(/* webpackChunkName:"spcardquery" */ '@/views/spcardquery'),
      },
      {
        path: '/accountquery',
        component: () =>
          import(/* webpackChunkName:"spcardquery" */ '@/views/AccountQuery'),
      },
      // {
      //   path: '/puserregister',
      //   component: () =>
      //     import(
      //     /* webpackChunkName:"spcardquery" */ '@/views/NewPublish/puserregister'
      //     ),
      // },
      {
        path: '/newpublishperson',
        component: () =>
          import(
            /* webpackChunkName:"spcardquery" */ '@/views/NewPublish/puserregister'
          ),
      },
      {
        path: '/newpublishperson',
        component: NewPublish,
        // redirect: '/newpublishperson/puserregister',
        children: [
          // {
          //   path: 'puserregister',
          //   component: () =>
          //     import(
          //       /* webpackChunkName:"newPublishUserRegister" */  '@/views/NewPublish/puserregister'
          //     ),
          //   meta: {
          //     step: 0,
          //     reload: true
          //   },
          // },
          {
            path: 'uservoucher',
            component: () =>
              import(
                /* webpackChunkName:"newPublishUserRegisterVoucher" */ '@/views/NewPublish/UserRegisterVoucher'
              ),
            meta: {
              step: 0,
            },
          },

          {
            path: 'carregister',
            component: () =>
              import(
                /* webpackChunkName:"newPublishCarRegister" */ '@/views/NewPublish/CarRegister'
              ),
            meta: {
              step: 3,
            },
          },
          {
            path: 'carregisterinput',
            component: () =>
              import(
                /* webpackChunkName:"newPublishCarRegisterInput" */ '@/views/NewPublish/CarRegisterInput'
              ),
            meta: {
              step: 1,
            },
          },
          {
            path: 'banksign',
            component: () =>
              import(
                /* webpackChunkName:"newPublishBankSigning" */ '@/views/NewPublish/BankSign'
              ),
            meta: {
              step: 2,
            },
          },
          {
            path: 'publishvoucher',
            component: () =>
              import(
                /* webpackChunkName:"newPublishPublishVoucher" */ '@/views/NewPublish/PublishVoucher'
              ),
            meta: {
              step: 3,
            },
          },
          {
            path: 'publish',
            component: () =>
              import(
                /* webpackChunkName:"newPublishPublishVoucher" */ '@/views/NewPublish/Publish'
              ),
            meta: {
              step: 3,
            },
          },
        ],
      },
      {
        path: '/newpublish',
        component: NewPublish,
        redirect: '/newpublish/userregister',
        children: [
          {
            path: 'userregister',
            component: () =>
              import(
                /* webpackChunkName:"newPublishUserRegister" */ '@/views/NewPublish/UserRegister'
              ),
            meta: {
              step: 0,
              reload: true,
            },
          },
          {
            path: 'uservoucher',
            component: () =>
              import(
                /* webpackChunkName:"newPublishUserRegisterVoucher" */ '@/views/NewPublish/UserRegisterVoucher'
              ),
            meta: {
              step: 0,
            },
          },

          {
            path: 'carregister',
            component: () =>
              import(
                /* webpackChunkName:"newPublishCarRegister" */ '@/views/NewPublish/CarRegister'
              ),
            meta: {
              step: 3,
            },
          },
          {
            path: 'carregisterinput',
            component: () =>
              import(
                /* webpackChunkName:"newPublishCarRegisterInput" */ '@/views/NewPublish/CarRegisterInput'
              ),
            meta: {
              step: 1,
            },
          },
          {
            path: 'banksign',
            component: () =>
              import(
                /* webpackChunkName:"newPublishBankSigning" */ '@/views/NewPublish/BankSign'
              ),
            meta: {
              step: 2,
            },
          },
          {
            path: 'publishvoucher',
            component: () =>
              import(
                /* webpackChunkName:"newPublishPublishVoucher" */ '@/views/NewPublish/PublishVoucher'
              ),
            meta: {
              step: 3,
            },
          },
          {
            path: 'publish',
            component: () =>
              import(
                /* webpackChunkName:"newPublishPublishVoucher" */ '@/views/NewPublish/Publish'
              ),
            meta: {
              step: 3,
            },
          },
        ],
      },
    ],
  },
  {
    path: '/workordermanagement',
    component: () =>
      import(
        /* webpackChunkName:"workordermanagement" */ '@/views/WorkOrderManagement'
      ),
  },

  {
    path: '/netreconciliation',
    component: () =>
      import(
        /* webpackChunkName:"netreconciliation" */ '@/views/NetReconciliation'
      ),
  },
  {
    path: '/licenseverify',
    component: () =>
      import(/* webpackChunkName:"licenseverify" */ '@/views/LicenseVerify'),
  },
  {
    path: '/allaccountinfo',
    component: () =>
      import(/* webpackChunkName:"allaccountinfo" */ '@/views/AllAccountInfo'),
  },
  {
    path: '*',
    name: '404',
    component: () => import(/* webpackChunkName:"login" */ '@/views/Login'),
  },
  // {
  //   path: '/v',
  //   component: () =>
  //     import(
  //       /* webpackChunkName:"allaccountinfo" */ '@/components/VoucherLayer'
  //     ),
  // },
  // {
  //   path: '/vc',
  //   component: () =>
  //     import(
  //       /* webpackChunkName:"allaccountinfo" */ '@/components/VoucherLayerConfirm'
  //     ),
  // },
  //  {
  //   path: '/c',
  //   component: () =>
  //     import(
  //       /* webpackChunkName:"allaccountinfo" */ '@/views/NewPublish/CarRegister/CarRegisterForm'
  //     ),
  // },
  // {
  //   path: '/vl',
  //   component: () =>
  //     import(
  //       /* webpackChunkName:"allaccountinfo" */ '@/components/VerifyLicenseDialog'
  //     ),
  // },
  // {
  //   path: '/td',
  //   component: () =>
  //     import(
  //       /* webpackChunkName:"allaccountinfo" */ '@/components/TransactorDialog'
  //     ),
  // },
  // {
  //   path: '/ci',
  //   component: () =>
  //     import(
  //       /* webpackChunkName:"allaccountinfo" */ '@/views/NewPublish/CarInfo'
  //     ),
  // },
];

// 车辆信息变更路由
routes.push({
  path: '',
  component: Layout,
  children: [
    {
      path: '',
      component: Home,
      redirect: '/menu',
      children: [...vehicleChangeRoute],
    },
  ],
});

export default routes;
