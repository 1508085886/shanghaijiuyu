// 车辆信息变更 业务 页面路由
module.exports = [
  {
    path: '/t', // 浏览器调试页面样式
    component: () => import('@/views/vehicleInfoChange/pages/PicUpload.vue'),
  },

  {
    path: '/vehicleinfochange/old', // 老页面
    component: () => import('@/views/vehicleInfoChange/index_old.vue'),
  },

  {
    path: '/vehicleinfochange/cate', // step 0, 选择 车牌 or 车型 变更
    component: () => import('@/views/vehicleInfoChange/pages/Category.vue'),
  },

  {
    path: '/vehicleinfochange/changeType', // step 0-1, 变更车型
    component: () => import('@/views/vehicleInfoChange/index.vue'),
  },

  {
    path: '/vehicleinfochange/picupload', // step1, 上传证件
    component: () => import('@/views/vehicleInfoChange/pages/PicUpload.vue'),
  },

  {
    path: '/vehicleinfochange/changeinfo', // step2, 信息变更
    component: () => import('@/views/vehicleInfoChange/pages/ChangeInfo.vue'),
  },

  // 接续办理 路由
  {
    path: '/convehiclechange', 
    component: () => import('@/views/vehicleInfoChange/pages/continue/index.vue'),
  },

  {
    path: '/convehiclechange/pic',  //step1
    component: () => import('@/views/vehicleInfoChange/pages/continue/PicUpload.vue'),
  },

  {
    path: '/convehiclechange/changeinfo',  //step2
    component: () => import('@/views/vehicleInfoChange/pages/continue/ChangeInfo.vue'),
  },
];
