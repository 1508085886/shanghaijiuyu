<!-- 带输入的类型下拉选 -->
<template>
  <el-input
    :type="type"
    :placeholder="placeholder"
    :value="value"
    @input="inputHandle"
    spellcheck="false"
    :maxlength="vmaxlength"
    :disabled="disabled"
    :readonly="readonly"
    @focus="$emit('focus')"
  >
    <!-- v-focus="ifocus" -->
    <!-- @keyup.native="getRegex" -->
    <slot slot="prepend" name="prependSelect"></slot>
    <slot slot="append" name="appendButton"></slot>
  </el-input>
</template>

<script>
import {
  getFormatCardId,
  getFormatOBUId,
  getFormatVehicleNumber,
  getFormatMobile,
  getFormatUserCode,
  getFormatCardFrontId,
  getFormatOBUFrontId,
  getBankId,
} from '@/utils/utils';
export default {
  data() {
    return {
      vmaxlength: 50,
    };
  },
  // directives: {
  //   focus: {
  //     // 指令的定义
  //     inserted: function (el, binding) {
  //       if (binding.value) {
  //         el.querySelector('input').focus();
  //       }
  //     },
  //   },
  // },
  props: {
    value: {
      default: '',
    },
    maxlength: {
      type: Number,
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    readonly: {
      type: Boolean,
      default: false,
    },
    // ifocus: {
    //   type: Boolean,
    //   default: false,
    // },
    placeholder: {
      default: '请输入',
    },
    type: {
      required: true,
    },
  },
  watch: {
    value(val) {
      this.inputHandle(val);
    },
  },
  methods: {
    inputHandle(val) {
      if (this.type === 'cardId') {
        val = getFormatCardId(val);
      } else if (this.type === 'obuId') {
        val = getFormatOBUId(val);
      } else if (this.type === 'vehicleNumber') {
        val = getFormatVehicleNumber(val);
      } else if (this.type === 'mobile') {
        val = getFormatMobile(val);
      } else if (this.type === 'userCode') {
        val = getFormatUserCode(val);
      } else if (this.type === 'cardFrontId') {
        this.vmaxlength = 24;
        val = getFormatCardFrontId(val);
      } else if (this.type === 'obuFrontId') {
        this.vmaxlength = 25;
        val = getFormatOBUFrontId(val);
      } else if (this.type === 'bankId') {
        val = getBankId(val);
      }
      this.$emit('input', val);
      this.$emit('change', val);
    },
    focus() {
      this.$el.querySelector('input').focus();
    },
  },
  mounted() {
    this.vmaxlength = this.maxlength;
  },
};
</script>
