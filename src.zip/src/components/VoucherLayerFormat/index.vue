<!-- 通用凭证 -->
<template>
  <div class="offline-voucherreceiptformat-layer">
    <transition name="fade">
      <div class="offline-voucherreceiptformat-layer_bg" v-if="visible"></div>
    </transition>
    <transition name="slide-right">
      <div
        class="offline-voucherreceiptformat-layer_container"
        :class="{ 'is-full': full }"
        v-if="visible"
      >
        <i
          class="offline-voucherreceiptformat-layer_close el-icon-close"
          @click="close"
          v-if="cancelShow"
        ></i>
        <div
          ref="imageWrapper"
          class="offline-voucherreceiptformat-layer_pic-block"
        >
          <div class="o-flex offline-voucherreceiptformat-layer_top">
            <h3>
              上海公共交通卡股份有限公司&nbsp;高速公路电子收费业务办理回执
            </h3>
            <el-row
              class="o-flex offline-voucherreceiptformat-layer_table-footer"
              v-if="hasFooter"
            >
              <el-col
                :span="10"
                class="
                  offline-voucherreceiptformat-layer_td
                  o-flex o-flex-align-center
                "
              >
                <div class="offline-voucherreceiptformat-layer_label">日期</div>
                <div class="o-flex-1">{{ footer.date }}</div>
              </el-col>
              <el-col
                :span="6"
                class="
                  offline-voucherreceiptformat-layer_td
                  o-flex o-flex-align-center o-flex-justify-center
                "
              >
                <div class="offline-voucherreceiptformat-layer_label">
                  网点ID
                </div>
                <div class>{{ footer.outletId }}</div>
              </el-col>
              <el-col
                :span="6"
                class="
                  offline-voucherreceiptformat-layer_td
                  o-flex o-flex-align-center o-flex-justify-center
                "
              >
                <div class="offline-voucherreceiptformat-layer_label">
                  操作员
                </div>
                <div class>{{ footer.operator }}</div>
              </el-col>
            </el-row>
          </div>
          <el-row
            :gutter="0"
            class="offline-voucherreceiptformat-layer_tablerow"
          >
            <el-col :span="12">
              <div class="offline-voucherreceiptformat-layer_table">
                <el-row
                  class="offline-voucherreceiptformat-layer_tr"
                  v-for="(tr, i) in tables"
                  :key="i"
                >
                  <el-col
                    :span="computedSpan(td.span)"
                    class="
                      offline-voucherreceiptformat-layer_td
                      o-flex o-flex-align-center
                    "
                    v-for="(td, j) in tr"
                    :key="i + '' + j"
                  >
                    <div
                      class="offline-voucherreceiptformat-layer_label"
                      :style="{
                        color: td.color,
                        width: td.labelWidth,
                        display: td.display,
                      }"
                    >
                      {{ td.label }}
                    </div>
                    <div
                      class="o-flex-1"
                      :style="{
                        color: td.color,
                        fontSize: td.fontSize,
                        fontWeight: td.fontWeight,
                        display: td.display,
                      }"
                    >
                      <span v-show="td.html" v-html="td.value"></span>
                      <span v-show="!td.html">{{ td.value }}</span>
                    </div>
                  </el-col>
                </el-row>
                <el-row
                  class="offline-voucherreceiptformat-layer_tr"
                  v-for="(tr, i) in tables2"
                  :key="'info2' + i"
                >
                  <el-col
                    :span="computedCircleSpan(td.span)"
                    class="
                      offline-voucherreceiptformat-layer_td
                      o-flex o-flex-align-center
                    "
                    v-for="(td, j) in tr"
                    :key="'info2' + i + '' + j"
                  >
                    <div
                      class="offline-voucherreceiptformat-layer_label"
                      :style="{ width: td.labelWidth }"
                    >
                      {{ td.label }}
                    </div>
                    <div
                      class="o-flex-1"
                      :style="{
                        color: td.color,
                        fontSize: td.fontSize,
                        fontWeight: td.fontWeight,
                      }"
                    >
                      {{ td.value }}
                    </div>
                  </el-col>
                </el-row>
              </div>
            </el-col>
            <el-col :span="12">
              <div
                v-if="voucherType == 'invoice'"
                class="offline-voucherreceiptformat-msgblock"
              >
                <p>
                  ETC用户：自2018年起，沪通卡充值、消费发票，统一在全国收费公路通行费电子发票服务平台开具。
                </p>
                <p class="offline-voucherreceiptformat-msgblock-noneedblank">
                  --------------------------------------------发票开具流程--------------------------------------------
                </p>
                <p>第一步：营改增信息采集</p>
                <p>PC端：登录www.sptcc.com，点击“ETC营改增信息采集”。</p>
                <p>
                  手机端：关注并进入“上海公共交通卡”微信公众号→点击“沪通卡”→点击“营改增信息采集”。
                </p>
                <p>
                  以上任意方式信息采集成功后，次日生效，获取的信息需在“票根”绑卡时输入。
                </p>
                <p>第二步：开票</p>
                <p>
                  登录www.txffp.com或下载“票根”APP→注册→绑定ETC卡（填写采集时获取的信息）→填写发票抬头→开票完成
                </p>
              </div>
            </el-col>
          </el-row>

          <div
            class="offline-voucherreceiptformat-layer_sign-wrap"
            :class="{ 'is-signed': isSigned }"
          >
            <div class="o-flex offline-voucherreceiptformat-layer_sign-block">
              <h5>签名区</h5>
            </div>
          </div>
        </div>
        <!-- <div class=""> -->
        <!-- clearfix -->
        <div class="offline-voucherreceiptformat-layer_sign-btn-wrap">
          <!-- <div
              style="height: 152px;width: 270px;"
            >
            </div> -->
          <div>
            <el-button
              class="offline-voucherreceiptformat-layer_complete-btn2"
              type="danger"
              @click="close"
              size="medium"
              v-if="cancelShow"
              :loading="loading"
              >取消</el-button
            >
            <el-button
              id="btn"
              class="offline-voucherreceiptformat-layer_complete-btn2"
              type="primary"
              @click="completeHandle"
              :loading="loading"
              :disabled="!isSigned"
              size="medium"
              v-if="completeShow"
              >代确认无误</el-button
            >
          </div>
        </div>

        <!-- </div> -->
      </div>
    </transition>
  </div>
</template>

<script>
import html2canvas from 'html2canvas';
import { mediaUpload, systemTime } from '@/api/common';
import { getQueryStringByName } from '@/utils/utils';
export default {
  data() {
    return {
      // timer: true,
      //timer2: true,
      loading: false,
      tables: [],
      tables2: [],
      isSigned: true,
      labelWidth: '110px',
      oldWindow: false,
      // footer: {
      //   date: '',
      //   outletId: '',
      //   operator: '',
      // },
    };
  },
  props: {
    full: {
      type: Boolean,
    },
    confirmFlag: {
      // 是否已经被确认
      type: Boolean,
      default: false,
    },
    voucherType: {
      // 类型
      type: String,
      default: 'invoice',
    },
    hasFooter: {
      type: Boolean,
      default: true,
    },
    cancelShow: {
      type: Boolean,
      default: true,
    },
    completeShow: {
      type: Boolean,
      default: true,
    },
    info: {
      type: Object,
      default: () => {},
    },
    footer: {
      type: Object,
      default: () => {
        return {
          // date: '',
          outletId: '',
          operator: '',
        };
      },
    },
    column: {
      type: Number,
      default: 2,
    },
    keys: {
      type: Array,
      default: () => [],
    },
    circleInfo: {
      type: Array,
      default: () => [],
    },
    circleColumn: {
      type: Number,
      default: 4,
    },
    circleKeys: {
      type: Array,
      default: () => [],
    },
    visible: {
      type: Boolean,
      // default:true,
    },
  },
  methods: {
    // 计算当前日期
    async getDate() {
      // const now = new Date();
      // this.footer.date = `${now.getFullYear()}/${
      //   now.getMonth() + 1
      // }/${now.getDate()}`;
      const res = await systemTime();
      if (res) {
        // this.footer.date = res.systemTime;
        this.$set(this.footer, 'date', res.systemTime);
        console.log(`receipt:${this.footer.date}`);
      }
    },
    computedSpan(span) {
      const column = this.column;
      if (!span) return 24 / column;
      if (span > column) span = column;
      return (24 / column) * span;
    },
    computedCircleSpan(span) {
      const circleColumn = this.circleColumn;
      if (!span) return 24 / circleColumn;
      if (span > circleColumn) span = circleColumn;
      return (24 / circleColumn) * span;
    },
    // 根据info，填充数据
    inertData() {
      const self = this;
      self.tables = [];
      const keys = self.keys;
      // console.log('keys:' + keys);
      for (let i = 0; i < keys.length; i++) {
        self.tables.push([]);
        for (let j = 0; j < keys[i].length; j++) {
          // console.log(keys[i][j]);
          self.tables[i].push({
            label: keys[i][j].label,
            value: self.info[keys[i][j].key] || '',
            span: keys[i][j].span || 1,
            labelWidth: keys[i][j].labelWidth || this.labelWidth,
            color: keys[i][j].color,
            fontSize: keys[i][j].fontSize,
            fontWeight: keys[i][j].fontWeight,
            display: keys[i][j].display,
            html: keys[i][j].html,
          });
        }
      }
    },
    // 根据circleInfo，填充数据
    inertCircleData() {
      const self = this;
      const keys = self.circleKeys;
      const datas = self.circleInfo;
      let dataArray = [];
      // let tempTable = [];
      // let rows = Math.ceil((datas.length * keys.length) / this.circleColumn);
      for (let i = 0; i < datas.length; i++) {
        for (let j = 0; j < keys.length; j++) {
          // console.log(keys[j]);
          dataArray.push({
            label: keys[j].label,
            value: datas[i][keys[j].key] || '',
            span: keys[j].span || 1,
            labelWidth: keys[j].labelWidth || this.labelWidth,
            color: keys[j].color,
            fontSize: keys[j].fontSize,
            fontWeight: keys[j].fontWeight,
          });
        }
      }
      // // 初始化临时数组
      // for (let i = 0; i < rows; i++) {
      //   tempTable.push([]);
      //   for (let c = 0; c < this.circleColumn; c++) {
      //     tempTable[i].push({});
      //   }
      // }
      // // 将数据二维数组化
      // for (let i = 0; i < dataArray.length; i++) {
      //   tempTable[Math.floor(i / this.circleColumn)][i % this.circleColumn] =
      //     dataArray[i];
      // }
      // self.tables2 = tempTable;
      self.tables2 = [dataArray];
    },
    // 关闭
    close() {
      const self = this;
      // self.loading = true;
      // self.timer = setTimeout(() => {
      const b = etcdev.closehangwriting();
      this.$emit('closed');
      this.$emit('update:visible', false);
      // }, 1);
      // self.timer2 = setTimeout(() => {
      //   self.loading = false;
      // }, 1000);
      // clearTimeout(timer);
      // clearTimeout(timer2);
      //self.loading = false;
    },
    sendpad() {
      const self = this;
      self.$nextTick(() => {
        html2canvas(self.$refs.imageWrapper).then((canvas) => {
          let dataURL = canvas.toDataURL('');
          dataURL = dataURL.replace('data:image/png;base64,', '');
          const pic = self.getpicture(dataURL);
        });
      });
    },

    padconfirm(confirmphoto) {
      if (this.confirmFlag) {
        return;
      }
      mediaUpload({
        fileType: '2',
        img: confirmphoto,
      }).then((res) => {
        this.close();
        this.$emit('complete', {
          frontImgid: res.frontImgid,
          img: confirmphoto,
          etx: '2',
        });
        this.$emit('update:confirmFlag', true); // 客户确认
      });
    },
    getpicture(dataURL) {
      const par = '123';
      window.DisplayDate = (pic, sign) => {
        const result = eval('(' + pic + ')');
        // alert(result);
        if (result.msg !== '签名版打开失败') {
          if (result.code === '0') {
            this.padconfirm(result.pic);
          } else if (result.msg === '签名版打开失败') {
            this.$message({
              message: result.msg,
              type: 'warning',
            });
            this.close();
          } else {
            // this.$message({
            //   message: '用户未确认',
            //   type: 'warning',
            // });
            this.close();
          }
        }
      };
      // alert('window.location:');
      // alert(
      //   window.location.href.substring(0, window.location.href.indexOf('?'))
      // ); //workordermanagement
      let newWindow = [];
      this.JumpPage.forEach((element) => {
        if (window.location.href.indexOf(element) > -1) {
          newWindow.push(element);
        } // 当前窗口是弹出的新窗口
      });
      // const b = '';
      if (newWindow.length !== 0) {
        let dif = getQueryStringByName('dif', window.location.href);
        // alert(dif);
        etcdev.showhangwriting(dataURL, 'DisplayDate', par, '1', dif);
      } else {
        // 主界面
        etcdev.showhangwriting(dataURL, 'DisplayDate', par, '1', '0');
      }
    },
    // 点击完成
    completeHandle() {
      if (this.confirmFlag) {
        return;
      }
      const self = this;
      document.getElementById('btn').disabled = true;
      console.log(document.getElementById('btn').disabled);
      //----------------------------------------------
      self.loading = true;
      let timer2 = setTimeout(() => {
        self.loading = false;
        document.getElementById('btn').disabled = false;
      }, 10000);
      // ------------------------------------------------
      html2canvas(self.$refs.imageWrapper).then((canvas) => {
        let dataURL = canvas.toDataURL('image/png');
        // 上传图片
        mediaUpload({
          fileType: '2',
          img: dataURL,
        }).then((res) => {
          self.close();
          self.$emit('complete', {
            frontImgid: res.frontImgid,
            img: dataURL,
            etx: '2',
          });
          //-------------------------
          clearTimeout(timer2);
          self.loading = false;
          document.getElementById('btn').disabled = false;
          console.log(document.getElementById('btn').disabled);
          //-------------------------
          this.$emit('update:confirmFlag', true); // 操作员确认
        });
      });
    },
  },
  watch: {
    info: {
      deep: true,
      handler() {
        this.inertData();
        this.getDate();
      },
    },
    keys: {
      deep: true,
      handler() {
        this.inertData();
        this.getDate();
      },
    },
    circleInfo: {
      deep: true,
      handler() {
        this.inertCircleData();
      },
    },
    circleKeys: {
      deep: true,
      handler() {
        this.inertCircleData();
      },
    },
  },
  mounted() {
    // this.getDate();
    // if (this.hasFooter) {
    // console.log(`this.hasFooter:${this.hasFooter}`);
    // this.getDate();
    // }
  },

  // destroyed() {
  //   clearTimeout(this.timer);
  //   clearTimeout(this.timer2);
  // },
  // updated() {
  //   this.$nextTick(function () {
  //       if (this.hasFooter) {
  //         this.getDate();
  //       }
  //   })
  // },
};
</script>
