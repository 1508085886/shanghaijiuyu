<!-- 签名区域 -->
<template>
  <div>
    <div class="offline-autograph" @click="visible = true">
      <div class="offline-autograph-content">
        <i class="el-icon-edit-outline"></i>
        <span class>点击签名</span>
      </div>
    </div>
    <o-dialog size="full" title="客户签名" :visible.sync="visible">
      <div class="offline-autograph_autograph"></div>
      <div slot="footer" class="dialog-footer">
        <el-button size="small" @click="formVisible = false">重 置</el-button>
        <el-button size="small" type="primary" @click="formVisible = false">确 定</el-button>
      </div>
    </o-dialog>
  </div>
</template>

<script>
import ODialog from '../Dialog';
export default {
  data() {
    return {
      visible: false,
    };
  },
  components: {
    ODialog,
  },
};
</script>
