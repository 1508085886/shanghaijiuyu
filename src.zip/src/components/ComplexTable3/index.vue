<!-- 复杂表格，传入获取数据地址，新增地址 -->
<template>
  <!--  size="large"
    :title="title"
    class="offline-complex-table3"
    :append-to-body="appendToBody"
    @opened="defaultShow" -->
  <!-- size="large" -->
  <b-dialog
    :visible.sync="cvisible"
    :title="title"
    width="90%"
    :append-to-body="appendToBody"
    class="offline-complex-table3"
    :showclose="showclose"
  >
    <!-- <el-dialog :visible.sync="cvisible" width="90%">
    <template slot="title">
      <div class='titleZise' style="color: #027AFF;font-size: 18px;font-weight: bold;">工单</div>
    </template> -->
    <div
      class="offline-complex-table3_container"
      :style="{ height: tableHeight + 30 + 'px' }"
    >
      <!-- style="width: 100%; height: 479px" -->
      <el-table
        ref="multipleTable"
        :data="tables"
        tooltip-effect="dark"
        @select="handleSelectionChange"
        @select-all="onSelectAll"
        :height="tableHeight"
        :header-cell-class-name="cellClass"
        :header-cell-style="{
          'background-color': '#D3D6DF',
        }"
      >
        >
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column
          :prop="column.filed"
          :label="column.name"
          v-for="(column, i) in columns"
          :key="column.filed + i"
        >
          <template slot-scope="scope">
            <span v-if="column.format">
              {{ column.format(scope.row[column.filed]) }}
            </span>
            <span v-else>{{ scope.row[column.filed] }}</span>
          </template>
        </el-table-column>
      </el-table>
      <el-table
        :show-header="false"
        ref="addMultipleTable"
        :data="addRows"
        tooltip-effect="dark"
        style="width: auto"
        v-show="addRows.length"
        class="offline-complex-table3_add-table"
      >
        <el-table-column width="55"></el-table-column>
        <el-table-column
          :prop="column.filed"
          :label="column.name"
          v-for="(column, i) in columns"
          :key="column.filed + i"
        >
          <template slot-scope="scope">
            <el-input
              v-if="column.edit"
              v-model="scope.row[column.filed]"
              placeholder="请输入内容"
            ></el-input>
            <span v-else>{{ column.default }}</span>
          </template>
        </el-table-column>
        <el-table-column class="offline-complex-table3_save-btn" width="57">
          <template slot-scope="scope">
            <el-button size="mini" @click="saveItem(scope.row)">保存</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div
        style="
          padding: 10px 10px;
          background: #d3d6df;
          height: 50px;
          margin-left: 0px;
          margin-right: 0px;
        "
        class="clearfix offline-workordermanagement_tableblock-pagination"
        v-if="total >= 10"
      >
        <div
          class="fl offline-workordermanagement_tableblock-pagination-desc"
          v-if="total"
        >
          第{{ startRecords }}到{{ currentSize }}条，
        </div>
        <el-pagination
          background
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="currentPage"
          :page-size="pageSize"
          layout="total,->,prev, pager, next,slot"
          :total="total"
        >
        </el-pagination>
      </div>
    </div>
    <div class="offline-complex-table3_tip o-font-family">{{ tip }}</div>
    <div
      slot="footer"
      style="margin-right: 32px; margin-bottom: 32px"
      class="dialog-footer"
    >
      <el-button
        v-if="needCancelBtn"
        @click="cvisible = false"
        style="width: 128px"
        >{{ cancelBtnText }}</el-button
      >
      <el-button type="primary" @click="getAllSelectRow" style="width: 128px">{{
        confirmBtnText
      }}</el-button>
    </div>
    <!-- </el-dialog> -->
  </b-dialog>
</template>

<script>
// import ODialog from '../Dialog';
import BDialog from '@/components/DialogBlueTitle';
import request from '@/utils/request';
import { branchQuery } from '@/api/common';
export default {
  data() {
    return {
      total: 0, //总条数
      currentPage: 1,
      page: 1, //初始显示第几页
      pageSize: 10, //每页显示多少数据
      currentSize: 0, // 当前页条数
      tables: [],
      cvisible: false,
      addRows: [],
      firstLoad: true,
      defaultValues: [],
    };
  },
  components: {
    // ODialog,
    BDialog,
  },
  props: {
    needCancelBtn: {
      default: true,
      type: Boolean,
    },
    showclose: {
      default: true,
      type: Boolean,
    },
    title: {
      default: '',
      required: true,
    },
    tip: {
      default: '',
      type: String,
    },
    tableHeight: {
      default: 200,
      type: Number,
    },
    cancelBtnText: {
      default: '取消',
      type: String,
    },
    confirmBtnText: {
      default: '确定',
      type: String,
    },
    visible: {
      type: Boolean,
      required: true,
    },
    requestListUrl: {
      type: String,
      required: true,
    },
    requestListParam: {
      default() {
        return {};
      },
      type: Object,
    },
    responseListFormat: {
      type: Function,
    },
    columns: {
      type: Array,
      required: true,
    },
    insertListUrl: {
      require: true,
      type: String,
    },
    appendToBody: {
      default: false,
      type: Boolean,
    },
    defaultValue: {
      type: Array,
    },
  },
  computed: {
    //起始记录
    startRecords() {
      return (this.page - 1) * this.pageSize + 1;
    },
  },
  methods: {
    cellClass(row) {
      // console.log(row);
      if (row.columnIndex === 0) {
        return 'DisableSelection';
      }
    },
    handleSizeChange(val) {
      this.pageSize = val;
      this.getListData();
      console.log(`每页 ${val} 条`);
    },
    ////////////////////////////////////////////////////
    async handleCurrentChange(val) {
      this.page = val;
      this.currentPage = val;
      this.getListData();
      console.log(`当前页: ${val}`);
    },
    // async resume() {
    //   const self = this;
    //   const res = await request({
    //     url: self.requestListUrl,
    //     method: 'POST',
    //     data: self.requestListParam,
    //   });
    //   if (res) {
    //     if (self.responseListFormat) {
    //       self.tables = self.responseListFormat(res);
    //     } else {
    //       self.tables = res;
    //     }
    //   }
    // },
    // 点击新增列表的保存
    async saveItem(item) {
      const self = this;
      const res = await request({
        url: self.insertListUrl,
        method: 'POST',
        data: item,
      });
      if (res) {
        // 更新列表
        self.getListData();
        // 清除在addRows中的数据
        self.removeNewRow(item);
      }
    },
    removeNewRow(item) {
      const self = this;
      const index = self.addRows.findIndex((row) => row === item);
      if (index > -1) {
        self.addRows.splice(index, 1);
      }
    },
    // 点击新增
    addNewRow() {
      const self = this;
      const row = {};
      for (let i = 0; i < self.columns.length; i++) {
        if (self.columns[i].default !== undefined) {
          row[self.columns[i].filed] = self.columns[i].default;
        } else {
          row[self.columns[i].filed] = '';
        }
      }
      self.addRows.push(row);
    },
    // 获取所有被勾选的项
    getAllSelectRow() {
      this.$emit('confirm', this.$refs.multipleTable.selection);
      // this.cvisible = false;
      // if (this.$refs.multipleTable.selection.length == '0') {
      //   this.$message.error('请选择分支机构');
      // }
      // for (let i = 0; i < this.$refs.multipleTable.selection.length; i++) {
      //   if (!this.$refs.multipleTable.selection[i].departmentAberrantData) {
      //     this.cvisible = false;
      //   } else {
      //     this.$message.error(
      //       '代理人信息异常，请用户登录中国ETC服务小程序修改经办人'
      //     );
      //   }
      // }
    },
    // // 处理打开Dialog事件
    // handleOpened() {
    //   this.$emit('setDefaultSelected', this.$refs.multipleTable, this.tables);
    // },
    // 清除勾选
    clearSelected() {
      this.$refs.multipleTable.clearSelection();
      this.addRows = [];
    },
    // 获取列表数据
    async getListData() {
      const self = this;
      const res = await request({
        url: self.requestListUrl,
        method: 'POST',
        data: self.requestListParam,
      });
      if (res) {
        this.total = res.recNum;
        if (self.responseListFormat) {
          self.tables = self.responseListFormat(res);
        } else {
          self.tables = res;
        }
      }
      this.total = res.recnum;
      this.currentSize =
        this.pageSize * this.page >= this.total
          ? this.total
          : this.page * this.pageSize;
    },
    handleSelectionChange(selection, row) {
      // console.log('vvv');
      // console.log(selection);
      // console.log(this.tables.filter((t) => t === row).length);
      // console.log(this.tables.filter((t) => t === row));
      // for (let i = 0; i < this.tables.filter((t) => t === row).length; i++) {
      //   if (
      //     selection.length != '0' &&
      //     this.tables.filter((t) => t === row)[i].departmentAberrantData &&
      //     this.tables.filter((t) => t === row)[i].departmentAberrantData != ''
      //   ) {
      //     this.$message.error(
      //       '代理人信息异常，请用户登录中国ETC服务小程序修改经办人'
      //     );
      //   }
      // }
      // 清除所有选中
      this.$refs.multipleTable.clearSelection();
      if (selection.length === 0) return;
      // 将当前点击项选中
      this.$refs.multipleTable.toggleRowSelection(row, true);
    },
    onSelectAll() {
      this.$refs.multipleTable.clearSelection();
    },
    // 根据columns生成表格的列
    createColumns() {},
  },
  watch: {
    cvisible() {
      this.$emit('update:visible', this.cvisible);
      // if (!this.cvisible) this.clearSelected();
    },
    visible() {
      this.cvisible = this.visible;
    },
  },
  async mounted() {
    await this.getListData();
    // this.filterDefaultValue();
  },
};
</script>
<style>
.el-table .DisableSelection .cell .el-checkbox__inner {
  display: none;
  position: relative;
}
</style>