<!-- 表格 -->
<template>
  <el-row class="offline-table">
    <el-col
      class="offline-table_td o-flex o-flex-align-center"
      v-for="(td, i) in info"
      :key="i"
      :md="info.length % 2 === 1 && i === info.length - 1 ? 24 : 12"
    >
      <div class="offline-table_label o-flex o-flex-align-center">
        <span>{{ td.label }}</span>
      </div>
      <div class="offline-table_value o-flex-1">{{ td.value }}</div>
    </el-col>
  </el-row>
</template>

<script>
export default {
  data() {
    return {};
  },
  props: {
    info: {},
  },
};
</script>
<style lang="scss"></style>
