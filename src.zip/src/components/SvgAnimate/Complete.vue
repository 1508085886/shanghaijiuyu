<!--  -->
<template>
  <svg class="offline-animate-svg-done" :style="{width: size, height: size}" viewBox="0 0 52 52">
    <circle class="offline-animate-svg-circle" cx="26" cy="26" r="25" fill="none" />
    <path class="offline-animate-svg-check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8" />
  </svg>
</template>

<script>
export default {
  props: {
    size: {
      type: Number,
      default: 46,
    },
  },
};
</script>
