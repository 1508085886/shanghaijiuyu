import Complete from './Complete.vue'
import Error from './Error.vue'

export const CompleteSvg = Complete
export const ErrorSvg = Error