<!--  -->
<template>
  <svg class="offline-animate-svg-error" :style="{width: size, height: size}" viewBox="0 0 52 52">
    <circle class="offline-animate-svg-circle" cx="26" cy="26" r="25" fill="none" />
    <path class="offline-animate-svg-line" fill="none" d="M17.36,34.736l17.368-17.472" />
    <path class="offline-animate-svg-line" fill="none" d="M34.78,34.684L17.309,17.316" />
  </svg>
</template>

<script>
export default {
  props: {
    size: {
      type: Number,
      default: 46,
    },
  },
};
</script>
