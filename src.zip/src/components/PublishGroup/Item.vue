<!-- 发行列表 -->
<template>
  <div class="offline-publish-group-item o-flex o-flex-align-center mt30">
    <div class="offline-publish-group-item_card-number">沪A301029</div>
    <div class="offline-publish-group-item_process o-flex-1">
      <span
        :class="[
          `offline-publish-group-item_process-${i + 1}`,
          { 'is-active': i < step },
        ]"
        v-for="(p, i) in process"
        :key="i"
        >{{ p }}</span
      >
    </div>
    <div :class="['offline-publish-group-item_status', status.class]">
      {{ status.text }}
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      process: ['卡片发行准备', '卡片发行', '发行准备', '标签发行'],
      statuses: [
        {
          class: 'is-wating',
          text: '等待中',
        },
        {
          class: 'is-publishing',
          text: '发行中',
        },
        {
          class: 'is-completed',
          text: '已完成',
        },
      ],
    };
  },
  props: {
    step: {
      type: Number,
      default: 0,
    },
  },
  computed: {
    status() {
      const step = this.step;
      if (step < 1) {
        return this.statuses[0];
      } else if (step < 4) {
        return this.statuses[1];
      } else {
        return this.statuses[2];
      }
    },
  },
};
</script>
<style lang='scss'>
</style>