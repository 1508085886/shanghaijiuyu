<!-- 发行组 -->
<template>
  <div class="offline-publish-group">
    <div class="offline-publish-group_head">
      <template v-if="isUpload">
        <img src="../../assets/images/loading.gif" />
        <span>正在发行...(1/3)</span>
      </template>
      <template v-else>
        <complete-svg />
        <span>发行成功(3/3)</span>
      </template>
    </div>
    <br />
    <slot></slot>
  </div>
</template>

<script>
import { CompleteSvg } from '@/components/SvgAnimate';

export default {
  data() {
    return {
      isUpload: true,
    };
  },
  components: {
    CompleteSvg,
  },
};
</script>
<style lang='scss'>
</style>