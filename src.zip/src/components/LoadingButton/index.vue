<!-- 反色按钮 -->
<template>
  <!-- :disabled="disabled" -->
  <el-button
    :size="size"
    :type="type"
    :round="round"
    :plain="plain"
    :circle="circle"
    :loading="btnLoading"
    :disabled="disabled"
    :icon="icon"
    :autofocus="autofocus"
    :nativeType="nativeType"
    @click="clickHandle"
  >
    <!-- plain -->
    <!-- class="offline-empty-button" -->
    <slot></slot>
  </el-button>
</template>

<script>
export default {
  name: 'LoadingButton',
  data() {
    return {
      btnLoading: false,
      noLoading: false,
    };
  },
  props: {
    size: {},
    type: {},
    round: {},
    plain: {},
    circle: {},
    loading: {},
    // disabled: {},
    icon: {},
    autofocus: {},
    clickNoLoading: {}, // 点击但不触发Loading
    nativeType: {},
    disabled: {},
  },
  watch: {
    loading: {
      handler(val) {
        this.btnLoading = val;
      },
      immediate: true,
    },
    clickNoLoading(val) {
      if (val) {
        this.noLoading = true;
        console.log('noLoading-noLoading', this.noLoading);
      }
    },
  },
  methods: {
    clickHandle(e) {
      console.log('clickHandle-clickHandleclickHandleclickHandleclickHandle');
      if (!this.noLoading) {
        this.$store.commit('SET_BTNSTATE', this);
      }
      // this.btnLoading = true;
      this.$emit('click', e);
    },
  },
};
</script>
