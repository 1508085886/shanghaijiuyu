<!-- 账户详情 -->
<template>
    <div class="offline-UseraccList_block">
        <el-form :model="formData" class="offline-UseraccList_block-form">
            <el-row :gutter="20">
                <el-row :gutter="20" class="offline-UseraccList_mb6">
                    <el-col :span='6' class="o-font-family form-text ">账户编号:</el-col>
                    <el-col :span='18' class="o-font-family form-text ">账户名称（开票抬头）：</el-col>
                    </el-col>
                </el-row>
                <el-row class="offline-UseraccList_mb16">
                    <el-col :span='6' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.userAcctid" style="width:331px">
                        </el-input>
                    </el-col>
                    <el-col :span='10' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.accountAlias" style="width:600px">
                        </el-input>
                    </el-col>
                    <el-col :span='2' class="o-font-family form-text offline-UseraccList_checkbox">
                        <el-checkbox v-model="formData.smsNotify" :disabled="readonly">短信通知
                        </el-checkbox>
                    </el-col>
                    <el-col :span='6' class="o-font-family form-text ">
                        <div class="el-col_text">短信通知号码</div>
                        <el-input :readonly="readonly" v-model="formData.smsNumber"
                            style="width:222px;margin-left: 10px">
                        </el-input>
                    </el-col>
                </el-row>
                <el-row class="offline-UseraccList_border"></el-row>
                <el-row :gutter="20" class="offline-UseraccList_mt16 offline-UseraccList_mb6">
                    <el-col :span='12' class="o-font-family form-text ">账户类型:</el-col>
                    <el-col :span='12' class="o-font-family form-text " style="padding: 0px 0px;">账户状态:</el-col>
                    </el-col>
                </el-row>
                <el-row class="offline-UseraccList_mb16">
                    <el-col :span='12' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="useracctType" style="width:600px">
                        </el-input>
                    </el-col>
                    <el-col :span='12' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="useracctStatus" style="width:600px">
                        </el-input>
                    </el-col>
                </el-row>
                <el-row class="offline-UseraccList_border"></el-row>
                <el-row :gutter="20" class="offline-UseraccList_mb6 offline-UseraccList_mt16">
                    <el-col :span='6' class="o-font-family form-text ">绑定签约渠道:</el-col>
                    <el-col :span='9' class="o-font-family form-text pd00">签约号:</el-col>
                    <el-col :span='5' class="o-font-family form-text pd00 " style="padding: 0px 0px;width: 350px;">
                        是否代扣充值：</el-col>
                    <el-col :span='4' class="o-font-family form-text pd00" style="padding: 0px 0px;">代扣充值金额：</el-col>
                </el-row>
                <el-row class="offline-UseraccList_mb16">
                    <el-col :span='6' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.paychannelName" style="width:331px">
                        </el-input>
                    </el-col>
                    <el-col :span='9' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.buyId" style="width:600px">
                        </el-input>
                    </el-col>
                    <el-col :span='5' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.dkFlag" style="width:222px">
                        </el-input>
                    </el-col>
                    <el-col :span='4' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.dkamount" style="width:222px">
                        </el-input>
                    </el-col>
                </el-row>
                <el-row class="offline-UseraccList_border"></el-row>
                <el-row :gutter="20" class="offline-UseraccList_mb6 offline-UseraccList_mt16">
                    <el-col :span='4' class="o-font-family form-text ">账户余额:</el-col>
                    <el-col :span='5' class="o-font-family form-text ">圈存余额:</el-col>
                    <el-col :span='5' class="o-font-family form-text " style="padding: 0px 5px;">挂账金额：</el-col>
                    <el-col :span='5' class="o-font-family form-text " style="padding: 0px 0px;width: 350px;">可用余额：
                    </el-col>
                    <el-col :span='4' class="o-font-family form-text " style="padding: 0px 0px;">待确认金额：</el-col>
                </el-row>
                <el-row class="offline-UseraccList_mb16">
                    <el-col :span='4' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.balance" style="width:222px">
                        </el-input>
                    </el-col>
                    <el-col :span='5' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.consumeLimit" style="width:222px">
                        </el-input>
                    </el-col>
                    <el-col :span='5' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.creditfee" style="width:222px">
                        </el-input>
                    </el-col>
                    <el-col :span='5' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.ratedBalance" style="width:222px">
                        </el-input>
                    </el-col>
                    <el-col :span='4' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.susTxnfee" style="width:222px">
                        </el-input>
                    </el-col>
                </el-row>
                <el-row class="offline-UseraccList_border"></el-row>
                <el-row :gutter="20" class="offline-UseraccList_mt16 offline-UseraccList_mb6">
                    <el-col :span='12' class="o-font-family form-text ">消费限额:</el-col>
                    <el-col :span='12' class="o-font-family form-text " style="padding: 0px 0px;">警告限额:</el-col>
                    </el-col>
                </el-row>
                <el-row class="offline-UseraccList_mb16">
                    <el-col :span='12' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.overLimit" style="width:600px">
                        </el-input>
                    </el-col>
                    <el-col :span='12' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.noticeLimit" style="width:600px">
                        </el-input>
                    </el-col>
                </el-row>
                <el-row class="offline-UseraccList_border"></el-row>
                <el-row :gutter="20" class="offline-UseraccList_mt16 offline-UseraccList_mb6">
                    <el-col :span='9' class="o-font-family form-text ">纳税人识别号:</el-col>
                    <el-col :span='6' class="o-font-family form-text " style="padding: 0px 0px;">开户行:</el-col>
                    </el-col>
                    <el-col :span='9' class="o-font-family form-text " style="padding: 0px 0px;">开户银行账号:</el-col>
                    </el-col>
                </el-row>
                <el-row class="offline-UseraccList_mb16">
                    <el-col :span='9' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.taxno" style="width:600px">
                        </el-input>
                    </el-col>
                    <el-col :span='6' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.taxbankName" style="width:331px">
                        </el-input>
                    </el-col>
                    <el-col :span='6' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.taxBankacct" style="width:331px">
                        </el-input>
                    </el-col>
                    <el-col :span='3' class="o-font-family form-text ">
                        <el-checkbox v-model="formData.dzfpFlag" class="offline-UseraccList_checkbox"
                            :disabled="readonly">交通部平台开票
                        </el-checkbox>
                    </el-col>
                </el-row>
                <el-row class="offline-UseraccList_border"></el-row>
                <el-row :gutter="20" class="offline-UseraccList_mt16 offline-UseraccList_mb6">
                    <el-col :span='6' class="o-font-family form-text ">创建日期:</el-col>
                    <el-col :span='6' class="o-font-family form-text ">注销日期:</el-col>
                    </el-col>
                    <el-col :span='6' class="o-font-family form-text " style="padding: 0px 0px;">结清日期:</el-col>
                    </el-col>
                </el-row>
                <el-row class="offline-UseraccList_mb16">
                    <el-col :span='6' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.createDate" style="width:331px">
                        </el-input>
                    </el-col>
                    <el-col :span='6' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.cancelDate" style="width:331px">
                        </el-input>
                    </el-col>
                    <el-col :span='6' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.castDate" style="width:331px">
                        </el-input>
                    </el-col>
                </el-row>
                <el-row class="offline-UseraccList_border"></el-row>
                <el-row :gutter="20" class="offline-UseraccList_mt16 offline-UseraccList_mb6">
                    <el-col :span='6' class="o-font-family form-text ">备注:</el-col>
                </el-row>
                <el-row class="offline-UseraccList_mb16">
                    <el-col :span='24' class="o-font-family form-text">
                        <el-input :readonly="readonly" v-model="formData.note">
                        </el-input>
                    </el-col>
                </el-row>
            </el-row>
        </el-form>
    </div>
</template>

<script>
    import {
        dicKeys,
        getAllDics,
        getDicDesByCode,
        getDicCodeByDes,
        getDicCodeByAll,
        getDicDesByAll,
    } from '@/methods/dics';
    import { getFormatAmount, getFormatAmountYuan2Fen, getDatePoint, getTimePoint } from '@/utils/utils';
    export default {
        data() {
            return {
                useracctStatus: '',
                useracctType: '',
                formData: {

                }
            };
        },
        props: {
            form: {
                type: Object,
                default: () => { },
            },
            readonly: {
                default: true,
                type: Boolean,
            }
        },
        watch: {
            form: {
                deep: true,
                handler() {
                    this.inertData();
                },
            },
        },
        computed: {

        },
        components: {

        },
        methods: {
            async inertData() {
                console.log(this.form)
                this.formData = { ...this.form }
                if (this.form.smsNotify === '1') {
                    this.formData.smsNotify = true
                }
                if (this.form.dzfpFlag === '1') {
                    this.formData.dzfpFlag = true
                }
                this.useracctType = await getDicDesByCode(
                    dicKeys.useracctType,
                    this.formData.useracctType
                );
                this.useracctStatus = await getDicDesByCode(
                    dicKeys.useracctStatus,
                    this.formData.useracctStatus
                );
                this.formData.dkamount = getFormatAmount(this.formData.dkamount);
                this.formData.balance = getFormatAmount(this.formData.balance);
                this.formData.creditfee = getFormatAmount(this.formData.creditfee);
                this.formData.ratedBalance = getFormatAmount(this.formData.ratedBalance);
                this.formData.susTxnfee = getFormatAmount(this.formData.susTxnfee);
                this.formData.consumeLimit = getFormatAmount(this.formData.consumeLimit);
                this.formData.createDate = getTimePoint(this.formData.createDate);
                this.formData.cancelDate = getTimePoint(this.formData.cancelDate);
                this.formData.castDate = getTimePoint(this.formData.castDate);
            }
        },
        mounted() {
            this.inertData();
        }
    };
</script>