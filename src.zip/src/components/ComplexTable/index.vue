<!-- 复杂表格，传入获取数据地址，新增地址 -->
<template>
  <o-dialog
    :visible.sync="cvisible"
    :title="title"
    class="offline-complex-table"
    size="large"
    :append-to-body="appendToBody"
    @opened="defaultShow"
  >
    <div class="offline-complex-table_container">
      <!-- <el-button @click="addNewRow" size="small">
        <i class="el-icon-plus"></i>
        新增{{ title }}
      </el-button> -->
      <el-table
        ref="multipleTable"
        :data="tables"
        tooltip-effect="dark"
        style="width: 100%"
        @select="handleSelectionChange"
        @select-all="onSelectAll"
      >
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column
          :prop="column.filed"
          :label="column.name"
          v-for="(column, i) in columns"
          :key="column.filed + i"
        >
          <template slot-scope="scope">
            <span v-if="column.format">
              {{ column.format(scope.row[column.filed]) }}
            </span>
            <span v-else>{{ scope.row[column.filed] }}</span>
          </template>
        </el-table-column>
      </el-table>
      <el-table
        :show-header="false"
        ref="addMultipleTable"
        :data="addRows"
        tooltip-effect="dark"
        style="width: 100%"
        v-show="addRows.length"
        class="offline-complex-table_add-table"
      >
        <el-table-column width="55"></el-table-column>
        <el-table-column
          :prop="column.filed"
          :label="column.name"
          v-for="(column, i) in columns"
          :key="column.filed + i"
        >
          <template slot-scope="scope">
            <el-input
              v-if="column.edit"
              v-model="scope.row[column.filed]"
              placeholder="请输入内容"
            ></el-input>
            <span v-else>{{ column.default }}</span>
          </template>
        </el-table-column>
        <el-table-column class="offline-complex-table_save-btn" width="57">
          <template slot-scope="scope">
            <el-button size="mini" @click="saveItem(scope.row)">保存</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-pagination
        background
        @current-change="handleCurrentChange"
        :current-page.sync="currentPage"
        :page-size="10"
        layout="total,->,prev, pager, next,slot"
        :total="total"
      >
      </el-pagination>
      <el-button @click="cvisible = false">取 消</el-button>
      <el-button type="primary" @click="getAllSelectRow">确 定</el-button>
    </div>
  </o-dialog>
</template>

<script>
import ODialog from '../Dialog';
import request from '@/utils/request';
import { branchQuery } from '@/api/common';
export default {
  data() {
    return {
      total: 0, //总条数
      tables: [],
      currentPage: 1,
      cvisible: false,
      addRows: [],
      firstLoad: true,
      defaultValues: [],
    };
  },
  components: {
    ODialog,
  },
  props: {
    title: {
      default: '',
      required: true,
    },
    visible: {
      type: Boolean,
      required: true,
    },
    requestListUrl: {
      type: String,
      required: true,
    },
    requestListParam: {
      default() {
        return {};
      },
      type: Object,
    },
    responseListFormat: {
      type: Function,
    },
    columns: {
      type: Array,
      required: true,
    },
    insertListUrl: {
      require: true,
      type: String,
    },
    appendToBody: {
      type: Boolean,
    },
    /**
     * [{ filed: 'agentIdNum', value: '76543234' }],
     * [{ filed: 'agement', value: ['销售部', '技术部'] }]
     */
    defaultValue: {
      type: Array,
    },
  },
  methods: {
    ////////////////////////////////////////////////////
    async handleCurrentChange(val) {
      // 当前为第几页时调用getTabelInfo()显示第几页数据
      // this.page = val;
      // this.currentPage = val;
      // this.getTabelInfo();
      // console.log(`当前页: ${val}`);
      // this.pageSize = 5;

      // const pagenum = (val - 1) * 5 + 1;
      this.currentPage = val;
      const pagenum = val;
      const self = this;
      const res = await branchQuery({
        etcUserId: self.requestListParam.etcUserId,
        pageNo: pagenum,
        pageSize: 10,
      });
      console.log('res');
      console.log(res);
      if (res) {
        self.tables = self.responseListFormat(res);
        this.total = res.recNum;
      }
    },
    async resume() {
      const self = this;
      const res = await request({
        url: self.requestListUrl,
        method: 'POST',
        data: self.requestListParam,
      });
      if (res) {
        if (self.responseListFormat) {
          self.tables = self.responseListFormat(res);
        } else {
          self.tables = res;
        }
      }
    },
    ////////////////////////////////////////////////////
    // 显示默认数据
    defaultShow() {
      if (!this.firstLoad) return;
      this.firstLoad = false;
      this.defaultValues.forEach((v) => {
        this.$refs.multipleTable.toggleRowSelection(v, true);
      });
    },
    // 过滤默认显示数据
    filterDefaultValue() {
      const defaultVal = this.defaultValue;
      const values = [];
      if (!defaultVal) {
        return;
      }
      if (defaultVal.length) {
        for (let i = 0; i < defaultVal.length; i++) {
          if (typeof defaultVal[i].value === 'string') {
            this.tables
              .filter((t) => defaultVal[i].value === t[defaultVal[i].filed])
              .forEach((t) => {
                values.push(t);
              });
          } else if (defaultVal[i].value instanceof Array) {
            defaultVal[i].value.forEach((d) => {
              this.tables
                .filter((t) => d === t[defaultVal[i].filed])
                .forEach((t) => {
                  values.push(t);
                });
            });
          }
        }
      } else {
        values.push(this.tables[0]);
      }
      this.defaultValues = values;
      console.log('默认值');
      console.log(this.defaultValues);
      for (let i = 0; i < this.defaultValues.length; i++) {
        if (
          this.defaultValues[i].departmentAberrantData &&
          this.defaultValues[i].departmentAberrantData != ''
        ) {
          this.$message.error(
            '代理人信息异常，请用户登录中国ETC服务小程序修改经办人'
          );
        }
      }
      this.$emit('getSelected', values);
    },
    // 点击新增列表的保存
    async saveItem(item) {
      const self = this;
      const res = await request({
        url: self.insertListUrl,
        method: 'POST',
        data: item,
      });
      if (res) {
        // 更新列表
        self.getListData();
        // 清除在addRows中的数据
        self.removeNewRow(item);
      }
    },
    removeNewRow(item) {
      const self = this;
      const index = self.addRows.findIndex((row) => row === item);
      if (index > -1) {
        self.addRows.splice(index, 1);
      }
    },
    // 点击新增
    addNewRow() {
      const self = this;
      const row = {};
      for (let i = 0; i < self.columns.length; i++) {
        if (self.columns[i].default !== undefined) {
          row[self.columns[i].filed] = self.columns[i].default;
        } else {
          row[self.columns[i].filed] = '';
        }
      }
      self.addRows.push(row);
    },
    // 获取所有被勾选的项
    getAllSelectRow() {
      this.$emit('getSelected', this.$refs.multipleTable.selection);
      if (this.$refs.multipleTable.selection.length == '0') {
        this.$message.error('请选择分支机构');
      }
      for (let i = 0; i < this.$refs.multipleTable.selection.length; i++) {
        if (!this.$refs.multipleTable.selection[i].departmentAberrantData) {
          this.cvisible = false;
        } else {
          this.$message.error(
            '代理人信息异常，请用户登录中国ETC服务小程序修改经办人'
          );
        }
      }
    },
    // // 处理打开Dialog事件
    // handleOpened() {
    //   this.$emit('setDefaultSelected', this.$refs.multipleTable, this.tables);
    // },
    // 清除勾选
    clearSelected() {
      this.$refs.multipleTable.clearSelection();
      this.addRows = [];
    },
    // 获取列表数据
    async getListData() {
      const self = this;
      const res = await request({
        url: self.requestListUrl,
        method: 'POST',
        data: self.requestListParam,
      });
      console.log('aberrantData');
      console.log(res);
      if (res) {
        this.total = res.recNum;
        if (self.responseListFormat) {
          self.tables = self.responseListFormat(res);
        } else {
          self.tables = res;
        }
      }
    },
    handleSelectionChange(selection, row) {
      console.log('vvv');
      console.log(selection);
      console.log(this.tables.filter((t) => t === row).length);
      console.log(this.tables.filter((t) => t === row));
      for (let i = 0; i < this.tables.filter((t) => t === row).length; i++) {
        if (
          selection.length != '0' &&
          this.tables.filter((t) => t === row)[i].departmentAberrantData &&
          this.tables.filter((t) => t === row)[i].departmentAberrantData != ''
        ) {
          this.$message.error(
            '代理人信息异常，请用户登录中国ETC服务小程序修改经办人'
          );
        }
      }
      // 清除所有选中
      this.$refs.multipleTable.clearSelection();
      if (selection.length === 0) return;
      // 将当前点击项选中
      this.$refs.multipleTable.toggleRowSelection(row, true);
    },
    onSelectAll() {
      this.$refs.multipleTable.clearSelection();
    },
    // 根据columns生成表格的列
    createColumns() {},
  },
  watch: {
    cvisible() {
      this.$emit('update:visible', this.cvisible);
      // if (!this.cvisible) this.clearSelected();
    },
    visible() {
      this.cvisible = this.visible;
    },
  },
  async mounted() {
    await this.getListData();
    this.filterDefaultValue();
  },
};
</script>
