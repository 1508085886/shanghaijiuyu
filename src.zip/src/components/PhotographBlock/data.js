import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';
import types from '@/config/picType';

/**
 * @description 获取证件类型数据
 * @param {string} type 证件类型
*/
export default async (type, flag) => {
  let arrs = []
  const maps = {
    person: [],
    company: [],
    normal: []
  }
  if (dicKeys[type]) {
    arrs = await getAllDics(type)
  } else {
    arrs = []
  }
  arrs.forEach(item => {
    if (types[item.value]) {
      const key = flag && types[item.value].belong || 'normal'
      const chooseList = []
      if (types[item.value].multiple) {

        if (types[item.value].multiple instanceof Array) {
          types[item.value].multiple.forEach((mul, index) => {
            chooseList.push({ description: mul.label, value: `${item.value}-${mul.value || (index + 1)}` })
          })
        } else {
          chooseList.push({ description: '正面', value: `${item.value}-1` })
          chooseList.push({ description: '背面', value: `${item.value}-2` })
        }
      } else {
        chooseList.push({ description: '正面', value: `${item.value}-1` })
      }
      maps[key].push({
        description: item.description,
        value: item.value,
        chooseList
      })
    }
  })
  return maps
}
