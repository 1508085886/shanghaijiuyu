<!-- 拍照识别块 -->
<template>
  <div class="offline-photograph-block o-flex o-flex-wrap">
    <template v-if="!isButton || onlyPics">
      <div
        class="offline-photograph-block_result mb20"
        v-for="(img, index) in imgUrls"
        :key="img.type + '' + index"
        :style="{ backgroundImage: `url(${img.url})` }"
      >
        <div
          class="
            offline-photograph-block_result-cover
            o-flex o-flex-align-center o-flex-justify-center
          "
        >
          <span class="offline-photograph-block_result-cover-bg"></span>
          <i class="el-icon-zoom-in mr20" @click="openBigPic(img)"></i>
          <i class="el-icon-delete" v-if="!noEdit" @click="deletePic(img)"></i>
          <el-image
            class="offline-photograph-block_big-review"
            :src="img.url"
            :preview-src-list="[img.url]"
          >
          </el-image>
        </div>
      </div>
      <div
        class="
          o-flex o-flex-align-center o-flex-justify-center o-height-full
          offline-photograph-block_container
        "
        @click="visible = true"
        :style="styles"
        v-if="!onlyPics && showBlock"
      >
        <div>
          <i class="icon iconfont iconxiangji"></i>
          <p>{{ title }}</p>
        </div>
      </div>
    </template>
    <el-button
      v-else
      @click="onlyButton"
      :disabled="isButtonDisabled"
      size="small"
      round
      :loading="oloading"
      class="offline-photograph-button"
    >
      <i class="el-icon-camera-solid" />
      &ensp; {{ label }}
      <input
        :disabled="isButtonDisabled"
        v-if="defaultType && noSelect === 'local'"
        type="file"
        title="本地上传"
        ref="localFile"
        class="offline-photograph-block_choose-local-image"
        accept="image/jpg, image/jpeg, image/png"
        @change="chooseLocalPic($event)"
      />
    </el-button>
    <o-dialog
      title="证件上传"
      :visible.sync="visible"
      :append-to-body="appendToBody"
      v-if="!onlyPics"
    >
      <div class="o-flex mt20">
        <div class="o-flex-1 ml30 mr30" v-if="normal.length > 0">
          <item
            v-for="item in normal"
            :key="item.value"
            :title="item.description"
            :chooseList="item.chooseList"
            class="offline-photograph-block_type-item"
            :selected.sync="selected"
            @change="getRadioVal(item.value)"
          />
        </div>
        <template v-else>
          <div class="o-flex-1 ml30 mr30" v-if="person.length != '0'">
            <h4 class="offline-photograph-block_title">个人用户 有效证件</h4>
            <item
              v-for="item in person"
              :key="item.value"
              :title="item.description"
              :chooseList="item.chooseList"
              class="offline-photograph-block_type-item"
              :selected.sync="selected"
              @change="getRadioVal(item.value)"
            />
          </div>
          <div class="o-flex-1 ml30 mr30" v-if="company.length != '0'">
            <h4 class="offline-photograph-block_title">单位用户 有效证件</h4>
            <item
              v-for="item in company"
              :key="item.value"
              :title="item.description"
              :chooseList="item.chooseList"
              class="offline-photograph-block_type-item"
              :selected.sync="selected"
            />
          </div>
        </template>
      </div>
      <div class="text-center mt30 mb30">
        <el-button
          class="mr20 offline-photograph-block_button"
          :disabled="!selected"
          :loading="loading"
          @click="$isPad ? takePadPhoto() : false"
        >
          <i class="icon iconfont iconshangchuan"></i>本地上传
          <input
            :type="$isPad ? '' : 'file'"
            title="本地上传"
            ref="localFile"
            class="offline-photograph-block_choose-local-image"
            @change="chooseLocalPic($event)"
            accept="image/jpg, image/jpeg, image/png"
            :disabled="!selected"
          />
        </el-button>
        <el-button
          type="primary"
          :disabled="!selected"
          @click="togpy"
          :loading="loading"
        >
          <i class="el-icon-camera-solid"></i>拍照上传
        </el-button>
      </div>
    </o-dialog>
  </div>
</template>

<script>
import ODialog from '../Dialog';
import Item from './item';
import getDataByType from './data';
import { mediaUpload } from '@/api/common';
import { ocrRequest } from '@/api/ocr';
import picTypes from '@/config/picType';
// import { image } from 'html2canvas/dist/types/css/types/image';

const allTypes = {
  // 用户证件
  userCertType: {
    dic: 'userCertType',
    haveTypes: true,
  },
  // 个人用户证件
  userCertTypeP: {
    dic: 'userCertTypeP',
    haveTypes: true,
  },
  userCertTypeC: {
    dic: 'userCertTypeC',
    haveTypes: true,
  },
  // 车主证件
  OwnerCertType: {
    dic: 'userCertType',
    haveTypes: true,
  },
  // 车辆证件
  vehicleCertType: {
    dic: 'vehicleCertType',
    haveTypes: false,
  },
  // 经办人证件类型
  agentCertType: {
    dic: 'agentCertType',
    haveTypes: false,
  },
  // 业务凭证
  voucherType: {
    dic: 'voucherType',
    haveTypes: false,
  },
  // 业务核验证件
  verificationType: {
    dic: 'verificationType',
  },
  // 银行
  bankCardType: {
    dic: 'bankCardType',
  },
};
let _choosePhotoCallbackName = '';

export default {
  data() {
    return {
      fn: {},
      // isPad: false,
      padChooseImgUrl: '',
      loading: false,
      visible: false,
      selected: '',
      imgUrls: [],
      normal: [],
      person: [],
      company: [],
    };
  },
  props: {
    noEdit: {
      type: Boolean,
      default: false,
    },
    oloading: {
      type: Boolean,
      default: false,
    },
    isButtonDisabled: {
      type: Boolean,
      default: false,
    },
    onlyPics: {
      type: Boolean,
    },
    noSelect: {
      type: String,
    },
    defaultType: {
      type: String,
    },
    isButton: {
      type: Boolean,
    },
    label: {
      default: '拍照识别',
      type: String,
    },
    width: {
      default: 0,
    },
    height: {
      default: 0,
    },
    title: {
      type: String,
      default: '证件上传',
    },
    // 确定显示的选项类型
    type: {
      validator(val) {
        return !val || !!allTypes[val];
      },
    },
    // 是否需要ocr识别
    ocr: {
      type: Boolean,
    },
    appendToBody: {
      default: false,
      type: Boolean,
    },
    defaultPics: {
      type: Array,
    },
    picsMaxLength: {
      // 照片最大张数
      type: Number,
    },
    choosePhotoCallbackName: {
      type: String,
    },
  },
  computed: {
    styles() {
      const style = {};
      if (this.width) {
        style.width = this.width + 'px';
      }
      if (this.height) {
        style.height = this.height + 'px';
      }
      return style;
    },
    showBlock() {
      // 是否显示初始化照片块
      if (this.noEdit) {
        return false;
      }
      if (this.picsMaxLength) {
        return !this.imgUrls.length || this.imgUrls.length < this.picsMaxLength;
      } else {
        return true;
      }
    },
  },
  components: {
    ODialog,
    Item,
  },
  watch: {
    defaultPics: {
      immediate: true,
      handler() {
        this.imgUrls = this.defaultPics || [];
      },
    },
    loading() {
      this.$emit('update:oloading', this.loading);
    },
    // visible(val) {
    //   if (val) {
    //     this.init();//用于解决搜索栏证件上传userCertType需要根据用户类型变化不起作用问题
    //   }
    // },
  },
  created() {
    _choosePhotoCallbackName = this.choosePhotoCallbackName;
  },
  mounted() {
    this.init();
    /*PAD端兼容代码*/
    if (this.$isPad) {
      let self = this;
      this.$set(this.fn, this.choosePhotoCallbackName, function (webImageBean) {
        self.padChooseImgUrl = webImageBean.base64;
        self.chooseLocalPic();
      });
      window[this.choosePhotoCallbackName] =
        this.fn[this.choosePhotoCallbackName];
    }
  },
  methods: {
    // 按钮形式的组件
    onlyButton() {
      const self = this;
      if (!self.noSelect) {
        self.visible = true;
        return;
      } else if (self.noSelect === 'gpy' && self.defaultType) {
        this.togpy();
      }
    },
    // 初始化
    init() {
      if (!this.onlyPics) {
        // 初始化selected
        this.initSelected();
        if (!this.noSelect) {
          // 根据类型加载选项列表
          this.getItemsByType();
        }
      }
    },
    // 初始化selected
    initSelected() {
      if (this.defaultType) {
        this.selected =
          this.defaultType.slice(0, -1) + '-' + this.defaultType.slice(-1);
      }
    },
    // 根据类型加载选项列表
    async getItemsByType() {
      const maps = await getDataByType(
        allTypes[this.type].dic,
        allTypes[this.type].haveTypes
      );
      this.normal = maps.normal;
      this.person = maps.person;
      this.company = maps.company;
    },

    // 删除图片
    deletePic(pic) {
      const self = this;
      console.log('this.imgUrls', this.imgUrls);
      const index = this.imgUrls.findIndex((img) => img === pic);
      this.imgUrls.splice(index, 1);
      self.$emit('complete', this.imgUrls);
      // self.$emit('delimageList', 'pic');
    },

    openBigPic(pic) {
      // alert(pic);
      // const index = this.imgUrls.findIndex((img) => img === pic);
      // this.imgUrls.splice(index, 1);
    },
    // // 插入图片
    // insertPic(pic) {
    //   // 判断该类型图片是否已经存在，存在则替换，不存在则新增
    //   const oIndex = this.imgUrls.findIndex(
    //     (img) => img.type === this.selected
    //   );
    //   if (oIndex > -1) {
    //     this.imgUrls[oIndex].url = pic;
    //   } else {
    //     this.imgUrls.push({
    //       url: pic,
    //       type: this.selected,
    //     });
    //   }
    //   this.visible = false;
    //   this.selected = '';
    // },
    //高拍仪
    async togpy() {
      const self = this;

      // 初始化selected
      this.initSelected();
      const result = eval('(' + etcdev.showhighbeatmeter() + ')');
      //alert(result.code);
      // console.log(result);
      if (result.code == '0') {
        //alert(result.pic);
        const self = this;
        self.loading = true;
        //alert(self.loading);
        let timer = setTimeout(() => {
          self.loading = false;
        }, 10000);
        const img = 'data:image/jpg;base64,' + result.pic;
        // const img = result.pic;
        let getimageid = '';
        // 上传图片
        // const res = await mediaUpload({
        //   fileType: '1',
        //   img: img,
        // });
        // 需要ocr识别
        const selectedItem = self.selected.split('-');
        let ocrRes = null;
        let fileType = '1';
        if (
          self.ocr &&
          picTypes[selectedItem[0]].ocr &&
          picTypes[selectedItem[0]].ocr[selectedItem[1]]
        ) {
          // 执行ocr识别，成功后将识别结果挂载到 imgUrls 上
          ocrRes = await self.ocrRequest({
            url: picTypes[selectedItem[0]].ocr[selectedItem[1]],
            imgType: selectedItem.join(''),
            fileType: '1',
            img: result.pic,
            // img: img,
          });
          if (ocrRes) {
            if (ocrRes.sealPageInnerImgid) {
              getimageid = ocrRes.sealPageInnerImgid;
            } else {
              // let res = await self.mediaUpload(fileType, arr[1]);
              let res = await self.mediaUpload(fileType, result.pic);
              getimageid = (res && res.frontImgid) || '';
            }
          }
        } else {
          let res = await self.mediaUpload(fileType, result.pic);
          getimageid = (res && res.frontImgid) || '';
        }
        clearTimeout(timer);
        self.loading = false;
        //alert(self.loading);
        // 插入图片回显
        // self.insertPic(img);
        if (self.isButton) {
          self.imgUrls = [];
        }
        self.imgUrls.push({
          url: img,
          type: self.selected,
          // frontImgid: res.frontImgid,
          frontImgid: getimageid,
          ocr: ocrRes,
        });
        self.visible = false;
        self.selected = '';
        // alert(this.imgUrls);
        self.$emit('complete', this.imgUrls);
      }

      // }
    },
    // 上传图片
    async mediaUploadFn(fileType, img, call) {
      const self = this;
      let res = await mediaUpload({
        fileType,
        img,
      });
      if (!res) {
        self
          .$confirm('上传图片失败，是否重试?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          })
          .then(() => {
            self.mediaUpload(fileType, img, call);
          })
          .catch((e) => {
            call && call(null);
          });
      } else {
        call && call(res);
      }
      //alert(self.loading);
      self.loading = false;
    },
    // 上传图片
    mediaUpload(fileType, img) {
      const self = this;
      return new Promise((resolve) => {
        self.mediaUploadFn(fileType, img, (res) => {
          resolve(res);
        });
      });
    },
    // ocr识别
    async ocrRequestFn(param, call) {
      const self = this;

      const res = await ocrRequest(param);
      if (res) {
        // if (this.decideOcrReturn(param, res)) {
        call && call(res);
      } else {
        call && call(null);
        self
          .$confirm('识别失败,是否重新识别', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          })
          .then(() => {
            self.ocrRequestFn(param, call);
            call && call(null);
          })
          .catch((e) => {
            call && call(null);
          });
      }
    },

    decideOcrReturn(param, res) {
      if (param.imgType === '1011') {
        if (!res.imgType) {
          return false;
        }
      }
      return true;
    },

    // ocr识别
    ocrRequest(param) {
      const self = this;
      return new Promise((resolve) => {
        self.ocrRequestFn(param, (res) => {
          resolve(res);
        });
      });
    },
    // aaa() {
    //   this.visible = true;
    // },
    takePadPhoto() {
      // 打开相机
      AndroidPic.choosePhoto(this.choosePhotoCallbackName);
    },
    // [_choosePhotoCallbackName](webImageBean) {
    //   this.padChooseImgUrl = webImageBean.base64;
    //   this.chooseLocalPic();
    // },
    // 选择本地图片
    async chooseLocalPic(event) {
      const self = this;
      let timer = setTimeout(() => {
        // this.$message.success('超时');
        self.loading = false;
      }, 10000);
      self.loading = true;
      // 初始化selected
      this.initSelected();
      if (!this.selected) return '';
      const extMaps = {
        jpg: '1',
        JPG: '1',
        PNG: '2',
        png: '2',
      };
      /*PAD端兼容代码*/
      if (this.$isPad) {
        // pad端
        let fileType = '';
        if (this.padChooseImgUrl) {
          // 只允许选择jpg，png格式
          let urlArr = this.padChooseImgUrl.split(',');
          let urlType = urlArr[0].split('/')[1].replace(';base64', '');
          if (extMaps[urlType]) {
            fileType = extMaps[urlType];
          } else {
            clearTimeout(timer);
            self.loading = false;
            return false;
          }
        } else {
          clearTimeout(timer);
          self.loading = false;
          return false;
        }
        let arr = this.padChooseImgUrl.split(',');
        // const img = 'data:image/png;base64,' + arr[1];
        const notimg = arr[1];
        let getimageid = '';
        // 需要ocr识别
        const selectedItem = self.selected.split('-');
        let ocrRes = null;
        if (
          self.ocr &&
          picTypes[selectedItem[0]].ocr &&
          picTypes[selectedItem[0]].ocr[selectedItem[1]]
        ) {
          // 执行ocr识别，成功后将识别结果挂载到 imgUrls 上
          ocrRes = await self.ocrRequest({
            url: picTypes[selectedItem[0]].ocr[selectedItem[1]],
            imgType: selectedItem.join(''),
            fileType,
            img: notimg,
          });
          if (ocrRes) {
            if (ocrRes.sealPageInnerImgid) {
              getimageid = ocrRes.sealPageInnerImgid;
            } else {
              let res = await self.mediaUpload(fileType, notimg);
              getimageid = (res && res.frontImgid) || '';
            }
          }
        } else {
          let res = await self.mediaUpload(fileType, notimg);

          getimageid = (res && res.frontImgid) || '';
        }
        clearTimeout(timer);
        self.loading = false;
        // 插入图片回显
        if (self.isButton) {
          self.imgUrls = [];
        }
        self.imgUrls.push({
          url: this.padChooseImgUrl,
          type: self.selected,
          // frontImgid: res.frontImgid,
          frontImgid: getimageid,
          ocr: ocrRes,
        });
        self.visible = false;
        self.selected = '';
        self.$emit('complete', this.imgUrls);
      } else {
        // web端
        let files = event.target.files[0];
        let name = files.name;
        let arr = name.split('.');
        let fileSize = 0;
        let fileMaxSize = 10240; //1M
        let fileType = '';

        event.target.value = '';

        if (files) {
          fileSize = files.size;
          if (fileSize > 10 * 1024 * 1024) {
            alert('文件大小不能大于10M！');
            file.value = '';
            return false;
          } else if (fileSize <= 0) {
            alert('文件大小不能为0M！');
            file.value = '';
            return false;
          }
          // 只允许选择jpg，png格式
          const namearr = files.name.split('.');
          if (extMaps[namearr[namearr.length - 1]]) {
            fileType = extMaps[namearr[namearr.length - 1]];
          } else {
            clearTimeout(timer);
            self.loading = false;
            return false;
          }
        } else {
          clearTimeout(timer);
          self.loading = false;
          return false;
        }

        //转码base64
        let reader = new FileReader();
        let imgFile;
        reader.readAsDataURL(files);
        reader.onload = async (e) => {
          imgFile = e.target.result;
          let arr = imgFile.split(',');
          const img = 'data:image/png;base64,' + arr[1];
          const notimg = arr[1];
          // const img = arr[1];
          // 上传图片
          // const res = await mediaUpload({
          //   fileType,
          //   img: arr[1],
          // });
          let getimageid = '';
          // 需要ocr识别
          const selectedItem = self.selected.split('-');
          let ocrRes = null;
          if (
            self.ocr &&
            picTypes[selectedItem[0]].ocr &&
            picTypes[selectedItem[0]].ocr[selectedItem[1]]
          ) {
            // 执行ocr识别，成功后将识别结果挂载到 imgUrls 上
            ocrRes = await self.ocrRequest({
              url: picTypes[selectedItem[0]].ocr[selectedItem[1]],
              imgType: selectedItem.join(''),
              fileType,
              img: notimg,
              // img
            });
            if (ocrRes) {
              if (ocrRes.sealPageInnerImgid) {
                getimageid = ocrRes.sealPageInnerImgid;
              } else {
                let res = await self.mediaUpload(fileType, notimg);
                // let res = await self.mediaUpload(fileType, img);
                getimageid = (res && res.frontImgid) || '';
              }
            }
          } else {
            let res = await self.mediaUpload(fileType, notimg);
            // let res = await self.mediaUpload(fileType, img);

            getimageid = (res && res.frontImgid) || '';
          }
          clearTimeout(timer);
          self.loading = false;
          // 插入图片回显
          // self.insertPic(img);
          if (self.isButton) {
            self.imgUrls = [];
          }

          self.imgUrls.push({
            url: img,
            type: self.selected,
            // frontImgid: res.frontImgid,
            frontImgid: getimageid,
            ocr: ocrRes,
          });
          self.visible = false;
          self.selected = '';
          self.$emit('complete', this.imgUrls);
        };
      }
    },
  },
};
</script>
