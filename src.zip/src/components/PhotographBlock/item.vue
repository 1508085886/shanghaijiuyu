<template>
  <div class="o-flex o-flex-align-center">
    <div class="o-flex-1">{{ title }}</div>
    <el-radio
      v-for="item in chooseList"
      :key="item.value"
      v-model="radio"
      :label="item.value"
      >{{ item.description }}</el-radio
    >
  </div>
</template>

<script>
export default {
  data() {
    return {
      radio: '',
    };
  },
  props: {
    title: {
      default: '',
    },
    selected: {
      default: '',
    },
    chooseList: {
      default() {
        return [];
      },
    },
  },
  watch: {
    selected: {
      immediate: true,
      handler(val) {
        this.radio = val;
      },
    },
    radio(val) {
      this.$emit('update:selected', val);
    },
  },
};
</script>
