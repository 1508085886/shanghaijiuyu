<!-- 抽屉 -->
<template>
  <div class="offline-drawer-wrap mt20">
    <div class="offline-drawer-wrap-order">
      <span>{{ order }}</span>
    </div>
    <div class="offline-drawer-wrap-content">
      <div class="offline-drawer-wrap-content-title">{{ title }}</div>
      <div class="offline-drawer-wrap-content-note" v-html="note">
        <!-- {{ note }} -->
      </div>
    </div>
    <!-- <el-button
      :type="type"
      :disabled="btnDisabled"
      :plain="plain"
      :icon="icon"
      @click="$emit('btnClick')"
      class="offline-drawer-wrap-btn"
      >{{ oBtnDesc }}</el-button
    > -->
    <loading-button
      :type="type"
      :disabled="btnDisabled"
      :plain="plain"
      :icon="icon"
      @click="$emit('btnClick')"
      class="offline-drawer-wrap-btn"
      >{{ oBtnDesc }}</loading-button
    >
  </div>
</template>

<script>
import LoadingButton from '@/components/LoadingButton';
export default {
  name: 'Drawer',
  data() {
    return {
      icon: '',
      type: 'primary',
      btnDisabled: false,
      plain: false,
      oBtnDesc: '按钮',
      // state: '',
    };
  },
  props: {
    order: {
      type: Number,
      default: 1,
    },
    title: {
      type: String,
    },
    note: {
      type: String,
    },
    btnState: {
      // 可用：usable，不可用：disable，已完成：complete
      type: String,
      default: 'usable',
    },
    btnDesc: {
      type: String,
      default: '操作',
    },
  },
  components: {
    LoadingButton,
  },
  watch: {
    btnState: {
      handler: function (val) {
        if (val === 'usable') {
          this.type = 'primary';
          this.plain = false;
          this.btnDisabled = false;
        } else if (val === 'disable') {
          this.type = 'primary';
          this.plain = false;
          this.btnDisabled = true;
        } else if (val === 'complete') {
          this.type = '';
          this.plain = true;
          this.btnDisabled = true;
          this.icon = 'el-icon-check'; // 绿色对勾
          this.oBtnDesc = '已完成';
        } else if (val === 'complete2use') {
          this.type = '';
          this.plain = true;
          this.icon = 'el-icon-check'; // 绿色对勾
          this.btnDisabled = false;
          // this.oBtnDesc = '已完成';
        }
      },
      immediate: true,
    },
    btnDesc: {
      handler: function (val) {
        this.oBtnDesc = val;
      },
      immediate: true,
    },
  },
  methods: {},
  mounted() {},
};
</script>
