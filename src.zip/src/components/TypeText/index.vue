<!-- 字典翻译文本 -->
<template>
  <span :is="tag">{{text}}</span>
</template>

<script>
import { dicKeys, getDicDesByCode } from '@/methods/dics';

export default {
  data() {
    return {
      text: '',
    };
  },
  props: {
    type: {
      required: true,
      validator: function (val) {
        return !!dicKeys[val];
      },
    },
    value: {
      required: true,
    },
    tag: {
      default: 'span',
    },
  },
  methods: {
    async getText() {
      this.text = await getDicDesByCode(dicKeys[this.type], this.value);
    },
  },
  mounted() {
    this.getText();
  },
};
</script>
