
<template>
  <!-- 
<message-warning>
    Message({ ...msg, duration: 0, showClose: true, }), :duration="0"
    :showClose="true"
  </message-warning> 
  -->
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {
    function() {
      message({
        ...msg,
        duration: 0,
        showClose: true,
      });
    },
  },

  props: {
    duration: {
      type: String,
    },
    0: {
      type: String,
    },
    true: {
      type: String,
    },
  },
};
</script>
