<!-- 新增分支机构 -->
<template>
  <o-dialog
    :visible.sync="addVisble"
    :title="title"
    class="offline-complex-table"
    size="large"
    :append-to-body="appendToBody"
    @close="closeAdd"
    :showclose="showclose"
  >
    <div style="padding: 0 0 45px 23%; background: #d1d3d8">
      <div style="width: 70%">
        <el-form
          :label-position="labelPosition"
          :model="form"
          :rules="rules"
          ref="form"
          label-width="130px"
          style="
            background: #e5e5ea;
            padding: 20px 10% 20px 12%;
            border: 1px solid #c0c4c9;
          "
        >
          <el-form-item label="代理人证件">
            <photograph-block
              @complete="complete"
              ocr
              width="104"
              height="104"
              type="userCertType"
              :append-to-body="appendToBody"
              style="margin-left: 15%"
              :picsMaxLength="1"
              :defaultPics="imgUser2"
            ></photograph-block>
          </el-form-item>
          <el-form-item
            label="分支机构名称"
            prop="department"
            style="padding-top: 15px"
          >
            <el-input class="branchInput" v-model="form.department"></el-input>
          </el-form-item>
          <el-form-item
            label="代理人姓名"
            prop="agentName"
            style="padding-top: 15px"
          >
            <el-input class="branchInput" v-model="form.agentName"></el-input>
          </el-form-item>
          <el-form-item
            label="代理人证件号"
            prop="agentIdNum"
            style="padding-top: 15px"
          >
            <el-input class="branchInput" v-model="form.agentIdNum"></el-input>
          </el-form-item>
          <el-form-item
            label="代理人证件类型"
            prop="agentIdType"
            style="padding-top: 15px"
          >
            <type-select
              type="agentIdType"
              v-model="form.agentIdType"
              placeholder="请选择"
              class="branchInput"
            />
          </el-form-item>
          <el-form-item
            label="代理人手机号"
            prop="agentPhoneNum"
            style="padding-top: 15px"
          >
            <el-input
              class="branchInput"
              v-model="form.agentPhoneNum"
            ></el-input>
          </el-form-item>
          <el-form-item
            label="默认标识"
            prop="defaultFlag"
            style="padding-top: 15px"
          >
            <el-radio-group
              ref="defaultFlag"
              v-model="form.defaultFlag"
              class="offline-changecardmain_block-readcard-radio"
            >
              <el-radio label="0" :disabled="isRadio">是</el-radio>
              <el-radio label="1" :disabled="isRadio">否</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-form>
        <el-row style="padding-top: 15px; text-align: center">
          <el-col>
            <el-button
              @click="submitForm('form')"
              type="primary"
              size="medium"
              round
              style="width: 150px"
              >新增</el-button
            >
          </el-col>
        </el-row>
      </div>
    </div>
  </o-dialog>
</template>
<script>
import ODialog from '../Dialog';
import PhotographBlock from '../PhotographBlock';
import { addBranch } from '@/api/branch';
export default {
  data() {
    return {
      labelPosition: 'left',
      addVisble: false,
      form: {
        etcUserId: '',
        department: '',
        agentPhoneNum: '',
        agentIdType: '',
        agentIdNum: '',
        agentName: '',
        defaultFlag: '0',
      },
      rules: {
        department: [
          { required: true, message: '请输入分支机构名称', trigger: 'blur' },
          { max: 64, message: '长度不能超过64个字符', trigger: 'blur' },
        ],
        agentPhoneNum: [
          { required: true, message: '请输入代理人手机号', trigger: 'blur' },
          { max: 11, message: '长度不能超过11个字符', trigger: 'blur' },
        ],
        agentIdType: [
          {
            required: true,
            message: '请输入代理人证件类型',
            trigger: 'change',
          },
          { max: 10, message: '长度不能超过10个字符', trigger: 'change' },
        ],
        agentIdNum: [
          { required: true, message: '请输入代理人证件号', trigger: 'blur' },
          { max: 18, message: '长度不能超过18个字符', trigger: 'blur' },
        ],
        agentName: [
          { required: true, message: '请输入代理人姓名', trigger: 'blur' },
          { max: 64, message: '长度不能超过64个字符', trigger: 'blur' },
        ],
        defaultFlag: [
          { required: true, message: '请选择默认标识', trigger: 'blur' },
        ],
      },
      imageInfoUser: {},
      isRadio: false,
      imgUser: [],
      imgUser2: [],
    };
  },
  props: {
    title: {
      type: String,
      default: '新建分支机构',
    },
    visible: {
      type: Boolean,
      required: true,
    },
    appendToBody: {
      default: true,
      type: Boolean,
    },
    popuptype: {
      type: String,
    },
    showclose: {
      default: true,
      type: Boolean,
    },
  },
  components: {
    PhotographBlock,
    ODialog,
  },
  methods: {
    // 选择图片
    async complete(imgs) {
      const self = this;
      console.log('imgs:', imgs);
      this.imgUser = imgs;
      if (imgs.length > 0) {
        // 获取识别结果，赋值显示
        const currentPic = imgs[imgs.length - 1];
        const ocr = imgs[imgs.length - 1].ocr;
        if (ocr && currentPic.type === '101-1') {
          if (ocr.userName) {
            self.$set(self.form, 'agentName', ocr.userName);
          }
          if (ocr.userCertType) {
            self.$set(self.form, 'agentIdType', ocr.userCertType.slice(0, -1));
          }
          if (ocr.userCode) {
            self.$set(self.form, 'agentIdNum', ocr.userCode);
          }
          this.imageInfoUser = {
            imgFrontID: ocr.sealPageInnerImgid,
            imgType: '1011',
            mediaType: '4',
          };
        }
        return;
      }
    },
    async addBranchInfo() {
      let imageInfos = [];
      imageInfos.push(this.imageInfoUser);
      const res = await addBranch({
        etcUserId: this.$store.getters.searchUserInfo.etcUserId,
        department: this.form.department,
        agentName: this.form.agentName,
        agentIdType: this.form.agentIdType,
        agentIdNum: this.form.agentIdNum,
        agentPhoneNum: this.form.agentPhoneNum,
        defaultFlag: this.form.defaultFlag,
        imageInfo: imageInfos,
      });
      if (res) {
        console.log('添加成功');
        this.$refs['form'].resetFields();
        this.addVisble = false;
      }
    },
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          if (this.imgUser.length) {
            this.addBranchInfo();
          } else {
            this.$alert('请上传代理人证件', '提示', {
              confirmButtonText: '确定',
              type: 'warning',
            });
          }
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    closeAdd() {
      console.log('关闭');
      this.$refs['form'].resetFields();
      this.parentcomCallback();
    },
    parentcomCallback() {
      console.log('触发父组件方法：', this.popuptype);
      if (this.popuptype === 'tablelist') {
        this.$emit('getTableLists', '');
      } else if (this.popuptype === 'addbranch') {
        this.$emit('addbranchs', '');
      } else {
        console.log('无触发父组件方法');
      }
    },
  },
  watch: {
    addVisble() {
      this.$emit('update:visible', this.addVisble);
    },
    visible() {
      this.addVisble = this.visible;
      this.imgUser2 = [];
    },
  },
  mounted() {
    console.log('this.popuptype:', this.popuptype);
    if (this.popuptype === 'addbranch') {
      this.isRadio = true;
    }
  },
};
</script>
<style scoped>
.branchInput {
  width: 320px;
  height: 32px;
  /* background: #ffffff; */
  /* border: 1px solid #c0c4c9; */
  opacity: 1;
  border-radius: 3px;
}
</style>