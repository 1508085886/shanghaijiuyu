<!-- 通用凭证 -->
<template>
  <div class="offline-voucher-layer">
    <transition name="fade">
      <div class="offline-voucher-layer_bg" v-if="visible"></div>
    </transition>
    <transition name="slide-right">
      <div
        class="offline-voucher-layer_container"
        :class="{ 'is-full': full }"
        v-if="visible"
      >
        <i
          class="offline-voucher-layer_close el-icon-close"
          @click="closeother"
        ></i>
        <div ref="imageWrapper" class="offline-voucher-layer_pic-block">
          <div class="o-flex offline-voucher-layer_top">
            <h3>
              上海公共交通卡股份有限公司&nbsp;高速公路电子收费业务办理确认
            </h3>
            <el-row
              class="o-flex offline-voucher-layer_table-footer"
              v-if="hasFooter"
            >
              <el-col
                :span="10"
                class="offline-voucher-layer_td o-flex o-flex-align-center"
              >
                <div class="offline-voucher-layer_label">日期</div>
                <div class="o-flex-1">{{ footer.date }}</div>
              </el-col>
              <el-col
                :span="6"
                class="
                  offline-voucher-layer_td
                  o-flex o-flex-align-center o-flex-justify-center
                "
              >
                <div class="offline-voucher-layer_label">网点ID</div>
                <div class>{{ footer.outletId }}</div>
              </el-col>
              <el-col
                :span="6"
                class="
                  offline-voucher-layer_td
                  o-flex o-flex-align-center o-flex-justify-center
                "
              >
                <div class="offline-voucher-layer_label">操作员</div>
                <div class>{{ footer.operator }}</div>
              </el-col>
            </el-row>
          </div>
          <div class="offline-voucher-layer_table">
            <el-row
              class="offline-voucher-layer_tr"
              v-for="(tr, i) in tables"
              :key="i"
            >
              <el-col
                :span="computedSpan(td.span)"
                class="offline-voucher-layer_td o-flex o-flex-align-center"
                v-for="(td, j) in tr"
                :key="i + '' + j"
              >
                <div
                  class="offline-voucher-layer_label"
                  :style="{ color: td.color, width: td.labelWidth }"
                >
                  {{ td.label }}
                </div>
                <div
                  class="o-flex-1"
                  :style="{
                    color: td.color,
                    fontSize: td.fontSize,
                    fontWeight: td.fontWeight,
                  }"
                >
                  {{ td.value }}
                </div>
              </el-col>
            </el-row>
            <el-row
              class="
                offline-voucher-layer_tr offline-voucher-layer_table-footer
              "
              v-if="hasFooter"
            >
              <el-col
                :span="8"
                class="offline-voucher-layer_td o-flex o-flex-align-center"
              >
                <div class="offline-voucher-layer_label">日期</div>
                <div class="o-flex-1">{{ footer.date }}</div>
              </el-col>
              <el-col
                :span="8"
                class="
                  offline-voucher-layer_td
                  o-flex o-flex-align-center o-flex-justify-center
                "
              >
                <div class="offline-voucher-layer_label">网点ID</div>
                <div class>{{ footer.outletId }}</div>
              </el-col>
              <el-col
                :span="8"
                class="
                  offline-voucher-layer_td
                  o-flex o-flex-align-center o-flex-justify-center
                "
              >
                <div class="offline-voucher-layer_label">操作员</div>
                <div class>{{ footer.operator }}</div>
              </el-col>
            </el-row>
          </div>
          <!-- 
          <div class="clearfix mt40">
            <div
              class="offline-voucher-layer_sign-wrap fr"
              :class="{ 'is-signed': isSigned }"
            >
              <h5>客户未签名</h5>
              <div class="offline-voucher-layer_sign-block"></div>
            </div>
          </div>-->
          <div class="offline-voucher-layer_opr" v-if="oprShow">
            代确认操作员：{{ $store.getters.oprtId }}
          </div>
          <h3 class="mt30 offline-voucher-layer_tip" v-if="isDeviceWriteoff">
            设备一旦注销，将无法再使用，且不能反悔，您确认要注销吗？
          </h3>
          <h3 class="mt30 offline-voucher-layer_tip" v-if="tip">
            {{ tip }}
          </h3>
        </div>
        <div align="center">
          <el-button
            class="offline-voucher-layer_complete-btn2 mt40"
            type="danger"
            @click="closeother"
            :loading="loading"
            size="medium"
            >取消</el-button
          >
          <el-button
            id="btn"
            class="offline-voucher-layer_complete-btn2"
            type="primary"
            @click="completeHandle"
            :disabled="isButtonDisabled"
            :loading="loading"
            size="medium"
            >代用户确认</el-button
          >
        </div>
      </div>
    </transition>
  </div>
</template>

<script>
import html2canvas from 'html2canvas';
import { mediaUpload, systemTime } from '@/api/common';
import { getQueryStringByName } from '@/utils/utils';
export default {
  data() {
    return {
      // timer : true,
      isButtonDisabled: false,
      flag: false,
      loading: false,
      username: '',
      tables: [],
      isSigned: true,
      oprShow: false,
      worker: null,
      labelWidth: '110px',
      // footer: {
      //   date: '',
      //   outletId: '',
      //   operator: '',
      // },
    };
  },
  props: {
    full: {
      type: Boolean,
    },
    confirmFlag: {
      // 是否已经被确认
      type: Boolean,
      default: false,
    },
    hasFooter: {
      type: Boolean,
      default: false,
    },
    isDeviceWriteoff: {
      type: Boolean,
      default: false,
    },
    tip: {
      type: String,
      default: '',
    },
    info: {
      type: Object,
      default: () => {},
    },
    footer: {
      type: Object,
      default: () => {
        return {
          // date: '',
          outletId: '',
          operator: '',
        };
      },
    },
    column: {
      type: Number,
      default: 2,
    },
    keys: {
      type: Array,
      default: () => [],
    },
    visible: {
      type: Boolean,
    },
  },
  methods: {
    // 计算当前日期
    async getDate() {
      // const now = new Date();
      // this.footer.date = `${now.getFullYear()}/${
      //   now.getMonth() + 1
      // }/${now.getDate()}`;
      const res = await systemTime();
      if (res) {
        // this.footer.date = res.systemTime;
        this.$set(this.footer, 'date', res.systemTime);
        console.log('confirm:' + this.footer.date);
      }
    },
    computedSpan(span) {
      const column = this.column;
      if (!span) return 24 / column;
      if (span > column) span = column;
      return (24 / column) * span;
    },
    // 根据info，填充数据
    inertData() {
      const self = this;
      self.tables = [];
      const keys = self.keys;
      // console.log('keys:' + keys);
      for (let i = 0; i < keys.length; i++) {
        self.tables.push([]);
        for (let j = 0; j < keys[i].length; j++) {
          // console.log(keys[i][j]);
          self.tables[i].push({
            label: keys[i][j].label,
            value: self.info[keys[i][j].key] || '',
            span: keys[i][j].span || 1,
            labelWidth: keys[i][j].labelWidth || this.labelWidth,
            color: keys[i][j].color,
            fontSize: keys[i][j].fontSize,
            fontWeight: keys[i][j].fontWeight,
          });
        }
      }
    },
    // 关闭
    close() {
      const self = this;
      // self.timer = setTimeout(() => {

      const b = etcdev.closehangwriting();

      this.$emit('update:visible', false);
      this.$emit('closed');

      // this.$emit('cancel');
    },
    closeother() {
      const self = this;
      // self.timer = setTimeout(() => {
      const b = etcdev.closehangwriting();
      this.$emit('update:visible', false);
      this.$emit('closed');
      this.$emit('cancel');
    },
    sendpad() {
      const self = this;
      // self.oprShow = false;
      // if(!self.oprShow){
      self.$nextTick(() => {
        html2canvas(self.$refs.imageWrapper).then((canvas) => {
          //debugger;
          let dataURL = canvas.toDataURL('');
          dataURL = dataURL.replace('data:image/png;base64,', '');
          const pic = self.getpicture(dataURL);
        });
      });
      // }
    },
    getpicture(dataURL) {
      const par = '123';
      window.DisplayDate = (pic, sign) => {
        // debugger;
        // console.log(this.flag);
        const result = eval('(' + pic + ')');

        if (result.msg !== '签名版打开失败') {
          console.log('code::' + result.code);
          if (result.code === '0') {
            //console.log(result.pic);
            this.padconfirm(result.pic);
          }
          //  else if (result.msg === '签名版打开失败') {
          //   this.$message({
          //     message: result.msg,
          //     type: 'warning',
          //   });
          //   this.close();
          // }
          else {
            // this.$message({
            //   message: '用户未确认',
            //   type: 'warning',
            // });
            this.close();
          }

          if (this.flag == false) {
            this.closeother();
          }
        }
      };
      // const b = etcdev.showhangwriting(dataURL, 'DisplayDate', par, '2');
      let newWindow = [];
      this.JumpPage.forEach((element) => {
        if (window.location.href.indexOf(element) > -1) {
          newWindow.push(element);
        } // 当前窗口是弹出的新窗口
      });
      if (newWindow.length !== 0) {
        let dif = getQueryStringByName('dif', window.location.href);
        // alert(dif);
        etcdev.showhangwriting(dataURL, 'DisplayDate', par, '3', dif);
      } else {
        // 主界面
        etcdev.showhangwriting(dataURL, 'DisplayDate', par, '3', '0');
      }
      this.flag = false;
    },

    padconfirm(confirmphoto) {
      if (this.confirmFlag) {
        return;
      }
      mediaUpload({
        fileType: '2',
        img: confirmphoto,
      }).then((res) => {
        this.close();
        this.$emit('complete', {
          frontImgid: res.frontImgid,
          img: confirmphoto,
          etx: '2',
        });
        this.$emit('update:confirmFlag', true); // 客户确认
      });
    },
    // 点击完成
    completeHandle() {
      if (this.confirmFlag) {
        return;
      }
      this.isButtonDisabled = true;
      this.flag = true;
      this.oprShow = true;
      const self = this;
      if (this.oprShow) {
        this.$nextTick(() => {
          //----------------------------------------------
          self.loading = true;
          let timer2 = setTimeout(() => {
            self.loading = false;
            this.isButtonDisabled = false;
          }, 10000);
          // ------------------------------------------------
          html2canvas(self.$refs.imageWrapper).then((canvas) => {
            let dataURL = canvas.toDataURL('image/png');
            // 上传图片
            mediaUpload({
              fileType: '2',
              img: dataURL,
            }).then((res) => {
              self.close();
              self.$emit('complete', {
                frontImgid: res.frontImgid,
                img: dataURL,
                etx: '2',
              });
              //-------------------------
              clearTimeout(timer2);
              self.loading = false;
              this.isButtonDisabled = false;
              //-------------------------
              this.$emit('update:confirmFlag', true); // 操作员确认
            });
          });
        });
      }
    },
    bbb() {
      this.$emit('update:visible', false);
    },
    // 点击完成
    aaa() {
      if (this.confirmFlag) {
        return;
      }
      this.isButtonDisabled = true;
      this.flag = true;
      this.oprShow = true;
      const self = this;
      if (this.oprShow) {
        this.$nextTick(() => {
          //----------------------------------------------
          self.loading = true;
          let timer2 = setTimeout(() => {
            self.loading = false;
            this.isButtonDisabled = false;
          }, 10000);
          // ------------------------------------------------
          // html2canvas(self.$refs.imageWrapper).then((canvas) => {
          //   let dataURL = canvas.toDataURL('image/png');
          //   // 上传图片
          //   mediaUpload({
          //     fileType: '2',
          //     img: dataURL,
          //   }).then((res) => {
          this.$emit('update:visible', false);
          self.$emit('complete');
          //-------------------------
          clearTimeout(timer2);
          self.loading = false;
          this.isButtonDisabled = false;
          //-------------------------
          this.$emit('update:confirmFlag', true); // 操作员确认
          // });
          // });
        });
      }
    },
  },
  watch: {
    info: {
      deep: true,
      handler() {
        this.inertData();
        this.getDate();
      },
    },
    visible: function (val, oldVal) {
      // console.log('new: %s, old: %s', val, oldVal);
      this.$emit('closed');
      if (val === true) {
        this.oprShow = false;
      }
    },
  },
  mounted() {
    this.inertData();
    if (this.hasFooter) {
      this.getDate();
    }
  },
  // destroyed() {
  //   clearTimeout(this.timer);
  //   alert(this.timer);
  //   clearTimeout(this.timer2);
  // },
};
</script>
