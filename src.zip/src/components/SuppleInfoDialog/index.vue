<!--  -->
<template>
  <o-dialog
    :visible.sync="cvisible"
    :title="title"
    class="offline-suppleinfo-dialog"
    :append-to-body="appendToBody"
    @open="handleOpen"
  >
    <div class="mt30 mr60 ml60 offline-suppleinfo-dialog_container">
      <h3>{{ title }}</h3>
      <div class="o-flex mb20">
        <photograph-block
          type="verificationType"
          is-button
          width="104"
          height="104"
          label="本地上传"
          default-type="false"
          :append-to-body="true"
          no-select="local"
          :oloading.sync="btnLoading"
          @complete="selectedPic($event, 'local')"
          class="ml10 mr20"
        />
        <photograph-block
          type="verificationType"
          is-button
          width="104"
          height="104"
          label="拍照上传"
          default-type="false"
          :append-to-body="true"
          no-select="gpy"
          :oloading.sync="btnLoading"
          @complete="selectedPic($event, 'gpy')"
        />
      </div>
      <div class="offline-home_dialog-content_pics o-flex o-flex-wrap">
        <photograph-block
          only-pics
          :default-pics="selectedPics"
          @complete="selectedPic($event, 'change')"
        />
      </div>
      <!--  @complete="complete" -->
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button :loading="btnLoading" @click="cvisible = false"
        >取 消</el-button
      >
      <el-button type="primary" :loading="btnLoading" @click="submit"
        >确 定</el-button
      >
    </div>
  </o-dialog>
</template
>

<script>
import ODialog from '../Dialog';
import PhotographBlock from '../PhotographBlock';
export default {
  data() {
    return {
      btnLoading: false,
      cvisible: false,
      selectedPics: [],
      // imageInfo: [],
    };
  },
  props: {
    title: {
      type: String,
      default: '补充资料上传',
    },
    visible: {
      type: Boolean,
    },
    appendToBody: {
      default: false,
      type: Boolean,
    },
    loading: {
      default: false,
      type: Boolean,
    },
  },
  components: {
    ODialog,
    PhotographBlock,
  },
  watch: {
    cvisible() {
      this.$emit('update:visible', this.cvisible);
    },
    visible() {
      this.cvisible = this.visible;
    },
    loading() {
      this.btnLoading = this.loading;
    },
  },
  methods: {
    // 提交
    submit() {
      // this.loading = true;
      // this.cvisible = false;
      this.$emit('complete', this.selectedPics);
    },
    // 选择图片
    selectedPic(pics, type) {
      if (type === 'change') {
        this.selectedPics = [...pics];
      } else {
        this.selectedPics = [...this.selectedPics, ...pics];
      }
    },
    // 选择图片
    //complete(imgs) {
    //console.log(imgs);
    //this.imageInfo = imgs;
    // },
    // 处理打开Dialog事件
    handleOpen() {
      this.selectedPics = [];
    },
  },
  mounted() {
    this.cvisible = this.visible;
  },
};
</script>
