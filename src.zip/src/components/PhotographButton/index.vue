<!--  -->
<template>
  <el-button
    @click="clickHandle"
    size="small"
    round
    class="offline-photograph-button"
  >
    <i class="el-icon-camera-solid" />
    &ensp; {{ label }}
  </el-button>
</template>

<script>
export default {
  props: {
    label: {
      default: '拍照识别',
      type: String,
    },
  },
  methods: {
    clickHandle() {
      // 获取到照片后执行父组件方法
      this.$emit('photograph', {});
    },
  },
};
</script>
