<!--  -->
<template>
  <transition name="fade-transform" mode="out-in">
    <router-view v-if="show" class="offline_layout-main_router-view-scroll" />
  </transition>
</template>

<script>
export default {
  data() {
    return {
      show: true,
    };
  },
  props: {
    reload: {
      type: Boolean,
    },
  },
  watch: {
    '$route.path'() {
      if (this.$route.meta.reload) {
        this.show = false;
        this.$nextTick(() => {
          this.show = true;
        });
      }
    },
  },
};
</script>
