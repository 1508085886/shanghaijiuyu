<!--  -->
<template>
  <el-input :value="formatValue" @input="handleInput(inputValue, $event)">
  </el-input>
</template>

<script>
export default {
  data() {
    return {
      formatValue: '',
      inputValue: '',
    };
  },
  model: {
    prop: 'value',
    event: 'input',
  },
  props: {
    formatText: {
      type: String,
    },
  },
  methods: {
    handleInput(inputValue, v) {
      console.log('event:' + v);
      console.log('inputValue:' + inputValue);
      this.inputValue = this.inputValue + inputValue || v;
      this.formatValue = v + ' ' + this.formatText;
      this.$emit('input', this.inputValue);
    },
  },
  mounted() {},
};
</script>
