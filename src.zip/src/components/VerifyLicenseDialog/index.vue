<!--  -->
<template>
  <o-dialog
    :visible.sync="cvisible"
    :title="title"
    class="offline-verifylicense-dialog"
    :append-to-body="appendToBody"
    @handleOpened="handleOpened"
  >
    <div class="mt30 mr60 ml60 offline-verifylicense-dialog_container">
      <h3>{{ title }}</h3>
      <div class="o-flex mb20">
        <photograph-block
          type="verificationType"
          is-button
          width="104"
          height="104"
          label="本地上传"
          default-type="false"
          :append-to-body="true"
          no-select="local"
          :oloading.sync="loading"
          @complete="selectedPic($event, 'local')"
          class="ml10 mr20"
        />
        <photograph-block
          type="verificationType"
          is-button
          width="104"
          height="104"
          label="拍照上传"
          default-type="false"
          :append-to-body="true"
          no-select="gpy"
          :oloading.sync="loading"
          @complete="selectedPic($event, 'gpy')"
        />
      </div>
      <div class="offline-home_dialog-content_pics o-flex o-flex-wrap">
        <photograph-block
          only-pics
          :default-pics="selectedPics"
          @complete="selectedPic($event, 'change')"
        />
      </div>
      <!--  @complete="complete" -->
    </div>
    <div slot="footer" class="dialog-footer">
      <div class="dialog-footer-desc">
        以下资料需拍照上传<br />
        对私：开户人身份证、车辆行驶证<br />
        对公：开户单位证件、开户单位证明、车辆行驶证、经办人身份证
      </div>
      <el-button @click="cvisible = false">取 消</el-button>
      <el-button type="primary" @click="submit">确 定</el-button>
    </div>
  </o-dialog>
</template
>

<script>
import ODialog from '../Dialog';
import PhotographBlock from '../PhotographBlock';
export default {
  data() {
    return {
      loading: false,
      cvisible: false,
      // title: '核验证件上传',
      selectedPics: [],
      // imageInfo: [],
    };
  },
  props: {
    title: {
      type: String,
      default: '核验证件上传',
    },
    visible: {
      type: Boolean,
    },
    appendToBody: {
      default: false,
      type: Boolean,
    },
  },
  components: {
    ODialog,
    PhotographBlock,
  },
  watch: {
    cvisible() {
      this.$emit('update:visible', this.cvisible);
    },
    visible() {
      this.cvisible = this.visible;
    },
  },
  methods: {
    // 提交
    submit() {
      // this.cvisible = false;
      this.$emit('complete', this.selectedPics);
    },
    // 选择图片
    selectedPic(pics, type) {
      if (type === 'change') {
        this.selectedPics = [...pics];
      } else {
        this.selectedPics = [...this.selectedPics, ...pics];
      }
    },
    // 选择图片
    complete(imgs) {
      console.log(imgs);
      this.imageInfo = imgs;
    },
    // 处理打开Dialog事件
    handleOpened() {},
  },
  mounted() {
    this.cvisible = this.visible;
    // this.$forceUpdate();
    // this.reload();
  },
};
</script>
