import HomeSearch from './Base.vue'

export const NoData = HomeSearch
