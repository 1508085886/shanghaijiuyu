<!-- 首页左侧搜索区域无数据提示 -->
<template>
  <div class="offline-no-data o-flex o-flex-align-center o-flex-justify-center" :style="styles">
    <div>
      <i class="icon iconfont iconchazhao" v-if="!simple"></i>
      <p>{{ message }}</p>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    height: {
      default: 0,
    },
    message: {
      default: '暂无数据',
    },
    simple: {
      type: Boolean,
    },
  },
  computed: {
    styles() {
      if (this.height) {
        return {
          height: this.height + 'px',
        };
      } else {
        return {};
      }
    },
  },
};
</script>
