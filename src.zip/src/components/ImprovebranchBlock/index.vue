<!-- 完善分支机构弹框组件 -->
<template>
  <o-dialog
    :visible.sync="imVisble"
    :title="title"
    class="offline-complex-table"
    size="large"
    :append-to-body="appendToBody"
  >
    <div class="offline-accountwriteoff">
      <div class="clearfix">
        <div class="fl">
          <h4 class="offline-accountwriteoff_title">完善分支机构</h4>
        </div>
      </div>
      <div class="o-flex offline-accountwriteoff_block-wrap">
        <div class="offline-accountwriteoff_block">
          <el-form
            :label-position="labelPosition"
            :model="form"
            ref="form"
            label-width="130px"
            style="
              background: #e5e5ea;
              padding: 10% 20% 10% 20%;
              border: 1px solid #c0c4c9;
            "
          >
            <el-form-item
              label="车牌号"
              prop="vehicleNumber"
              style="padding-top: 15px"
            >
              <el-input class="input" v-model="form.vehicleNumber"></el-input>
            </el-form-item>
            <el-form-item
              label="车牌颜色"
              prop="vehicleColor"
              style="padding-top: 15px"
            >
              <type-select
                type="vehicleColor"
                v-model="form.vehicleColor"
                placeholder="请选择"
                class="input"
              />
            </el-form-item>
            <div style="padding-top: 10%; text-align: center">
              <el-button
                @click="upBranch()"
                type="primary"
                size="medium"
                round
                style="width: 150px"
                >完善</el-button
              >
            </div>
          </el-form>
        </div>
      </div>
      <addbranch-block
        :visible.sync="addvisble"
        :append-to-body="true"
        @addbranchs="upBranch"
        :popuptype="addbranch"
      ></addbranch-block>
    </div>
  </o-dialog>
</template>

<script>
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';
import { perfectVehicleDepartment } from '@/api/branch';
import AddbranchBlock from '../AddbranchBlock';
import ODialog from '../Dialog';
export default {
  data() {
    return {
      labelPosition: 'left',
      form: {
        vehicleNumber: '',
        vehicleColor: '',
      },
      addvisble: false,
      imVisble: false,
      addbranch: 'addbranch',
    };
  },
  props: {
    title: {
      type: String,
      default: '完善分支机构',
    },
    visible: {
      type: Boolean,
      required: true,
    },
    appendToBody: {
      default: true,
      type: Boolean,
    },
    popuptype: {
      type: String,
    },
    vehicleNumbers: {
      type: String,
    },
    vehicleColors: {
      type: String,
    },
  },
  components: { AddbranchBlock, ODialog },
  computed: {},
  watch: {
    imVisble() {
      this.$emit('update:visible', this.imVisble);
    },
    visible() {
      this.imVisble = this.visible;
    },
    vehicleColors: {
      handler: function (val, oldVal) {
        this.form.vehicleColor = val;
      },
      immediate: true,
    },
    vehicleNumbers: {
      handler: function (val, oldVal) {
        this.form.vehicleNumber = val;
      },
      immediate: true,
    },
  },
  methods: {
    async upBranch() {
      let res, loading;
      try {
        loading = this.$loading();
        res = await perfectVehicleDepartment({
          vehicleNumber: this.form.vehicleNumber,
          vehicleColor: this.form.vehicleColor,
        });
        loading.close();
      } catch (error) {
        loading.close();
      }
      if (res) {
        if (res.msg) {
          let tiptext = '';
          tiptext = '该用户名下无默认分支机构，请新建';
          tiptext = '默认分支机构无效，请新建';
          this.$confirm(tiptext, '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
            showClose: false,
          })
            .then(async () => {
              // 确定
              console.log('弹出新建分支机构');
              this.addvisble = true;
            })
            .catch(() => {
              // 取消
            });
        } else {
          console.log('完善分支机构成功');
          this.imVisble = true;
        }
      }
    },
  },
  mounted() {},
};
</script>
