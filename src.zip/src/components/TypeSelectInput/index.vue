<!-- 带输入的类型下拉选 -->
<template>
  <el-input
    :placeholder="placeholder"
    :value="model"
    @input="inputChange"
    spellcheck="false"
    class="offline-select-width-input"
    :disabled="disabled"
    :maxlength="len"
  >
    <type-select
      slot="prepend"
      :value="val"
      @input="selectChange"
      :type="type"
      :disabled="disabled"
      :placeholder="label"
    />
    <!-- <el-select
      class="offline-select-width-input_select"
      :value="val"
      @input="selectChange"
      
      :placeholder="label"
    >
      <el-option
        :label="type.description"
        :value="type.value"
        v-for="type in dicsItem"
        :key="type.value"
      ></el-option>
    </el-select>-->
  </el-input>
</template>

<script>
import { dicKeys, getAllDics } from '@/methods/dics';
import TypeSelect from '../TypeSelect';

export default {
  data() {
    return {
      dicsItem: [],
    };
  },
  props: {
    len: {
      default: '',
    },
    app: {
      required: true,
      default: '',
    },
    pre: {
      required: true,
      default: '',
    },
    placeholder: {
      default: '请输入',
    },
    label: {
      default: '请选择',
    },
    inputnochinese: {
      default: false,
    },
    carnumber: {
      default: false,
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    type: {
      required: true,
      validator: function (val) {
        return !!dicKeys[val];
      },
    },
  },
  components: {
    TypeSelect,
  },
  computed: {
    val() {
      return this.pre;
    },
    model() {
      return this.app;
    },
  },
  watch: {
    model(val) {
      if (this.inputnochinese) {
        this.$emit('update:app', val.replace(/[\u4E00-\u9FA5]+/, ''));
      }

      if (this.carnumber) {
        this.$emit(
          'update:app',
          val.replace(/[^\a-\z\A-\Z\d\u4E00-\u9FA5]/g, '').toLocaleUpperCase()
        );
      }
    },
  },
  methods: {
    selectChange(val) {
      this.$emit('update:pre', val);
    },
    inputChange(val) {
      this.$emit('update:app', val);
    },
    // 根据字典类型加载对应字典列表
    async getDicsList() {
      const self = this;
      if (!self.type) return;
      const res = await getAllDics(dicKeys[self.type]);
      self.dicsItem = res;
    },
  },
  mounted() {
    this.getDicsList();
  },
};
</script>
