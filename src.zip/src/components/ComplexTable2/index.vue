<!-- 复杂表格，传入获取数据地址，新增地址 -->
<template>
  <o-dialog
    :visible.sync="cvisible"
    :title="title"
    class="offline-complex-table"
    size="large"
    :append-to-body="appendToBody"
    @opened="defaultShow"
  >
    <div class="offline-complex-table_container">
      <el-form class="offline_layout-aside_search-form">
        <!-- <div class="clearfix">
          <div class="fl">
            <h4 class="offline-devicewriteoff_title">分支机构管理</h4>
          </div>
        </div> -->
        <div class="mt30 offline-systemInfoChecked">
          <el-button
            class="addBtn"
            @click="addvisble = true"
            size="small"
            type="primary"
            plain
          >
            <i class="el-icon-plus"></i>
            新增{{ title }}
          </el-button>
          <el-input
            class="input"
            v-model="form.department"
            placeholder="分支机构名称"
          ></el-input>
          <el-input
            class="input"
            v-model="form.agentName"
            placeholder="代理人名称"
          ></el-input>
          <el-form-item>
            <type-select-input
              :app.sync="form.agentIdNum"
              :pre.sync="form.agentIdType"
              inputnochinese="true"
              type="agentIdType"
              label="代理人证件类型"
              placeholder="代理人证件号码"
              spellcheck="false"
              :len="64"
            />
          </el-form-item>
          <div class="btn">
            <el-button
              class="btn1"
              type="primary"
              @click="searchTalbe"
              icon="el-icon-search"
              size="small"
              round
              >搜索</el-button
            >
          </div>
        </div>
      </el-form>
      <el-table
        ref="multipleTable"
        :data="tables"
        tooltip-effect="dark"
        style="width: 100%"
        @select="handleSelectionChange"
        @select-all="onSelectAll"
      >
        <el-table-column type="selection" width="55"></el-table-column>
        <!-- <el-table-column
          :prop="column.filed"
          :label="column.name"
          v-for="(column, i) in columns"
          :key="column.filed + i"
        >
          <template slot-scope="scope">
            <span v-if="column.format">
              {{ column.format(scope.row[column.filed]) }}
            </span>
            <span v-else>{{ scope.row[column.filed] }}</span>
          </template>
        </el-table-column> -->
        <el-table-column label="分支机构名称" prop="department" width="150">
        </el-table-column>
        <el-table-column label="代理人名称" prop="agentName" width="120">
        </el-table-column>
        <el-table-column label="代理人证件号码" prop="agentIdNum" width="180">
        </el-table-column>
        <el-table-column
          label="代理人证件类型"
          prop="agentIdTypeDesc"
          width="240"
        >
        </el-table-column>
        <el-table-column
          label="代理人手机号码"
          prop="agentPhoneNum"
          width="150"
        >
        </el-table-column>
        <el-table-column label="代理人证件类型" prop="agentIdType" v-if="show">
        </el-table-column>
        <el-table-column
          label="有效标识"
          prop="notFitrule"
          :formatter="fmIsValid"
        >
        </el-table-column>
        <el-table-column
          label="默认标识"
          prop="defaultFlag"
          :formatter="fmIsDefault"
        >
        </el-table-column>
      </el-table>
    </div>
    <div slot="footer" class="dialog-footer">
      <div
        class="fl offline-workordermanagement_tableblock-pagination-desc"
        v-if="total"
      >
        第{{ startRecords }}到{{ currentSize }}条，
      </div>
      <el-pagination
        background
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page.sync="currentPage"
        :page-size="pageSize"
        layout="total,->,prev, pager, next,slot"
        :total="total"
      >
      </el-pagination>
      <el-button @click="cvisible = false">取 消</el-button>
      <el-button type="primary" @click="getAllSelectRow">确 定</el-button>
    </div>
    <addbranch-block
      :visible.sync="addvisble"
      :append-to-body="true"
      @getTableLists="getTableList"
      :popuptype="tablelist"
    ></addbranch-block>
  </o-dialog>
</template>

<script>
import ODialog from '../Dialog';
import request from '@/utils/request';
import { branchQuery } from '@/api/branch';
import { dicKeys, getDicDesByCode, getDicCodeByDes } from '@/methods/dics';
import AddbranchBlock from '../AddbranchBlock';
export default {
  data() {
    return {
      total: 0, //总条数
      tables: [],
      currentPage: 1,
      page: 1,
      pageSize: 10,
      cvisible: false,
      addvisble: false,
      addRows: [],
      firstLoad: true,
      defaultValues: [],
      form: {
        departmentName: '',
        agentName: '',
        agentIdType: '',
        agentIdNum: '',
      },
      invalidBtnDisabled: false,
      defaultBtnDisabled: false,
      show: false,
      tablelist: 'tablelist',
    };
  },
  components: {
    ODialog,
    AddbranchBlock,
  },
  props: {
    title: {
      default: '',
      required: true,
    },
    visible: {
      type: Boolean,
      required: true,
    },
    requestListUrl: {
      type: String,
      required: true,
    },
    requestListParam: {
      default() {
        return {};
      },
      type: Object,
    },
    responseListFormat: {
      type: Function,
    },
    columns: {
      type: Array,
      required: true,
    },
    insertListUrl: {
      require: true,
      type: String,
    },
    appendToBody: {
      type: Boolean,
    },
    /**
     * [{ filed: 'agentIdNum', value: '76543234' }],
     * [{ filed: 'agement', value: ['销售部', '技术部'] }]
     */
    defaultValue: {
      type: Array,
    },
  },
  methods: {
    handleSizeChange(val) {
      this.pageSize = val;
      this.getTableList();
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      // 当前为第几页时调用getTabelInfo()显示第几页数据
      // this.page = val;
      // this.currentPage = val;
      // this.getTabelInfo();
      // console.log(`当前页: ${val}`);
      // this.pageSize = 5;

      // const pagenum = (val - 1) * 5 + 1;
      this.currentPage = val;
      // this.startRecords = (val - 1) * this.pageSize + 1;
      this.page = val;
      // const self = this;
      // const res = await branchQuery({
      //   etcUserId: self.requestListParam.etcUserId,
      //   pageNo: this.startRecords,
      //   pageSize: this.pageSize,
      // });
      // console.log('res');
      // console.log(res);
      // if (res) {
      //   self.tables = self.responseListFormat(res);
      //   this.total = res.recNum;
      // }
      // this.getListData();
      this.getTableList();
      console.log(`当前页: ${val}`);
    },
    // 显示默认数据
    defaultShow() {
      if (!this.firstLoad) return;
      this.firstLoad = false;
      this.defaultValues.forEach((v) => {
        this.$refs.multipleTable.toggleRowSelection(v, true);
      });
    },
    // 获取所有被勾选的项
    getAllSelectRow() {
      this.$emit('getSelected', this.$refs.multipleTable.selection);
      if (this.$refs.multipleTable.selection.length == '0') {
        this.$message.error('请选择分支机构');
      }
      for (let i = 0; i < this.$refs.multipleTable.selection.length; i++) {
        if (!this.$refs.multipleTable.selection[i].departmentAberrantData) {
          this.cvisible = false;
        } else {
          this.$message.error('代理人信息异常');
        }
      }
    },
    // // 处理打开Dialog事件
    // handleOpened() {
    //   this.$emit('setDefaultSelected', this.$refs.multipleTable, this.tables);
    // },
    // 清除勾选
    clearSelected() {
      this.$refs.multipleTable.clearSelection();
      this.addRows = [];
    },
    // 获取列表数据
    async getTableList() {
      const self = this;
      const res = await branchQuery({
        etcUserId: self.requestListParam.etcUserId,
        departmentName: this.form.departmentName,
        agentName: this.form.agentName,
        agentIdType: this.form.agentIdType,
        pageNo: this.startRecords,
        pageSize: this.pageSize,
      });
      console.log(res);
      // if (res) {
      //   this.total = res.recNum;
      //   if (self.responseListFormat) {
      //     self.tables = self.responseListFormat(res);
      //   } else {
      //     self.tables = res;
      //   }
      // }
      if (res) {
        let recordListArr = res.departmentInfo;
        for (let i = 0; i < recordListArr.length; i++) {
          // 是否默认
          if (recordListArr[i].defaultFlag === '0') {
            res.departmentInfo[i].defaultFlagBtnDisabled = true;
          } else {
            res.departmentInfo[i].defaultFlagBtnDisabled = false;
          }
          // 是否无效
          if (recordListArr[i].notFitrule === '合规') {
            res.departmentInfo[i].invalidBtnDisabled = false;
          } else {
            res.departmentInfo[i].invalidBtnDisabled = true;
          }
          recordListArr[i].agentIdTypeDesc = await getDicDesByCode(
            dicKeys.agentIdType,
            recordListArr[i].agentIdType
          );
        }
        this.tables = recordListArr;
        this.total = res.recnum;
        this.currentSize =
          this.pageSize * this.page >= this.total
            ? this.total
            : this.page * this.pageSize;
        console.log(`this.total: ${this.total}`);
        // self.tables = recordListArr;
      }
    },
    handleSelectionChange(selection, row) {
      console.log('vvv');
      console.log(selection);
      console.log(this.tables.filter((t) => t === row).length);
      console.log(this.tables.filter((t) => t === row));
      console.log(
        this.tables.filter((t) => t === row)[0].departmentAberrantData
      );
      for (let i = 0; i < this.tables.filter((t) => t === row).length; i++) {
        if (
          selection.length != '0' &&
          this.tables.filter((t) => t === row)[i].departmentAberrantData &&
          this.tables.filter((t) => t === row)[i].departmentAberrantData != ''
        ) {
          this.$message.error('代理人信息异常');
        }
      }
      // 清除所有选中
      this.$refs.multipleTable.clearSelection();
      if (selection.length === 0) return;
      // 将当前点击项选中
      this.$refs.multipleTable.toggleRowSelection(row, true);
    },
    onSelectAll() {
      this.$refs.multipleTable.clearSelection();
    },
    // 根据columns生成表格的列
    createColumns() {},
    fmIsValid(row, column) {
      return row.notFitrule === '合规' ? (
        <div style="color: #67C33A">
          <i class="el-icon-success"></i>
        </div>
      ) : (
        <div style="color: #F56C6C">
          <i class="el-icon-error"></i>
        </div>
      );
    },
    fmIsDefault(row, column) {
      return row.defaultFlag === '0' ? (
        <div style="color: #67C33A">
          <i class="el-icon-success"></i>
        </div>
      ) : (
        <div style="color: #F56C6C">
          <i class="el-icon-error"></i>
        </div>
      );
    },
    async searchTalbe() {
      this.page = 1;
      this.currentPage = 1;
      await this.getTableList();
    },
  },
  computed: {
    //起始记录
    startRecords() {
      console.log('记录修改：');
      return (this.page - 1) * this.pageSize + 1;
    },
  },
  watch: {
    cvisible() {
      this.$emit('update:visible', this.cvisible);
      // if (!this.cvisible) this.clearSelected();
    },
    visible() {
      this.cvisible = this.visible;
    },
  },
  async mounted() {
    await this.getTableList();
  },
};
</script>
<style scoped>
.input {
  width: 240px;
  height: 32px;
  background: #ffffff;
  border: 1px solid #c0c4c9;
  opacity: 1;
  border-radius: 3px;
  margin-right: 20px;
}
.btn {
  width: 150px;
  height: 34px;
  opacity: 1;
}
.btn1 {
  margin-left: 30px;
  margin-top: 2px;
}
.addBtn {
  width: 130px;
  height: 34px;
  opacity: 1;
  margin-right: 20px;
}
.el-pagination span {
  float: left;
}
</style>
