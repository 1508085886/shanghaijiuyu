<!-- 拍照识别块 -->
<template>
  <div class="offline-upload-license-block o-flex" @click="handleClick">
    <div
      class="o-flex o-flex-align-center o-flex-justify-center o-height-full offline-upload-license-block_container"
      @click="visible = true"
      :style="styles"
    >
      <div>
        <i class="icon iconfont icondianzizhengjian"></i>
        <p><span>上传</span>&ensp;{{ title }}</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      visible: false,
    };
  },
  props: {
    width: {
      default: 0,
    },
    height: {
      default: 0,
    },
    darkBorderVisible: {
      type: Boolean,
      default: false,
    },
    title: {
      type: String,
      default: '证件',
    },
  },
  computed: {
    styles() {
      const style = {};
      if (this.width) {
        style.width = this.width + 'px';
      }
      if (this.height) {
        style.height = this.height + 'px';
      }
      if (this.darkBorderVisible) {
        style.border = '1px solid #027AFF';
      } else {
        style.border = '1px dashed #dcdfe6';
      }
      return style;
    },
  },
  methods: {
    handleClick() {
      this.$emit('click');
    },
  },
};
</script>
