<!-- 二维码 -->
<template>
  <div class="offline-qrcode" ref="qrCodeUrl"></div>
</template>

<script>
import QRCode from 'qrcodejs2';

export default {
  data() {
    return {
      qrcode: null,
    };
  },
  props: {
    text: {
      type: String,
      default: '',
    },
  },
  watch: {
    text(val) {
      if (this.qrcode) this.qrcode.makeCode(val);
    },
  },
  methods: {
    creatQrCode() {
      const self = this;
      self.qrcode = new QRCode(this.$refs.qrCodeUrl, {
        text: self.text, // 需要转换为二维码的内容
        width: 300,
        height: 300,
        colorDark: '#000000',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.H,
      });
      self.qrcode._el.title = '';
    },
  },
  mounted() {
    this.creatQrCode();
  },
};
</script>
<style lang='scss'>
</style>