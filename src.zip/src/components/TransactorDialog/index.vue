<!--  -->
<template>
  <o-dialog
    :visible.sync="cvisible"
    :title="title"
    class="offline-transactor-dialog"
    :append-to-body="appendToBody"
    @handleOpened="handleOpened"
  >
    <div class="mt30 mr60 ml60 offline-transactor-dialog_container">
      <!-- <h3>上传经办人证件</h3> -->
      <div class="o-flex">
        <photograph-block
          @complete="complete"
          type="agentCertType"
          :append-to-body="true"
        ></photograph-block>
      </div>
    </div>
    <div slot="footer" class="dialog-footer">
      <div class="fl mt5">请上传经办人证件、银行签约单及其他证件资料</div>
      <el-button @click="cvisible = false">取 消</el-button>
      <el-button type="primary" @click="submitTransactorInfo">确 定</el-button>
    </div>
  </o-dialog>
</template
>

<script>
import ODialog from '../Dialog';
import PhotographBlock from '../PhotographBlock';
export default {
  data() {
    return {
      cvisible: false,
      title: '补充经办人证件',
      imageInfo: [],
    };
  },
  props: {
    visible: {
      type: Boolean,
    },
    appendToBody: {
      default: false,
      type: Boolean,
    },
  },
  components: {
    ODialog,
    PhotographBlock,
  },
  watch: {
    cvisible() {
      this.$emit('update:visible', this.cvisible);
    },
    visible() {
      this.cvisible = this.visible;
    },
  },
  methods: {
    // 提交经办人信息
    submitTransactorInfo() {
      this.cvisible = false;
      this.$emit('transactorDialogComplete', this.imageInfo);
    },
    // 选择图片
    complete(imgs) {
      console.log(imgs);
      this.imageInfo = imgs;
    },
    // 处理打开Dialog事件
    handleOpened() {},
  },
  mounted() {
    this.cvisible = this.visible;
  },
};
</script>
