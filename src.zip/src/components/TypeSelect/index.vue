<!-- 带输入的类型下拉选 -->
<template>
  <el-select class="offline-select" v-model="val" :placeholder="placeholder" :disabled="disabled"
    @change="$emit('change', val)">
    <el-option :disabled="readonly" :label="description(type)" :value="type.value" v-for="(type, i) in dicsItem"
      :key="type.value + i"></el-option>
  </el-select>
</template>

<script>
  import { dicKeys, getAllDics } from '@/methods/dics';

  export default {
    data() {
      return {
        dicsItem: [],
        val: '',
      };
    },
    props: {
      value: {
        default: '',
      },
      disabled: {
        default: false,
      },
      placeholder: {
        default: '请选择',
      },
      type: {
        required: true,
        validator: function (val) {
          return !!dicKeys[val];
        },
      },
      readonly: {
        type: Boolean,
      },
      addOptions: {
        type: Array,
        default() {
          return [];
        },
      },
      delOptions: {
        type: Array,
        default() {
          return [];
        },
      },
    },
    computed: {
      model() {
        return this.app;
      },
      description() {
        return function (item) {
          return item.value + ' - ' + item.description;
          // if (item.fieldCode === 'vehicleClass') {
          // } else {
          //   return item.description;
          // }
        };
      },
    },
    watch: {
      // type(newV, oldV) {
      //   // do something
      //   console.log('000000');
      // },
      value: {
        immediate: true,
        handler(val) {
          this.val = val;
        },
      },
      val(val) {
        this.$emit('input', val);
      },
    },
    methods: {
      selectChange(val) {
        this.$emit('input', val);
      },
      // 根据字典类型加载对应字典列表
      async getDicsList() {
        const self = this;
        // debugger;
        if (!self.type) return;
        const res = await getAllDics(dicKeys[self.type]);
        // console.log('res');
        // console.log(res);
        // self.dicsItem = res;
        self.dicsItem = res.concat(self.addOptions);

        for (let i = 0; i < self.delOptions.length; i++) {
          const index = self.dicsItem.findIndex(
            (row) => row.value === self.delOptions[i].value
          );

          if (index > -1) {
            self.dicsItem.splice(index, 1);
          }
        }

        self.dicsItem.splice();
      },
    },
    mounted() {
      this.getDicsList();
    },
  };
</script>