<!--  -->
<template>
  <el-dialog :class="['offline-dialog', 'offline-dialog-' + size]" :title="title" :visible.sync="cvisible"
    :append-to-body="appendToBody" :close-on-click-modal="false" @opened="opened" @open="open" @close="close"
    v-dialogDrag :show-close="showclose" :close-on-press-escape="showclose">
    <slot></slot>
    <slot name="footer" slot="footer"></slot>
  </el-dialog>
</template>

<script>
  export default {
    data() {
      return {
        cvisible: false,
      };
    },
    props: {
      title: {
        type: String,
      },
      visible: {
        type: Boolean,
      },
      size: {
        type: String,
        default: 'normal',
      },
      appendToBody: {
        default: false,
        type: Boolean,
      },
      showclose: {
        default: true,
        type: Boolean,
      },
    },
    watch: {
      cvisible() {
        this.$emit('update:visible', this.cvisible);
      },
      visible() {
        this.cvisible = this.visible;
      },
    },
    methods: {
      opened() {
        this.$emit('opened');
      },
      open() {
        this.$emit('open');
      },
      close() {
        this.$emit('close');
      },
    },
    mounted() {
      this.cvisible = this.visible;
    },
  };
</script>