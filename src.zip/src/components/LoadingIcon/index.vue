<!-- 加载动画 -->
<template>
  <div class="offline-loading-icon">
    <img v-if="loading" src="../../assets/images/loading.gif" />
    <complete-svg :size="20" v-else />
  </div>
</template>

<script>
import { CompleteSvg } from '@/components/SvgAnimate';
export default {
  props: {
    loading: {
      type: Boolean,
    },
  },
  components: {
    CompleteSvg,
  },
};
</script>
