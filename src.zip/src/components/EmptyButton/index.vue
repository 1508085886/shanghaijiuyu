<!-- 反色按钮 -->
<template>
  <el-button
    :size="size"
    :type="type"
    :round="round"
    :circle="circle"
    :loading="loading"
    :disabled="disabled"
    :icon="icon"
    :autofocus="autofocus"
    :nativeType="nativeType"
    plain
    class="offline-empty-button"
    @click="clickHandle"
  >
    <slot></slot>
  </el-button>
</template>

<script>
export default {
  name: 'EmptyButton',
  props: {
    size: {},
    type: {},
    round: {},
    circle: {},
    loading: {},
    disabled: {},
    icon: {},
    autofocus: {},
    nativeType: {},
  },
  methods: {
    clickHandle(e) {
      this.$emit('click', e);
    },
  },
};
</script>
