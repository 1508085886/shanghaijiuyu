/**
 * @description 用户访问权限
*/
import router from './router'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import { getOperCardId, getToken, getRandom } from '@/methods/account'
import store from '@/store'
import { isEmptyObj } from '@/utils/utils.js' // 对象判空

NProgress.configure({ showSpinner: false })


// const whiteList = ['/login', '/pidchange', '/cidchange']
const whiteList = ['/login']
const tokenAccessList = ['/menu', '/jumpBlankPage', '/convehiclechange'] // 只要有token就能进的页面
// '/accountwriteoff',
// '/devicewriteoff',
// '/menu',
// '/v','/vc','/vl','/td',
const jumpPage = ['/workordermanagement', '/netreconciliation', '/licenseverify', '/allaccountinfo',]// 重新打开页面的page
router.beforeEach(async (to, from, next) => {
  NProgress.start()
  next();
  // try {
  //   // 获取操作员卡号
  //   // await getOperCardId()
  //   // 获取操作员随机数
  //   // await getRandom()
  // } catch (e) { }
  // if (whiteList.indexOf('/' + to.path.split('/')[1]) > -1) {
  //   next()
  // } else {
  //   if (getToken()) {
  //     //车型变更业务直接跳转
  //     console.log('to', to);
  //     if(to.path.includes("vehicleinfochange")) {
  //       next()
  //       return;
  //     }
  //     const menuItems = store.getters.permissions;
  //     // console.log('menuItems', menuItems);
  //     const elementPermissions = store.getters.elementPermissions;
  //     // console.log('elementPermissions', elementPermissions);
  //     let elementPermission = elementPermissions.find(obj => obj.menu == '/' + to.path.split('/')[1]);
  //     if (menuItems.indexOf('/' + to.path.split('/')[1]) > -1) {
  //       if (!isEmptyObj(to.query)) {
  //         // console.log('to.query', to.query);
  //         next()
  //       } else if (!isEmptyObj(elementPermission.permissions)) {
  //         next({
  //           path: elementPermission.menu,
  //           query: elementPermission.permissions
  //         })
  //       } else {
  //         next()
  //       }
  //     } else if (tokenAccessList.indexOf('/' + to.path.split('/')[1]) > -1) {
  //       next()
  //     }
  //     else if (jumpPage.indexOf('/' + to.path.split('/')[1]) > -1) {
  //       next()
  //     }
  //     else {
  //       next(`/login`) // 404/无权限页 重定向到登录页
  //     }
  //   } else {//没有得到本地token，优先从url上取token
  //     if (to.fullPath.indexOf('token') > -1 && to.query.token !== '') {
  //       if (jumpPage.indexOf('/' + to.path.split('/')[1]) > -1) {
  //         next()
  //       }
  //     } else {
  //       next(`/login?redirect=${to.path}`) // 否则全部重定向到登录页
  //     }
  //   }

  // }
  NProgress.done()
})

export const JumpPage = jumpPage;
