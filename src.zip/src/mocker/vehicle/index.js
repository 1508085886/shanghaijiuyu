module.exports = {
  'POST /mock/vehicle/getVehicleType': {
    vehicleClass: '2',
    description: '这是详细描述',
  },
  'POST /mock/vehicle/getVehicleUserType': {
    vehicleUserClass: '0',
  },
  'POST /mock/vehicle/vehicleOwnerInfo': {
    status: true,
  },
  'POST /mock/vehicle/registerVehicle': {
    vehicleId: '0',
    description: '详细描述',
    vehicleClass: '2',
  },
  'POST /mock/vehicleVerification': {
    msg: '可发行',
  },
};
