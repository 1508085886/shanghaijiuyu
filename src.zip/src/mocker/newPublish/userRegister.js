module.exports = {
  'POST /mock/userRegister': {
    // exCode: '9002',
    etcUserId: '456789876523',
    identifyFlag: '0',
    description: '这是描述'
  },
  'POST /mock/user/channelList': {
    channelCount: 9,
    channelList: [
      // {
      //   "channelId": "ETC_CCB_ZH",
      //   "subChannelId": "1",
      //   "remarks": "建设银行"
      // }, {
      //   "channelId": "ETC_COUNTRYPAY1",
      //   "subChannelId": "004",
      //   "remarks": "农业银行总行"
      // },
      {
        "channelId": "ETC_BOSC_CO",
        "subChannelId": "2",
        "remarks": "上海银行"
      },
      {
        "channelId": "ETC_ABC_CO",
        "subChannelId": "004",
        "remarks": "农业银行"
      },
      {
        "channelId": "ETC_UNIONPAY",
        "subChannelId": "014",
        "remarks": "银联"
      },
      // {
      //   "channelId": "建设银行",
      //   "subChannelId": "016",
      //   "remarks": "建设银行"
      // },
      // {
      //   "channelId": "ETC_COUNTRYPAY2",
      //   "subChannelId": "015",
      //   "remarks": "平安银行总行"
      // },
      // {
      //   "channelId": "ETC_COUNTRYPAY",
      //   "subChannelId": "014",
      //   "remarks": "兴业银行总行"
      // }
    ]
  }
}
