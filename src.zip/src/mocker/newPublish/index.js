module.exports = {
  ...require('./userRegister')
}