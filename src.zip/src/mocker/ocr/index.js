module.exports = {
    'POST /mock/idOrcIdentify': {
        sealPageInnerImgid: '123456',
        userCertType: '1011',
        userCode: '422827202010301818',
        userName: '张三',
        address: '上海浦东',
    },
    'POST /mock/businessLicense': {
        sealPageInnerImgid: '123456',
        userCertType: '203',
        regNum: '422827202010301818',
        name: '张三公司',
        address: '上海浦东',
    },
}