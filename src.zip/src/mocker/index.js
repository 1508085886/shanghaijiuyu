const login = require('./login');
const compre = require('./compre');
const dic = require('./dataDictionary');
const upload = require('./upload');
const newPublish = require('./newPublish');
const user = require('./user');
const vehicle = require('./vehicle');
const order = require('./order');
const department = require('./department');
const rechargeAccount = require('./rechargeAccount');
const repayment = require('./repayment');
const writeoff = require('./writeoff');
const equipment = require('./equipment');
const recharge = require('./recharge');
const invoice = require('./invoice');
const info = require('./info');
const branch = require('./branch');
const ocr = require('./ocr');
const reversebus = require('./reversebus');

module.exports = {
  ...login,
  ...compre,
  ...dic,
  ...upload,
  ...newPublish,
  ...user,
  ...vehicle,
  ...order,
  ...department,
  ...rechargeAccount,
  ...repayment,
  ...writeoff,
  ...equipment,
  ...recharge,
  ...invoice,
  ...info,
  ...branch,
  ...ocr,
  ...reversebus,
};
