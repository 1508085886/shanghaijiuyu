const data = require('./data.json');

const proxy = {
  // 综合查询
  'POST /mock/multipleQuery': {
    vehicleInfo: data.vehicleInfo, // 车辆信息
    cardInfo: data.cardInfo, // 卡片信息
    obuInfo: data.obuInfo, // 标签信息
    userInfo: data.userInfo, // 开户人信息
    departmentInfo: data.departmentInfo, // 部门信息
    userNoticeList: data.userNoticeList, // 开户人通知
    userAcctList: data.userAcctList, // 账户列表
    vehicleList: data.vehicleList, // 车辆列表
    errorMsg: null,
    // errorMsg: '代理人信息异常，请去完善分支机构',
  },
  // 图片上传
  'POST /mock/imgUpload': {
    frontImgid: '88888888',
    img: 'xxxx.com',
    etx: '2',
  },
  // 系统时间
  'POST /mock/systemTime': {
    systemTime: '2020-11-05 15:18:04',
  },
  // 系统参数
  'POST /mock/systemParameterQuery': {
    value: '20210406',
  },
  // s
  'POST /mock/bankCardOrc': {
    value: true,
  },
  // 安装码
  'POST /mock/queryInstallCode': {
  },
  // 开票申请
  'POST /mock/addBranch': {
  },
  // 修改密码
  'POST /mock/updateOptPwd': {
    value: '111',
  },
  // 3.15上传日志文件查询
  'POST /mock/uploadFileQuery': {
    uploadList: [
      {
        id: '11111',
        uploadDate: '20210715'
      },
    ]
  },
  //3.14上传日志文件
  'POST /mock/uploadFile': {
    value: '111',
  },
};
module.exports = proxy;
