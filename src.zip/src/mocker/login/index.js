const appData = require('./data.json')

const proxy = {
	// 登录
	'POST /mock/login': {
		token: '6273792329',
		netLevel: '1',
		position: '1',
		menuIds: [{
			"title": "车辆业务",
			"lev": "1",
			"hidden": "0",
			"children": [
				{
					"title": "单位新办发行",
					"lev": "2",
					"hidden": "0",
					"url": "/newpublish",
					"endchildren": []
				},
				{
					"title": "设备注销",
					"lev": "2",
					"hidden": "0",
					"url": "/devicewriteoff",
					"endchildren": []
				}, {
					"title": "车牌验证",
					"lev": "2",
					"hidden": "0",
					"url": "censeverify",
					"endchildren": []
				}, {
					"title": "车辆信息变更",
					"lev": "2",
					"hidden": "0",
					"url": "/vehicleinfochange",
					"endchildren": []
				}, {
					"title": "个人新办发行",
					"lev": "2",
					"hidden": "0",
					"url": "/newpublishperson",
					"endchildren": []
				}, {
					"title": "设备发行",
					"lev": "2",
					"hidden": "0",
					"url": "/equipmentissuance",
					"endchildren": []
				}, {
					"title": "账户注销",
					"lev": "2",
					"hidden": "1",
					"url": "/accountwriteoff",
					"endchildren": []
				}, {
					"title": "完善分支机构",
					"lev": "2",
					"hidden": "0",
					"url": "/improvebranch",
					"endchildren": []
				}, {
					"title": "车辆发行资格校验",
					"lev": "2",
					"hidden": "0",
					"url": "/vissueverification",
					"endchildren": []
				}]
		}, {
			"title": "账户及签约",
			"lev": "1",
			"hidden": "0",
			"children": [{
				"title": "账户注销",
				"lev": "2",
				"hidden": "0",
				"url": "/accountwriteoff",
				"endchildren": []
			}, {
				"title": "换卡",
				"lev": "2",
				"hidden": "0",
				"url": "/changecard",
				"endchildren": [
					{
						"title": "换卡特许免费",
						"hidden": "0",
					}
				]
			}, {
				"title": "换签",
				"lev": "2",
				"hidden": "0",
				"url": "/changeobu",
				"endchildren": [
					{
						"title": "换签特许免费",
						"hidden": "0",
					}
				]
			},]
		}, {
			"title": "用户业务",
			"lev": "1",
			"hidden": "0",
			"children": [{
				"title": "发行信息核对",
				"lev": "2",
				"hidden": "0",
				"url": "/test1",
				"endchildren": []
			}, {
				"title": "单位信息变更",
				"lev": "2",
				"hidden": "0",
				"url": "/cidchange",
				"endchildren": []
			}, {
				"title": "个人用户变更",
				"lev": "2",
				"hidden": "0",
				"url": "/pidchange",
				"endchildren": []
			}, {
				"title": "特殊车辆查询",
				"lev": "2",
				"hidden": "0",
				"url": "/spcardquery",
				"endchildren": []
			}, {
				"title": "卡内交易查询",
				"lev": "2",
				"hidden": "0",
				"url": "/purchaserecord",
				"endchildren": []
			}]
		}, {
			"title": "卡片业务",
			"lev": "1",
			"hidden": "0",
			"children": [{
				"title": "卡片挂失",
				"lev": "2",
				"hidden": "0",
				"url": "/reportloss",
				"endchildren": []
			}, {
				"title": "卡片解挂",
				"lev": "2",
				"hidden": "0",
				"url": "/untiedhang",
				"endchildren": []
			}, {
				"title": "补卡",
				"lev": "2",
				"hidden": "0",
				"url": "/cardReplacement",
				"endchildren": [
					{
						"title": "补卡特许免费",
						"hidden": "0",
					}
				]
			}, {
				"title": "分支机构管理",
				"lev": "2",
				"hidden": "0",
				"url": "/branchManage",
				"endchildren": []
			}, {
				"title": "标签挂失",
				"lev": "2",
				"hidden": "0",
				"url": "/obureportloss",
				"endchildren": []
			}, {
				"title": "标签解挂",
				"lev": "2",
				"hidden": "0",
				"url": "/obuuntiedhang",
				"endchildren": []
			}, {
				"title": "补签",
				"lev": "2",
				"hidden": "0",
				"url": "/obuReplacement",
				"endchildren": [
					{
						"title": "补签特许免费",
						"hidden": "0",
					}
				]
			},]
		}, {
			"title": "7月版",
			"lev": "1",
			"hidden": "0",
			"children": [{
				"title": "储值卡充值",
				"lev": "2",
				"hidden": "0",
				"url": "/storagecardrecharge",
				"endchildren": []
			}, {
				"title": "储值卡圈存",
				"lev": "2",
				"hidden": "0",
				"url": "/storagecardcirclerecharge",
				"endchildren": []
			}, {
				"title": "储值卡挂账还款",
				"lev": "2",
				"hidden": "0",
				"url": "/storagecardrepayment",
				"endchildren": []
			}, {
				"title": "储值卡冲正",
				"lev": "2",
				"hidden": "0",
				"url": "/storedValueCardReverse",
				"endchildren": []
			}, {
				"title": "圈存账户冲正",
				"lev": "2",
				"hidden": "0",
				"url": "/transferAcctReverse",
				"endchildren": [{
					"title": "圈存账户冲正日期权限",
					"hidden": "0",
				}]
			}, {
				"title": "账户充值",
				"lev": "2",
				"hidden": "0",
				"url": "/accountrecharge",
				"endchildren": []
			}, {
				"title": "账户冲正",
				"lev": "2",
				"hidden": "0",
				"url": "/accountReverse",
				"endchildren": [{
					"title": "账户冲正日期权限",
					"hidden": "0",
				}]
			}, {
				"title": "储值卡验卡",
				"lev": "2",
				"hidden": "0",
				"url": "/storagecardcheckcard",
				"endchildren": []
			}]
		}],
	},
	// 登出
	'POST /mock/logout': {},
	// 根据操作员卡号查询随机串
	'POST /mock/getRandom': {
		random: 'random12345678'
	}
}
module.exports = proxy