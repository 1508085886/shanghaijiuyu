module.exports = {
  'POST /mock/queryCardObuOneSendInfo': {
    // obuSysID: '0131002714297278',// 卡片
    obuSysID: '869D4700A239D203',// 标签
    // obuSysID: '0131000555274605',
    printID: '33333333333333333333',
    idType: '22',
    txType: '2',
    manufacturerID: '',
    equipmentClass: '',
    issueVersion: '00',
  },
  'POST /mock/calculateCardReplacement': {
    price: 20000,
  },
  'POST /mock/calculateObuReplacement': {
    price: 10000,
  },
  'POST /mock/orderCharges': {
    status: '1',
  },
  'POST /mock/queryCardReplacement': {
    chargeInfo: {
      payChannel: '',
      subPayChannelId: '',
      vehicleNumber: '鄂CH0032',
      vehicleColor: '1',
      price: 20000,
      payMode: '1',
    },
    userInfo: {
      userName: '公司三零',
      userCertType: '203',
      userCode: '913384003910345609',
    },
    vehicleInfo: {
      vehicleNumber: '鄂CH0032',
      vehicleColor: '1',
      approvedAccount: 5,
      viTotalMass: '2375',
      vehicleClass: '2',
      vehicleType: '0',
    },
    newCardInfo: {
      cardId: '0131002714297278',
      cardType: '2',
      cardVersion: '10',
      status: '1',
      expiryDate: '20310219',
      freeEndDate: '20220808',
    },
    oldCardInfo: {
      cardId: '0131002714297278',
      cardType: '2',
      cardVersion: '10',
      status: '1',
      expiryDate: '20310219',
      freeEndDate: '20220808',
    },
  },
  'POST /mock/queryReceiptChange': {
    chargeInfo: {
      payChannel: '',
      subPayChannelId: '',
      vehicleNumber: '鄂CH0032',
      vehicleColor: '1',
      price: 20000,
      payMode: '1',
    },
    userInfo: {
      userName: '公司三零',
      userCertType: '203',
      userCode: '913384003910345609',
    },
    vehicleInfo: {
      vehicleNumber: '鄂CH0032',
      vehicleColor: '1',
      approvedAccount: 5,
      viTotalMass: '2375',
      vehicleClass: '2',
      vehicleType: '0',
    },
    newObuInfo: {
      obuId: '869D4700A239D203',
      obuVersion: '11',
      status: '1',
      expiryDate: '20310219',
      freeEndDate: '20220808',
    },
    oldObuInfo: {
      obuId: '869D4700A239D203',
      obuVersion: '11',
      status: '1',
      expiryDate: '20310219',
      freeEndDate: '20220808',
    },
  },
  'POST /mock/changeCard': {
    // exCode: '9001',
    status: '1',
  },
  'POST /mock/changeObu': {
    exCode: '9001',
    status: '1',
  },
  'POST /mock/checkSurfaceCode': {
    matchPrintIdStartStr: '11111111',
  },
  'POST /mock/preIssueApply': {
    fileContent15: {
      fileContent: '0000D3E1D3CED8A90000000000000000000000000000333130313038313938363031313732383539000000000000000000000000000000',
      startIndex: '0',
      length: '55',
      verNo: '10'
    },
    fileContent16: {
      fileContent: '0000D3E1D3CED8A90000000000000000000000000000333130313038313938363031313732383539000000000000000000000000000000',
      startIndex: '0',
      length: '55',
      verNo: '10'
    },
    fileContentDFEF01: {
      fileContent: '0000D3E1D3CED8A90000000000000000000000000000333130313038313938363031313732383539000000000000000000000000000000',
      startIndex: '0',
      length: '55',
      verNo: '10'
    },
    fileContentMFEF01: {
      fileContent: '0000D3E1D3CED8A90000000000000000000000000000333130313038313938363031313732383539000000000000000000000000000000',
      startIndex: '0',
      length: '55',
      verNo: '10'
    },
  },
  'POST /mock/preIssueConfirm': {
    result: '1',
    description: '111111',
  },
  'POST /mock/v1/PreIssueApply': {
    fileContent15: {
      fileContent: '0000D3E1D3CED8A90000000000000000000000000000333130313038313938363031313732383539000000000000000000000000000000',
      startIndex: '0',
      length: '55',
      verNo: '10'
    },
    fileContent16: {
      fileContent: '0000D3E1D3CED8A90000000000000000000000000000333130313038313938363031313732383539000000000000000000000000000000',
      startIndex: '0',
      length: '55',
      verNo: '10'
    },
    fileContentDFEF01: {
      fileContent: '0000D3E1D3CED8A90000000000000000000000000000333130313038313938363031313732383539000000000000000000000000000000',
      startIndex: '0',
      length: '55',
      verNo: '10'
    },
    fileContentMFEF01: {
      fileContent: '0000D3E1D3CED8A90000000000000000000000000000333130313038313938363031313732383539000000000000000000000000000000',
      startIndex: '0',
      length: '55',
      verNo: '10'
    },
  },
  'POST /mock/v1/PreIssueConfirm': {
    result: '1',
    description: '111111',
  },
  'POST /mock/afterSale/checkQualification': {
    result: true,
  },
  'POST /mock/statusQuery': {
    obuBlackInfo: {
      optime: '20200101',
      reason: '2',
      notetype: '1',
      note: 'xxxxx',
    },
    cardBlackInfo: {
      optime: '20200102',
      reason: '6',
      notetype: '2',
      note: 'xxxxx',
    },
  },
  //卡片挂失：
  'POST /mock/calculateLostCard': {
    price: 11187,
  },
  'POST /mock/LostCard': {
    result: true,
  },
  'POST /mock/queryReceiptLostCard': {
    chargeInfo: {
      payChannel: '',
      subPayChannelId: '',
      vehicleNumber: '鄂CH0032',
      vehicleColor: '1',
      price: 11187,
      payMode: '1',
    },
    userInfo: {
      userName: '公司三零',
      userCertType: '203',
      userCode: '913384003910345609',
    },
    vehicleInfo: {
      vehicleNumber: '鄂CH0032',
      vehicleColor: '1',
      approvedAccount: 5,
      viTotalMass: '2375',
      vehicleClass: '2',
      vehicleType: '0',
    },
    lostInfo: {
      cardId: '0131002714297278',
      cardType: '2',
      status: '5',
    },
  },
  'POST /mock/queryLostCard': {
    workOrderInfo: {
      isUploadReceipt: '0',
      isInvoice: '0',
      isUploadCert: '1',
      isCharge: '0',
      isBusinessCompleted: '1',
    },
    lostInfo: {
      cardId: '0131002714297278',
      cardType: '2',
      status: '5',
    },
  },
  //卡片解挂：
  'POST /mock/UncouplingCard': {
    result: true,
  },
  'POST /mock/queryReceiptUncouplingCard': {
    chargeInfo: {
      payChannel: '',
      subPayChannelId: '',
      vehicleNumber: '鄂CH0032',
      vehicleColor: '1',
      price: 11187,
      payMode: '1',
    },
    userInfo: {
      userName: '公司三零',
      userCertType: '203',
      userCode: '913384003910345609',
    },
    vehicleInfo: {
      vehicleNumber: '鄂CH0032',
      vehicleColor: '1',
      approvedAccount: 5,
      viTotalMass: '2375',
      vehicleClass: '2',
      vehicleType: '0',
    },
    lostInfo: {
      cardId: '0131002714297278',
      cardType: '2',
      status: '5',
    },
  },
  'POST /mock/queryUncouplingCard': {
    workOrderInfo: {
      isUploadReceipt: '0',
      isInvoice: '0',
      isUploadCert: '1',
      isCharge: '0',
      isBusinessCompleted: '1',
    },
    lostInfo: {
      cardId: '0131002714297278',
      cardType: '2',
      status: '5',
    },
  },
  //标签挂失：
  'POST /mock/LostObu': {
    result: true,
  },
  'POST /mock/queryReceiptLostObu': {
    chargeInfo: {
      payChannel: '',
      subPayChannelId: '',
      vehicleNumber: '鄂CH0032',
      vehicleColor: '1',
      price: 11187,
      payMode: '1',
    },
    userInfo: {
      userName: '公司三零',
      userCertType: '203',
      userCode: '913384003910345609',
    },
    vehicleInfo: {
      vehicleNumber: '鄂CH0032',
      vehicleColor: '1',
      approvedAccount: 5,
      viTotalMass: '2375',
      vehicleClass: '2',
      vehicleType: '0',
    },
    lostInfo: {
      obuId: '869D4700A239D203',
      obuPrintId: '2',
      status: '5',
    },
  },
  'POST /mock/queryLostObu': {
    workOrderInfo: {
      isUploadReceipt: '0',
      isInvoice: '0',
      isUploadCert: '1',
      isCharge: '0',
      isBusinessCompleted: '1',
    },
    lostInfo: {
      obuId: '869D4700A239D203',
      obuPrintId: '2',
      status: '5',
    },
  },
  //标签解挂：
  'POST /mock/UncouplingObu': {
    result: true,
  },
  'POST /mock/queryReceiptUncouplingObu': {
    chargeInfo: {
      payChannel: '',
      subPayChannelId: '',
      vehicleNumber: '鄂CH0032',
      vehicleColor: '1',
      price: 11187,
      payMode: '1',
    },
    userInfo: {
      userName: '公司三零',
      userCertType: '203',
      userCode: '913384003910345609',
    },
    vehicleInfo: {
      vehicleNumber: '鄂CH0032',
      vehicleColor: '1',
      approvedAccount: 5,
      viTotalMass: '2375',
      vehicleClass: '2',
      vehicleType: '0',
    },
    lostInfo: {
      obuId: '869D4700A239D203',
      obuPrintId: '2',
      status: '5',
    },
  },
  'POST /mock/queryUncouplingObu': {
    workOrderInfo: {
      isUploadReceipt: '0',
      isInvoice: '0',
      isUploadCert: '1',
      isCharge: '0',
      isBusinessCompleted: '1',
    },
    lostInfo: {
      obuId: '869D4700A239D203',
      obuPrintId: '2',
      status: '5',
    },
  },
  // 补卡计费：
  'POST /mock/calculateCardReissue': {
    price: 20000,
  },
  // 补卡业务申请：
  'POST /mock/reissueCard': {
    // orderId: '123456',
    // produceOrderId: '111222333',
    exCode: '9001',
  },
  // 补卡业务回执查询
  'POST /mock/queryCardReissue': {
    chargeInfo: {
      payChannel: '',
      subPayChannelId: '',
      vehicleNumber: '鄂CH0032',
      vehicleColor: '1',
      price: 11187,
      payMode: '1',
    },
    userInfo: {
      userName: '公司三零',
      userCertType: '203',
      userCode: '913384003910345609',
    },
    vehicleInfo: {
      vehicleNumber: '鄂CH0032',
      vehicleColor: '1',
      approvedAccount: 5,
      viTotalMass: '2375',
      vehicleClass: '2',
      vehicleType: '0',
    },
    oldCardInfo: {
      CardId: '0131002714297278',
      cardType: '2',
      cardVersion: '10',
      status: '1',
      freeEndDate: '20220808',
    },
    newCardInfo: {
      CardId: '0131002714297278',
      cardType: '2',
      cardVersion: '10',
      status: '1',
      expiryDate: '20310219',
      freeEndDate: '20220808',
    },
  },
  // 补卡业务查询
  'POST /mock/queryReissueCard': {
    workOrderInfo: {
      isUploadReceipt: '0',
      isInvoice: '0',
      isUploadCert: '1',
      isCharge: '1',
    },
    oldCardInfo: {
      cardId: '0131000555274605',
      cardVersion: '01',
      status: '2',
    },
    newCardInfo: {
      cardId: '0131000555274605',
      cardVersion: '01',
      status: '1',
    }
  },
  // 补签计费：
  'POST /mock/calculateObuReissue': {
    price: 20000,
  },
  // 补签业务申请：
  'POST /mock/reissueObu': {
    orderId: '123456',
    produceOrderId: '111222333',
  },
  'POST /mock/queryReceiptReissue': {
    chargeInfo: {
      payChannel: '支付宝',
      subPayChannelId: '123',
      vehicleNumber: '鄂CH0032',
      vehicleColor: '1',
      price: 20000,
      payMode: '1',
    },
    userInfo: {
      userName: '公司三零',
      userCertType: '203',
      userCode: '913384003910345609',
    },
    vehicleInfo: {
      vehicleNumber: '鄂CH0032',
      vehicleColor: '1',
      approvedAccount: 5,
      viTotalMass: '2375',
      vehicleClass: '2',
      vehicleType: '0',
    },
    newObuInfo: {
      obuId: '869D4700A239D203',
      obuVersion: '11',
      status: '1',
      expiryDate: '20310219',
      freeEndDate: '20220808',
    },
    oldObuInfo: {
      obuId: '869D4700A239D203',
      obuVersion: '11',
      status: '1',
      freeEndDate: '20220808',
    },
  },
  // 补签业务查询
  'POST /mock/queryReissueObu': {
    workOrderInfo: {
      isUploadReceipt: '0',
      isInvoice: '0',
      isUploadCert: '1',
      isCharge: '1',
    },
    oldObuInfo: {
      obuId: '0131000555274605',
      obuVersion: '01',
      status: '2',
    },
    newObuInfo: {
      obuId: '0131000555274605',
      obuVersion: '01',
      status: '1',
    }
  },
}