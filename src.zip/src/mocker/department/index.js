module.exports = {
  'POST /mock/departmentList': {
    departmentList: [
      {
        departmentId: '1',
        department: '研发部',
        agentName: '张三',
        agentIdType: '101',
        agentIdNum: '3982749082032',
        tel: '13333333333'
      }, {
        departmentId: '2',
        department: '销售部',
        agentName: '李四',
        agentIdType: '101',
        agentIdNum: '76543234',
        tel: '13333333334'
      }, {
        departmentId: '3',
        department: '市场部',
        agentName: '王五',
        agentIdType: '101',
        agentIdNum: '243344755453',
        tel: '13333333335'
      }
    ]
  },
  'POST /mock/departmentAdd': {
    msg: '成功'
  }
}