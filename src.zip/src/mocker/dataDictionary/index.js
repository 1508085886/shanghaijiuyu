/**
 * @description 数据字典查询
 * @param userCertType 证件类型
 * @param vehicleColor 车牌颜色
 * @param vehicleClass 车型
*/
const dic = require('./data.json')

module.exports = {
  'POST /mock/dataDictionary': (req, res) => {
    const { fieldCode } = req.body.data;
    return res.json({
      dataDictList: dic[fieldCode]
    });
  },
  // 网点列表查询
  'POST /mock/getNetInfoList': {
    netInfoList: [
      {
        netId: '111',
        netName: '网点A',
        netPhone: '188111111111',
        netAddr: '地址1',
      },
      {
        netId: '112',
        netName: '网点B',
        netPhone: '188111111111',
        netAddr: '地址1',
      },
      {
        netId: '113',
        netName: '网点C',
        netPhone: '188111111111',
        netAddr: '地址1',
      },
    ],
  },
  // 操作员列表查询
  'POST /mock/getOprtInfoList': {
    oprtInfoList: [
      {
        oprtId: '001',
        oprtName: '操作员A',
      },
      {
        oprtId: '002',
        oprtName: '操作员B',
      },
      {
        oprtId: '003',
        oprtName: '操作员C',
      },
    ],
  },
}