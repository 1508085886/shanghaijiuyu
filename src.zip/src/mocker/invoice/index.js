module.exports = {
    'POST /mock/addBranch': {
        workOrderList: [
            {
                requestUrl: "/image/imagepath",
                fpqqlsh: "o123456789"
            }
        ]
    },
    'POST /mock/refund': {
        workOrderID: "123456"
    },
}