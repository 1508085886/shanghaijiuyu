

module.exports = {
  "POST /mock/queryNewVersionInfo": {
    data:{
      versionList:[
        {version: 'V008', updateTime: '20210412120100', content:'更新了xx' },
        {version: 'V007', updateTime: '20210412120100', content:'更新了xx' },
        {version: 'V006', updateTime: '20210412120100', content:'更新了xx' },
        {version: 'V005', updateTime: '20210412120100', content:'更新了xx' },
      ]
    }
  }
}
