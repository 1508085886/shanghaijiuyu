/**
 * @description 文件上传
*/

module.exports = {
  'POST /mock/upload': (req, res) => {
    const { file } = req.body.data;
    return res.json({
      innerImgid: '1'
    });
  }
}
