module.exports = {
  'POST /mock/rechargeAccount': [
    {
      accountNum: '29873892',
      accountName: 'B类充值账户',
      zhye: 10000,
      xfxe: 50000,
      jgxe: 50000,
      kywqsje: 0
    }, {
      accountNum: '12918023',
      accountName: 'B类充值账户',
      zhye: 20000,
      xfxe: 40000,
      jgxe: 30000,
      kywqsje: 0
    }
  ]
}