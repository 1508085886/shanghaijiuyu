module.exports = {
    'POST /mock/queryLists': {
        chargeList: [
            {
                accountId: '2222',
                cardId: '123456',
                workOrderId: '123456',
                workrderStatus: '0',
                tradeType: '1',
                tradeDate: '2021-07-13',
                tradeTime: '2021-07-13 12:00:00',
                txAmountBef: '100',
                txAmount: '100',
                payMode: '1',
                operatorid: '123456',
                netid: '1001',
                unLoadFlag: '0',
            },
            {
                accountId: '2222',
                cardId: '123456',
                workOrderId: '123456',
                workrderStatus: '0',
                tradeType: '1',
                tradeDate: '2021-07-13',
                tradeTime: '2021-07-13 12:00:00',
                txAmountBef: '100',
                txAmount: '100',
                payMode: '1',
                operatorid: '123456',
                netid: '1001',
                unLoadFlag: '0',
            },
        ]
    },
    'POST /mock/reverseCPCheck': {
        unloadResult: '2',
    },
    'POST /mock/cardCircleConfirm': {
        unloadResult: '3',
    },
    'POST /mock/cardUnLoad': {
        loadUpMac1: '12345678',
    },
    'POST /mock/accountReversal': {
        loadUpMac1: '12345678',
    },
    'POST /mock/acctCircleRectification': {
        loadUpMac1: '12345678',
    },
    'POST /mock/preReversal': {
        loadUpMac1: '12345678',
    },
    'POST /mock/reverseRecordQuery': {
        purchaseList: [
        ],
    },
    'POST /mock/reverseReceiptQuery': {
        username: '张三',
        zjlx: '101',
        userCode: '320754199912124567',
        cardId: '0322 0040 8667 5681',
        accountId: '374645',
        accountType: '4',
        accountStatus: '1',
        amount: '10000',
        acctBalanceBef: '20000',
        acctBalanceAft: '10000',
    },
};
