/**
 * @description 获取账户相关数据，store配合localstorage和动态库
*/
import store from '@/store'
// import { getSessionStorage } from '@/utils/storage'
// import { TOKEN_KEY } from '@/config/staticVariable'


/**
 * @description 本地图片存储
*/
export const savepic = async (strPath, strPicName, strPic) => {
  const rs = JSON.parse(etcdev.savepic(strPath, strPicName, strPic));
  // if (rs.oprtid) {
  //   return rs.oprtid;
  // }
  // alert(rs.msg);
  return rs;
}

/**
 * @description 本地图片读取
*/
export const getpic = async (strPath, strPicName) => {
  const rs = JSON.parse(etcdev.getpic(strPath, strPicName));
  // if (rs.oprtid) {
  //   return rs.oprtid;
  // }
  // alert(rs.msg);
  return rs;
}


/**
 * @description 本地图片删除
*/
export const deletepic = async (strPath, strPicName) => {
  const rs = JSON.parse(etcdev.deletepic(strPath, strPicName));
  // if (rs.oprtid) {
  //   return rs.oprtid;
  // }
  // alert(rs.msg);
  return rs;
}
