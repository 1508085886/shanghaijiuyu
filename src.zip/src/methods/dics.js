/**
 * @description 数据字典相关
*/
import { requestDictionary } from '@/api/common'
import dicConf from '@/config/dictionary'
import localDics from '@/config/localDictionary'

/**
 * @description 存储已获得的字典
*/
const dicsMap = {}
/**
 * @description key映射
*/
export const dicKeys = (function (dicConf) {
  const keys = {}
  for (let k in dicConf) {
    keys[k] = k
  }
  return keys
})(dicConf)

/**
 * @description 获取指定类型所有字典
*/
export const getAllDics = async (key) => {
  if (!(dicsMap[key] && dicsMap[key].length > 0)) {
    let dics = ''
    if (dicConf[key].origin === 'remote') {
      dics = await requestDictionary(dicConf[key].filedCode, dicConf[key].fieldName)
      dicsMap[key] = dics.dataDictList || null
    } else {
      dics = await localDics(dicConf[key].filedCode)
      dicsMap[key] = dics || null
    }
  }
  if (dicConf[key].filter) {
    const newVals = []
    dicsMap[key].forEach(d => {
      if (dicConf[key].filter(d.value)) {
        newVals.push(d)
      }
    })
    dicsMap[key] = newVals
  }
  return dicsMap[key]
}

/**
 * @description 根据代码获取指定类型文本，格式2-xxx
*/
export const getDicDesByCode = async (key, code) => {
  if (!dicsMap[key]) {
    await getAllDics(key)
  }
  const type = dicsMap[key].find(dic => dic.value === code)
  return type && (code + ' - ' + type.description) || ''
}
/**
 * @description 根据代码获取指定类型简单文本
*/
export const getDicEasyDesByCode = async (key, code) => {
  if (!dicsMap[key]) {
    await getAllDics(key)
  }
  const type = dicsMap[key].find(dic => dic.value === code)
  return type && (type.description) || ''
}

/**
 * @description 根据文本获取指定类型的代码
*/
export const getDicCodeByDes = async (key, des) => {
  if (!dicsMap[key]) {
    await getAllDics(key)
  }
  const type = dicsMap[key].find(dic => dic.description === des)
  return type && type.value || ''
}

/**
 * @description 根据传入的类型筛选返回文本
*/
export const getDicDesByAll = (dics, code) => {

  if (!dics || !code) return ''
  const type = dics.find(dic => dic.value === code)
  return type && (code + ' - ' + type.description) || ''
}

/**
 * @description 根据传入的类型筛选返回代码
*/
export const getDicCodeByAll = (dics, des) => {
  if (!dics || !des) return ''
  const type = dics.find(dic => dic.description === des)
  return type && type.value || ''
}
