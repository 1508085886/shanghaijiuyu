/**
 * @description 发行公共方法
*/
// import { getCpuInfo, getObuInfo, issueCard, issueObu } from '@/api/dynamicLibrary'
import { getOperCardId, getCpuId, getObuId, issueCard, issueOBU } from '@/utils/dynamic'
import { devicePublish, ensureDevicePublish } from '@/api/publish'
// import { issueCard } from '@/api/dynamicLibrary'
/**
 * @description 发行卡
*/
export const publishCard = async ({
  orderType, // 订单类型
  vehicleNumber, // 车牌号码
  vehicleColor, // 车牌颜色
  etcUserId,
  msgType,
  workOrderID,

}) => {
  // 读取卡片信息
  // const cardInfo = getCpuInfo()
  const cardInfo = getCpuId();
  if (cardInfo.code != "0") {
    return new Promise((resolve) => {
      resolve({
        status: false,
        msg: cardInfo.msg
      })
    })
  }
  if (cardInfo.issueversion == 'FF') {
    return new Promise((resolve) => {
      resolve({
        status: false,
        msg: '卡版本为空,无法发行'
      })
    })
  }
  // 设备空发
  const publishRes = await devicePublish({
    orderType,
    vehicleNumber,
    vehicleColor,
    etcUserId,
    msgType,
    workOrderID,
    cardId: cardInfo.cardid,
    cardVerNo: cardInfo.issueversion
  })
  if (publishRes) {
    const issueCardRes = await issueCard(cardInfo, publishRes);
    if (issueCardRes && issueCardRes.code === '0') {
      const ensureRes = await ensureDevicePublish({
        etcUserId,
        orderType,
        vehicleNumber, // 车牌号码
        vehicleColor,
        workOrderID,
        cardId: cardInfo.cardid,
        msgType: '1'
      })
      return new Promise((resolve) => {
        resolve({
          status: ensureRes.result === '1',
          msg: ensureRes.description
        })
      })
    } else {
      return new Promise((resolve) => {
        resolve({
          status: false,
          msg: issueCardRes.msg
          // msg: '写卡失败'
        })
      })
    }
  } else {
    return new Promise((resolve) => {
      resolve({
        status: false,
        msg: '硬件故障：卡片发行失败'
      })
    })
  }
}

/**
 * @description 发行obu
*/
export const publishObu = async ({
  orderType, // 订单类型
  vehicleNumber, // 车牌号码
  vehicleColor, // 车牌颜色
  etcUserId,
  msgType,
  workOrderID,
}) => {
  // 读取OBU
  const obuInfo = getObuId();
  // debugger;
  if (obuInfo.code != "0") {
    return new Promise((resolve) => {
      resolve({
        status: false,
        msg: obuInfo.msg
      })
    })
  }
  if (obuInfo.issueversion == 'FF') {
    return new Promise((resolve) => {
      resolve({
        status: false,
        msg: '标签版本为空,无法发行'
      })
    })
  }
  // 设备空发
  const publishRes = await devicePublish({
    orderType,
    vehicleNumber,
    vehicleColor,
    obuId: obuInfo.obuid,
    obuSign: '2',
    obuVerNo: obuInfo.issueversion,
    etcUserId,
    msgType,
    workOrderID,
  })
  if (publishRes) {
    // debugger;
    // alert(publishRes.fileContentDFEF01.fileContent.length);
    const issueOBURes = await issueOBU(obuInfo, publishRes);
    if (issueOBURes && issueOBURes.code === '0') {
      const ensureRes = await ensureDevicePublish({
        etcUserId,
        orderType,
        vehicleNumber, // 车牌号码
        vehicleColor,
        workOrderID,
        obuId: obuInfo.obuid,
        msgType: '1'
      })
      return new Promise((resolve) => {
        resolve({
          status: ensureRes.result === '1',
          msg: ensureRes.description
        })
      })
    } else {
      return new Promise((resolve) => {
        resolve({
          status: false,
          msg: issueOBURes.msg
        })
      })
    }
  } else {
    return new Promise((resolve) => {
      resolve({
        status: false,
        msg: '硬件故障：标签发行失败'
      })
    })
  }
}
