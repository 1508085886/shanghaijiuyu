/**
 * @description 进入项目，恢复本地数据库保存的数据
*/
import store from '@/store'

/**
 * @description 恢复车辆注册数据
*/
export const recoveryRegisterVehicle = () => {
  store.dispatch('RecoveryRegisterVehicle')
}

/**
 * @description 恢复注册用户数据
*/
export const recoveryRegisterUser = () => {
  store.dispatch('RecoveryRegisterUser')
}

/**
 * @description 恢复经办人图片数据
*/
export const recoveryTransactorImg = () => {
  store.dispatch('RecoveryTransactorImg')
}
// /**
//  * @description 恢复换卡-上传证件-经办人证件图片数据
// */
// export const recoveryChangeCardAgentImg = () => {
//   store.dispatch('idbChangeCard/RecoveryAgentImg')
// }
// /**
//  * @description 恢复换卡-上传证件-其他证件图片数据
// */
// export const recoveryChangeCardOtherImg = () => {
//   store.dispatch('idbChangeCard/RecoveryOtherImg')
// }

/**
 * @description 恢复所有数据
*/
export default () => {
  // 恢复车辆注册数据
  recoveryRegisterVehicle()
  // 恢复新办发行注册用户数据
  recoveryRegisterUser()
  // 恢复经办人图片数据
  recoveryTransactorImg()
  // // 恢复换卡-上传证件-经办人证件图片数据
  // recoveryChangeCardAgentImg()
  // // 恢复换卡-上传证件-其他证件图片数据
  // recoveryChangeCardOtherImg()
}
