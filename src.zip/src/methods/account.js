/**
 * @description 获取账户相关数据，store配合localstorage和动态库
*/
import store from '@/store'
import { getSessionStorage } from '@/utils/storage'
import { TOKEN_KEY } from '@/config/staticVariable'

/**
 * @description 获取token
*/
export const getToken = () => {
  // return '1234'
  let token = store.getters.token
  if (!token) {
    token = getSessionStorage(TOKEN_KEY)
    store.dispatch('GetToken', token)
  }
  return token
}

/**
 * @description 获取操作员卡号
*/
export const getOperCardId = async () => {



  const rs = JSON.parse(etcdev.getopercardid());
  if (rs.oprtid) {
    return rs.oprtid;
  }
  return null;
  // return '12345678'
  if (!store.getters.operCardId) {
    await store.dispatch('GetOperCardId')
  }
  return store.getters.operCardId
}

/**
 * @description 获取操作员随机数
*/
export const getRandom = async () => {
  // return '88888888'
  // if (!store.getters.random) {
  await store.dispatch('GetRandom')
  // }
  return store.getters.random
}

/**
 * @description 获取mac
*/
export const getMac = async () => {
  // return '88888888'
  if (!store.getters.mac) {
    await store.dispatch('GetMac')
  }
  return store.getters.mac
}

/**
 * @description 获取菜单页面数组，获得页面权限
*/
export const getMenuItems = async () => {
  const menuIds = store.getters.menuIds;
  let menuItems = [];
  if (menuIds) {
    // menuIds.filter(element => 
    //   element.hidden === '0'
    // ).
    menuIds.forEach(menuL1 => {
      //   menuL1.children.filter(child => 
      //     child.hidden === '0'
      //  ).
      menuL1.children.forEach(child => {
        menuItems.push(child.url);
      });
    })
    await store.dispatch('GetPermissions', menuItems)
  }
  // return menuItems
}
/**
 * @description 获取页面元素权限数组，格式为[{menu:'changecard',permissions:{specialfree:true,xxxx:true}},]
*/
export const getElementPermissions = async () => {
  const menuIds = store.getters.menuIds;
  let elementPermissions = [];
  if (menuIds) {
    menuIds.forEach(menuL1 => {
      menuL1.children.forEach(child => {
        let obj = { permissions: {} };
        obj.menu = child.url;
        child.endchildren.forEach(element => {
          if (element.title.indexOf('特许免费') > -1) {
            obj.permissions.specialfree = true
          }
          if (element.title.indexOf('日期权限') > -1) {
            obj.permissions.dateauthority = true
          }
        });
        elementPermissions.push(obj);
      });
    })
    await store.dispatch('GetElementPermissions', elementPermissions)
    // console.log('getters.elementPermissions', store.getters.elementPermissions)
  }
  // return menuItems
}
