import { banks } from '../config/bankNameMap'

/**
 * @description 根据简称查全名
 * @param { String } abb 简称
*/
export const getFullNameByAbb = abb => {
  return banks[abb]
}

/**
 * @description 根据全名查简称
 * @param { String } full 全名
*/
export const getAbbFByullName = full => {
  for (let key in banks) {
    if (banks[key] === full) return key
  }
  return undefined
}
