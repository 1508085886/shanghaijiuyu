import Vue from 'vue'
import constants from './globeProperty/constants' // 常量
import methods from './globeProperty/methods' // 全局方法
import router from './router'
import App from './App.vue'
import store from './store'
import ElementUI from 'element-ui'
import ElImageViewer from 'element-ui/packages/image/src/image-viewer'
import IndexedDb from '@/utils/indexedDb'
import recoveryLocalData from '@/methods/recoveryLocalData'
import EmptyButton from '@/components/EmptyButton'
import LoadingButton from '@/components/LoadingButton'
import TypeSelectInput from '@/components/TypeSelectInput'
import TypeSelect from '@/components/TypeSelect'
import TypeText from '@/components/TypeText'
import VueWorker from 'vue-worker'
import 'element-ui/lib/theme-chalk/index.css'
import './assets/icons' // icon
import '@/assets/styles/index.scss'
import './globeProperty/filters'
import { getFormatAmount, getDatePoint, getFormatCardIdw, getFormatOBUFrontIdw } from '@/utils/utils'
import { JumpPage } from '@/permission'
import { dbclick } from '@/views/dbClick'
import '@/utils/dialogDrag' // 拖拽子窗体
import { isEmptyObj } from '@/utils/utils.js' // 对象判空
import VConsole from 'vconsole';
Vue.use(constants)// 常量

// const vConsole = new VConsole()
// Vue.use(vConsole)
/*PAD端兼容代码*/
// Vue.prototype.$isPad = (navigator.userAgent === Vue.prototype.$padUserAgent);
// console.log('Vue1.$isPad ', Vue.$isPad)
if (Vue.prototype.$isPad) {
  const vConsole = new VConsole()
  Vue.use(vConsole)
  //4.1.	获取网络请求信息
  let netInfo = null;
  let multipleQuery = null;
  let rtnNet = AndroidBean.getNetInfoBean();
  if (!rtnNet) {
    Vue.$message.error('获取网络请求信息失败');
  } else {
    netInfo = JSON.parse(rtnNet);
  }
  //4.2.	获取综合查询信息
  let rtnMul = AndroidBean.getMultipleQueryBean();
  if (!rtnMul) {
    Vue.$message.error('获取综合查询信息失败');
  } else {
    multipleQuery = JSON.parse(rtnMul);
  }
  Vue.mixin({
    mounted: function () {
      if (netInfo) {
        // 设置网络请求信息
        store.commit('SET_REG_APPID', netInfo.regAppId || '');
        store.commit('SET_OPRT_ID', netInfo.oprtId || '');
        store.commit('SET_REG_CHANNEL_ID', netInfo.regChannelId || '');
        store.commit('SET_TOKEN', netInfo.token || '');
      }
      if (multipleQuery) {
        // 设置综合查询信息
        store.commit('SET_SEARCH_CAR_INFO', multipleQuery.vehicleInfo || {});
        store.commit('SET_SEARCH_CARD_INFO', multipleQuery.cardInfo || {});
        store.commit('SET_SEARCH_OBU_INFO', multipleQuery.obuInfo || {});
        store.commit('SET_SEARCH_User_INFO', multipleQuery.userInfo || {});
        store.commit('SET_SEARCH_DEPARTMENT_INFO', multipleQuery.departmentInfo || {});
        if (multipleQuery.userAcctList && multipleQuery.userAcctList.length > 0) {
          store.commit('SET_SEARCH_ACCOUNT_INFO', multipleQuery.userAcctList[0] || {});
        }
      }
    }
  })
}
import './permission' // 权限控制文件

Vue.use(dbclick)
Vue.use(IndexedDb)

Vue.use(VueWorker)


Vue.use(ElementUI, {
  size: 'medium' // set element-ui default size
})
Vue.use(methods)// 全局方法

recoveryLocalData()

Vue.component('EmptyButton', EmptyButton)
Vue.component('LoadingButton', LoadingButton)// 控制加载按钮
Vue.component('TypeSelectInput', TypeSelectInput)
Vue.component('TypeSelect', TypeSelect)
Vue.component('TypeText', TypeText)
Vue.component('ElImageViewer', ElImageViewer)

Vue.config.productionTip = false

Vue.filter('amount', getFormatAmount)//金额分转换元，保留2位小数

Vue.filter('datepoint', getDatePoint)//时间格式化加 。

Vue.filter('space4', getFormatCardIdw)// 4位一组格式化数据
Vue.filter('space42218', getFormatOBUFrontIdw)// 42218分隔格式化数据

setTimeout(() => {
  new Vue({
    router,
    store,
    render: h => h(App)
  }).$mount('#app')
}, 300);

Vue.prototype.isEmptyObj = isEmptyObj;// 对象判空
Vue.prototype.$message = function (msg) {
  ElementUI.Message({
    ...msg,
    duration: 0,
    showClose: true,
  })
}
Vue.prototype.$message.info = function (msg) {
  return ElementUI.Message.info({
    message: msg,
    duration: 0,
    showClose: true,
  })
}
Vue.prototype.$message.error = function (msg) {
  return ElementUI.Message.error({
    dangerouslyUseHTMLString: true,
    message: msg,
    duration: 0,
    showClose: true,
  })
}
Vue.prototype.$message.warning = function (msg) {
  return ElementUI.Message.warning({
    message: msg,
    duration: 0,
    showClose: true,
  })
}
Vue.prototype.$message.success = function (msg) {
  return ElementUI.Message.success({
    message: msg,
  })
}

// //全局loading 
// Vue.prototype.$loading = function () {
//   return ElementUI.Loading.service({
//     lock: true,
//     text: 'Loading',
//     spinner: 'el-icon-loading',
//     background: 'rgba(0, 0, 0, 0.7)'
//   })
// }

Vue.prototype.$trim = function (str) {// 去除字符串中所有空格
  return str.replace(/\s/g, '');
}
Vue.prototype.JumpPage = JumpPage // 重新打开页面的page集合



