/**
 * @description 本地数据库配置
 */

/**
 * @description 数据库名称
 */
export const dbName = 'EtcFront';

/**
 * @description 数据表配置
 */
export const sheets = {
  // user: '++id',
  carRegister: '++id',
  registerVehicle: '++id',
  registerUser: '++id',
  transactorImg: '++id',
  verifyLicenseImg: '++id',
  bankCardImg: '++id',
  reportLoss_userImg: '++id',// 卡片挂失-上传证件-用户证件
  reportLoss_agentImg: '++id',// 卡片挂失-上传证件-经办人证件
  reportLoss_otherImg: '++id',// 卡片挂失-上传证件-其他证件
  untiedHang_userImg: '++id',// 卡片解挂-上传证件-用户证件
  untiedHang_agentImg: '++id',// 卡片解挂-上传证件-经办人证件
  untiedHang_otherImg: '++id',// 卡片解挂-上传证件-其他证件
  obureportLoss_userImg: '++id',// 标签挂失-上传证件-用户证件
  obureportLoss_agentImg: '++id',// 标签挂失-上传证件-经办人证件
  obureportLoss_otherImg: '++id',// 标签挂失-上传证件-其他证件
  obuUntiedHang_userImg: '++id',// 标签解挂-上传证件-用户证件
  obuUntiedHang_agentImg: '++id',// 标签解挂-上传证件-经办人证件
  obuUntiedHang_otherImg: '++id',// 标签解挂-上传证件-其他证件
  changeCard_agentImg: '++id',// 换卡-上传证件-经办人证件
  changeCard_otherImg: '++id',// 换卡-上传证件-其他证件
  changeOBU_agentImg: '++id',// 换签-上传证件-经办人证件
  changeOBU_otherImg: '++id',// 换签-上传证件-其他证件
  search_agentImg: '++id',// 搜索框-上传证件-经办人证件
  search_userImg: '++id',// 搜索框-上传证件-用户证件
  search_otherImg: '++id',// 搜索框-上传证件-用户证件
  cardReplacement_userImg: '++id',// 补卡-上传证件-用户证件
  cardReplacement_agentImg: '++id',// 补卡-上传证件-经办人证件
  cardReplacement_otherImg: '++id',// 补卡-上传证件-其他证件
  obuReplacement_userImg: '++id',// 补签-上传证件-用户证件
  obuReplacement_agentImg: '++id',// 补签-上传证件-经办人证件
  obuReplacement_otherImg: '++id',// 补签-上传证件-其他证件
};
