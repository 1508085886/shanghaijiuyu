/**
 * @description 全局静态变量名称
*/

// token本地存储名称
export const TOKEN_KEY = 'token'
