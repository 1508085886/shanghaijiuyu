export default {
  '101': {
    multiple: true,
    belong: 'person',
    ocr: {
      '1': '/idOrcIdentify'
    }
  },
  '102': {
    multiple: false,
    belong: 'person',
    ocr: {
      '1': ''
    }
  },
  '103': {
    multiple: true,
    belong: 'person',
    ocr: {
      '1': ''
    }
  },
  '104': {
    multiple: true,
    belong: 'person',
    ocr: {
      '1': ''
    }
  },
  '105': {
    multiple: false,
    belong: 'person'
  },
  '106': {
    multiple: true,
    belong: 'person'
  },
  '113': {
    multiple: true,
    belong: 'person'
  },
  '114': {
    multiple: true,
    belong: 'person'
  },
  '199': {
    multiple: false,
    belong: 'person'
  },
  '201': {
    multiple: false,
    belong: 'company'
  },
  '202': {
    multiple: false,
    belong: 'company',
    ocr: {
      '1': ''
    }
  },
  '203': {
    multiple: false,
    belong: 'company',
    ocr: {
      '1': '/businessLicense'
    }
  },
  '204': {
    multiple: false,
    belong: 'company',
    ocr: {
      '1': ''
    }
  },
  '205': {
    multiple: false,
    belong: 'company'
  },
  '206': {
    multiple: false,
    belong: 'company'
  },
  '217': {
    multiple: false,
    belong: 'company'
  },
  '218': {
    multiple: false,
    belong: 'company'
  },
  '219': {
    multiple: false,
    belong: 'company'
  },
  '299': {
    multiple: false,
    belong: 'company'
  },
  '301': {
    multiple: [
      {
        label: '印章页'
      }, {
        label: '条码页'
      }
    ],
    ocr: {
      '1': '/vehicleLicenseSealAutomaticIdentificate',
      '2': '/vehicleLicenseAutomaticIdentificate',
    }
  },
  '302': {
    multiple: false,
    ocr: {
      '1': '/motorVehicleRegisterOrcIdentify'
    }
  },
  '401': {
    multiple: false
  },
  '501': {
    multiple: false
  },
  '502': {
    multiple: false
  },
  '601': {
    multiple: false,
    ocr: {
      '1': '/bankCardOrc'
    }
  }

}
