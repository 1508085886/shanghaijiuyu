/**
 * @description 字典信息配置
 */

export default {
  upgradeStatus: {
    filedCode: 'upgradeStatus',
    fieldName: '升级状态',
    origin: 'local',
  },
  issueStatus: {
    filedCode: 'issueStatus',
    fieldName: '发行状态',
    origin: 'local',
  },
  vehicleLocation: {
    filedCode: 'vehicleLocation',
    fieldName: '车辆归属地',
    origin: 'local',
  },
  whiteType: {
    filedCode: 'whiteType',
    fieldName: '白名单类型',
    origin: 'local',
  },
  cardnoteType: {
    filedCode: 'cardnoteType',
    fieldName: '卡片黑名单发布方',
    origin: 'local',
  },
  obunoteType: {
    filedCode: 'obunoteType',
    fieldName: '黑名单发布方',
    origin: 'local',
  },
  obuStatusReason: {
    filedCode: 'obuStatusReason',
    fieldName: '标签入单原因',
    origin: 'local',
  },
  cardStatusReason: {
    filedCode: 'cardStatusReason',
    fieldName: '卡片入单原因',
    origin: 'local',
  },
  userType: {
    filedCode: 'userType',
    fieldName: '用户类型',
    origin: 'local',
  },
  userTypeP: {
    filedCode: 'userTypeP',
    fieldName: '用户类型',
    origin: 'local',
  },
  userTypeC: {
    filedCode: 'userTypeC',
    fieldName: '用户类型',
    origin: 'local',
  },
  agentIdType: {
    filedCode: 'agentIdType',
    fieldName: '用户类型',
    origin: 'local',
  },
  userCertType: {
    filedCode: 'userCertType',
    fieldName: '证件类型',
    origin: 'local',
  },
  userCertTypeP: {
    filedCode: 'userCertTypeP',
    fieldName: '证件类型',
    origin: 'local',
  },
  userCertTypeC: {
    filedCode: 'userCertTypeC',
    fieldName: '证件类型',
    origin: 'local',
  },
  vehicleColor: {
    filedCode: 'vehicleColor',
    fieldName: '车牌颜色',
    origin: 'local',
  },
  mediaType: {
    filedCode: 'mediaType',
    fieldName: '图片类型',
    origin: 'local',
  },
  vehicleType: {
    filedCode: 'vehicleType',
    fieldName: '车辆类型',
    origin: 'remote',
  },
  vehicleUserClass: {
    filedCode: 'vehicleUserClass',
    fieldName: '车辆用户类型',
    origin: 'local',
  },
  blackStatus: {
    filedCode: 'blackStatus',
    fieldName: '状态名单',
    origin: 'local',
  },
  cardType: {
    filedCode: 'cardType',
    fieldName: '卡片类型',
    origin: 'local',
  },
  vehicleClass: {
    filedCode: 'vehicleType',
    fieldName: '收费车型',
    origin: 'remote',
  },
  vehicleClassL: {
    filedCode: 'vehicleClassL',
    fieldName: '收费车型',
    origin: 'local',
  },
  vehicleCategory: {
    filedCode: 'vehicleCategory',
    fieldName: '车种',
    origin: 'remote',
  },
  vehicleCategoryL: {
    filedCode: 'vehicleCategoryL',
    fieldName: '车种',
    origin: 'local',
  },
  giver: {
    filedCode: 'giver',
    fieldName: '优惠活动',
    origin: 'remote',
  },
  netId: {
    filedCode: 'netId',
    fieldName: '网点',
    origin: 'remote',
  },
  oprtId: {
    filedCode: 'oprtId',
    fieldName: '操作员ID',
    origin: 'remote',
  },
  allowTakeOff: {
    filedCode: 'allowTakeOff',
    fieldName: '允许脱绑',
    origin: 'local',
  },
  fixType: {
    filedCode: 'installMode',
    fieldName: '安装方式',
    origin: 'remote',
  },
  payMode0: {
    filedCode: 'payMode0',
    fieldName: '支付方式',
    origin: 'local',
  },
  payMode1: {
    filedCode: 'payMode1',
    fieldName: '支付方式',
    origin: 'local',
  },
  payMode: {
    filedCode: 'payMode',
    fieldName: '支付方式',
    origin: 'remote',
  },
  vehicleCertType: {
    filedCode: 'vehicleCertType',
    fieldName: '车辆证件类型',
    origin: 'local',
  },
  bizCode: {
    filedCode: 'bizCode',
    fieldName: '业务类型',
    origin: 'local',
  },
  province: {
    filedCode: 'province',
    fieldName: '所属省',
    origin: 'local',
  },
  bankName: {
    filedCode: 'bankName',
    fieldName: '银行名称',
    origin: 'remote',
  },
  agentCertType: {
    filedCode: 'userCertType',
    fieldName: '证件类型', // 经办人证件类型
    origin: 'local',
    filter(item) {
      return /^1.*$/.test(item);
    },
  },
  voucherType: {
    filedCode: 'voucherType',
    fieldName: '业务凭证',
    origin: 'local',
  },
  verificationType: {
    filedCode: 'verificationType',
    fieldName: '业务核验证件',
    origin: 'local',
  },
  bankCardType: {
    filedCode: 'bankCardType',
    fieldName: '银行卡',
    origin: 'local',
  },
  netReconciliationType: {
    filedCode: 'netReconciliationType',
    fieldName: '网点对账类型',
    origin: 'local',
  },
  useracctType: {
    filedCode: 'useracctType',
    fieldName: '账户类型',
    origin: 'local',
  },
  status: {
    filedCode: 'status',
    fieldName: '完成状态',
    origin: 'local',
  },
  imgType: {
    filedCode: 'imgType',
    fieldName: '图片类型',
    origin: 'local',
  },
  useracctStatus: {
    filedCode: 'useracctStatus',
    fieldName: '帐户状态',
    origin: 'local',
  },
  eVoucherType: {
    filedCode: 'eVoucherType',
    fieldName: '凭证类型',
    origin: 'local',
  },
  cardStatus: {
    filedCode: 'cardStatus',
    fieldName: '卡状态',
    origin: 'local',
  },
  obuStatus: {
    filedCode: 'obuStatus',
    fieldName: '标签状态',
    origin: 'local',
  },
  cardType2: {
    filedCode: 'cardType2',
    fieldName: '卡类型',
    origin: 'local',
  },
  saleFlag: {
    filedCode: 'saleFlag',
    fieldName: '设备销售标志 ',
    origin: 'local',
  },
  payFlag: {
    filedCode: 'payFlag',
    fieldName: '收讫标志',
    origin: 'local',
  },
  deviceRecieveStatus: {
    filedCode: 'deviceRecieveStatus',
    fieldName: '设备领取状态',
    origin: 'local',
  },
  newCardType: {
    filedCode: 'newCardType',
    fieldName: '新卡状态',
    origin: 'local',
  },
  newOBUType: {
    filedCode: 'newOBUType',
    fieldName: '新标签状态',
    origin: 'local',
  },
  idType: {
    filedCode: 'idType',
    fieldName: '设备类型',
    origin: 'local',
  },
  txType: {
    filedCode: 'txType',
    fieldName: '发行状态',
    origin: 'local',
  },
  applyType: {
    filedCode: 'applyType',
    fieldName: '售后类型',
    origin: 'local',
  },
  orderType: {
    filedCode: 'orderType',
    fieldName: '订单类型',
    origin: 'local',
  },
  msgType: {
    filedCode: 'msgType',
    fieldName: '消息类型',
    origin: 'local',
  },
  userProperty: {
    filedCode: 'userProperty',
    fieldName: '客户类型',
    origin: 'local',
  },
  rechargeWay: {
    filedCode: 'rechargeWay',
    fieldName: '充值方式',
    origin: 'local',
  },
  userAcctStatus: {
    filedCode: 'userAcctStatus',
    fieldName: '账户状态',
    origin: 'local',
  },
  netLevel: {
    filedCode: 'netLevel',
    fieldName: '网点级别',
    origin: 'local',
  },
  position: {
    filedCode: 'position',
    fieldName: '操作员权限',
    origin: 'local',
  },
  tradeType: {
    filedCode: 'tradeType',
    fieldName: '交易类型',
    origin: 'local',
  },
};
