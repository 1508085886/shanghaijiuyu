<!-- 用户信息 -->
<template>
  <div class="offline_layout-aside_user-info">
    <no-data message="请新增或搜索用户" height="221" v-if="noData" />
    <template v-else>
      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">用户编号</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ info.userID }}
        </div>
      </div>

      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">用户名称</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ info.userName }}{{ userTypeText }}
        </div>
      </div>

      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">证件类型</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ userCertType }}
          <!-- <type-text type="userCertType" :value="info.userCertType"></type-text> -->
        </div>
      </div>

      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">证件号码</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ info.userCode }}
        </div>
      </div>
      <!-- <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">联系人</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ info.userName }}
        </div>
      </div> -->
      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">联系电话</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ phoneNumber }}
        </div>
      </div>
      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">手机号码</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ phoneNumber2 }}
        </div>
      </div>
      <!-- <div class="o-flex offline_layout-aside_user-info_item">
        <div class="o-flex o-flex-1">
          <div class="offline_layout-aside_user-info_label">联系人</div>
          <div class="offline_layout-aside_user-info_value o-flex-1">
            {{ info.userName }}
          </div>
        </div>
        <div class="o-flex o-flex-1">
          <div class="offline_layout-aside_user-info_label">手机号码</div>
          <div class="offline_layout-aside_user-info_value o-flex-1">
            {{ phoneNumber }}
          </div>
        </div>
      </div> -->
      <div class="o-flex offline_layout-aside_user-info_item">
        <!-- <div class="o-flex o-flex-1">
          <div class="offline_layout-aside_user-info_label">证件类型</div>
          <div class="offline_layout-aside_user-info_value o-flex-1">
            <type-text
              type="userCertType"
              :value="info.userCertType"
            ></type-text>
          </div>
        </div> -->
        <!-- <div class="o-flex o-flex-1">
          <div class="offline_layout-aside_user-info_label">开户日期</div>
          <div class="offline_layout-aside_user-info_value o-flex-1">
            {{ info.productType }}
          </div>
        </div> -->
      </div>
      <!-- 
      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">证件号码</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ cardNo }}
        </div>
      </div>-->
      <!-- <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">联系地址</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ info.address }}
        </div>
      </div> -->
    </template>
  </div>
</template>

<script>
import { NoData } from '@/components/NoData';
import { formatDate, formatCardNo, formatPhoneNo } from '@/utils/format';
import { isEmptyObj } from '@/utils/validate';
import { dicKeys, getAllDics, getDicDesByCode } from '@/methods/dics';
export default {
  data() {
    return {
      userCertType: '',
      userTypeText: '',
    };
  },
  components: {
    NoData,
  },
  props: {
    info: {
      default: {},
    },
  },
  watch: {
    'info.userType'(val) {
      getDicDesByCode(dicKeys.userType, val).then((text) => {
        this.userTypeText = (text && `[${text}用户]`) || '';
      });
    },
  },
  methods: {
    async getuserCertType() {
      const res = await getDicDesByCode(
        dicKeys.userCertType,
        this.info.userCertType
      );
      if (res) {
        this.userCertType = res;
      }
    },
  },
  computed: {
    noData() {
      return isEmptyObj(this.info);
    },
    cardNo() {
      const code = this.info.userCode;
      return (code && formatCardNo(code)) || '';
    },
    phoneNumber() {
      const phone = this.info.userPhone;
      return phone;
      // return (phone && formatPhoneNo(phone)) || '';
    },
    phoneNumber2() {
      const phone = this.info.userPhone2;
      return phone;
      // return (phone && formatPhoneNo(phone)) || '';
    },
  },
  updated() {
    this.getuserCertType();
  },
};
</script>
