<!-- 分支机构 -->
<template>
  <div class="offline_layout-aside_car-info">
    <no-data message="请新增或搜索用户" height="221" v-if="noData" />
    <template v-else>
      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">分支机构</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ info.department }}
        </div>
      </div>

      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">代理人姓名</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ info.agentName }}
        </div>
      </div>

      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">代理人证件类型</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ agentIdType }}
        </div>
      </div>

      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">代理人证件号码</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ info.agentIdNum }}
        </div>
      </div>

      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">代理人电话</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ info.agentPhoneNum }}
        </div>
      </div>
    </template>
  </div>
</template>

<script>
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
} from '@/methods/dics';
import { NoData } from '@/components/NoData';
import { isEmptyObj } from '@/utils/validate';
export default {
  data() {
    return {
      agentIdType: '',
    };
  },
  components: {
    NoData,
  },
  props: {
    info: {
      default: {},
    },
  },
  methods: {
    async getagentIdType() {
      const res = await getDicDesByCode(
        dicKeys.agentIdType,
        this.info.agentIdType
      );
      if (res) {
        this.agentIdType = res;
      }
    },
    // // 获取车辆用户类型
    // async getVehicleTypes() {
    //   const res = await getDicDesByCode(
    //     dicKeys.vehicleUserClass,
    //     this.info.vehicleType
    //   );
    //   if (res) {
    //     this.vehicleType = res;
    //   }
    // },
    // // 获取收费车型
    // async getVehicleClass() {
    //   const res = await getDicDesByCode(
    //     dicKeys.vehicleClass,
    //     this.info.vehicleClass
    //   );
    //   if (res) {
    //     this.vehicleClass = res;
    //   }
    // },
  },
  updated() {
    this.getagentIdType();
    // this.getVehicleTypes();
    // // 获取收费车型
    // this.getVehicleClass();
  },
  computed: {
    noData() {
      return isEmptyObj(this.info);
    },
  },
};
</script>
