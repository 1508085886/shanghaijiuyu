<!--  -->
<template>
  <div style="margin: 10px 0">
    <!-- 搜索部分 start -->
    <el-form class="offline_layout-aside_search-form">
      <div class="clearfix" style="margin-bottom: 8px">
        <!-- <div class="fl offline_layout-aside_search-form_title">综合查询</div> -->
        <!-- 
        <photograph-block
          type="userCertType"
          @complete="ocrComplete"
          isButton
          class="fr"
          ocr
        ></photograph-block>-->
        <!-- <photograph-button class="fr"></photograph-button> -->
      </div>
      <el-form-item>
        <type-select-input :app.sync="form.userCode" :pre.sync="form.userCertType" inputnochinese="true"
          type="userCertType" label="证件类型" placeholder="请输入证件号" spellcheck="false" :disabled="routeDisabled"
          :len="64" />
      </el-form-item>
      <el-form-item>
        <type-select-input :app.sync="form.vehicleNumber" :pre.sync="form.vehicleColor" carnumber="true"
          type="vehicleColor" label="车牌颜色" placeholder="请输入车牌号" spellcheck="false" :disabled="routeDisabled"
          :len="12" />
      </el-form-item>
      <el-form-item>
        <regex-input type="cardId" placeholder="请输入ETC卡号" :maxlength="16" v-model="form.cardId" spellcheck="false"
          :disabled="routeDisabled">
          <!-- onkeyup="value=value.replace(/[^\w\.\/]/ig,'')" -->
          <el-button slot="appendButton" type="primary" @click="readcard" :disabled="routeDisabled">读卡</el-button>
        </regex-input>
      </el-form-item>
      <el-form-item>
        <regex-input type="obuId" placeholder="请输入标签号" v-model="form.obuID" :maxlength="16" spellcheck="false"
          :disabled="routeDisabled">
          <el-button style="width: 70px; padding-left: 0; padding-right: 0" slot="appendButton" type="primary"
            @click="readobu" :disabled="routeDisabled">读标签</el-button>
        </regex-input>
      </el-form-item>
      <el-form-item>
        <el-input type="" v-model="form.obuPrintID" placeholder="请输入标签表面号" spellcheck="false" :maxlength="20"
          :disabled="routeDisabled" onkeyup="value=value.replace(/[^\w\.\/]/ig,'')"></el-input>
      </el-form-item>

      <el-form-item class="offline_layout-aside_buttons">
        <el-button size="small" type="primary" @click="toSearch" round :loading="loading" :disabled="routeDisabled">
          <i class="el-icon-search" /> 查询
        </el-button>

        <!-- <router-link> -->
        <!-- <empty-button type="primary" size="small" round @click="issue">
          <i class="el-icon-plus" /> 新办发行
        </empty-button> -->
        <!-- </router-link> -->
        <empty-button type="primary" size="small" round @click="clear">
          <i class="el-icon-refresh" /> 清除
        </empty-button>
      </el-form-item>
    </el-form>
    <!-- 搜索部分 end -->
    <!-- 相关信息 start -->
    <el-tabs class="offline_layout-aside_search-info" type="border-card">
      <el-tab-pane>
        <span slot="label">
          <!-- <i class="el-icon-user-solid" />  -->
          用户信息
        </span>
        <user-info :info="userInfoRes" />
      </el-tab-pane>
      <el-tab-pane>
        <span slot="label">
          <!-- <i class="icon iconfont iconxiaoqiche"></i>  -->
          车辆信息
        </span>
        <car-info :info="vehicleInfoRes" />
      </el-tab-pane>
      <el-tab-pane>
        <span slot="label">
          <!-- <i class="icon iconfont iconxiaoqiche"></i> -->
          分支机构
        </span>
        <department-info :info="departmentInfoRes" />
      </el-tab-pane>
      <el-tab-pane>
        <span slot="label">
          <!-- <i class="el-icon-s-ticket" />  -->
          账户信息
        </span>
        <account-info :info="userAcctListRes" />
      </el-tab-pane>
    </el-tabs>
    <!-- 相关信息 end -->

    <!-- 上传证件 start -->
    <el-tabs class="offline_layout-aside_certificate-info" type="border-card">
      <el-tab-pane>
        <span slot="label">
          <i class="el-icon-user-solid" />
          用户证件
        </span>
        <div v-show="!canUploadUserPhoto" class="
            o-flex o-flex-column o-flex-align-center o-flex-justify-center
            offline_layout-aside_certificate-disable
          ">
          <img src="../../../assets/images/icon禁用.png" />
          <div class="offline_layout-aside_certificate-disable-desc">禁用</div>
        </div>
        <photograph-block v-show="canUploadUserPhoto" type="userCertType" width="110" height="110" :pics-max-length="2"
          title="上传用户证件" :defaultPics="userPics" @complete="userPhotoComplete"></photograph-block>
      </el-tab-pane>
      <el-tab-pane>
        <span slot="label">
          <i class="el-icon-user"></i>
          经办人证件
        </span>
        <div v-show="!canUploadAgentPhoto" class="
            o-flex o-flex-column o-flex-align-center o-flex-justify-center
            offline_layout-aside_certificate-disable
          ">
          <img src="../../../assets/images/icon禁用.png" />
          <div class="offline_layout-aside_certificate-disable-desc">禁用</div>
        </div>
        <photograph-block v-show="canUploadAgentPhoto" type="agentCertType" width="110" height="110"
          :pics-max-length="2" title="上传经办人证件" :defaultPics="agentPics" @complete="agentPhotoComplete">
        </photograph-block>
      </el-tab-pane>
      <el-tab-pane>
        <span slot="label">
          <i class="icon iconfont iconmore"></i>
          其他证件
        </span>
        <div v-show="!canUploadOtherPhoto" class="
            o-flex o-flex-column o-flex-align-center o-flex-justify-center
            offline_layout-aside_certificate-disable
          ">
          <img src="../../../assets/images/icon禁用.png" />
          <div class="offline_layout-aside_certificate-disable-desc">禁用</div>
        </div>
        <photograph-block v-show="canUploadOtherPhoto" type="agentCertType" width="110" height="110" title="上传其他证件"
          :defaultPics="otherPics" @complete="otherPhotoComplete"></photograph-block>
      </el-tab-pane>
    </el-tabs>
    <!-- 上传证件 end -->

    <!-- 用户通知 start -->
    <!-- <div class="offline_layout-aside_user-notice">
      <div class="offline_layout-aside_user-notice-head">
        <i class="icon iconfont icontongzhi"></i> 用户通知
      </div>
      <no-data
        class="offline_layout-aside_user-notice-content-nodata"
        message="请新增或搜索用户"
        height="170"
        v-if="userNoticeListRes.length === 0"
      />
      <template v-else>
        <ul>
          <li
            class="offline_layout-aside_user-notice-item o-flex"
            v-for="(notice, index) in userNoticeListRes"
            :key="index"
          >
            <div class="o-flex-1">{{ notice.notice }}</div>
            <div class="offline_layout-aside_user-notice-date">
              {{ notice.noticeDate | datepoint }}
            </div>
          </li>
        </ul>
        <div class="offline_layout-aside_user-notice-button clearfix"></div>
      </template>
    </div> -->
    <!-- 用户通知 end -->
    <addbranch-block :visible.sync="addvisble" :append-to-body="true" popuptype="addbranch" :showclose="false"
      @addbranchs="improveBranch"></addbranch-block>
  </div>
</template>

<script>
  import TypeSelectInputReg from '@/components/TypeSelectInput/indexReg.vue';
  import PhotographBlock from '@/components/PhotographBlock';
  import { NoData } from '@/components/NoData';
  import { requestCompre } from '@/api/compre';
  import { userCheck, systemTime } from '@/api/user';
  import UserInfo from './userInfo';
  import DepartmentInfo from './departmentInfo';
  import AccountInfo from './accountInfo';
  import CarInfo from './carInfo';
  import {
    dicKeys,
    getAllDics,
    getDicDesByCode,
    getDicCodeByDes,
  } from '@/methods/dics';
  import { getFormatAmount } from '@/utils/utils';
  import RegexInput from '@/components/RegexInput';
  import { globalBus } from '@/utils/globalBus';
  import emit from '@/utils/emit';
  import { validrole } from '@/utils/role';
  import { cancelWorkOrder } from '@/api/order';
  import { perfectVehicleDepartment } from '@/api/branch';
  import AddbranchBlock from '@/components/AddbranchBlock';
  //import { publishCard, publishObu } from '@/methods/publish';
  import {
    getOperCardId,
    getCpuId,
    getObuId,
    issueCard,
    issueOBU,
  } from '@/utils/dynamic';
  import { store } from '@/store';
  export default {
    inject: ['reload'],
    name: 'SearchContainer',
    data() {
      return {
        // userType: '',
        addvisble: false,
        carColour: '',
        carBizcode: '',
        oprtId: this.$store.getters.oprtId,
        netId: this.$store.getters.netid,
        ehicleTypeTimer: null,
        loading: false,
        routeDisabled: false,
        form: {}, // 查询条件
        userInfoRes: {}, // 用户信息查询结果
        userAcctListRes: {}, // 账户列表
        vehicleListRes: [], //车辆信息
        userNoticeListRes: [], // 用户通知
        vehicleInfoRes: {}, // 车辆信息
        departmentInfoRes: {}, //分支机构信息
        ocr: null,
        allAccountShow: false, //账户信息 查看全部
        clickToSearch: false, // 其他触发综合查询
        etcUserId: '',
        vehicleId: '',
      };
    },
    components: {
      UserInfo,
      AccountInfo,
      DepartmentInfo,
      CarInfo,
      NoData,
      PhotographBlock,
      RegexInput,
      // TypeSelectInput
      TypeSelectInputReg,
      AddbranchBlock,
    },
    // computed: {
    //   date() {
    //     const self = this;
    //     for (let i = 0; i < self.userNoticeListRes.length; i++) {
    //       self.userNoticeListRes[i].noticeDate = '777';
    //     }
    //     // userNoticeListRes;
    //   },
    // },
    computed: {
      // vehicleInfo() {
      //   return this.$store.getters.searchCarInfo;
      // },
      // obuInfo() {
      //   return this.$store.getters.searchObuInfo;
      // },
      // cardInfo() {
      //   return this.$store.getters.searchCardInfo;
      // },
      userInfo() {
        return this.$store.getters.searchUserInfo;
      },
      // 业务上传的图片，自动保存到主页的证件上传区域
      userPics() {
        return this.$store.getters.searchUserImg;
      },
      agentPics() {
        return this.$store.getters.searchAgentImg;
      },
      otherPics() {
        return this.$store.getters.searchOtherImg;
      },
      canUploadOtherPhoto() {
        // 是否可以上传其他信息证件
        return !this.isEmptyObj(this.userInfo);
      },
      canUploadUserPhoto() {
        // 是否可以上传用户信息证件
        return !this.isEmptyObj(this.userInfo);
      },
      canUploadAgentPhoto() {
        // 是否可以上传经办人信息证件，对公用户可以上传，对私用户也可上传经办人证件，非必须
        if (this.canUploadUserPhoto) {
          // return this.userInfo.userProperty === '2'; // 单位
          return true;
        } else {
          return false;
        }
      },
      // userCertType() {//弃用
      //   //用户证件上传为单位/个人
      //   if (this.userInfo.userProperty === '2') {
      //     // 单位
      //     console.log(
      //       'userCertTypeC-this.userInfo.userProperty',
      //       this.userInfo.userProperty
      //     );
      //     return 'userCertTypeC';
      //   } else if (this.userInfo.userProperty === '1') {
      //     console.log(
      //       'userCertTypeP-this.userInfo.userProperty',
      //       this.userInfo.userProperty
      //     );
      //     // 个人
      //     return 'userCertTypeP';
      //   } else {
      //     console.log(
      //       'userCertType-this.userInfo.userProperty',
      //       this.userInfo.userProperty
      //     );
      //     return 'userCertType';
      //   }
      // },
    },
    watch: {
      $route(to, from) {
        if (this.$route.path === '/menu') {
          this.routeDisabled = false;
        } else {
          this.routeDisabled = true;
        }
      },
      // 'userInfo.userProperty': {//用于解决搜索栏证件上传userCertType需要根据用户类型变化不起作用问题
      //   handler(val) {
      //     //用户证件上传为单位/个人
      //     if (val === '2') {
      //       // 单位////
      //       console.log('userCertTypeC-userInfo.userProperty', val);
      //       this.userType = 'userCertTypeC';
      //     } else if (val === '1') {
      //       // 个人
      //       console.log('userCertTypeP-userInfo.userProperty', val);
      //       this.userType = 'userCertTypeP';
      //     } else {
      //       console.log('userCertType-userInfo.userProperty', val);
      //       this.userType = 'userCertType';
      //     }
      //   },
      //   immediate: true,
      // },
    },
    created() {
      this.search();
      this.to();
      this.toChangeCard();
      this.toChangeOBU();
      this.handleContinue(); // 注册继续办理方法

      this.conVechicleChange();
    },
    methods: {
      conVechicleChange() {
        emit.on('ev-vehiclechange', (data) => {
          this.$router.push({
            path: '/jumpBlankPage', // 中间的过度路由，为了页面组件的重载
            query: {
              ...data,
            },
          });
        });
      },
      userPhotoComplete(imgs) {
        this.$store.dispatch('GetSearchUserImg', imgs);
      },
      agentPhotoComplete(imgs) {
        this.$store.dispatch('GetSearchAgentImg', imgs);
      },
      otherPhotoComplete(imgs) {
        this.$store.dispatch('GetSearchOtherImg', imgs);
      },
      search() {
        globalBus.$off('clickToSearch');
        globalBus.$on('clickToSearch', (form) => {
          this.clickToSearch = true;
          // const res = await this.toSearch(form);
          // this.clickToSearch = false;
          // if (res) {
          //   console.log('toSearch-return true');
          //   return true;
          // } else {
          //   console.log('toSearch-return false');
          //   return false;
          // }

          return new Promise((resolve, reject) => {
            const res = this.toSearch(form);
            this.clickToSearch = false;
            res
              .then(() => {
                console.log('toSearch-resolve true');
                resolve(true);
              })
              .catch((err) => {
                console.log('toSearch-reject false');
                reject(false);
              });
          });
        });
      },
      to() {
        console.log('to');
        console.log('emit', emit);
        emit.on('abc', (p) => {
          console.log('toAccountWriteoff');
          console.log(p.a);
          this.$router.push({
            path: '/accountwriteoff',
            // path: '/newpublish/banksign',
          });
        });
      },
      handleContinue() {
        // 继续办理换卡跳转页面
        emit.on('handleContinue', (p) => {
          console.log('handleContinue-----------------');
          let query = {
            continueType: p.continueType,
            workOrderID: p.workOrderID,
            payFlag: p.payFlag,
            price: p.price,
            payMode: p.payMode,
            cdif: p.cdif,
            etcUserId: p.etcUserId,
            newVehicleNumber: p.newVehicleNumber,
            newVehicleColor: p.newVehicleColor,
          };
          let elementPermissionObj = eval('(' + p.elementPermission + ')');
          let newQuery = { ...query, ...elementPermissionObj };
          this.$router.push({
            path: '/jumpBlankPage',
            query: newQuery,
          });
        });
      },
      toChangeCard() {
        // 继续办理换卡跳转页面
        emit.on('toChangeCard', (p) => {
          console.log('changecard');
          console.log(p.workOrderID);
          console.log(p.payFlag);
          console.log(p.cdif);
          let query = {
            isChangeCard: true,
            workOrderID: p.workOrderID,
            payFlag: p.payFlag,
            price: p.price,
            payMode: p.payMode,
            cdif: p.cdif,
            etcUserId: p.etcUserId,
            newVehicleNumber: p.newVehicleNumber,
            newVehicleColor: p.newVehicleColor,
          };
          // let elementPermissionObj = JSON.parse(
          //   JSON.stringify(p.elementPermission)
          // );
          let elementPermissionObj = eval('(' + p.elementPermission + ')');
          let newQuery = { ...query, ...elementPermissionObj };
          console.log('newQuery', newQuery);
          this.$router.push({
            // path: '/changecard',
            path: '/jumpBlankPage',
            query: newQuery,
          });
        });
      },
      toChangeOBU() {
        // 继续办理换签跳转页面
        emit.on('toChangeOBU', (p) => {
          console.log('changeobu');
          console.log(p.workOrderID);
          console.log(p.cdif);
          let query = {
            isChangeOBU: true,
            workOrderID: p.workOrderID,
            cdif: p.cdif,
            payFlag: p.payFlag,
            price: p.price,
            payMode: p.payMode,
            etcUserId: p.etcUserId,
            newVehicleNumber: p.newVehicleNumber,
            newVehicleColor: p.newVehicleColor,
            oldObuysId: p.oldObuysId,
          };
          let elementPermissionObj = eval('(' + p.elementPermission + ')');
          let newQuery = { ...query, ...elementPermissionObj };
          this.$router.push({
            // path: '/changeobu',
            path: '/jumpBlankPage',
            query: newQuery,
          });
        });
      },
      issue() {
        // const self = this;
        // self
        //   .$confirm(
        //     '本系统目前只提供“建行”、“对公”车辆的发行，其他发行业务暂不支持。',
        //     '注意！',
        //     {
        //       confirmButtonText: '确定',
        //       cancelButtonText: '取消',
        //       type: 'warning',
        //     }
        //   )
        //   .then(() => {
        self.$router.push({
          path: '/newpublish',
        });
        // })
        // .catch(() => {});
      },
      open(res) {
        const self = this;
        self
          .$confirm(
            '该车辆有进行中的工单，是否继续' + this.carBizcode + '业务？',
            '提示',
            {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning',
            }
          )
          .then(() => {
            let newPath;
            if (
              'newpublishperson' === self.$router.currentRoute.path.split('/')[1]
            ) {
              newPath = '/newpublishperson/banksign';
            } else {
              newPath = '/newpublish/banksign';
            }
            self.$router.push({
              // path: '/newpublish/banksign',
              path: newPath,
              query: {
                woid: res.vehicleInfo.workOrderId,
                vid: res.vehicleInfo.vehicleId,
              },
            });
          })
          .catch(() => { });
      },

      async readcard() {
        const self = this;

        const cardInfo = getCpuId();
        if (cardInfo.cardid) {
          self.form = { ...self.form, cardId: cardInfo.cardid };
        } else {
          this.$message({
            message: cardInfo.msg,
            type: 'error',
          });
        }
      },
      readobu() {
        const self = this;
        const obuInfo = getObuId();
        console.log(obuInfo);
        if (obuInfo.obuid) {
          self.form = { ...self.form, obuID: obuInfo.obuid };
        } else {
          this.$message({
            message: obuInfo.msg,
            type: 'error',
          });
        }
      },

      ocrComplete(pic) {
        const self = this;
        if (pic && pic instanceof Array && pic.length > 0) {
          self.ocr = pic;
          self.$set(
            self.form,
            'userCertType',
            (pic[0].ocr.userCertType && pic[0].ocr.userCertType.slice(0, -1)) ||
            ''
          );
          self.$set(self.form, 'userCode', pic[0].ocr.userCode || '');
          self.$set(self.form, 'vehicleNumber', pic[0].ocr.vehicleNumber || '');
          self.$set(self.form, 'vehicleColor', pic[0].ocr.vehicleColor || '');
        }
      },
      // 完善分支机构
      async improveBranch() {
        console.log('综合查询-重复调用improveBranch'); // 新建完分支机构后，再次调后台4.12.完善分支机构接口
        // 点击确定后调用后台4.12.完善分支机构接口，由系统自动进行完善处理
        let resPer, loading;
        try {
          loading = this.$loading();
          resPer = await perfectVehicleDepartment({
            etcUserId: this.etcUserId,
            vehicleId: this.vehicleId,
          });
          loading.close();
        } catch (error) {
          loading.close();
        }

        if (resPer) {
          if (resPer.exCode == '9002') {
            // 如果4.12.完善分支机构接口返回9002，前端提示“该用户名下无有效默认分支机构，请新建”
            this.$confirm('该用户名下无有效默认分支机构，请新建', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              closeOnClickModal: false,
              closeOnPressEscape: false,
              type: 'warning',
            }).then(() => {
              // 点击确定后自动弹出新建分支机构的页面，引导操作员完成新建分支机构
              this.addvisble = true;
            });
          }
          if (!resPer.exCode) {
            this.$alert('完善成功', '提示', {
              confirmButtonText: '确定',
              type: 'success',
            });
          }
        }
      },
      // 查询
      async toSearch(form) {
        // const ll = this.$loading({});
        // setTimeout(() => {
        //   ll.setText('Loading....ok\nLoading....ok');
        // }, 1000);
        // setTimeout(() => {
        //   ll.setText('Loading....ok\nLoading....ok\nLoading....ok');
        // }, 2000);
        // setTimeout(() => {
        //   ll.setText(
        //     'Loading....ok\nLoading....ok\nLoading....ok\nLoading....ok'
        //   );
        // }, 3000);
        // setTimeout(() => {
        //   ll.close();
        // }, 5000);

        const self = this;
        let formData = self.form;
        if (this.clickToSearch && !this.isEmptyObj(form)) {
          // 其他触发搜索栏综合查询，模拟点击【查询】效果
          formData = form;
        }
        if (formData.userCode) {
          if (!formData.userCertType) {
            this.$message({
              message: '请选择证件类型',
              type: 'error',
            });
            return;
          }
        }
        if (formData.vehicleNumber) {
          if (!formData.vehicleColor) {
            this.$message({
              message: '请选择车牌颜色',
              type: 'error',
            });
            return;
          }
        }
        let timer = setTimeout(() => {
          // this.$message.success('超时');
          self.loading = false;
        }, 3000);
        self.loading = true;
        if (Object.keys(formData).length === 0) {
          this.$message.info('请填写查询项');
          clearTimeout(timer);
          self.loading = false;
          return;
        }
        let userInfo = {
          localPic: self.ocr,
        };
        if (formData.userCode) {
          formData.userCode = formData.userCode.trim();
        }
        const res = await requestCompre(formData);
        if (res) {
          const errMessage = '代理人信息异常，请去完善分支机构';
          let showPerfect =
            res.errorMsg === errMessage ||
            (res.departmentInfo &&
              res.departmentInfo.departmentAberrantData === errMessage);
          if (showPerfect) {
            this.$confirm(errMessage, '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              closeOnClickModal: false,
              closeOnPressEscape: false,
              type: 'warning',
            })
              .then(async () => {
                this.etcUserId = res.userInfo.etcUserId;
                this.vehicleId = res.vehicleInfo.vehicleId;
                this.improveBranch();
              })
              .catch(() => {
                // 取消暂无操作
              });
          } else {
            if (res.errorMsg) {
              // 将接口的指定出参字段提示出来
              this.$alert(res.errorMsg, '提示', {
                confirmButtonText: '确定',
                type: 'error',
              });
            }
          }
        }
        // if (res.errorMsg) {
        //   // 将接口的指定出参字段提示出来
        //   this.$alert(res.errorMsg, '提示', {
        //     confirmButtonText: '确定',
        //     type: 'error',
        //   });
        // }
        console.log('综合查询');
        // var s = etcdev.writelog('测试日志-综合查询');
        // var w = etcdev.getlog('web20210611.log');
        // console.log(w);
        // console.log(JSON.parse(s));
        // console.log(JSON.parse(w));
        var massage = '';
        if (res.vehicleInfo && res.vehicleInfo.vehicleAberrantData) {
          massage =
            massage +
            '车辆异常信息:&nbsp&nbsp' +
            res.vehicleInfo.vehicleAberrantData;
        }
        if (res.userInfo && res.userInfo.userAberrantData) {
          if (res.vehicleInfo && res.vehicleInfo.vehicleAberrantData) {
            massage =
              massage +
              '</br></br>用户异常信息:&nbsp&nbsp' +
              res.userInfo.userAberrantData;
          } else {
            massage =
              massage + '用户异常信息:&nbsp&nbsp' + res.userInfo.userAberrantData;
          }
        }
        if (res.departmentInfo && res.departmentInfo.departmentAberrantData) {
          if (res.userInfo && res.userInfo.userAberrantData) {
            massage =
              massage +
              '</br></br>分支机构异常信息:&nbsp&nbsp' +
              res.departmentInfo.departmentAberrantData;
          } else if (res.vehicleInfo && res.vehicleInfo.vehicleAberrantData) {
            massage =
              massage +
              '</br></br>分支机构异常信息:&nbsp&nbsp' +
              res.departmentInfo.departmentAberrantData;
          } else {
            massage =
              massage +
              '分支机构异常信息:&nbsp&nbsp' +
              res.departmentInfo.departmentAberrantData;
          }
        }
        if (massage != '') {
          this.$message.error(massage);
        }
        if (res) {
          // 搜索框-上传证件：若未清除，重新输入查询条件，重新查询，只要用户没变，之前上传的用户证件仍保留。
          let oldUserInfo = this.$store.getters.searchUserInfo;
          if (!this.clickToSearch) {
            console.log('--------查询需要清除证件照片-------------------------');
            // 不是其他触发搜索栏综合查询，模拟的查询不需要清除证件照片
            if (oldUserInfo.userID != res.userInfo.userID) {
              console.log('清除之前搜索框上传的证件---------');
              // 清除之前搜索框上传的证件
              self.$store.dispatch('ClearSearchUserImg');
              self.$store.dispatch('ClearSearchAgentImg');
              self.$store.dispatch('ClearSearchOtherImg');
            }
          }
          // console.log('oldUserInfo', oldUserInfo);
          // 查询etcUserId
          self.$store.dispatch('GetSearchCarInfo', {});
          self.$store.dispatch('GetSearchObuInfo', {});
          self.$store.dispatch('GetSearchCardInfo', {});
          self.$store.dispatch('GetSearchUserInfo', {});
          self.$store.dispatch('GetSearchAccountInfo', {});
          self.$store.dispatch('GetSearchDepartmentInfo', {});
          self.$store.dispatch('GetRegisterVehicle', []);

          const userRes = await userCheck({
            userName: res.userInfo.userName,
            userCode: res.userInfo.userCode,
            userCertType: res.userInfo.userCertType,
          });

          if (userRes) {
            res.userInfo.etcUserId = userRes.etcUserId;
          }
          if (res.etcUserId) {
            res.userInfo.etcUserId = res.etcUserId;
          }
          res.userInfo.etcUserId = userRes.etcUserId;
          self.userInfoRes = res.userInfo || {};
          // 对userAcctList有金额数据做处理

          // if (!res.userAcctList) {
          // } else if (res.userAcctList.length !== 0) {
          //   let userAcctListTemp = res.userAcctList;
          //   for (let i = 0; i < userAcctListTemp.length; i++) {
          //     userAcctListTemp[i].balance = getFormatAmount(
          //       userAcctListTemp[i].balance
          //     );
          //     userAcctListTemp[i].ratedBalance = getFormatAmount(
          //       userAcctListTemp[i].ratedBalance
          //     );
          //   }
          //   self.userAcctListRes = userAcctListTemp;
          // } else {
          //   self.userAcctListRes = [];
          // }
          // // self.userAcctListRes = res.userAcctList || [];
          // self.userAcctListRes.length === 0
          //   ? (this.allAccountShow = false)
          //   : (this.allAccountShow = true);

          self.vehicleListRes = res.vehicleList || [];
          self.userNoticeListRes = res.userNoticeList || [];
          self.vehicleInfoRes = res.vehicleInfo || {};
          self.departmentInfoRes = res.departmentInfo || {};
          if (res.userAcctList) {
            self.userAcctListRes = res.userAcctList[0] || {};
          }
          // 卡/签兼容版本号00为10
          if (res.obuInfo) {
            if (res.obuInfo.versionNo.startsWith('0')) {
              res.obuInfo.versionNo = '10';
            }
          }
          if (res.cardInfo) {
            if (res.cardInfo.versionNo.startsWith('0')) {
              res.cardInfo.versionNo = '10';
            }
          }
          self.$store.dispatch(
            'GetSearchDepartmentInfo',
            res.departmentInfo || {}
          );
          self.$store.dispatch('GetSearchCarInfo', res.vehicleInfo || {});
          self.$store.dispatch('GetSearchObuInfo', res.obuInfo || {});
          self.$store.dispatch('GetSearchCardInfo', res.cardInfo || {});
          self.$store.dispatch('GetSearchUserInfo', res.userInfo || {});
          if (res.userAcctList && res.userAcctList.length > 0) {
            self.$store.dispatch(
              'GetSearchAccountInfo',
              res.userAcctList[0] || {}
            );
          }
          self.$store.dispatch('GetRegisterVehicle', res.vehicleInfo || []);
          const abc = self.$store.getters.registerVehicle;
          userInfo = {
            ...userInfo,
            ...res.userInfo,
          };

          // console.log('res');
          // console.log(res);
          // console.log('res');
          // console.log(res.vehicleInfo);


          if (res.vehicleInfo) {
            //alert('21' + this.$store.getters.registerUser.etcUserId);
            const rescolour = await getDicDesByCode(
              dicKeys.vehicleColor,
              res.vehicleInfo.vehicleColor
            );
            if (rescolour) {
              this.carColour = rescolour;
            }
            let resbizcode = await getDicDesByCode(
              dicKeys.bizCode,
              res.vehicleInfo.bizCode
            );
            if (resbizcode) {
              console.log('resbizcode');
              console.log(resbizcode);
              if (resbizcode === '05 - 新办发行') {
                resbizcode = '新办发行';
              }
              this.carBizcode = resbizcode;
            }
            const systemDate = await systemTime({});
            console.log('当前时间：' + systemDate.systemTime);
            console.log('工单创建时间' + res.vehicleInfo.createTime);
            var sTime = Date.parse(systemDate.systemTime);
            var cTime = Date.parse(res.vehicleInfo.createTime);
            var timediff = sTime - cTime;

            if (res.vehicleInfo.orderStatus == '1') {
              if (self.oprtId == res.vehicleInfo.oprtId.trim()) {
                if (res.vehicleInfo.bizCode == '05') {
                  if (res.vehicleInfo.isBind == '0') {
                    const a = this.$store.getters.menuIds;

                    if (res.userInfo.userProperty == '1') {
                      if (validrole(a, '个人新办发行')) {
                        this.open(res);
                      }
                    }
                    if (res.userInfo.userProperty == '2') {
                      if (validrole(a, '单位新办发行')) {
                        this.open(res);
                      }
                    }
                    // if (validrole(a, '新办发行')) {
                    //   this.open(res);
                    // }
                  }
                } else if (res.vehicleInfo.bizCode === '20') {
                  await self
                    .$confirm('该车辆有进行中的工单，请继续办理或关闭', '提示', {
                      cancelButtonText: '取消',
                      confirmButtonText: '确定',
                    })
                    .then(() => { })
                    .catch(() => { });
                } else if (res.vehicleInfo.bizCode === '21') {
                  await self
                    .$confirm('该车辆有进行中的工单，请继续办理或关闭', '提示', {
                      cancelButtonText: '取消',
                      confirmButtonText: '确定',
                    })
                    .then(() => { })
                    .catch(() => { });
                }
              }

              if (self.oprtId != res.vehicleInfo.oprtId.trim()) {
                if (timediff > 259200000) {
                  await self
                    .$confirm(
                      res.vehicleInfo.vehicleNumber +
                      ',   ' +
                      this.carColour +
                      '车辆有一条进行中的工单,业务类型为' +
                      this.carBizcode +
                      '。' +
                      self.netId +
                      '网点,创建时间为' +
                      res.vehicleInfo.createTime +
                      ',已超3个自然日，是否需要关闭？',
                      '提示',
                      {
                        cancelButtonText: '取消',
                        confirmButtonText: '确定',
                        type: 'warning',
                      }
                    )
                    .then(() => {
                      this.closeWorkOrder();
                    })
                    .catch(() => { });
                }
                if (timediff < 259200000) {
                  await this.$alert(
                    res.vehicleInfo.vehicleNumber +
                    ',   ' +
                    this.carColour +
                    '车辆有一条进行中的工单,业务类型为' +
                    this.carBizcode +
                    '。' +
                    self.netId +
                    '网点,创建时间为' +
                    res.vehicleInfo.createTime +
                    ',不超3个自然日，如需办理业务，请联系客服中心关闭工单。',
                    '提示',
                    {
                      confirmButtonText: '确定',
                    }
                  );
                }
              }
            }
          }
          if (res.userAcctList[0]) {
            if (res.userAcctList[0].oweBalance && res.userAcctList[0].oweBalance > 0) {
              await this.$alert('卡片有挂账交易，请对挂账进行还款', '提示', {
                confirmButtonText: '确定',
                showClose: false,
                type: 'warning',
              }).then(() => {
                self.$router.push({
                  path: '/storagecardrepayment',
                });
              });
            }
          }
          self.$store.dispatch('GetRegisterUser', userInfo);
          clearTimeout(timer);
          self.loading = false;
          return true;
        } else {
          //debugger;
          //alert('11' + this.$store.getters.registerUser.etcUserId);
          userInfo = {
            ...userInfo,
            ...userInfo.localPic[0].ocr,
          };

          if (userInfo.localPic[0].ocr && userInfo.localPic[0].ocr.userCertType) {
            userInfo.userCertType = userInfo.localPic[0].ocr.userCertType.slice(
              0,
              -1
            );
          }
          self.$store.dispatch('GetRegisterUser', userInfo);
          clearTimeout(timer);
          self.loading = false;
          return false;
        }
        // self.$store.dispatch('GetRegisterUser', userInfo);
        // clearTimeout(timer);
        // self.loading = false;
      },

      async closeWorkOrder() {
        const res = await cancelWorkOrder({
          etcUserId: this.$store.getters.searchUserInfo.etcUserId,
          workOrderID: this.vehicleInfoRes.workOrderId,
        });
        console.log(this.$store.getters.searchUserInfo.etcUserId);
      },
      clear() {
        const self = this;

        self
          .$confirm('是否清除当前数据，并终止办理', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          })
          .then(() => {
            self.form = {}; // 查询条件
            self.userInfoRes = {}; // 用户信息查询结果
            self.userAcctListRes = {}; // 账户列表
            self.vehicleListRes = []; //车辆信息
            self.userNoticeListRes = []; // 用户通知
            self.vehicleInfoRes = {}; // 车辆信息
            self.departmentInfoRes = {}; //分支机构信息
            // 用户注册
            self.$store.dispatch('ClearRegisterUser');
            // 经办人证件
            self.$store.dispatch('ClearTransactorImg');
            // 清空注册车辆信息
            self.$store.dispatch('ClearRegisterVehicle');

            // self.$store.dispatch('GetSearchCardInfo', res.cardInfo || {});

            self.$store.dispatch('GetSearchCardInfo', {});
            self.$store.dispatch('GetSearchUserInfo', {});
            self.$store.dispatch('GetSearchCarInfo', {});
            self.$store.dispatch('GetSearchUserInfo', {});
            self.$store.dispatch('GetSearchAccountInfo', {});
            self.$store.dispatch('GetSearchDepartmentInfo', {});

            // alert(self.$store.getters.searchCarInfo.vehicleNumber);
            self.$store.dispatch('GetSearchObuInfo', {});

            // 在主页点击过清除按钮后，之前上传的用户证件\经办人证件清空
            console.log('【清除】按钮后，之前上传的用户证件经办人证件清空');
            self.$store.dispatch('ClearSearchUserImg');
            self.$store.dispatch('ClearSearchAgentImg');
            self.$store.dispatch('ClearSearchOtherImg');

            self.reload();
            // this.$router.go(0);
            // location.reload;

            self.$router.push({
              path: '/menu',
              query: {},
            });
          })
          .catch(() => { });
      },
    },

    mounted() { },
  };
</script>