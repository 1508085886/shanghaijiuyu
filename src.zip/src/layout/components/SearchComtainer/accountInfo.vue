<!-- 账户信息 -->
<template>
  <div class="offline_layout-aside_account-info">
    <no-data message="请新增或搜索用户" height="221" v-if="noData" />
    <template v-else>
      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">账户编号</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ info.userAcctId }}
        </div>
      </div>

      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">账户状态</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ userAcctStatus }}
        </div>
      </div>

      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">账户类型</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ userAcctType }}
        </div>
      </div>

      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">签约渠道</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ subPaychannelName }}（{{ paychannelName }}）
        </div>
      </div>

      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">签约号</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ info.signOrderNo }}
        </div>
      </div>
      <div class="o-font-family useracctlistQuery ">
        <li @click="toPage('/useraccList')">
          查看详情
        </li>
      </div>
      <!-- <el-table
        ref="multipleTable"
        :data="info"
        tooltip-effect="dark"
        style="width: 100%"
      >
      
        <el-table-column
          label="账户编号"
          prop="userAcctId"
          min-width="90px"
        ></el-table-column>
        <el-table-column
          label="账户状态"
          prop="userAcctStatus"
        ></el-table-column>
        <el-table-column prop="userAcctType" label="账户类型"></el-table-column>
        <el-table-column prop="payChannel" label="签约渠道"></el-table-column>
        <el-table-column prop="signOrderNo" label="签约号"></el-table-column>
      </el-table> -->
    </template>
  </div>
</template>

<script>
  import { dicKeys, getDicDesByCode } from '@/methods/dics';
  import { NoData } from '@/components/NoData';
  import { isEmptyObj } from '@/utils/validate';
  import { openWindow } from '@/utils/utils';
  export default {
    data() {
      return {
        userAcctStatus: '',
        userAcctType: '',
        paychannelName: '',
        subPaychannelName: '',
      };
    },
    props: {
      info: {
        default: {},
      },
    },
    components: {
      NoData,
    },
    methods: {
      toPage(page) {
        console.log('jumpto useracctlist'
        );
        const query = {
          userAcctId: this.info.userAcctId,
          oprtId: this.$store.getters.oprtId,
          netid: this.$store.getters.netid,
          token: this.$store.getters.token,
          etcUserId: this.$store.getters.searchUserInfo.etcUserId,
          elementPermissions: JSON.stringify(
            this.$store.getters.elementPermissions
          ),
          // oldWindow: window,
        };
        openWindow(page, query);
      },
      getPayChannelName() {
        // if (this.info.subPaychannelName) {
        //   this.paychannelName = this.info.subPaychannelName;
        // } else {
        //   this.paychannelName = this.info.paychannelName;
        // }
        this.paychannelName = this.info.paychannelName;
        this.subPaychannelName = this.info.subPaychannelName;
      },
      async getUserAcctStatus() {
        const res = await getDicDesByCode(
          dicKeys.useracctStatus,
          this.info.userAcctStatus
        );
        console.log(res);
        if (res) {
          this.userAcctStatus = res;
        }
      },
      async getuserAcctType() {
        const res = await getDicDesByCode(
          dicKeys.useracctType,
          this.info.userAcctType
        );
        console.log(res);
        if (res) {
          this.userAcctType = res;
        }
      },
      // toAll() {
      //   const query = {
      //     etcUserId: this.$store.getters.searchUserInfo.etcUserId,
      //     oprtId: this.$store.getters.oprtId,
      //     token: this.$store.getters.token,
      //   };
      //   // console.log(`etcUserId:${this.$store.getters.searchUserInfo.etcUserId}`);
      //   openWindow('/allaccountinfo', query);
      // },
    },
    updated() {
      this.getUserAcctStatus();
      this.getuserAcctType();
      this.getPayChannelName();
    },
    computed: {
      carInfo() {
        //debugger;
        return this.$store.getters.searchCarInfo;
      },
      noData() {
        return isEmptyObj(this.info);
      },
    },
  };
</script>