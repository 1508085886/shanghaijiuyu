<!-- 车辆信息 -->
<template>
  <div class="offline_layout-aside_car-info">
    <no-data message="请新增或搜索用户" height="221" v-if="noData" />
    <template v-else>
      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">行驶证车辆类型</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ info.dzfpVehicleType }}
        </div>
      </div>

      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">车辆识别代码</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ info.vin }}
        </div>
      </div>

      <div v-if="info.vehicleCategory === '1'">
        <div class="o-flex offline_layout-aside_user-info_item">
          <div class="offline_layout-aside_user-info_label">核定载人数</div>
          <div class="offline_layout-aside_user-info_value o-flex-1">
            {{ info.approvedAccount }} 人
          </div>
        </div>

        <div class="o-flex offline_layout-aside_user-info_item">
          <div class="offline_layout-aside_user-info_label">车身尺寸</div>
          <div class="offline_layout-aside_user-info_value o-flex-1">
            {{ info.viLength }}mm x {{ info.viWidth }}mm x {{ info.viHeight }}mm
          </div>
        </div>
      </div>

      <div v-else>
        <div class="o-flex offline_layout-aside_user-info_item">
          <div class="offline_layout-aside_user-info_label">轴数</div>
          <div class="offline_layout-aside_user-info_value o-flex-1">
            {{ info.axleCount }}
          </div>
        </div>

        <div class="o-flex offline_layout-aside_user-info_item">
          <div class="offline_layout-aside_user-info_label">总质量</div>
          <div class="offline_layout-aside_user-info_value o-flex-1">
            {{ info.viTotalMass }} KG
          </div>
        </div>

        <div class="o-flex offline_layout-aside_user-info_item">
          <div class="offline_layout-aside_user-info_label">车身尺寸</div>
          <div class="offline_layout-aside_user-info_value o-flex-1">
            {{ info.viLength }}mm x {{ info.viWidth }}mm x {{ info.viHeight }}mm
          </div>
        </div>
      </div>

      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">收费车型</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ vehicleClass }}
        </div>
      </div>

      <div class="o-flex offline_layout-aside_user-info_item">
        <div class="offline_layout-aside_user-info_label">车辆用户类型</div>
        <div class="offline_layout-aside_user-info_value o-flex-1">
          {{ vehicleType }}
        </div>
      </div>
    </template>
  </div>
</template>

<script>
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
} from '@/methods/dics';
import { NoData } from '@/components/NoData';
import { isEmptyObj } from '@/utils/validate';
export default {
  data() {
    return {
      vehicleType: '',
      vehicleClass: '',
    };
  },
  components: {
    NoData,
  },
  props: {
    info: {
      default: {},
    },
  },
  methods: {
    // 获取车辆用户类型
    async getVehicleTypes() {
      const res = await getDicDesByCode(
        dicKeys.vehicleUserClass,
        this.info.vehicleType
      );
      console.log(res);
      // if (res) {
      //   this.vehicleType = res;
      // }
      if (res) {
        if (res === '0 - 普通客车/普通货车') {
          if (this.info.vehicleCategory == '1') {
            this.vehicleType = '0 - 普通客车';
          } else if (this.info.vehicleCategory == '') {
            this.vehicleType = '';
          } else {
            this.vehicleType = '0 - 普通货车';
          }
        } else {
          this.vehicleType = res;
        }
      }
    },
    // 获取收费车型
    async getVehicleClass() {
      const res = await getDicDesByCode(
        dicKeys.vehicleClass,
        this.info.vehicleClass
      );
      if (res) {
        this.vehicleClass = res;
      }
    },
  },
  updated() {
    this.getVehicleTypes();
    // 获取收费车型
    this.getVehicleClass();
  },
  mounted() {
    console.log(this.info);
  },
  computed: {
    noData() {
      return isEmptyObj(this.info);
    },
  },
};
</script>
