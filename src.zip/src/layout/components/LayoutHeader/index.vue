<!--  -->
<template>
  <el-header :height="height">
    <div class="offline_layout-header" :style="{ height: height }">
      <router-link to="/">
        <img class="offline_layout-logo" src="../../../assets/images/full-logo.png" />
      </router-link>
      <ul class="offline_layout-header_nav">
        <li></li>

        <!-- <svg-icon icon="el-icon-back" @click="logout" />退出登录 -->
        <!-- </router-link> -->
        <!-- </li> -->

        <!-- /////////////////////////////////////////////////////////////////////////-->
        <li class="el-dropdown" v-if="logoutShow">
          <el-dropdown trigger="click">
            <!-- <span class="el-dropdown-link">
              下拉菜单<i class="el-icon-arrow-down el-icon--right"></i>
            </span> -->
            <el-dropdown-menu class="el-dropdown-menu" slot="dropdown">
              <el-dropdown-item>
        <li @click="logout" style="cursor: pointer" v-if="logoutShow">
          <i class="el-icon-switch-button"></i>退出登录
        </li>
        </el-dropdown-item>
        <el-dropdown-item divided>
          <li @click="openFullScreen2" style="cursor: pointer">
            Loading
          </li>
        </el-dropdown-item>
        <el-dropdown-item divided>
          <li @click="openFullScreen1" v-loading.fullscreen.lock="fullscreenLoading" style="cursor: pointer">
            <i class="el-icon-switch-button"></i>LOADING
          </li>
        </el-dropdown-item>
        <el-dropdown-item divided>
          <li @click="openFullScreen2" style="cursor: pointer">
            Loading
          </li>
        </el-dropdown-item>
        <el-dropdown-item divided>
          <li @click="logout" style="cursor: pointer" v-if="logoutShow">
            <i class="el-icon-switch-button"></i>退出登录
          </li>
        </el-dropdown-item>
        </el-dropdown-menu>
        <el-dropdown-menu></el-dropdown-menu>
        </el-dropdown>
        </li>
        <!-- //////////////////////////////////////////////////////////////////////////-->
        <!-- <li @click="showViewer" style="cursor: pointer" v-if="linkShow">
          <i class="el-icon-document">缓存图片</i>
        </li> -->
        <el-image-viewer v-if="viewerVisible" :on-close="closeViewer" :url-list="srcList"></el-image-viewer>
        <li @click="cPw" style="cursor: pointer">
          <i class="el-icon-lock"></i>修改密码
        </li>
        <li @click="uploadfile" style="cursor: pointer">
          <i class="el-icon-edit-outline"></i>上传日志
        </li>
        <li @click="notice" style="cursor: pointer">
          <i class="icon iconfont icontongzhi1"></i>用户通知
        </li>
        <li @click="toPage('/workordermanagement')" style="cursor: pointer" v-if="linkShow">
          <i class="el-icon-document"></i>工单管理
        </li>
        <!-- <li @click="toPage('netreconciliation')">
          <i class="el-icon-document"></i>网点对账
        </li> -->
        <li @click="about" style="cursor: pointer">
          <i class="el-icon-document"></i>关于
        </li>
        <!-- <li><svg-icon icon-class="education" />帮助文档</li> -->
        <li>
          <!-- <screenfull /> -->
        </li>
        <li v-if="avatarShow">
          <img class="offline_layout-header_avatar" :src="avatar" />{{
          username
          }}
        </li>
        <!-- <li v-if="avatarShow">
          <img class="offline_layout-header_avatar" :src="avatar" />{{ netid }}
        </li> -->
        <li @click="logout" style="cursor: pointer" v-if="logoutShow">
          <i class="el-icon-switch-button"></i>退出登录
        </li>
      </ul>
    </div>
    <!--修改密码-->
    <b-dialog :visible.sync="cPassword" :title="title" :append-to-body="appendToBody" @close="closeCPW"
      class="offline-complex-table" :showclose="showclose">
      <div style="padding: 0 0 45px 23%;">
        <div style="width: 70%;height: 500px;padding-top: 60px;">
          <el-form :label-position="labelPosition" :model="form" :rules="rules" ref="form" label-width="130px" style="
          background: #e5e5ea;
          padding: 20px 5% 20px 10%;
          border: 1px solid #c0c4c9;
        ">
            <el-form-item label="原密码：" prop="oldPassword" style="padding-top: 15px;padding-right:15px;float:left">
              <el-input v-model="form.oldPassword" show-password>
              </el-input>
              <!-- <el-input v-model="form.oldPassword" :show-password='oldbotton'>
            </el-input> -->
            </el-form-item>
            <!-- <div style="padding-top: 25px;" @click="oldbtn" class="icon iconfont iconbukejian">
          </div> -->
            <el-form-item label="新密码：" prop="newPassword" style="padding-top: 25px;padding-right:15px;float:left">
              <el-input v-model="form.newPassword" show-password></el-input>
              <!-- <el-input v-model="form.newPassword" :show-password='newbotton'></el-input> -->
            </el-form-item>
            <!-- <div style="padding-top: 55px;" @click="newbtn" class="icon iconfont iconbukejian"></div> -->
            <el-form-item label="新密码确认：" prop="newPasswordConfirm"
              style="padding-top: 25px;padding-right:15px;float:left">
              <el-input v-model="form.newPasswordConfirm" show-password></el-input>
              <!-- <el-input v-model="form.newPasswordConfirm" :show-password='newC'></el-input> -->
            </el-form-item>
            <!-- <div style="padding-top: 55px;" @click="newbtnC" class="icon iconfont iconbukejian"></div> -->
            <span style="display: inline-block;color:#F00;padding-top: 25px">密码规则: 8-14位，大小写英文字母和数字各至少一个</span>
          </el-form>
          <el-row style="padding-top: 60px; text-align: center">
            <el-col>
              <el-button @click="changePassword" type="primary" size="medium" round style="width: 150px">修改
              </el-button>
            </el-col>
          </el-row>
        </div>
      </div>
    </b-dialog>

    <!-- 用户通知 -->
    <el-dialog :visible.sync="noticePage" title="用户通知" :append-to-body="true" width="30%"
      custom-class="offline_layout-notice" :close-on-click-modal="false">
      <div class="content about offline_layout-notice-content-wrap">
        <div class="ulist">
          <p class="title">通知内容：</p>
          <ul class="offline_layout-notice-content">
            <li>1. 通知通知通知通知通知通知通知</li>
            <li>2. 通知通知通知通知通知通知通知</li>
            <li>3. 通知通知通知通知通知通知通知</li>
          </ul>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="noticePage = false">我知道了</el-button>
      </span>
    </el-dialog>
    <!-- 关于 -->
    <el-dialog :visible.sync="aboutPage" title="关于" :append-to-body="true" width="30%" :close-on-click-modal="false"
      v-dialog-drag @closed="() => (relaseHistory = false)">
      <div class="content about">
        <el-scrollbar style="height: 100%">
          <div class="info">
            <p v-if="!relaseHistory">新功能</p>
            <p v-if="!relaseHistory">
              <a href="javascript:void(0);" style="color: #027aff" @click="relaseHistory = true">版本历史记录</a>
            </p>
          </div>
          <div class="ulist ulist-latest" :class="{ 'border-bot': relaseHistory }">
            <div class="ver">
              <p>版本{{ verLatest.version }}</p>
              <p class="relase-time">{{ verLatest.updateTime | timeFormat }}</p>
            </div>
            <p class="title">本次更新</p>
            <ul>
              <!-- <li>{{ verLatest.content }}</li> -->
              <li v-html="verLatest.content"></li>
            </ul>
          </div>
          <div class="ver-history" v-if="relaseHistory">
            <div class="item border-bot" v-for="(item, index) in versionListShow" :key="index">
              <div class="ver">
                <p>版本{{ item.version }}</p>
                <p>{{ verLatest.updateTime | timeFormat }}</p>
              </div>
              <p class="title">本次更新</p>
              <ul>
                <!-- <li>{{ verLatest.content }}</li> -->
                <li v-html="verLatest.content"></li>
              </ul>
            </div>
          </div>
        </el-scrollbar>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="aboutPage = false">我知道了</el-button>
      </span>
    </el-dialog>
  </el-header>
</template>

<script>
  import { updateOptPwd, uploadFileQuery, uploadFile314 } from '@/api/common';
  import Screenfull from '@/components/Screenfull';
  import { logout } from '@/api/login';
  import { openWindow } from '@/utils/utils';
  import { getVersionInfo } from '@/api/common';
  import BDialog from '@/components/DialogBlueTitle'
  import ODialog from '@/components/Dialog';
  export default {
    data() {
      return {
        labelPosition: 'left',
        oldbotton: 'false',
        newbotton: 'false',
        newC: 'false',
        form: {
          oldPassword: '',
          newPassword: '',
          newPasswordConfirm: '',
        },
        rules: {
          oldPassword: [
            { required: true, message: '请输入旧密码', trigger: 'blur' },
            // { pattern: /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,14}$/, message: '密码规则: 8-14位，大小写英文字母和数字各至少一个' }
          ],
          newPassword: [
            { required: true, message: '请输入新密码', trigger: 'blur' },
            { pattern: /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,14}$/, message: '密码规则: 8-14位，大小写英文字母和数字各至少一个' }
          ],
          newPasswordConfirm: [
            { required: true, message: '请确认新密码', trigger: 'blur' },
            { pattern: /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,14}$/, message: '密码规则: 8-14位，大小写英文字母和数字各至少一个' }
          ]
        },
        fullscreenLoading: false,
        username: '',
        oprid: '',
        netid: '',
        height: '50px',
        avatar: require('../../../assets/images/kefu_default.png'),
        viewerVisible: false,
        // srcList: [
        // require('../../../assets/images/kefu_default.png'),
        // require('../../../assets/images/full-logo.png'),
        //   ],
        // srcList: [],

        // 关于
        aboutPage: false,
        relaseHistory: false,
        verList: [],
        verLatest: {},
        noticePage: false, // 用户通知
        cPassword: false,//修改密码
      };
    },
    props: {
      title: {
        type: String,
        default: '修改密码',
      },
      showclose: {
        default: true,
        type: Boolean,
      },
      appendToBody: {
        default: true,
        type: Boolean,
      },
      linkShow: {
        type: Boolean,
        default: true,
      },
      avatarShow: {
        type: Boolean,
        default: true,
      },
      logoutShow: {
        type: Boolean,
        default: true,
      },
    },
    components: {
      Screenfull,
      ODialog,
      BDialog
    },
    computed: {
      srcList() {
        let list = [];
        let registerUser = this.$store.getters.registerUser;
        if (registerUser.userpzpic) {
          let registerUserPic = registerUser.userpzpic.url || '';
          if (registerUserPic.startsWith('data:image')) {
            list.push(registerUserPic);
          } else {
            list.push('data:image/png;base64,' + registerUserPic);
          }
        }
        this.$store.getters.registerVehicle.forEach((veh) => {
          if (veh.carpzpic) {
            let registerVehiclePic = veh.carpzpic.url || '';
            if (registerVehiclePic.startsWith('data:image')) {
              list.push(registerVehiclePic);
            } else {
              list.push('data:image/png;base64,' + registerVehiclePic);
            }
          }
        });
        return list;
      },

      versionListShow() {
        return this.verList.slice(1);
      },
    },
    methods: {
      showViewer() {
        console.log(this.srcList);
        if (this.srcList.length === 0) {
          this.$message.info('暂无新办发行凭证');
        } else {
          this.viewerVisible = true;
        }
      },
      closeViewer() {
        this.viewerVisible = false;
      },
      openFullScreen1() {
        this.fullscreenLoading = true;
        setTimeout(() => {
          this.fullscreenLoading = false;
        }, 2000);
      },
      openFullScreen2() {
        const loading = this.$loading({
          lock: true,
          text: 'Loading',
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.7)',
        });
        setTimeout(() => {
          loading.close();
        }, 2000);
      },
      toPage(page) {
        console.log(
          'layoutheader-elementPermissions',
          this.$store.getters.elementPermissions
        );
        const query = {
          oprtId: this.$store.getters.oprtId,
          netid: this.$store.getters.netid,
          token: this.$store.getters.token,
          elementPermissions: JSON.stringify(
            this.$store.getters.elementPermissions
          ),
          // oldWindow: window,
        };
        openWindow(page, query);
      },
      // toPage2() {
      //   window.open(
      //     '127.0.0.1:8001/#/workordermanagement?oprtId=wjx&netid=100001&token=1340910760322138112'
      //   );
      // },
      async logout() {
        // const res = await logout();
        const a = this.$store.dispatch('Logout', {});
        this.$router.push({
          path: '/login',
        });
      },

      about() {
        this.aboutPage = true;
      },
      cPw() {
        this.cPassword = true;
      },
      async uploadfile() {
        //调后台接口查询是否有上传日志任务
        const res0 = await uploadFileQuery({
          oprtId: this.oprid,
          netId: this.netid,
        });
        if (res0) {
          //调客户端框架的获取日志接口，得到日志文件的Base64字符串
          for (let i = 0; i < res0.uploadList.length; i++) {
            const strLogDate = res0.uploadList[i].uploadDate
            const getlog = etcdev.getlog(strLogDate)
            const code = etcdev.getlog(strLogDate).slice(9, 10)
            if (code == '1') {
              this.$alert(etcdev.getlog(strLogDate).slice(18, -10), '提示', {
                confirmButtonText: '确定',
                type: 'warning',
              });
              return
            } else {
              //调后台的日志上传接口将Base64上传到服务器
              getlog = JSON.parse(getlog)
              console.log('getlog:', getlog)
              const res1 = await uploadFile314({
                id: res0.uploadList[i].id,
                fileName: getlog.name,
                fileContent: getlog.log
              });
            }
          }
        }
      },
      closeCPW() {
        console.log('关闭修改密码');
        this.$refs['form'].resetFields();
        this.oldbotton = false;
        this.newbotton = false;
        this.newC = false
      },
      async changePassword() {
        if (!this.form.oldPassword) {
          this.$message.error(
            '请输入旧密码'
          );
          return
        }
        if (!this.form.newPassword) {
          this.$message.error(
            '请输入新密码'
          );
          return
        }
        if (!this.form.newPasswordConfirm) {
          this.$message.error(
            '请确认新密码'
          );
          return
        }
        if (this.form.newPassword != this.form.newPasswordConfirm) {
          this.$message.error(
            '两次新密码输入不一致'
          );
          return
        }
        const resUpdateOptPwd = await updateOptPwd({
          oprtId: this.oprid,
          oprtPasswd: this.form.newPassword
        });
        console.log(resUpdateOptPwd)
      },
      oldbtn() {
        if (this.oldbotton == false) {
          this.oldbotton = true
        } else {
          this.oldbotton = false
        }
      },
      newbtn() {
        if (this.newbotton == false) {
          this.newbotton = true
        } else {
          this.newbotton = false
        }
      },
      newbtnC() {
        if (this.newC == false) {
          this.newC = true
        } else {
          this.newC = false
        }
      },
      notice() {
        this.noticePage = true;
      },
    },
    async mounted() {
      this.$nextTick(() => {
        this.username = this.$store.getters.userName;
        this.netid = this.$store.getters.netid;
        this.oprid = this.$store.getters.oprtId;
      });
      getVersionInfo().then((data) => {
        // console.log('data', data)
        if (data && data.versionList && data.versionList.length > 0) {
          this.verList = [...data.versionList];
          // [ {content:'13241', updateTime:'20210414120100', version:'V008' } ]
          this.verLatest = { ...data.versionList[0] };
        }
      });
      // const data = await getVersionInfo();
      // if (data) {
      //   // console.log('data', data)
      //   // if (data && data.versionList && data.versionList.length > 0) {
      //   //   this.verList = [...data.versionList];
      //   //   // [ {content:'13241', updateTime:'20210414120100', version:'V008' } ]
      //   //   // this.verLatest = { ...data.versionList[0] };
      //   this.verLatest = {
      //     content:
      //       '1、新增换卡业务<br>2、新增换签业务<br>3、工单管理，新增继续办理功能<br>4、工单管理，新增退单功能<br>5、工单管理，新增支付方式修改功能<br>6、新增查看系统版本功能<br>7、系统主页新增上传用户证件及经办人证件的功能',
      //   };
      //   // }
      // }
    },

    filters: {
      timeFormat(timeStr) {
        if (!timeStr) return '';
        // 20210420124544, 截取年月日
        const yyyy = timeStr.substr(0, 4);
        const mm = timeStr.substr(4, 2);
        const dd = timeStr.substr(6, 2);
        return yyyy + '-' + mm + '-' + dd;
      },
    },
  };
</script>
<style>
  .el-scrollbar .el-scrollbar__wrap {
    overflow-x: hidden;
  }

  .offline-replacecard_step3-btn {
    background: #536395;
    border-color: #536395;
  }

  .el-dialog__body .about.content {
    height: 400px;
    overflow: hidden;
  }

  .el-dialog__body .about.content .info {
    display: flex;
    justify-content: space-between;
    padding-right: 15px;
  }

  .el-dialog__body .about.content .ver {
    display: flex;
    justify-content: space-between;
    padding-right: 15px;
  }

  .ver {
    font-size: 14px;
    color: #707070;
  }

  .ver+.title {
    font-size: 16px;
  }

  .border-bot {
    border-bottom: 1px solid #ddd;
    padding-bottom: 5px;
  }

  .content.about p {
    margin: 10px 0;
  }
</style>