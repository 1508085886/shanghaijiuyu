<!--  -->
<template>
  <el-container class="offline_layout o-font-family is-vertical">
    <layout-header />
    <el-container style="height: 0">
      <el-aside
        width="420px"
        class="o-height-full offline_layout-aside o-font-family"
      >
        <search-container />
      </el-aside>
      <el-main class="o-height-full offline_layout-main o-flex o-flex-column">
        <div class="offline_layout-main-scroll">
          <router-transition reload />
        </div>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import SearchContainer from './components/SearchComtainer';
import LayoutHeader from './components/LayoutHeader';
import RouterTransition from '@/components/RouterTransition';
export default {
  components: {
    SearchContainer,
    LayoutHeader,
    RouterTransition,
  },
};
</script>
