import axios from 'axios'
import { Notification, Message } from 'element-ui'
import store from '@/store'
import routes from '@/router'
import { isEmptyObj } from '@/utils/utils.js' // 对象判空

axios.defaults.method = 'POST'
axios.defaults.headers['Content-Type'] = 'application/json;charset=utf-8'
// 创建axios实例
const service = axios.create({
  // axios中请求配置有baseURL选项，表示请求URL公共部分
  // baseURL: '',
  baseURL: process.env.BASE_API,
  // 超时
  timeout: 60000
})
// request拦截器
service.interceptors.request.use(
  config => {
    let btnId = '';
    // console.log('btnPress', store.getters.btnPress)
    if (store.getters.btnPress) {
      btnId = store.getters.btnArr[store.getters.btnArr.length - 1].id;
      store.commit('SET_BTNARR', btnId);
      // console.log('btnId', btnId)
    }
    config.data = {
      channelId: store.getters.channelId,
      regAPPId: store.getters.regAPPId,
      regChannelId: store.getters.regChannelId,
      oprtId: store.getters.oprtId,
      token: store.getters.token,
      serialNo: store.getters.serialNo,
      timeStamp: Date.now() / 1000,
      data: config.data,
      btnId: btnId,
    }

    // if (!(config.url === '/getRandom' || config.url === '/login')) {
    //   if (!store.getters.oprtId || !store.getters.token) {
    //     Message({
    //       message: '长时间未操作，请重新登录',
    //       type: 'warning',
    //       duration: 3 * 1000
    //     })
    //     axios.CancelToken.source();
    //   }
    // }
    return config
  },
  error => {
    console.log(error)
    Promise.reject(error)
  }
)
const btnLoadingFalse = (res) => {
  store.getters.btnArr.forEach((element) => {
    if (element.id === JSON.parse(res.config.data).btnId) {
      element.count--;
      if (element.count === 0) {
        store.getters.btnMap.get(element.id).btnLoading = false;
        store.commit('DELETE_BTNSTATE', element.id);
      }
    }
    // else if (element.count === 0) {// 按钮没有调用接口
    //   store.getters.btnMap.get(element.id).btnLoading = false;
    //   console.log('element.count')
    // }
  });
}
// 响应拦截器
service.interceptors.response.use(res => {
  // if (res.status !== 200) {
  //   return Promise.reject(res.statusText || '网络异常')
  // }
  if (store.getters.btnPress) {
    btnLoadingFalse(res);
  }
  const code = res.data.code
  // console.log('res.data.code', res.data.code);
  if (process.env.BASE_API === '/mock') {
    return res.data
  }

  if (code === '9999') {
    Message({
      message: res.data.msg,
      type: 'error',
      duration: 0,
      showClose: true,
    })
    // const logres = await logout();
    // const a = store.dispatch('Logout', {});
    // debugger;
    routes.push({
      path: '/login',
    });
    return null;
  }
  else if (code !== '0000') {
    if (code.startsWith('9') || code === '6029') {// 6029是在对公新办发行4.9.分支机构查询接口里是独有特殊报错，直接这个判断吧，返回这个就代表了你给的查询条件查不到分支机构
      // && !res.data.data.exCode
      if (!isEmptyObj(res.data.data)) {
        res.data.data.exCode = code;
      } else if (!res.data.data) {
        res.data.data = {};
        res.data.data.exCode = code;
      }
      return res.data.data || {}
    }
    if (!(res.config.headers.noMsg && JSON.parse(res.config.headers.noMsg).some(m => m === code))) {
      Message({
        message: res.data.msg,
        type: 'error',
        duration: 0,
        showClose: true,
      })
    }
    // Notification.error({
    //   title: res.data.msg
    // })
    // return Promise.reject('error')
    return null
  }
  return res.data.data || {}
},
  error => {
    if (store.getters.btnPress) {
      btnLoadingFalse(error.response);
    }
    console.log('err', error.response)
    // console.log('err' + error)
    Message({
      // message: "error.message",
      message: "网络连接超时，请重新尝试。",
      type: 'error',
      duration: 0,
      showClose: true,
    })
    // return null
    return Promise.reject(error)
  }
)

export default service
