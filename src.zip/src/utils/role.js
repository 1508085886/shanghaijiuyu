
export function validrole(menuid, str) {
  for (let i = 0; i < menuid.length; i++) {
    const parin = menuid[i]; //{}
    const parchildren = parin.children;
    for (let j = 0; j < parchildren.length; j++) {
      if (str === parchildren[j].title) {
        console.log('menutitle,true')
        return true;
      }
    }
  }
  console.log('menutitle,false')
  return false;
}
