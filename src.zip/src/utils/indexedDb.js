import Dexie from 'dexie';
import { dbName, sheets } from '@/config/indexedDb';

/**
 * @description 创建数据库
 */
const db = new Dexie(dbName);
/**
 * @description 创建表
 */
db.version(3).stores(sheets);

/**
 * @description 数据库操作
 */
const indexedDb = {};
for (let key in sheets) {
  indexedDb[key] = {
    db: db[key],
    save(data, oId) {
      return new Promise((resolve, reject) => {
        db.transaction('rw', db[key], async () => {
          if (
            oId &&
            (await db[key]
              .where('id')
              .equals(oId)
              .count()) > 0
          ) {
            db[key]
              .update(oId, data)
              .then(res => {
                resolve(res);
              })
              .catch(e => {
                reject(e);
              });
          } else {
            db[key]
              .add(data)
              .then(id => {
                resolve(id);
              })
              .catch(e => {
                reject(e);
              });
          }
        });
      });
    },
    get(param) {
      return db[key].get(param);
    },
    getAll() {
      return db[key].toArray();
    },
    delete(param) {
      return db[key].delete(param);
    },
    clear() {
      return db[key].clear();
    },
  };
}

export const idb = indexedDb;

export default {
  install(Vue) {
    Vue.prototype.$db = indexedDb;
  },
};
