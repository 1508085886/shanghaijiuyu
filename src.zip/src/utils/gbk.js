window.Promise = Promise;

export function GBKchange(val) {
    let arr = [];
    if (val.length % 2 === 0) {
        for (let i = 0; i < val.length; i = i + 2) {
            arr.push('0x' + val.slice(i, i + 2));
        }
        //console.log(this.arr);
    }
    return arr
};



export function GBKFlagchange(val) {
    let arr2 = [];
    if (val.length % 2 === 0) {
        for (let i = 0; i < val.length; i = i + 2) {
            arr2.push('0x' + val.slice(i, i + 2));
        }
        // console.log(this.arr2);
    }
    return arr2
};