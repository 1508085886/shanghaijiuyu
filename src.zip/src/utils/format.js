/**
 * @description 定义各种格式化工具函数
*/
import { validID, validPhone } from './validate'

/**
 * @description 格式化日期
 * @param { String } format 指定格式日期
 * @param { Date | Number | String } date Date格式的日期对象，支持 YYYY,YY,MM,M,DD,D,HH,H,FF,F,SS,S
*/
const addZero = val => {
  return val < 10 ? '0' + val : val
}
export const formatDate = (format, date = new Date()) => {
  if (!(date instanceof Date)) {
    date = new Date(date)
  }
  format = format.toUpperCase()
  const YY = date.getFullYear()
  const YYYY = date.getFullYear()
  const M = date.getMonth() + 1
  const MM = addZero(M)
  const D = date.getDate()
  const DD = addZero(D)
  const H = date.getHours()
  const HH = addZero(H)
  const F = date.getMinutes()
  const FF = addZero(F)
  const S = date.getSeconds()
  const SS = addZero(S)
  return format
    .replace(/YYYY/, YYYY)
    .replace(/YY/, YY)
    .replace(/MM/, MM)
    .replace(/M/, M)
    .replace(/DD/, DD)
    .replace(/D/, D)
    .replace(/HH/, HH)
    .replace(/H/, H)
    .replace(/FF/, FF)
    .replace(/F/, F)
    .replace(/SS/, SS)
    .replace(/S/, S)
}

/**
 * @description 格式化身份证号码
 * @param { String } id 身份证号码
*/
export const formatCardNo = id => {
  if (!validID(id)) {
    console.error('身份证格式不合法')
    return ''
  }
  const arr = id.split('')
  arr.splice(6, 8, '********')
  return arr.join('')
}

/**
 * @description 格式化手机号码
 * @param { String | Number } phoneNumber 手机号码
*/
export const formatPhoneNo = phoneNumber => {
  if (!validPhone(phoneNumber)) {
    console.error('手机号格式不合法')
    return ''
  }
  const arr = phoneNumber.split('')
  arr.splice(3, 4, '****')
  return arr.join('')
}
