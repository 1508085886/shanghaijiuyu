/**
 * @param {string} path
 * @returns {Boolean}
 */
export function isExternal(path) {
  return /^(https?:|mailto:|tel:)/.test(path)
}

/**
 * @param {string} str
 * @returns {Boolean}
 */
export function validUsername(str) {
  const valid_map = ['admin', 'editor']
  return valid_map.indexOf(str.trim()) >= 0
}

/**
 * @param {string} url
 * @returns {Boolean}
 */
export function validURL(url) {
  const reg = /^(https?|ftp):\/\/([a-zA-Z0-9.-]+(:[a-zA-Z0-9.&%$-]+)*@)*((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]?)(\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}|([a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+\.(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|[a-zA-Z]{2}))(:[0-9]+)*(\/($|[a-zA-Z0-9.,?'\\+&%$#=~_-]+))*$/
  return reg.test(url)
}

/**
 * @param {string} str
 * @returns {Boolean}
 */
export function validLowerCase(str) {
  const reg = /^[a-z]+$/
  return reg.test(str)
}

/**
 * @param {string} str
 * @returns {Boolean}
 */
export function validUpperCase(str) {
  const reg = /^[A-Z]+$/
  return reg.test(str)
}

/**
 * @param {string} str
 * @returns {Boolean}
 */
export function validAlphabets(str) {
  const reg = /^[A-Za-z]+$/
  return reg.test(str)
}

/**
 * @param {string} email
 * @returns {Boolean}
 */
// export function validEmail(email) {
//   const reg = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
//   return reg.test(email)
// }

/**
 * @param {string} str
 * @returns {Boolean}
 */
export function isString(str) {
  if (typeof str === 'string' || str instanceof String) {
    return true
  }
  return false
}

/**
 * @param {Array} arg
 * @returns {Boolean}
 */
export function isArray(arg) {
  if (typeof Array.isArray === 'undefined') {
    return Object.prototype.toString.call(arg) === '[object Array]'
  }
  return Array.isArray(arg)
}

/**
 * @description 验证码手机号码
 * @param { Number } phone 手机号码
 * @returns { Boolean }
*/
export function validPhone(phone) {
  // return /^1[3|4|5|6|7|8|9][0-9]{9}$/.test(phone)
  return /^1[0-9]{10}$/.test(phone.replace(/\s/g, ""))
}

export function validGDPhone(phone) {
  // return /^0[1-9][0-9]{1,2}-[1-9][0-9]{5,7}(-[0-9]{1,5})?|1[3|4|5|6|7|8|9][0-9]{9}$/.test(phone)
  return /^0[1-9][0-9]{1,2}-[1-9][0-9]{5,7}(-[0-9]{1,5})?|1[3|4|5|6|7|8|9][0-9]{9}|[0-9]{8}$/.test(phone)
}

export function validEmail(param) {
  if (!param) {
    return true;
  }
  return /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(param)
}




/**
 * @description 传入正则和参数，判断true和false
 * @param { \\ } zz 正则表达式
 * @param { \\ } param 验证参数
 * @returns { Boolean }
*/
export function vzz(zz, param) {
  return zz.test(param.replace(/\s/g, ''))
}

/**
 * @description 验证身份证号码
 * @param { String } idcode 身份证号码
*/
export const validID = idcode => {
  // 加权因子
  var weight_factor = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];
  // 校验码
  var check_code = ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'];

  var code = idcode + "";
  if (code.length !== 18) return false
  var last = idcode[17];//最后一位

  var seventeen = code.substring(0, 17);

  // ISO 7064:1983.MOD 11-2
  // 判断最后一位校验码是否正确
  var arr = seventeen.split("");
  var len = arr.length;
  var num = 0;
  for (var i = 0; i < len; i++) {
    num = num + arr[i] * weight_factor[i];
  }

  // 获取余数
  var resisue = num % 11;
  var last_no = check_code[resisue];

  // 格式的正则
  // 正则思路
  /*
  第一位不可能是0
  第二位到第六位可以是0-9
  第七位到第十位是年份，所以七八位为19或者20
  十一位和十二位是月份，这两位是01-12之间的数值
  十三位和十四位是日期，是从01-31之间的数值
  十五，十六，十七都是数字0-9
  十八位可能是数字0-9，也可能是X
  */
  var idcard_patter = /^[1-9][0-9]{5}([1][9][0-9]{2}|[2][0][0|1][0-9])([0][1-9]|[1][0|1|2])([0][1-9]|[1|2][0-9]|[3][0|1])[0-9]{3}([0-9]|[X])$/;

  // 判断格式是否正确
  var format = idcard_patter.test(idcode);

  // 返回验证结果，校验码和格式同时正确才算是合法的身份证号码
  return last === last_no && format ? true : false;
}

/**
 * @description 验证对象是否为空对象
 * @param { Object } obj
*/
export const isEmptyObj = obj => {
  return (Object.keys(obj).length === 0)
}

/**
 * @description 验证手机号码 适用于表单rules
 * @param { Number } value 手机号码
 * @returns { Boolean }
*/
export function validatePhone(rule, value, callback) {
  if (value == '' || value == undefined || value == null) {
    callback();
  } else {
    if ((!validPhone(value)) && value != '') {
      callback(new Error('请输入正确的手机号码'));
    } else {
      callback();
    }
  }
}
/**
 * @description 验证所属市 适用于表单rules
 * @param { Number } value 所属市 
 * @returns { Boolean }
*/
export function validateCity(rule, value, callback) {
  const reg = /[^\u4E00-\u9FA5]/g;
  if (value == '' || value == undefined || value == null) {
    callback();
  } else {
    if ((reg.test(value)) && value != '') {
      callback(new Error('请输入正确所属市'));
    } else {
      callback();
    }
  }
}
/**
 * @description 验证金额 适用于表单rules
 * @param { Number } value 金额 
 * @returns { Boolean }
*/
export function validateAmount(rule, value, callback) {
  const reg = /^\d+$|^\d*\.\d+$/g;
  if (value == '' || value == undefined || value == null) {
    callback();
  } else {
    if ((!reg.test(value)) && value != '') {
      callback(new Error('请输入正确金额'));
    } else {
      callback();
    }
  }
}

/**
 * @description 验证卡号 适用于表单rules
 * @param { Number } value 卡号 
 * @returns { Boolean }
*/
export function validateCardId(rule, value, callback) {
  const reg = /[0-9]{16}/g;
  if (value == '' || value == undefined || value == null) {
    callback();
  } else {
    if ((!reg.test(value)) && value != '') {
      callback(new Error('请输入正确卡号'));
    } else {
      callback();
    }
  }
}
/**
 * @description 验证码车牌号码
 * @param { Number } vehicleNumber 车牌号码
 * @returns { Boolean }
*/
export function validVehicleNumber(vehicleNumber) {
  if (vehicleNumber.includes("应急")) {
    //alert('车牌号码含应急')
    return /^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领测A-HJ-NP-Z0-9]{1}[A-HJ-NP-Z0-9]{5}应急$/.test(vehicleNumber)
  } else {
    //alert('不含应急')
    // let result2 = /^([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领测A-HJ-NP-Z0-9][A-HJ-NP-Z0-9](([DF](?![ABCDEFGHJKLMNPQRSTUVWXYZ0-9]*[IO])[0-9]{4})|([0-9]{5}[DF])))|^默A00000$|^([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领测A-HJ-NP-Z0-9]{1}[A-HJ-NP-Z0-9]{5}[A-HJ-NP-Z0-9学警港澳领试超外]{1}([A-HJ-NP-Z0-9外])?)|^([A-Z0-9]{7})$/
    //   .test(vehicleNumber);
    // alert(result2);
    return /^([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领测A-HJ-NP-Z0-9][A-HJ-NP-Z0-9](([DF](?![ABCDEFGHJKLMNPQRSTUVWXYZ0-9]*[IO])[0-9]{4})|([0-9]{5}[DF])))|^默A00000$|^([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领测A-HJ-NP-Z0-9]{1}[A-HJ-NP-Z0-9]{5}[A-HJ-NP-Z0-9学警港澳领试超外]{1}([A-HJ-NP-Z0-9外])?)|^([A-Z0-9]{7})$/.test(vehicleNumber)
  }

}