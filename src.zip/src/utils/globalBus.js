import Vue from 'vue';
// export const globalBus = new Vue();
const bus = {}

export const globalBus = {
    $on(key, call) {
        if (bus[key]) {
            bus[key].push(call)
        } else {
            bus[key] = [call]
        }
    },
    $emit: async function (key, params) {
        if (bus[key]) {
            for (let i = 0; i < bus[key].length; i++) {
                return await bus[key][i](params);
            }
        }
    },
    $off(key) {
        if (!key) {// 如果没有提供参数，则移除所有的事件监听器；
            bus = {};
        } else if (bus[key]) {
            // 如果只提供了事件，则移除该事件所有的监听器；
            console.log('移除该事件所有的监听器', key);
            bus[key] = null;
            // bus.splice(bus.findIndex(item => item.key === key), 1)
        }
    },
}

// export default globalBus
