const bus = {}

window.vueEmit = (param) => {
  const p = JSON.parse(param)
  emit.emit(p.type, p.param)
}

const emit = {
  on(key, call) {
    if (bus[key]) {
      bus[key].push(call)
    } else {
      bus[key] = [call]
    }
  },
  emit(key, params) {
    if (bus[key]) {
      for (let i = 0; i < bus[key].length; i++) {
        bus[key][i](params)
      }
    }
  }
}

export default emit
