
/**
 *  开票二维码查看方法封装，方法依赖于$createElement,所以只能在组件中使用,
 *  
 *  参数: 
 *  vm  组件的实例，
 *  href  电子发票的url地址
 *  options 配置参数 可选 可配置beforeClose参数回调
 * 
 *  返回值：
 *  promise
 */

import Qrcode from "../components/QrCode"
const showQrcode = (vm, href, options = {}) => {
    const h = vm.$createElement
    return vm.$msgbox({
        title: '二维码',
        showConfirmButton: false,
        showCancelButton: false,
        closeOnClickModal: false,
        closeOnPressEscape: false,
        customClass: 'qrcode-dialog',
        message: h(Qrcode, {
            attrs: {
                text: href
            }
        }),
        ...options
    })
}

export default showQrcode