/**
 * @author hzw
 * @description 返回正则
 */
import { Message } from 'element-ui';

/**
 * @description 返回证件号正则
 */
export const getcodezz = val => {
  let rules = /^[A-Za-z0-9()-]+$/;
  switch (val) {
    //身份证
    case '101':
      rules = /^\d{17}[\dX]$/;
      break;
    //
    case '105':
      rules = /^[\u2E80-\uFE4FA-Za-z0-9-—]+$/;
    case '106':
      rules = /^[\u2E80-\uFE4FA-Za-z0-9-—]+$/;
      break;
    case '102':
      rules = /^[A-Za-z0-9()-]+$/;
      break;
    case '103':
      rules = /^[A-Za-z0-9()-]+$/;
      break;
    case '104':
      rules = /^[A-Za-z0-9()-]+$/;
      break;
    case '113':
      rules = /^[A-Za-z0-9()-]+$/;
      break;
    case '114':
      rules = /^[A-Za-z0-9()-]+$/;
      break;

    case '201':
      rules = /^[A-Za-z0-9()-]+$/;
      break;

    case '202':
      rules = /^[A-Za-z0-9()-]+$/;
      break;
    case '203':
      rules = /^[A-Za-z0-9()-]+$/;
      break;
    case '204':
      rules = /^[A-Za-z0-9()-]+$/;
      break;
    case '205':
      rules = /^[A-Za-z0-9()-]+$/;
      break;
    case '206':
      rules = /^[A-Za-z0-9()-]+$/;
      break;
  }
  return rules;


};
