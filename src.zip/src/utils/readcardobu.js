window.Promise = Promise;
import { GBKchange, GBKFlagchange } from '@/utils/gbk';
import store from '@/store';
import { Message } from 'element-ui'

export function getCardVersionNo() {
    var cardVersion = '';
    const get15info = JSON.parse(etcdev.get0015info());
    if (get15info.info.substring(18, 19) === '1') {
        cardVersion = '1x'
    };
    if (get15info.info.substring(18, 19) === '4') {
        if (
            get15info.info.substring(19, 20) === '8' ||
            get15info.info.substring(19, 20) === '9'
        ) {
            cardVersion = '48'
        } else {
            cardVersion = '4x'
        }
    }
    return cardVersion
}

export function getObuVersionNo() {
    var obuVersionNo = '';
    const getmfef01 = JSON.parse(etcdev.getmfef01info());
    if (getmfef01.info.substring(18, 19) === '1') {
        obuVersionNo = '1x';
    };
    if (getmfef01.info.substring(18, 19) === '4') {
        if (
            getmfef01.info.substring(19, 20) === '8' ||
            getmfef01.info.substring(19, 20) === '9'
        ) {
            obuVersionNo = '48'
        } else {
            obuVersionNo = '4x'
        }
    }
    return obuVersionNo

}


export function get15info() {
    var vehicleCategory = '';
    vehicleCategory = store.getters.searchCarInfo.vehicleCategory; //车种
    const get15info = JSON.parse(etcdev.get0015info());
    console.log(
        '/////////////////////////////////////////////////////////////////'
    );
    console.log('get15info');
    console.log(get15info.info);
    //1X,长三角ETC系统 CPU卡、ESAM结构v5.0
    if (get15info.info.substring(18, 19) === '1') {
        //console.log('版本号1x');
        let versionNo0015 = '1' + get15info.info.substring(19, 20);
        if (get15info.info.substring(19, 20) === '0') {
            versionNo0015 = '10';
        }
        var issueFlag = get15info.info.substring(0, 16);
        const res = GBKFlagchange(issueFlag);
        var encodingConvert = require('encoding');
        var buffer = new Buffer(res);
        var issueFlagplateDecoded = encodingConvert.convert(
            buffer,
            'UTF8',
            'GBK'
        );
        //console.log('发卡方标识');
        // console.log(issueFlagplateDecoded.toString());
        let cardType = parseInt(get15info.info.substring(16, 18), 16);
        if (cardType == '21') {
            cardType = '年/月票卡';
        } else if (cardType == '22') {
            cardType = '储值卡';
        } else if (cardType == '23') {
            cardType = '记账卡';
        } else if (cardType == '22') {
            cardType = '储值卡';
        } else if (cardType == '51') {
            cardType = '测试用年/月票卡';
        } else if (cardType == '22') {
            cardType = '测试用储值卡';
        } else if (cardType == '53') {
            cardType = '测试用记账卡';
        }
        // console.log('卡片类型');
        // console.log(cardType);
        // console.log('卡内版本号');
        // console.log(versionNo0015);
        let cardNetId = get15info.info.substring(20, 24);
        // if (cardNetId == '1F01') {
        //     cardNetId = '上海：1F01';
        // } else if (cardNetId == '2001') {
        //     cardNetId = '江苏：2001';
        // }
        //console.log('卡内网络编号');
        //console.log(cardNetId);
        let cpuCardId = get15info.info.substring(24, 40);
        // console.log('CPU卡片内部编号');
        // console.log(cpuCardId);
        // console.log('启用时间');
        var startDate =
            get15info.info.substring(40, 44) +
            '年' +
            get15info.info.substring(44, 46) +
            '月' +
            get15info.info.substring(46, 48) +
            '日';
        // console.log(startDate);
        // console.log('到期时间');
        var endDate =
            get15info.info.substring(48, 52) +
            '年' +
            get15info.info.substring(52, 54) +
            '月' +
            get15info.info.substring(54, 56) +
            '日';
        // console.log(endDate);
        var vehicleNumber = get15info.info.substring(56, 80);
        // console.log(vehicleNumber);
        const res2 = GBKchange(vehicleNumber.replace(/00/g, ''));
        var encodingConvert = require('encoding');
        var buffer = new Buffer(res2);
        var vehicleNumberplateDecoded = encodingConvert.convert(
            buffer,
            'UTF8',
            'GBK'
        );
        // console.log('车牌号码');
        //  console.log(vehicleNumberplateDecoded.toString());
        let userType = get15info.info.substring(80, 82);
        if (userType == '00') {
            userType = '0 - 普通用户';
        } else if (userType == '01') {
            userType = '1 - 集装箱卡车';
        } else if (userType == '02') {
            userType = '2 - 卧铺客车';
        } else if (userType == '03') {
            userType = '3 - 江苏保留使用';
        } else if (userType == '04') {
            userType = '4 - 安徽保留使用';
        } else if (userType == '05') {
            userType = '5 - 公务车用户';
        } else if (userType == '06') {
            userType = '6 - 江西保留';
        } else if (userType == '08') {
            userType = '8 - 军车用户';
        } else if (userType == '09') {
            userType = '9 - 警车用户';
        } else if (userType == '10') {
            userType = '10 - 紧急车用户';
        } else if (userType == '12') {
            userType = '12 - 免费用户';
        } else if (userType == '14') {
            userType = '14 - 军队用户';
        } else if (userType == '15') {
            userType = '15 - 浙江保留使用（警通）';
        } else if (userType == '16') {
            userType = '16 - 上海保留使用';
        }
        //  console.log('用户类型');
        // console.log(userType);
        let vehicleColor = parseInt(get15info.info.substring(82, 86), 16);
        if (vehicleColor == '0') {
            vehicleColor = '0 - 蓝色';
        } else if (vehicleColor == '1') {
            vehicleColor = '1 - 黄色';
        } else if (vehicleColor == '2') {
            vehicleColor = '2 - 黑色';
        } else if (vehicleColor == '3') {
            vehicleColor = '3 - 白色';
        }
        //  console.log('车牌颜色');
        //  console.log(vehicleColor);
        var json0015 = JSON.parse(
            '{"issueFlag":"test","cardType":"test2","versionNo0015":"test3","cardNetId":"test4","cpuCardId":"test5","startDate":"test6","endDate":"test7","vehicleNumber":"test8","userType":"test9","vehicleColor":"test10"}'
        );
        json0015.issueFlag = issueFlagplateDecoded.toString();
        json0015.cardType = cardType;
        json0015.versionNo0015 = versionNo0015;
        json0015.cardNetId = cardNetId;
        json0015.cpuCardId = cpuCardId;
        json0015.startDate = startDate;
        json0015.endDate = endDate;
        json0015.vehicleNumber = vehicleNumberplateDecoded.toString();
        json0015.userType = userType;
        json0015.vehicleColor = vehicleColor;
        //console.log(json0015);
    }
    //
    //
    //
    if (get15info.info.substring(18, 19) === '4') {
        //48或49,（交办公路函〔2019〕1524号）交通运输部办公厅关于做好货车及专项作业车ETC发行服务有关工作的通知 20191025-J1J2标准已废除
        if (
            get15info.info.substring(19, 20) === '8' ||
            get15info.info.substring(19, 20) === '9'
        ) {

            var issueFlag = get15info.info.substring(0, 16);
            const res = GBKFlagchange(issueFlag);
            var encodingConvert = require('encoding');
            var buffer = new Buffer(res);
            var issueFlagplateDecoded = encodingConvert.convert(
                buffer,
                'UTF8',
                'GBK'
            );
            // console.log('发卡方标识');
            // console.log(issueFlagplateDecoded.toString());
            let cardType = parseInt(get15info.info.substring(16, 18), 16);
            if (cardType == '21') {
                cardType = '年/月票卡';
            } else if (cardType == '22') {
                cardType = '储值卡';
            } else if (cardType == '23') {
                cardType = '记账卡';
            } else if (cardType == '22') {
                cardType = '储值卡';
            } else if (cardType == '51') {
                cardType = '测试用年/月票卡';
            } else if (cardType == '22') {
                cardType = '测试用储值卡';
            } else if (cardType == '53') {
                cardType = '测试用记账卡';
            }
            // console.log('卡片类型');
            // console.log(cardType);
            let versionNo0015 = '4' + get15info.info.substring(19, 20);
            //  console.log('卡片版本号');
            //  console.log(versionNo);
            let cardNetId = get15info.info.substring(20, 24);
            //  console.log('卡片网络编号');
            //  console.log(cardNetId);
            let cpuCardId = get15info.info.substring(24, 40);
            // console.log('用户卡内部编号');
            // console.log(cpuCardId);
            // console.log('启用时间');
            var startDate =
                get15info.info.substring(40, 44) +
                '年' +
                get15info.info.substring(44, 46) +
                '月' +
                get15info.info.substring(46, 48) +
                '日';
            // console.log(startDate);
            // console.log('到期时间');
            var endDate =
                get15info.info.substring(48, 52) +
                '年' +
                get15info.info.substring(52, 54) +
                '月' +
                get15info.info.substring(54, 56) +
                '日';
            // console.log(endDate);
            var vehicleNumber = get15info.info.substring(56, 80);

            const res2 = GBKchange(vehicleNumber.replace(/00/g, ''));
            var encodingConvert = require('encoding');
            var buffer = new Buffer(res2);


            var vehicleNumberplateDecoded = encodingConvert.convert(
                buffer,
                'UTF8',
                'GBK'
            );
            // console.log('车牌号码');
            // console.log(vehicleNumberplateDecoded.toString());
            let userType = get15info.info.substring(80, 82);
            if (userType == '18') {
                userType = '0x18 - 货物专用运输(集装箱)J1';
            } else if (userType == '1B') {
                userType = '0x1B - 牵引车';
            } else if (userType == '1A') {
                userType = '0x1A - 应急救援车';
            } else if (userType == '1C') {
                userType = '0x1C - 货物专用运输(集装箱)及普通货运J2';
            } else if (userType == '06') {
                userType = '0x06 - 公务车';
            } else if (userType == '00') {
                if (vehicleCategory == '1') {
                    userType = '0x00 - 普通客车用户';
                } else {
                    userType = '0x00 - 普通货车用户';
                }
            }
            //console.log('车辆用户类型');
            //console.log(userType);
            let vehicleColor = get15info.info.substring(82, 84);
            if (vehicleColor == '00') {
                vehicleColor = '0x00 - 蓝色';
            } else if (vehicleColor == '01') {
                vehicleColor = '0x01 - 黄色';
            } else if (vehicleColor == '02') {
                vehicleColor = '0x02 - 黑色';
            } else if (vehicleColor == '03') {
                vehicleColor = '0x03 - 白色';
            } else if (vehicleColor == '04') {
                vehicleColor = '0x04 - 渐变绿色';
            } else if (vehicleColor == '05') {
                vehicleColor = '0x05 - 黄绿双拼色';
            } else if (vehicleColor == '06') {
                vehicleColor = '0x06 - 蓝白渐变色';
            } else {
                vehicleColor = '0x' + vehicleColor;
            }
            //console.log('车牌颜色');
            //console.log(vehicleColor);
            let vehicleClass = get15info.info.substring(84, 86);
            if (vehicleClass == '01') {
                vehicleClass = '01 - 一类客车';
            } else if (vehicleClass == '02') {
                vehicleClass = '02 - 二类客车';
            } else if (vehicleClass == '03') {
                vehicleClass = '03 - 三类客车';
            } else if (vehicleClass == '04') {
                vehicleClass = '04 - 四类客车';
            } else if (vehicleClass == '05') {
                vehicleClass = '05 - 五类客车';
            } else if (vehicleClass == '06') {
                vehicleClass = '06 - 六类客车';
            } else if (vehicleClass == '0B') {
                vehicleClass = '0B - 一类货车';
            } else if (vehicleClass == '0C') {
                vehicleClass = '0C - 二类货车';
            } else if (vehicleClass == '0D') {
                vehicleClass = '0D - 三类货车';
            } else if (vehicleClass == '0E') {
                vehicleClass = '0E - 四类货车';
            } else if (vehicleClass == '0F') {
                vehicleClass = '0F - 五类货车';
            } else if (vehicleClass == '10') {
                vehicleClass = '10 - 六类货车';
            } else if (vehicleClass == '15') {
                vehicleClass = '15 - 一类专项作业车';
            } else if (vehicleClass == '16') {
                vehicleClass = '16 - 二类专项作业车';
            } else if (vehicleClass == '17') {
                vehicleClass = '17 - 三类专项作业车';
            } else if (vehicleClass == '18') {
                vehicleClass = '18 - 四类专项作业车';
            } else if (vehicleClass == '19') {
                vehicleClass = '19 - 五类专项作业车';
            } else if (vehicleClass == '1A') {
                vehicleClass = '1A - 六类专项作业车';
            }
            // console.log('车型');
            //console.log(vehicleClass);
            let appHold = get15info.info.substring(86, 92);
            // console.log('行业应用保留，默认写入0xFF');
            //console.log(appHold);
            let customApp = get15info.info.substring(92, 100);
            // console.log('省内自定义应用，默认写入0xFF');
            //console.log(customApp);
            var json0015 = JSON.parse(
                '{"issueFlag":"test","cardType":"test2","versionNo0015":"test3","cardNetId":"test4","cpuCardId":"test5","startDate":"test6","endDate":"test7","vehicleNumber":"test8","userType":"test9","vehicleColor":"test10","vehicleClass":"test11","appHold":"test12","customApp":"test13"}'
            );
            json0015.issueFlag = issueFlagplateDecoded.toString();
            json0015.cardType = cardType;
            json0015.versionNo0015 = versionNo0015;
            json0015.cardNetId = cardNetId;
            json0015.cpuCardId = cpuCardId;
            json0015.startDate = startDate;
            json0015.endDate = endDate;
            json0015.vehicleNumber = vehicleNumberplateDecoded.toString();
            json0015.userType = userType;
            json0015.vehicleColor = vehicleColor;
            json0015.vehicleClass = vehicleClass;
            json0015.appHold = appHold;
            json0015.customApp = customApp;
            //console.log(json0015);
        }
        //4X
        else {
            // console.log('版本号4x');
            //4X客车，附录4 全国高速公路电子不停车收费联网用户卡、ESAM文件结构与数据定义20150123
            if (vehicleCategory === '1') {
                var issueFlag = get15info.info.substring(0, 16);

                const res = GBKFlagchange(issueFlag);
                var encodingConvert = require('encoding');
                var buffer = new Buffer(res);


                var issueFlagplateDecoded = encodingConvert.convert(
                    buffer,
                    'UTF8',
                    'GBK'
                );
                //console.log('发卡方标识');
                //console.log(issueFlagplateDecoded.toString());
                let cardType = parseInt(get15info.info.substring(16, 18), 16);
                if (cardType == '21') {
                    cardType = '年/月票卡';
                } else if (cardType == '22') {
                    cardType = '储值卡';
                } else if (cardType == '23') {
                    cardType = '记账卡';
                } else if (cardType == '22') {
                    cardType = '储值卡';
                } else if (cardType == '51') {
                    cardType = '测试用年/月票卡';
                } else if (cardType == '22') {
                    cardType = '测试用储值卡';
                } else if (cardType == '53') {
                    cardType = '测试用记账卡';
                }
                //console.log('卡片类型');
                //console.log(cardType);
                let versionNo0015 = '4' + get15info.info.substring(19, 20);
                // console.log('卡片版本号');
                //console.log(versionNo);
                let cardNetId = get15info.info.substring(20, 24);
                // console.log('卡片网络编号');
                //console.log(cardNetId);
                let cpuCardId = get15info.info.substring(24, 40);
                // console.log('用户卡内部编号');
                // console.log(cpuCardId);
                // console.log('启用时间');
                var startDate =
                    get15info.info.substring(40, 44) +
                    '年' +
                    get15info.info.substring(44, 46) +
                    '月' +
                    get15info.info.substring(46, 48) +
                    '日';
                // console.log(startDate);
                //console.log('到期时间');
                var endDate =
                    get15info.info.substring(48, 52) +
                    '年' +
                    get15info.info.substring(52, 54) +
                    '月' +
                    get15info.info.substring(54, 56) +
                    '日';
                // console.log(endDate);
                var vehicleNumber = get15info.info.substring(56, 80);

                const res2 = GBKchange(vehicleNumber.replace(/00/g, ''));
                var encodingConvert = require('encoding');
                var buffer = new Buffer(res2);


                var vehicleNumberplateDecoded = encodingConvert.convert(
                    buffer,
                    'UTF8',
                    'GBK'
                );
                // console.log('车牌号码');
                // console.log(vehicleNumberplateDecoded.toString());
                let userType = get15info.info.substring(80, 82);
                if (userType == '18') {
                    userType = '0x18 - 货物专用运输(集装箱)J1';
                } else if (userType == '1B') {
                    userType = '0x1B - 牵引车';
                } else if (userType == '1A') {
                    userType = '0x1A - 应急救援车';
                } else if (userType == '1C') {
                    userType = '0x1C - 货物专用运输(集装箱)及普通货运J2';
                } else if (userType == '06') {
                    userType = '0x06 - 公务车';
                } else if (userType == '00') {
                    userType = '0x00 - 普通客车用户';
                }
                // console.log('用户类型');
                // console.log(userType);
                let vehicleColor = get15info.info.substring(82, 84);
                if (vehicleColor == '00') {
                    vehicleColor = '0x00 - 蓝色';
                } else if (vehicleColor == '01') {
                    vehicleColor = '0x01 - 黄色';
                } else if (vehicleColor == '02') {
                    vehicleColor = '0x02 - 黑色';
                } else if (vehicleColor == '03') {
                    vehicleColor = '0x03 - 白色';
                } else if (vehicleColor == '04') {
                    vehicleColor = '0x04 - 渐变绿色';
                } else if (vehicleColor == '05') {
                    vehicleColor = '0x05 - 黄绿双拼色';
                } else if (vehicleColor == '06') {
                    vehicleColor = '0x06 - 蓝白渐变色';
                } else {
                    vehicleColor = '0x' + vehicleColor;
                }
                // console.log('车牌颜色');
                // console.log(vehicleColor);
                let vehicleClass = get15info.info.substring(84, 86);
                if (vehicleClass == '01') {
                    vehicleClass = '01 - 一类客车';
                } else if (vehicleClass == '02') {
                    vehicleClass = '02 - 二类客车';
                } else if (vehicleClass == '03') {
                    vehicleClass = '03 - 三类客车';
                } else if (vehicleClass == '04') {
                    vehicleClass = '04 - 四类客车';
                } else if (vehicleClass == '05') {
                    vehicleClass = '05 - 五类客车';
                } else if (vehicleClass == '06') {
                    vehicleClass = '06 - 六类客车';
                } else if (vehicleClass == '0B') {
                    vehicleClass = '0B - 一类货车';
                } else if (vehicleClass == '0C') {
                    vehicleClass = '0C - 二类货车';
                } else if (vehicleClass == '0D') {
                    vehicleClass = '0D - 三类货车';
                } else if (vehicleClass == '0E') {
                    vehicleClass = '0E - 四类货车';
                } else if (vehicleClass == '0F') {
                    vehicleClass = '0F - 五类货车';
                } else if (vehicleClass == '10') {
                    vehicleClass = '10 - 六类货车';
                } else if (vehicleClass == '15') {
                    vehicleClass = '15 - 一类专项作业车';
                } else if (vehicleClass == '16') {
                    vehicleClass = '16 - 二类专项作业车';
                } else if (vehicleClass == '17') {
                    vehicleClass = '17 - 三类专项作业车';
                } else if (vehicleClass == '18') {
                    vehicleClass = '18 - 四类专项作业车';
                } else if (vehicleClass == '19') {
                    vehicleClass = '19 - 五类专项作业车';
                } else if (vehicleClass == '1A') {
                    vehicleClass = '1A - 六类专项作业车';
                }
                // console.log('车型');
                //console.log(vehicleClass);
                let appHold = get15info.info.substring(86, 92);
                // console.log('行业应用保留，默认写入0xFF');
                // console.log(appHold);
                let customApp = get15info.info.substring(92, 100);
                // console.log('省内自定义应用，默认写入0xFF');
                // console.log(customApp);
                var json0015 = JSON.parse(
                    '{"issueFlag":"test","cardType":"test2","versionNo0015":"test3","cardNetId":"test4","cpuCardId":"test5","startDate":"test6","endDate":"test7","vehicleNumber":"test8","userType":"test9","vehicleColor":"test10","vehicleClass":"test11","appHold":"test12","customApp":"test13"}'
                );
                json0015.issueFlag = issueFlagplateDecoded.toString();
                json0015.cardType = cardType;
                json0015.versionNo0015 = versionNo0015;
                json0015.cardNetId = cardNetId;
                json0015.cpuCardId = cpuCardId;
                json0015.startDate = startDate;
                json0015.endDate = endDate;
                json0015.vehicleNumber = vehicleNumberplateDecoded.toString();
                json0015.userType = userType;
                json0015.vehicleColor = vehicleColor;
                json0015.vehicleClass = vehicleClass;
                json0015.appHold = appHold;
                json0015.customApp = customApp;
                //console.log(json0015);
            }
            //4x货车,（交办公路函〔2019〕1524号）交通运输部办公厅关于做好货车及专项作业车ETC发行服务有关工作的通知 20191025-J1J2标准已废除
            else {
                var issueFlag = get15info.info.substring(0, 16);

                const res = GBKFlagchange(issueFlag);
                var encodingConvert = require('encoding');
                var buffer = new Buffer(res);

                var issueFlagplateDecoded = encodingConvert.convert(
                    buffer,
                    'UTF8',
                    'GBK'
                );
                // console.log('发卡方标识');
                // console.log(issueFlagplateDecoded.toString());
                let cardType = parseInt(get15info.info.substring(16, 18), 16);
                if (cardType == '21') {
                    cardType = '年/月票卡';
                } else if (cardType == '22') {
                    cardType = '储值卡';
                } else if (cardType == '23') {
                    cardType = '记账卡';
                } else if (cardType == '22') {
                    cardType = '储值卡';
                } else if (cardType == '51') {
                    cardType = '测试用年/月票卡';
                } else if (cardType == '22') {
                    cardType = '测试用储值卡';
                } else if (cardType == '53') {
                    cardType = '测试用记账卡';
                }
                // console.log('卡片类型');
                // console.log(cardType);
                let versionNo0015 = '4' + get15info.info.substring(19, 20);
                // console.log('卡片版本号');
                // console.log(versionNo);
                let cardNetId = get15info.info.substring(20, 24);
                // console.log('卡片网络编号');
                // console.log(cardNetId);
                let cpuCardId = get15info.info.substring(24, 40);
                // console.log('用户卡内部编号');
                // console.log(cpuCardId);
                // console.log('启用时间');
                var startDate =
                    get15info.info.substring(40, 44) +
                    '年' +
                    get15info.info.substring(44, 46) +
                    '月' +
                    get15info.info.substring(46, 48) +
                    '日';
                // console.log(startDate);
                // console.log('到期时间');
                var endDate =
                    get15info.info.substring(48, 52) +
                    '年' +
                    get15info.info.substring(52, 54) +
                    '月' +
                    get15info.info.substring(54, 56) +
                    '日';
                //console.log(endDate);
                var vehicleNumber = get15info.info.substring(56, 80);

                const res2 = GBKchange(vehicleNumber.replace(/00/g, ''));
                var encodingConvert = require('encoding');
                var buffer = new Buffer(res2);


                var vehicleNumberplateDecoded = encodingConvert.convert(
                    buffer,
                    'UTF8',
                    'GBK'
                );
                // console.log('车牌号码');
                // console.log(vehicleNumberplateDecoded.toString());
                let userType = get15info.info.substring(80, 82);
                if (userType == '18') {
                    userType = '0x18 - 货物专用运输(集装箱)J1';
                } else if (userType == '1B') {
                    userType = '0x1B - 牵引车';
                } else if (userType == '1A') {
                    userType = '0x1A - 应急救援车';
                } else if (userType == '1C') {
                    userType = '0x1C - 货物专用运输(集装箱)及普通货运J2';
                } else if (userType == '06') {
                    userType = '0x06 - 公务车';
                } else if (userType == '00') {
                    userType = '0x00 - 普通货车用户';
                }
                // console.log('车辆用户类型');
                // console.log(userType);
                let vehicleColor = get15info.info.substring(82, 84);
                if (vehicleColor == '00') {
                    vehicleColor = '0x00 - 蓝色';
                } else if (vehicleColor == '01') {
                    vehicleColor = '0x01 - 黄色';
                } else if (vehicleColor == '02') {
                    vehicleColor = '0x02 - 黑色';
                } else if (vehicleColor == '03') {
                    vehicleColor = '0x03 - 白色';
                } else if (vehicleColor == '04') {
                    vehicleColor = '0x04 - 渐变绿色';
                } else if (vehicleColor == '05') {
                    vehicleColor = '0x05 - 黄绿双拼色';
                } else if (vehicleColor == '06') {
                    vehicleColor = '0x06 - 蓝白渐变色';
                } else {
                    vehicleColor = '0x' + vehicleColor;
                }
                // console.log('车牌颜色');
                // console.log(vehicleColor);
                let vehicleClass = get15info.info.substring(84, 86);
                if (vehicleClass == '01') {
                    vehicleClass = '0x01 - 一类客车';
                } else if (vehicleClass == '02') {
                    vehicleClass = '0x02 - 二类客车';
                } else if (vehicleClass == '03') {
                    vehicleClass = '0x03 - 三类客车';
                } else if (vehicleClass == '04') {
                    vehicleClass = '0x04 - 四类客车';
                } else if (vehicleClass == '05') {
                    vehicleClass = '0x05 - 五类客车';
                } else if (vehicleClass == '06') {
                    vehicleClass = '0x06 - 六类客车';
                } else if (vehicleClass == '0B') {
                    vehicleClass = '0x0B - 一类货车';
                } else if (vehicleClass == '0C') {
                    vehicleClass = '0x0C - 二类货车';
                } else if (vehicleClass == '0D') {
                    vehicleClass = '0x0D - 三类货车';
                } else if (vehicleClass == '0E') {
                    vehicleClass = '0x0E - 四类货车';
                } else if (vehicleClass == '0F') {
                    vehicleClass = '0x0F - 五类货车';
                } else if (vehicleClass == '10') {
                    vehicleClass = '0x10 - 六类货车';
                } else if (vehicleClass == '15') {
                    vehicleClass = '0x15 - 一类专项作业车';
                } else if (vehicleClass == '16') {
                    vehicleClass = '0x16 - 二类专项作业车';
                } else if (vehicleClass == '17') {
                    vehicleClass = '0x17 - 三类专项作业车';
                } else if (vehicleClass == '18') {
                    vehicleClass = '0x18 - 四类专项作业车';
                } else if (vehicleClass == '19') {
                    vehicleClass = '0x19 - 五类专项作业车';
                } else if (vehicleClass == '1A') {
                    vehicleClass = '0x1A - 六类专项作业车';
                } else {
                    vehicleClass = '0x' + vehicleClass;
                }
                // console.log('车型');
                // console.log(vehicleClass);
                let appHold = get15info.info.substring(86, 92);
                //console.log('行业应用保留，默认写入0xFF');
                // console.log(appHold);
                let customApp = get15info.info.substring(92, 100);
                // console.log('省内自定义应用，默认写入0xFF');
                // console.log(customApp);
                var json0015 = JSON.parse(
                    '{"issueFlag":"test","cardType":"test2","versionNo0015":"test3","cardNetId":"test4","cpuCardId":"test5","startDate":"test6","endDate":"test7","vehicleNumber":"test8","userType":"test9","vehicleColor":"test10","vehicleClass":"test11","appHold":"test12","customApp":"test13"}'
                );
                json0015.issueFlag = issueFlagplateDecoded.toString();
                json0015.cardType = cardType;
                json0015.versionNo0015 = versionNo0015;
                json0015.cardNetId = cardNetId;
                json0015.cpuCardId = cpuCardId;
                json0015.startDate = startDate;
                json0015.endDate = endDate;
                json0015.vehicleNumber = vehicleNumberplateDecoded.toString();
                json0015.userType = userType;
                json0015.vehicleColor = vehicleColor;
                json0015.vehicleClass = vehicleClass;
                json0015.appHold = appHold;
                json0015.customApp = customApp;
                //console.log(json0015);
            }
        }
    }
    return json0015;
}

export function get16info() {
    const cardVersionNo = getCardVersionNo();
    const get16info = JSON.parse(etcdev.get0016info());
    console.log(
        '/////////////////////////////////////////////////////////////////'
    );
    console.log('get16info');
    console.log(get16info.info);
    //1X,长三角ETC系统 CPU卡、ESAM结构v5.0
    if (cardVersionNo == '1x') {
        let ownerFlag = get16info.info.substring(0, 2);
        // console.log('持卡人身份标识');
        // console.log(ownerFlag);
        let employeeFlag = get16info.info.substring(2, 4);
        // console.log('本系统职工标识');
        // console.log(employeeFlag);
        var ownerName = get16info.info.substring(4, 44);
        // console.log(ownerName)
        // console.log(ownerName.replace(/00/g, ''))
        const res = GBKFlagchange(ownerName.replace(/00/g, ''));
        var encodingConvert = require('encoding');
        // console.log('res')
        // console.log(res)
        // console.log(res.replace("00", ''))
        var buffer = new Buffer(res);
        var ownerNameplateDecoded = encodingConvert.convert(
            buffer,
            'UTF8',
            'GBK'
        );
        // console.log('持卡人姓名');
        // console.log(ownerNameplateDecoded.toString());
        var ownerIdNum = get16info.info.substring(44, 108);
        const res2 = GBKchange(ownerIdNum.replace(/00/g, ""));
        var encodingConvert = require('encoding');
        var buffer = new Buffer(res2);
        var ownerIdNumplateDecoded = encodingConvert.convert(
            buffer,
            'UTF8',
            'GBK'
        );
        // console.log('持卡人证件号码');
        // console.log(ownerIdNumplateDecoded.toString());
        let ownerCardType = get16info.info.substring(108, 110);
        if (ownerCardType == '00') {
            ownerCardType = '0 - 身份证';
        } else if (ownerCardType == '01') {
            ownerCardType = '1 - 军官证';
        } else if (ownerCardType == '02') {
            ownerCardType = '2 - 护照';
        } else if (ownerCardType == '03') {
            ownerCardType = '3 - 入境证（限港台居民）';
        } else if ((ownerCardType == '04')) {
            ownerCardType = '4 - 临时身份证';
        } else if ((ownerCardType == '06')) {
            ownerCardType = '203 - 营业执照';
        }
        //  console.log('持卡人证件类型');
        // console.log(ownerCardType);
        var json0016 = JSON.parse(
            '{"ownerFlag":"test","employeeFlag":"test2","ownerNameplateDecoded":"test3","ownerIdNumplateDecoded":"test4","ownerCardType":"test5"}'
        );
        json0016.ownerFlag = ownerFlag;
        json0016.employeeFlag = employeeFlag;
        json0016.ownerNameplateDecoded = ownerNameplateDecoded.toString();
        json0016.ownerIdNumplateDecoded = ownerIdNumplateDecoded.toString();
        json0016.ownerCardType = ownerCardType;
        //console.log(json0016);
    }
    //48或49,（交办公路函〔2019〕1524号）交通运输部办公厅关于做好货车及专项作业车ETC发行服务有关工作的通知 20191025-J1J2标准已废除
    if (cardVersionNo == '48') {
        let ownerFlag = get16info.info.substring(0, 2);
        //  console.log('持卡人身份标识');
        // console.log(ownerFlag);
        let employeeFlag = get16info.info.substring(2, 4);
        //  console.log('本系统职工标识');
        //  console.log(employeeFlag);
        var ownerName = get16info.info.substring(4, 44);
        const res = GBKFlagchange(ownerName.replace(/00/g, ''));
        var encodingConvert = require('encoding');
        var buffer = new Buffer(res);
        var ownerNameplateDecoded = encodingConvert.convert(
            buffer,
            'UTF8',
            'GBK'
        );
        //  console.log('持卡人姓名');
        //  console.log(ownerNameplateDecoded.toString());
        var ownerIdNum = get16info.info.substring(44, 108);
        const res2 = GBKchange(ownerIdNum.replace(/00/g, ''));
        var encodingConvert = require('encoding');
        var buffer = new Buffer(res2);
        var ownerIdNumplateDecoded = encodingConvert.convert(
            buffer,
            'UTF8',
            'GBK'
        );
        //  console.log('持卡人证件号码');
        //  console.log(ownerIdNumplateDecoded.toString());
        let ownerCardType = get16info.info.substring(108, 110);
        if (ownerCardType == '00') {
            ownerCardType = '0 - 身份证';
        } else if (ownerCardType == '01') {
            ownerCardType = '1 - 军官证';
        } else if (ownerCardType == '02') {
            ownerCardType = '2 - 护照';
        } else if (ownerCardType == '03') {
            ownerCardType = '3 - 入境证（限港台居民）';
        } else if ((ownerCardType == '04')) {
            ownerCardType = '4 - 临时身份证';
        } else if ((ownerCardType == '06')) {
            ownerCardType = '203 - 营业执照';
        }
        //  console.log('持卡人证件类型');
        // console.log(ownerCardType);
        var json0016 = JSON.parse(
            '{"ownerFlag":"test","employeeFlag":"test2","ownerNameplateDecoded":"test3","ownerIdNumplateDecoded":"test4","ownerCardType":"test5"}'
        );
        json0016.ownerFlag = ownerFlag;
        json0016.employeeFlag = employeeFlag;
        json0016.ownerNameplateDecoded = ownerNameplateDecoded.toString();
        json0016.ownerIdNumplateDecoded = ownerIdNumplateDecoded.toString();
        json0016.ownerCardType = ownerCardType;
        //console.log(json0016);
    }

    if (cardVersionNo == '4x') {
        //4X客车，附录4 全国高速公路电子不停车收费联网用户卡、ESAM文件结构与数据定义20150123
        if (store.getters.searchCarInfo.vehicleCategory == '1') {
            let ownerFlag = get16info.info.substring(0, 2);
            //  console.log('持卡人身份标识');
            // console.log(ownerFlag);
            let employeeFlag = get16info.info.substring(2, 4);
            // console.log('本系统职工标识');
            // console.log(employeeFlag);
            var ownerName = get16info.info.substring(4, 44);
            const res = GBKFlagchange(ownerName.replace(/00/g, ''));
            var encodingConvert = require('encoding');
            var buffer = new Buffer(res);
            var ownerNameplateDecoded = encodingConvert.convert(
                buffer,
                'UTF8',
                'GBK'
            );
            // console.log('持卡人姓名');
            // console.log(ownerNameplateDecoded.toString());
            var ownerIdNum = get16info.info.substring(44, 108);
            const res2 = GBKchange(ownerIdNum.replace(/00/g, ''));
            var encodingConvert = require('encoding');
            var buffer = new Buffer(res2);
            var ownerIdNumplateDecoded = encodingConvert.convert(
                buffer,
                'UTF8',
                'GBK'
            );
            // console.log('持卡人证件号码');
            //console.log(ownerIdNumplateDecoded.toString());
            let ownerCardType = get16info.info.substring(108, 110);
            if (ownerCardType == '00') {
                ownerCardType = '0 - 身份证';
            } else if (ownerCardType == '01') {
                ownerCardType = '1 - 军官证';
            } else if (ownerCardType == '02') {
                ownerCardType = '2 - 护照';
            } else if (ownerCardType == '03') {
                ownerCardType = '3 - 入境证（限港台居民）';
            } else if ((ownerCardType == '04')) {
                ownerCardType = '4 - 临时身份证';
            } else if ((ownerCardType == '06')) {
                ownerCardType = '203 - 营业执照';
            }
            //  console.log('持卡人证件类型');
            //  console.log(ownerCardType);
            var json0016 = JSON.parse(
                '{"ownerFlag":"test","employeeFlag":"test2","ownerNameplateDecoded":"test3","ownerIdNumplateDecoded":"test4","ownerCardType":"test5"}'
            );
            json0016.ownerFlag = ownerFlag;
            json0016.employeeFlag = employeeFlag;
            json0016.ownerNameplateDecoded = ownerNameplateDecoded.toString();
            json0016.ownerIdNumplateDecoded = ownerIdNumplateDecoded.toString();
            json0016.ownerCardType = ownerCardType;
            //console.log(json0016);
        }
        //4x货车,（交办公路函〔2019〕1524号）交通运输部办公厅关于做好货车及专项作业车ETC发行服务有关工作的通知 20191025-J1J2标准已废除
        else {
            let ownerFlag = get16info.info.substring(0, 2);
            //  console.log('持卡人身份标识');
            //  console.log(ownerFlag);
            let employeeFlag = get16info.info.substring(2, 4);
            //  console.log('本系统职工标识');
            //  console.log(employeeFlag);
            var ownerName = get16info.info.substring(4, 44);
            const res = GBKFlagchange(ownerName.replace(/00/g, ''));
            var encodingConvert = require('encoding');
            var buffer = new Buffer(res);
            var ownerNameplateDecoded = encodingConvert.convert(
                buffer,
                'UTF8',
                'GBK'
            );
            //  console.log('持卡人姓名');
            //  console.log(ownerNameplateDecoded.toString());
            var ownerIdNum = get16info.info.substring(44, 108);
            const res2 = GBKchange(ownerIdNum.replace(/00/g, ''));
            var encodingConvert = require('encoding');
            var buffer = new Buffer(res2);
            var ownerIdNumplateDecoded = encodingConvert.convert(
                buffer,
                'UTF8',
                'GBK'
            );
            //  console.log('持卡人证件号码');
            //  console.log(ownerIdNumplateDecoded.toString());
            let ownerCardType = get16info.info.substring(108, 110);
            if (ownerCardType == '00') {
                ownerCardType = '0 - 身份证';
            } else if (ownerCardType == '01') {
                ownerCardType = '1 - 军官证';
            } else if (ownerCardType == '02') {
                ownerCardType = '2 - 护照';
            } else if (ownerCardType == '03') {
                ownerCardType = '3 - 入境证（限港台居民）';
            } else if ((ownerCardType == '04')) {
                ownerCardType = '4 - 临时身份证';
            } else if ((ownerCardType == '06')) {
                ownerCardType = '203 - 营业执照';
            }
            //  console.log('持卡人证件类型');
            //  console.log(ownerCardType);
            var json0016 = JSON.parse(
                '{"ownerFlag":"test","employeeFlag":"test2","ownerNameplateDecoded":"test3","ownerIdNumplateDecoded":"test4","ownerCardType":"test5"}'
            );
            json0016.ownerFlag = ownerFlag;
            json0016.employeeFlag = employeeFlag;
            json0016.ownerNameplateDecoded = ownerNameplateDecoded.toString();
            json0016.ownerIdNumplateDecoded = ownerIdNumplateDecoded.toString();
            json0016.ownerCardType = ownerCardType;
            //console.log(json0016);
        }
    }
    return json0016;
};



export function getmf01info() {
    const getmfef01 = JSON.parse(etcdev.getmfef01info());

    console.log(
        '/////////////////////////////////////////////////////////////////'
    );
    console.log('getmfef01');
    console.log(getmfef01)
    console.log(getmfef01.info);
    if (getmfef01.code == '1' && getmfef01.info == '') {
        Message({
            showClose: true,
            message: getmfef01.msg,
            type: 'error',
            duration: 0,
        })
        return
    }
    //1X,长三角ETC系统 CPU卡、ESAM结构v5.0
    if (getmfef01.info.substring(18, 19) === '1') {
        var serverCode = getmfef01.info.substring(0, 16);
        const res = GBKFlagchange(serverCode);
        var encodingConvert = require('encoding');
        var buffer = new Buffer(res);
        var obuVersionNoplateDecoded = encodingConvert.convert(
            buffer,
            'UTF8',
            'GBK'
        );
        // console.log('服务提供商编码');
        // console.log(obuVersionNoplateDecoded.toString());
        let procotolType = getmfef01.info.substring(16, 18);
        // console.log('协约类型');
        // console.log('0x' + procotolType);
        let obuVersion = getmfef01.info.substring(18, 20);
        //  console.log('合同版本');
        // console.log(obuVersion);
        let obuNo = getmfef01.info.substring(20, 36);
        // console.log('合同序列号');
        //  console.log(obuNo);
        //  console.log('合同签署日期');
        var startDate =
            getmfef01.info.substring(36, 40) +
            '年' +
            getmfef01.info.substring(40, 42) +
            '月' +
            getmfef01.info.substring(42, 44) +
            '日';
        //  console.log(startDate);
        // console.log('合同到期日期');
        var endDate =
            getmfef01.info.substring(44, 48) +
            '年' +
            getmfef01.info.substring(48, 50) +
            '月' +
            getmfef01.info.substring(50, 52) +
            '日';
        //   console.log(endDate);
        let status = getmfef01.info.substring(52, 54);
        //  console.log(getmfef01.info.substring(52, 54));
        if (parseInt(getmfef01.info.substring(52, 53), 16) == '0') {
            status = '由路侧根据防拆信息控制OBU的通行';
        } else if (parseInt(getmfef01.info.substring(52, 53), 16) == '1') {
            status = '由OBU根据防拆信息设置自身工作状态';
        } else if (parseInt(getmfef01.info.substring(52, 53), 16) == '15') {
            status = '防拆信息未启用';
        }
        if (parseInt(getmfef01.info.substring(53, 54), 16) == '0') {
            status = '标签已被非法拆卸';
        } else if (parseInt(getmfef01.info.substring(53, 54), 16) == '1') {
            status = '正常工作状态';
        }
        //  console.log('拆卸状态');
        // console.log(status);
        let left = getmfef01.info.substring(54, 198);
        // console.log('预留');
        // console.log(left);
        var jsonmfef01 = JSON.parse(
            '{"obuVersionNoplateDecoded":"test","procotolType":"test2","obuVersion":"test3","obuNo":"test4","startDate":"test5","endDate":"test6","status":"test7","left":"test8"}'
        );
        jsonmfef01.obuVersionNoplateDecoded = obuVersionNoplateDecoded.toString();
        jsonmfef01.procotolType = procotolType;
        jsonmfef01.obuVersion = obuVersion;
        jsonmfef01.obuNo = obuNo;
        jsonmfef01.startDate = startDate;
        jsonmfef01.endDate = endDate;
        jsonmfef01.status = status;
        jsonmfef01.left = left;
        //console.log(jsonmfef01);
    }
    if (getmfef01.info.substring(18, 19) === '4') {
        //48或49,（交办公路函〔2019〕1524号）交通运输部办公厅关于做好货车及专项作业车ETC发行服务有关工作的通知 20191025-J1J2标准已废除
        if (
            getmfef01.info.substring(19, 20) === '8' ||
            getmfef01.info.substring(19, 20) === '9'
        ) {
            var serverCode = getmfef01.info.substring(0, 16);
            const res = GBKFlagchange(serverCode);
            var encodingConvert = require('encoding');
            var buffer = new Buffer(res);;
            var obuVersionNoplateDecoded = encodingConvert.convert(
                buffer,
                'UTF8',
                'GBK'
            );
            //  console.log('服务提供商编码');
            //  console.log(obuVersionNoplateDecoded.toString());
            let procotolType = getmfef01.info.substring(16, 18);
            //  console.log('协约类型');
            //  console.log('0x' + procotolType);
            //let obuVersion = getmfef01.info.substring(18, 20);
            //  console.log('合同版本');
            //  console.log('0x49');
            let obuNo = getmfef01.info.substring(20, 36);
            //  console.log('合同序列号');
            //  console.log(obuNo);
            //  console.log('合同签署日期');
            var startDate =
                getmfef01.info.substring(36, 40) +
                '年' +
                getmfef01.info.substring(40, 42) +
                '月' +
                getmfef01.info.substring(42, 44) +
                '日';
            // console.log(startDate);
            // console.log('合同到期日期');
            var endDate =
                getmfef01.info.substring(44, 48) +
                '年' +
                getmfef01.info.substring(48, 50) +
                '月' +
                getmfef01.info.substring(50, 52) +
                '日';
            // console.log(endDate);
            let status = getmfef01.info.substring(52, 54);
            // console.log('拆卸状态');
            // console.log(status);
            let vin = getmfef01.info.substring(54, 88);
            // console.log('车辆识别代码');
            //  console.log(vin);
            let left = getmfef01.info.substring(88, 198);
            //  console.log('预留');
            //  console.log(left);
            var jsonmfef01 = JSON.parse(
                '{"obuVersionNoplateDecoded":"test","procotolType":"test2","obuVersion":"test3","obuNo":"test4","startDate":"test5","endDate":"test6","status":"test7","left":"test8","vin":"test9"}'
            );
            jsonmfef01.obuVersionNoplateDecoded = obuVersionNoplateDecoded.toString();
            jsonmfef01.procotolType = procotolType;
            jsonmfef01.obuVersion = '49'; //合同版本
            jsonmfef01.obuNo = obuNo; //合同序列号
            jsonmfef01.startDate = startDate;
            jsonmfef01.endDate = endDate;
            jsonmfef01.status = status;
            jsonmfef01.vin = vin;
            jsonmfef01.left = left;
            //console.log(jsonmfef01);
        }
        //4x
        else {
            //4X客车，附录4 全国高速公路电子不停车收费联网用户卡、ESAM文件结构与数据定义20150123
            if (store.getters.searchCarInfo.vehicleCategory == '1') {
                var serverCode = getmfef01.info.substring(0, 16);
                const res = GBKFlagchange(serverCode);
                var encodingConvert = require('encoding');
                var buffer = new Buffer(res);
                var obuVersionNoplateDecoded = encodingConvert.convert(
                    buffer,
                    'UTF8',
                    'GBK'
                );
                // console.log('服务提供商编码');
                // console.log(obuVersionNoplateDecoded.toString());
                let procotolType = getmfef01.info.substring(16, 18);
                //  console.log('协约类型');
                // console.log('0x' + procotolType);
                let obuVersion = getmfef01.info.substring(19, 20);
                //  console.log('合同版本');
                //  console.log('4' + obuVersion);
                let obuNo = getmfef01.info.substring(20, 36);
                //  console.log('合同序列号');
                //  console.log(obuNo);
                //  console.log('合同签署日期');
                var startDate =
                    getmfef01.info.substring(36, 40) +
                    '年' +
                    getmfef01.info.substring(40, 42) +
                    '月' +
                    getmfef01.info.substring(42, 44) +
                    '日';
                //  console.log(startDate);
                //  console.log('合同到期日期');
                var endDate =
                    getmfef01.info.substring(44, 48) +
                    '年' +
                    getmfef01.info.substring(48, 50) +
                    '月' +
                    getmfef01.info.substring(50, 52) +
                    '日';
                //  console.log(endDate);
                let status = getmfef01.info.substring(52, 54);
                //  console.log('拆卸状态');
                //  console.log(status);
                let left = getmfef01.info.substring(54, 198);
                //  console.log('预留');
                //  console.log(left);
                var jsonmfef01 = JSON.parse(
                    '{"obuVersionNoplateDecoded":"test","procotolType":"test2","obuVersion":"test3","obuNo":"test4","startDate":"test5","endDate":"test6","status":"test7","left":"test8"}'
                );
                jsonmfef01.obuVersionNoplateDecoded = obuVersionNoplateDecoded.toString(); //服务提供商编码
                jsonmfef01.procotolType = procotolType;
                jsonmfef01.obuVersion = '4' + obuVersion; //合同版本
                jsonmfef01.obuNo = obuNo; //合同序列号
                jsonmfef01.startDate = startDate;
                jsonmfef01.endDate = endDate;
                jsonmfef01.status = status;
                jsonmfef01.left = left;
                //console.log(jsonmfef01);
            }
            //4x货车,（交办公路函〔2019〕1524号）交通运输部办公厅关于做好货车及专项作业车ETC发行服务有关工作的通知 20191025-J1J2标准已废除
            else {
                var serverCode = getmfef01.info.substring(0, 16);
                const res = GBKFlagchange(serverCode);
                var encodingConvert = require('encoding');
                var buffer = new Buffer(res);
                var obuVersionNoplateDecoded = encodingConvert.convert(
                    buffer,
                    'UTF8',
                    'GBK'
                );
                //    console.log('服务提供商编码');
                //    console.log(obuVersionNoplateDecoded.toString());
                let procotolType = getmfef01.info.substring(16, 18);
                //    console.log('协约类型');
                //    console.log('0x' + procotolType);
                //let obuVersion = getmfef01.info.substring(18, 20);
                //     console.log('合同版本');
                //    console.log('0x49');
                let obuNo = getmfef01.info.substring(20, 36);
                //    console.log('合同序列号');
                //    console.log(obuNo);
                //    console.log('合同签署日期');
                var startDate =
                    getmfef01.info.substring(36, 40) +
                    '年' +
                    getmfef01.info.substring(40, 42) +
                    '月' +
                    getmfef01.info.substring(42, 44) +
                    '日';
                //   console.log(startDate);
                //   console.log('合同到期日期');
                var endDate =
                    getmfef01.info.substring(44, 48) +
                    '年' +
                    getmfef01.info.substring(48, 50) +
                    '月' +
                    getmfef01.info.substring(50, 52) +
                    '日';
                //  console.log(endDate);
                let status = getmfef01.info.substring(52, 54);
                //  console.log('拆卸状态');
                //  console.log(status);
                let vin = getmfef01.info.substring(54, 88);
                // console.log('车辆识别代码');
                //  console.log(vin);
                let left = getmfef01.info.substring(88, 198);
                //  console.log('预留');
                //  console.log(left);
                var jsonmfef01 = JSON.parse(
                    '{"obuVersionNoplateDecoded":"test","procotolType":"test2","obuVersion":"test3","obuNo":"test4","startDate":"test5","endDate":"test6","status":"test7","left":"test8","vin":"test9"}'
                );
                jsonmfef01.obuVersionNoplateDecoded = obuVersionNoplateDecoded.toString();
                jsonmfef01.procotolType = procotolType;
                jsonmfef01.obuVersion = '49'; //合同版本
                jsonmfef01.obuNo = obuNo; //合同序列号
                jsonmfef01.startDate = startDate;
                jsonmfef01.endDate = endDate;
                jsonmfef01.status = status;
                jsonmfef01.vin = vin;
                jsonmfef01.left = left;
                //console.log(jsonmfef01);
            }
        }
    }
    return jsonmfef01;
}




export function getdf01Info() {

    var regAPPId = store.getters.regAPPId;
    var token = store.getters.token;
    var strRandom = store.getters.random;
    var strOprtId = store.getters.oprtId;
    console.log(
        '/////////////////////////////////////////////////////////////////'
    );
    console.log('getdfef01');
    const getdf01 = JSON.parse(etcdev.getdfef01info(
        regAPPId,
        token,
        strRandom,
        strOprtId
    ));
    console.log(getdf01)
    // console.log(getdf01.code)
    // console.log(getdf01.info)
    if (getdf01.code == '1' && getdf01.info == '') {
        Message({
            showClose: true,
            message: getdf01.msg,
            type: 'error',
            duration: 0,
        })
        return
    }
    var getdf01_info = getdf01.info
    var obuVersionNo = getObuVersionNo();

    ////////////////
    // var getdf01_info = 'BBA6444A563337320000000000000100002E1A120402001D00000500C2EDD7D4B4EFC5C643414D3731353030000000000000000000000000000000'
    // var obuVersionNo = '1x'
    // var getdf01_info = 'BBA641445A313033360000000004010010A806E7065200000000067C00082C054C53474643365232384D5330323933353153474D37303038474342455600000000FFFFFFFFFFFFFFFFFFFFFFFFFFFF'
    // var obuVersionNo = '48'
    ////////////////
    //1X,长三角ETC系统 CPU卡、ESAM结构v5.0
    if (obuVersionNo == '1x') {
        var dfVehicleNumber = getdf01_info.substring(0, 24);//车牌号
        const res = GBKFlagchange(dfVehicleNumber.replace(/00/g, ''));
        var encodingConvert = require('encoding');
        var buffer = new Buffer(res);
        var dfVehicleNumberDecoded = encodingConvert.convert(
            buffer,
            'UTF8',
            'GBK'
        );
        var dfVehicleColor = getdf01_info.substring(26, 28)//车牌颜色
        if (dfVehicleColor == '00') {
            dfVehicleColor = '0 - 蓝色'
        } else if (dfVehicleColor == '01') {
            dfVehicleColor = '1 - 黄色'
        } else if (dfVehicleColor == '02') {
            dfVehicleColor = '2 - 黑色'
        } else if (dfVehicleColor == '03') {
            dfVehicleColor = '3 - 白色'
        } else if (dfVehicleColor == '04') {
            dfVehicleColor = '4 - 渐变绿色'
        } else if (dfVehicleColor == '05') {
            dfVehicleColor = '5 - 黄绿双拼色'
        } else if (dfVehicleColor == '06') {
            dfVehicleColor = '6 - 蓝白渐变色'
        }

        var dfVehicleClass = getdf01_info.substring(28, 30)//车型
        if (dfVehicleClass == '01') {
            dfVehicleClass = '1 - 一型客车'
        } else if (dfVehicleClass == '02') {
            dfVehicleClass = '2 - 二型客车'
        } else if (dfVehicleClass == '03') {
            dfVehicleClass = '3 - 三型客车'
        } else if (dfVehicleClass == '04') {
            dfVehicleClass = '4 - 四型客车'
        } else if (dfVehicleClass == '05') {
            dfVehicleClass = '5 - 五型客车'
        } else if (dfVehicleClass == '06') {
            dfVehicleClass = '6 - 六型客车'
        } else if (dfVehicleClass == '11') {
            dfVehicleClass = '11 - 一型客车'
        } else if (dfVehicleClass == '12') {
            dfVehicleClass = '12 - 二型客车'
        } else if (dfVehicleClass == '13') {
            dfVehicleClass = '13 - 三型客车'
        } else if (dfVehicleClass == '14') {
            dfVehicleClass = '14 - 四型客车'
        } else if (dfVehicleClass == '15') {
            dfVehicleClass = '15 - 五型客车'
        } else if (dfVehicleClass == '16') {
            dfVehicleClass = '16 - 六型客车'
        }

        var dfVehicleType = getdf01_info.substring(30, 32)//车辆用户类型
        if (dfVehicleType == '00') {
            dfVehicleType = '0 - 普通用户'
        } else if (dfVehicleType == '01') {
            dfVehicleType = '1 -  集装箱卡车'
        } else if (dfVehicleType == '02') {
            dfVehicleType = '2 -  卧铺客车'
        } else if (dfVehicleType == '03') {
            dfVehicleType = '3 -  江苏保留使用'
        } else if (dfVehicleType == '04') {
            dfVehicleType = '4 -  安徽保留使用'
        } else if (dfVehicleType == '05') {
            dfVehicleType = '5 -  公务车用户'
        } else if (dfVehicleType == '06') {
            dfVehicleType = '6 -  江西保留'
        } else if (dfVehicleType == '08') {
            dfVehicleType = '8 -  军车用户'
        } else if (dfVehicleType == '09') {
            dfVehicleType = '9 -  警车用户'
        } else if (dfVehicleType == '10') {
            dfVehicleType = '10 -  紧急车用户'
        } else if (dfVehicleType == '12') {
            dfVehicleType = '12 -  免费用户'
        } else if (dfVehicleType == '14') {
            dfVehicleType = '14 -  军队用户'
        } else if (dfVehicleType == '15') {
            dfVehicleType = '15 -  浙江保留使用'
        } else if (dfVehicleType == '16') {
            dfVehicleType = '16 -  上海保留使用'
        }
        //车辆尺寸
        var note = parseInt(getdf01_info.substring(32, 36), 16) + 'dm x ' + parseInt(getdf01_info.substring(36, 38), 16) + 'dm x ' + parseInt(getdf01_info.substring(38, 40), 16) + 'dm';
        //车轮数
        var wheelCount = parseInt(getdf01_info.substring(40, 42), 16)
        //车轴数
        var axleCount = parseInt(getdf01_info.substring(42, 44), 16)
        //轴距
        var axleDistance = parseInt(getdf01_info.substring(44, 48), 16) + 'dm'
        //车辆载重/座位数
        var permittedWeight = parseInt(getdf01_info.substring(48, 54), 16)
        //保留
        var left = getdf01_info.substring(54, 56)
        //车辆特征描述
        var describe1x = getdf01_info.substring(56, 86).replace(/00/g, '')
        const res7 = GBKFlagchange(describe1x.replace(/00/g, ''));
        var encodingConvert = require('encoding');
        var buffer = new Buffer(res7);
        var describe1xDecoded = encodingConvert.convert(
            buffer,
            'UTF8',
            'GBK'
        );
        //车辆发动机号
        var engineNum = getdf01_info.substring(86, 118).replace(/00/g, '')
        const res8 = GBKFlagchange(engineNum.replace(/00/g, ''));
        var encodingConvert = require('encoding');
        var buffer = new Buffer(res8);
        var engineNumDecoded = encodingConvert.convert(
            buffer,
            'UTF8',
            'GBK'
        );
        //保留字段
        var left2 = getdf01_info.substring(118, 158)

        var jsondf01 = JSON.parse(
            '{"dfVehicleNumberDecoded":"test","dfVehicleColor":"test2","dfVehicleClass":"test3","dfVehicleType":"test4","note":"test5","wheelCount":"test6","axleCount":"test7","axleDistance":"test8","permittedWeight":"test9","left":"test10","describe":"test11","engineNum":"test12","left2":"test13"}'
        );
        jsondf01.dfVehicleNumberDecoded = dfVehicleNumberDecoded.toString();
        jsondf01.dfVehicleColor = dfVehicleColor;
        jsondf01.dfVehicleClass = dfVehicleClass;
        jsondf01.dfVehicleType = dfVehicleType;
        jsondf01.note = note;
        jsondf01.wheelCount = wheelCount;
        jsondf01.axleCount = axleCount;
        jsondf01.axleDistance = axleDistance;
        jsondf01.permittedWeight = permittedWeight;
        jsondf01.left = left;
        jsondf01.describe = describe1xDecoded.toString();
        jsondf01.engineNum = engineNumDecoded.toString();
        jsondf01.left2 = left2;

    }
    //48或49,（交办公路函〔2019〕1524号）交通运输部办公厅关于做好货车及专项作业车ETC发行服务有关工作的通知 20191025-J1J2标准已废除
    if (obuVersionNo == '48') {
        var dfVehicleNumber = getdf01_info.substring(0, 24);//车牌号
        const res = GBKFlagchange(dfVehicleNumber.replace(/00/g, ''));
        var encodingConvert = require('encoding');
        var buffer = new Buffer(res);
        var dfVehicleNumberDecoded = encodingConvert.convert(
            buffer,
            'UTF8',
            'GBK'
        );
        var dfVehicleColor = getdf01_info.substring(26, 28)//车牌颜色

        if (dfVehicleColor == '00') {
            dfVehicleColor = '0 - 蓝色'
        } else if (dfVehicleColor == '01') {
            dfVehicleColor = '1 - 黄色'
        } else if (dfVehicleColor == '02') {
            dfVehicleColor = '2 - 黑色'
        } else if (dfVehicleColor == '03') {
            dfVehicleColor = '3 - 白色'
        } else if (dfVehicleColor == '04') {
            dfVehicleColor = '4 - 渐变绿色'
        } else if (dfVehicleColor == '05') {
            dfVehicleColor = '5 - 黄绿双拼色'
        } else if (dfVehicleColor == '06') {
            dfVehicleColor = '6 - 蓝白渐变色'
        }
        var dfVehicleClass = getdf01_info.substring(28, 30)//车型
        if (dfVehicleClass == '01') {
            dfVehicleClass = '1 - 一型客车';
        } else if (dfVehicleClass == '02') {
            dfVehicleClass = '2 - 二型客车';
        } else if (dfVehicleClass == '03') {
            dfVehicleClass = '3 - 三型客车';
        } else if (dfVehicleClass == '04') {
            dfVehicleClass = '4 - 四型客车';
        } else if (dfVehicleClass == '05') {
            dfVehicleClass = '5 - 五型客车';
        } else if (dfVehicleClass == '06') {
            dfVehicleClass = '6 - 六型客车';
        } else if (dfVehicleClass == '0B') {
            dfVehicleClass = '0B - 一类货车';
        } else if (dfVehicleClass == '0C') {
            dfVehicleClass = '0C - 二类货车';
        } else if (dfVehicleClass == '0D') {
            dfVehicleClass = '0D - 三类货车';
        } else if (dfVehicleClass == '0E') {
            dfVehicleClass = '0E - 四类货车';
        } else if (dfVehicleClass == '0F') {
            dfVehicleClass = '0F - 五类货车';
        } else if (dfVehicleClass == '10') {
            dfVehicleClass = '10 - 六类货车';
        } else if (dfVehicleClass == '15') {
            dfVehicleClass = '15 - 一类专项作业车';
        } else if (dfVehicleClass == '16') {
            dfVehicleClass = '16 - 二类专项作业车';
        } else if (dfVehicleClass == '17') {
            dfVehicleClass = '17 - 三类专项作业车';
        } else if (dfVehicleClass == '18') {
            dfVehicleClass = '18 - 四类专项作业车';
        } else if (dfVehicleClass == '19') {
            dfVehicleClass = '19 - 五类专项作业车';
        } else if (dfVehicleClass == '1A') {
            dfVehicleClass = '1A - 六类专项作业车';
        }

        var dfVehicleType = getdf01_info.substring(30, 32)//车辆用户类型
        if (dfVehicleType == '18') {
            dfVehicleType = '0x18 - 货物专用运输(集装箱)J1';
        } else if (dfVehicleType == '1B') {
            dfVehicleType = '0x1B - 牵引车';
        } else if (dfVehicleType == '1A') {
            dfVehicleType = '0x1A - 应急救援车';
        } else if (dfVehicleType == '1C') {
            dfVehicleType = '0x1C - 货物专用运输(集装箱)及普通货运J2';
        } else if (dfVehicleType == '06') {
            dfVehicleType = '0x06 - 公务车';
        } else if (dfVehicleType == '00') {
            dfVehicleType = '0 - 普通用户';
        }

        //车辆尺寸
        var note = parseInt(getdf01_info.substring(32, 36), 16) + 'mm x ' + parseInt(getdf01_info.substring(36, 40), 16) + 'mm x ' + parseInt(getdf01_info.substring(40, 44), 16) + 'mm';
        //console.log(getdf01_info.substring(32, 44))
        //额定载质量
        var permittedWeight = parseInt(getdf01_info.substring(44, 50), 16) + 'kg'
        //整备质量
        var maintenaceMass = parseInt(getdf01_info.substring(50, 56), 16) + 'kg'
        //总质量
        var viTotalMass = parseInt(getdf01_info.substring(56, 62), 16) + 'kg'
        //载人数
        var approvedAccount = parseInt(getdf01_info.substring(62, 64), 16)
        //vin
        var vin = getdf01_info.substring(64, 98)
        const res5 = GBKFlagchange(vin.replace(/00/g, ''));
        var encodingConvert = require('encoding');
        var buffer = new Buffer(res5);
        var vinDecoded = encodingConvert.convert(
            buffer,
            'UTF8',
            'GBK'
        );
        //车辆特征描述
        var describe = getdf01_info.substring(98, 130).replace(/00/g, '')
        const res6 = GBKFlagchange(describe.replace(/00/g, ''));
        var encodingConvert = require('encoding');
        var buffer = new Buffer(res6);
        var describe48Decoded = encodingConvert.convert(
            buffer,
            'UTF8',
            'GBK'
        );
        //保留字段
        var left2 = getdf01_info.substring(130, 158)

        var jsondf01 = JSON.parse(
            '{"dfVehicleNumberDecoded":"test","dfVehicleColor":"test2","dfVehicleClass":"test3","dfVehicleType":"test4","note":"test5","permittedWeight":"test6","maintenaceMass":"test7","viTotalMass":"test8","approvedAccount":"test9","vin":"test10","describe":"test11","left2":"test12"}'
        );
        jsondf01.dfVehicleNumberDecoded = dfVehicleNumberDecoded.toString();
        jsondf01.dfVehicleColor = dfVehicleColor;
        jsondf01.dfVehicleClass = dfVehicleClass;
        jsondf01.dfVehicleType = dfVehicleType;
        jsondf01.note = note;
        jsondf01.permittedWeight = permittedWeight;
        jsondf01.maintenaceMass = maintenaceMass;
        jsondf01.viTotalMass = viTotalMass;
        jsondf01.approvedAccount = approvedAccount;
        jsondf01.vin = vinDecoded.toString();
        jsondf01.describe = describe48Decoded.toString();
        jsondf01.left2 = left2;
    }
    if (obuVersionNo == '4x') {
        //4X客车，附录4 全国高速公路电子不停车收费联网用户卡、ESAM文件结构与数据定义20150123
        if (store.getters.searchCarInfo.vehicleCategory == '1') {
            var dfVehicleNumber = getdf01_info.substring(0, 24);//车牌号
            const res = GBKFlagchange(dfVehicleNumber.replace(/00/g, ''));
            var encodingConvert = require('encoding');
            var buffer = new Buffer(res);
            var dfVehicleNumberDecoded = encodingConvert.convert(
                buffer,
                'UTF8',
                'GBK'
            );
            var dfVehicleColor = getdf01_info.substring(26, 28)//车牌颜色
            if (dfVehicleColor == '00') {
                dfVehicleColor = '00 - 蓝色'
            } else if (dfVehicleColor == '01') {
                dfVehicleColor = '1 - 黄色'
            } else if (dfVehicleColor == '02') {
                dfVehicleColor = '2 - 黑色'
            } else if (dfVehicleColor == '03') {
                dfVehicleColor = '3 - 白色'
            } else if (dfVehicleColor == '04') {
                dfVehicleColor = '4 - 渐变绿色'
            } else if (dfVehicleColor == '05') {
                dfVehicleColor = '5 - 黄绿双拼色'
            } else if (dfVehicleColor == '06') {
                dfVehicleColor = '6 - 蓝白渐变色'
            }

            var dfVehicleClass = getdf01_info.substring(28, 30)//车型
            if (dfVehicleClass == '01') {
                dfVehicleClass = '1 - 一型客车'
            } else if (dfVehicleClass == '02') {
                dfVehicleClass = '2 - 二型客车'
            } else if (dfVehicleClass == '03') {
                dfVehicleClass = '3 - 三型客车'
            } else if (dfVehicleClass == '04') {
                dfVehicleClass = '4 - 四型客车'
            } else if (dfVehicleClass == '05') {
                dfVehicleClass = '5 - 五型客车'
            } else if (dfVehicleClass == '06') {
                dfVehicleClass = '6 - 六型客车'
            } else if (dfVehicleClass == '11') {
                dfVehicleClass = '11 - 一型客车'
            } else if (dfVehicleClass == '12') {
                dfVehicleClass = '12 - 二型客车'
            } else if (dfVehicleClass == '13') {
                dfVehicleClass = '13 - 三型客车'
            } else if (dfVehicleClass == '14') {
                dfVehicleClass = '14 - 四型客车'
            } else if (dfVehicleClass == '15') {
                dfVehicleClass = '15 - 五型客车'
            } else if (dfVehicleClass == '16') {
                dfVehicleClass = '16 - 六型客车'
            }

            var dfVehicleType = getdf01_info.substring(30, 32)//车辆用户类型
            if (dfVehicleType == '00') {
                dfVehicleType = '0 - 普通用户'
            } else if (dfVehicleType == '01') {
                dfVehicleType = '1 -  集装箱卡车'
            } else if (dfVehicleType == '02') {
                dfVehicleType = '2 -  卧铺客车'
            } else if (dfVehicleType == '03') {
                dfVehicleType = '3 -  江苏保留使用'
            } else if (dfVehicleType == '04') {
                dfVehicleType = '4 -  安徽保留使用'
            } else if (dfVehicleType == '05') {
                dfVehicleType = '5 -  公务车用户'
            } else if (dfVehicleType == '06') {
                dfVehicleType = '6 -  江西保留'
            } else if (dfVehicleType == '08') {
                dfVehicleType = '8 -  军车用户'
            } else if (dfVehicleType == '09') {
                dfVehicleType = '9 -  警车用户'
            } else if (dfVehicleType == '10') {
                dfVehicleType = '10 -  紧急车用户'
            } else if (dfVehicleType == '12') {
                dfVehicleType = '12 -  免费用户'
            } else if (dfVehicleType == '14') {
                dfVehicleType = '14 -  军队用户'
            } else if (dfVehicleType == '15') {
                dfVehicleType = '15 -  浙江保留使用'
            } else if (dfVehicleType == '16') {
                dfVehicleType = '16 -  上海保留使用'
            }
            //车辆尺寸
            var note = parseInt(getdf01_info.substring(32, 36), 16) + 'dm x ' + parseInt(getdf01_info.substring(36, 38), 16) + 'dm x ' + parseInt(getdf01_info.substring(38, 40), 16) + 'dm';
            //车轮数
            var wheelCount = parseInt(getdf01_info.substring(40, 42), 16)
            //车轴数
            var axleCount = parseInt(getdf01_info.substring(42, 44), 16)
            //轴距
            var axleDistance = parseInt(getdf01_info.substring(44, 48), 16) + 'dm'
            //车辆载重/座位数
            var permittedWeight = parseInt(getdf01_info.substring(48, 54), 16)
            //车辆特征描述
            var describe1x = getdf01_info.substring(56, 86).replace(/00/g, '')
            const res7 = GBKFlagchange(describe1x.replace(/00/g, ''));
            var encodingConvert = require('encoding');
            var buffer = new Buffer(res7);
            var describe1xDecoded = encodingConvert.convert(
                buffer,
                'UTF8',
                'GBK'
            );
            //车辆发动机号
            var engineNum = getdf01_info.substring(86, 118).replace(/00/g, '')
            const res8 = GBKFlagchange(engineNum.replace(/00/g, ''));
            var encodingConvert = require('encoding');
            var buffer = new Buffer(res8);
            var engineNumDecoded = encodingConvert.convert(
                buffer,
                'UTF8',
                'GBK'
            );
            //保留字段
            var left2 = getdf01_info.substring(118, 158)

            var jsondf01 = JSON.parse(
                '{"dfVehicleNumberDecoded":"test","dfVehicleColor":"test2","dfVehicleClass":"test3","dfVehicleType":"test4","note":"test5","wheelCount":"test6","axleCount":"test7","axleDistance":"test8","permittedWeight":"test9","describe":"test11","engineNum":"test12","left2":"test13"}'
            );
            jsondf01.dfVehicleNumberDecoded = dfVehicleNumberDecoded.toString();
            jsondf01.dfVehicleColor = dfVehicleColor;
            jsondf01.dfVehicleClass = dfVehicleClass;
            jsondf01.dfVehicleType = dfVehicleType;
            jsondf01.note = note;
            jsondf01.wheelCount = wheelCount;
            jsondf01.axleCount = axleCount;
            jsondf01.axleDistance = axleDistance;
            jsondf01.permittedWeight = permittedWeight;
            jsondf01.describe = describe1xDecoded.toString();
            jsondf01.engineNum = engineNumDecoded.toString();
            jsondf01.left2 = left2;
        }
        //4x货车,（交办公路函〔2019〕1524号）交通运输部办公厅关于做好货车及专项作业车ETC发行服务有关工作的通知 20191025-J1J2标准已废除
        else {
            var dfVehicleNumber = getdf01_info.substring(0, 24);//车牌号
            const res = GBKFlagchange(dfVehicleNumber.replace(/00/g, ''));
            var encodingConvert = require('encoding');
            var buffer = new Buffer(res);
            var dfVehicleNumberDecoded = encodingConvert.convert(
                buffer,
                'UTF8',
                'GBK'
            );
            var dfVehicleColor = getdf01_info.substring(26, 28)//车牌颜色
            if (dfVehicleColor == '00') {
                dfVehicleColor = '00 - 蓝色'
            } else if (dfVehicleColor == '01') {
                dfVehicleColor = '1 - 黄色'
            } else if (dfVehicleColor == '02') {
                dfVehicleColor = '2 - 黑色'
            } else if (dfVehicleColor == '03') {
                dfVehicleColor = '3 - 白色'
            } else if (dfVehicleColor == '04') {
                dfVehicleColor = '4 - 渐变绿色'
            } else if (dfVehicleColor == '05') {
                dfVehicleColor = '5 - 黄绿双拼色'
            } else if (dfVehicleColor == '06') {
                dfVehicleColor = '6 - 蓝白渐变色'
            }

            var dfVehicleClass = getdf01_info.substring(28, 30)//车型
            if (dfVehicleClass == '01') {
                dfVehicleClass = '01 - 一类客车';
            } else if (dfVehicleClass == '02') {
                dfVehicleClass = '02 - 二类客车';
            } else if (dfVehicleClass == '03') {
                dfVehicleClass = '03 - 三类客车';
            } else if (dfVehicleClass == '04') {
                dfVehicleClass = '04 - 四类客车';
            } else if (dfVehicleClass == '05') {
                dfVehicleClass = '05 - 五类客车';
            } else if (dfVehicleClass == '06') {
                dfVehicleClass = '06 - 六类客车';
            } else if (dfVehicleClass == '0B') {
                dfVehicleClass = '0B - 一类货车';
            } else if (dfVehicleClass == '0C') {
                dfVehicleClass = '0C - 二类货车';
            } else if (dfVehicleClass == '0D') {
                dfVehicleClass = '0D - 三类货车';
            } else if (dfVehicleClass == '0E') {
                dfVehicleClass = '0E - 四类货车';
            } else if (dfVehicleClass == '0F') {
                dfVehicleClass = '0F - 五类货车';
            } else if (dfVehicleClass == '10') {
                dfVehicleClass = '10 - 六类货车';
            } else if (dfVehicleClass == '15') {
                dfVehicleClass = '15 - 一类专项作业车';
            } else if (dfVehicleClass == '16') {
                dfVehicleClass = '16 - 二类专项作业车';
            } else if (dfVehicleClass == '17') {
                dfVehicleClass = '17 - 三类专项作业车';
            } else if (dfVehicleClass == '18') {
                dfVehicleClass = '18 - 四类专项作业车';
            } else if (dfVehicleClass == '19') {
                dfVehicleClass = '19 - 五类专项作业车';
            } else if (dfVehicleClass == '1A') {
                dfVehicleClass = '1A - 六类专项作业车';
            }

            var dfVehicleType = getdf01_info.substring(30, 32)//车辆用户类型
            if (dfVehicleType == '18') {
                dfVehicleType = '0x18 - 货物专用运输(集装箱)J1';
            } else if (dfVehicleType == '1B') {
                dfVehicleType = '0x1B - 牵引车';
            } else if (dfVehicleType == '1A') {
                dfVehicleType = '0x1A - 应急救援车';
            } else if (dfVehicleType == '1C') {
                dfVehicleType = '0x1C - 货物专用运输(集装箱)及普通货运J2';
            } else if (dfVehicleType == '06') {
                dfVehicleType = '0x06 - 公务车';
            } else if (dfVehicleType == '00') {
                dfVehicleType = '0 - 普通用户';
            }

            //车辆尺寸
            var note = parseInt(getdf01_info.substring(32, 36), 16) + 'mm x ' + parseInt(getdf01_info.substring(36, 40), 16) + 'mm x ' + parseInt(getdf01_info.substring(40, 44), 16) + 'mm';
            //console.log(getdf01_info.substring(32, 44))
            //额定载质量
            var permittedWeight = parseInt(getdf01_info.substring(44, 50), 16) + 'kg'
            //整备质量
            var maintenaceMass = parseInt(getdf01_info.substring(50, 56), 16) + 'kg'
            //总质量
            var viTotalMass = parseInt(getdf01_info.substring(56, 62), 16) + 'kg'
            //载人数
            var approvedAccount = parseInt(getdf01_info.substring(62, 64), 16)
            //vin
            var vin = getdf01_info.substring(64, 98)
            const res5 = GBKFlagchange(vin.replace(/00/g, ''));
            var encodingConvert = require('encoding');
            var buffer = new Buffer(res5);
            var vinDecoded = encodingConvert.convert(
                buffer,
                'UTF8',
                'GBK'
            );
            //车辆特征描述
            var describe = getdf01_info.substring(98, 130).replace(/00/g, '')
            const res6 = GBKFlagchange(describe.replace(/00/g, ''));
            var encodingConvert = require('encoding');
            var buffer = new Buffer(res6);
            var describe4xDecoded = encodingConvert.convert(
                buffer,
                'UTF8',
                'GBK'
            );
            //保留字段
            var left2 = getdf01_info.substring(130, 158)

            var jsondf01 = JSON.parse(
                '{"dfVehicleNumberDecoded":"test","dfVehicleColor":"test2","dfVehicleClass":"test3","dfVehicleType":"test4","note":"test5","permittedWeight":"test6","maintenaceMass":"test7","viTotalMass":"test8","approvedAccount":"test9","vin":"test10","describe":"test11","left2":"test12"}'
            );
            jsondf01.dfVehicleNumberDecoded = dfVehicleNumberDecoded.toString();
            jsondf01.dfVehicleColor = dfVehicleColor;
            jsondf01.dfVehicleClass = dfVehicleClass;
            jsondf01.dfVehicleType = dfVehicleType;
            jsondf01.note = note;
            jsondf01.permittedWeight = permittedWeight;
            jsondf01.maintenaceMass = maintenaceMass;
            jsondf01.viTotalMass = viTotalMass;
            jsondf01.approvedAccount = approvedAccount;
            jsondf01.vin = vinDecoded.toString();
            jsondf01.describe = describe4xDecoded.toString();
            jsondf01.left2 = left2;
        }
    }
    return jsondf01
}



export function purchaserecord() {
    var records = [];
    var jsonRecords = [];
    const purchaserecords = JSON.parse(etcdev.getpurchaserecords());
    console.log(
        '/////////////////////////////////////////////////////////////////'
    );
    console.log('purchaserecords');
    //console.log(parseInt((purchaserecords.info.length + 1) / 47));
    console.log(purchaserecords.info);
    for (let i = 0; i < purchaserecords.info.length + 1; i = i + 47) {
        records.push(purchaserecords.info.slice(i, i + 46));
    }
    //console.log(this.records); //50条记录
    for (let j = 0; j < records.length; j++) {
        var transactionNo = records[j].substring(0, 4); //联机交易序号
        var overdraftLimit = records[j].substring(4, 10); //透支限额
        var transactionAmount = records[j].substring(10, 18); //交易金额
        var transactionType = records[j].substring(18, 20); //交易类型标识
        if (transactionType == '01') {
            transactionType = '01 - ED圈存';
        } else if (transactionType == '02') {
            transactionType = '02 - EP圈存';
        } else if (transactionType == '03') {
            transactionType = '03 - 圈提';
        } else if (transactionType == '04') {
            transactionType = '04 - ED取款';
        } else if (transactionType == '05') {
            transactionType = '05 - ED消费';
        } else if (transactionType == '06') {
            transactionType = '06 - EP消费';
        } else if (transactionType == '07') {
            transactionType = '07 - ED修改透支限额';
        } else if (transactionType == '08') {
            transactionType = '08 - 信用消费';
        } else if (transactionType == '09') {
            transactionType = '09 - 路网消费';
        }
        var terminalNo = records[j].substring(20, 32); //终端机编号
        var transactionDate =
            records[j].substring(32, 36) +
            '年' +
            records[j].substring(36, 38) +
            '月' +
            records[j].substring(38, 40) +
            '日';
        var transactionTime =
            records[j].substring(40, 42) +
            '时' +
            records[j].substring(42, 44) +
            '分' +
            records[j].substring(44, 46) +
            '秒';
        var json = JSON.parse(
            '{"transactionNo":"test","overdraftLimit":"test2","transactionAmount":"test3","transactionType":"test4","terminalNo":"test5","transactionDate":"test6","transactionTime":"test7"}'
        );
        json.transactionNo = transactionNo;
        json.overdraftLimit = overdraftLimit;
        json.transactionAmount = transactionAmount;
        json.transactionType = transactionType;
        json.terminalNo = terminalNo;
        json.transactionDate = transactionDate;
        json.transactionTime = transactionTime;
        jsonRecords.push(json);
    }
    //console.log(jsonRecords);
    return jsonRecords;
}