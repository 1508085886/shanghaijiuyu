/**
 * @author lijun
 * @description 动态库交互
 */
import Vue from 'vue'
import { Message, MessageBox } from 'element-ui';
import ElementUI from 'element-ui'
import store from '@/store';
import { getRandom } from '@/methods/account';
import { isEmptyObj } from '@/utils/utils.js'; // 对象判空
import constants from '@/globeProperty/constants' // 常量
// import methods from '@/globeProperty/methods' // 全局方法
Vue.use(constants)// 常量
// Vue.use(methods)// 全局方法
const regAPPId = store.getters.regAPPId;
const token = store.getters.token;
const strOprtId = store.getters.oprtId;
// const strRandom = store.getters.random;

/**
 * 全局loading 
 * @param {*} txt 
 * @returns 
 */
const eLoading = (txt) => {
  return ElementUI.Loading.service({
    lock: true,
    text: txt || 'Loading',
    spinner: 'el-icon-loading',
    background: 'rgba(0, 0, 0, 0.7)'
  })
};
/**
 * @description 获取操作员卡号
 */
export const getOprId = () => {
  return JSON.parse(etcdev.getcpuid()).operCardID;
};

/**
 * @description 从动态库获取操作员卡号
 */
export const getOperCardId = () => {
  return new Promise((resolve, reject) => {
    try {
      resolve('012345678912');
    } catch (e) {
      Message.error(err);
      reject(e);
    }
  });
};
/**
 * @description 写本地文件 运行目录下/log/web+8位时间+.log
 */
export const writeLog = (strlog) => {
  let res = JSON.parse(etcdev.writelog(strlog));
  return res;
};


/**
 * @description 按落地文件名称获取文件base64字符串，一次获取一个文件
 */
export const getLog = () => {
  return JSON.parse(etcdev.getlog());
};

/**
 * @description 2.13	读取卡片内50笔交易信息
 */
export const get50Records = async () => {
  // let res = JSON.parse(etcdev.getpurchaserecords());
  let res = {
    code: '0',
    msg: '成功',
    info: [
      {
        id: '1',
        price: '1',
        type: '1',
      }, {
        id: '2',
        price: '2',
        type: '2',
      }
    ]
  };
  writeLog('2.13	读取卡片内50笔交易信息，返回值' + JSON.stringify(res));
  return res;
};

/**
 * @description 从动态库读沪通卡
 */
export const getCpuId = () => {
  // return JSON.parse(etcdev.getcpuid());
  let res = JSON.parse(etcdev.getcpuid());
  if (res.issueversion === 'FF') {
    res.issueversion = '10';
  }
  if (res.issueversion.startsWith('0')) {
    res.issueversion = '10';
  }
  return res;
};
/**
 * @description 从动态库读OBU号
 */
export const getObuId = () => {
  // return JSON.parse(etcdev.getobuid());
  let res = JSON.parse(etcdev.getobuid());
  if (res.issueversion === 'FF') {
    res.issueversion = '10';
  }
  if (res.issueversion.startsWith('0')) {
    res.issueversion = '10';
  }
  return res;
};
/**
 * @description 从动态库读沪通卡，当版本是FF时，改为10
 */
export const getCpuIdFF = () => {
  let res = JSON.parse(etcdev.getcpuid());
  if (res.issueversion === 'FF') {
    res.issueversion = '10';
  }
  if (res.issueversion.startsWith('0')) {
    res.issueversion = '10';
  }
  return res;
};

/**
 * @description 动态库2.19	读取沪通卡中所有内容
 */
export const getPurchaseRecords = async () => {
  // return JSON.parse(etcdev.getcardinfoall());
  return {
    code: '0',
    msg: '成功',
    price: '10000',
    cardId: '0131002714297278',
    reloadSeq: '1111',
    debitSeq: '2222',
  };
};

/**
 * @description PAD端读沪通卡，当版本是FF时，改为10
 */
export const getCpuIdFFAd = async () => {
  /*PAD端兼容代码*/
  return new Promise(function (resolve, reject) {
    // 读卡回调
    let onGetCpuId = (getDeviceIdBean) => {
      let padCardObj = null;
      padCardObj = {};
      padCardObj.code = getDeviceIdBean.code;
      padCardObj.msg = getDeviceIdBean.msg;
      padCardObj.cardid = getDeviceIdBean.id;
      padCardObj.issueversion = getDeviceIdBean.version;
      padCardObj.expirydate = getDeviceIdBean.expiredDate;
      resolve(padCardObj);
    };
    window.onGetCpuId = onGetCpuId;
    AndroidBle.getCpuId('onGetCpuId');
  });
};

/**
 * @description 从动态库读OBU号，当版本是FF时，改为10
 */
export const getObuIdFF = () => {
  let res = JSON.parse(etcdev.getobuid());
  if (res.issueversion === 'FF') {
    res.issueversion = '10';
  }
  if (res.issueversion.startsWith('0')) {
    res.issueversion = '10';
  }
  return res;
};
/**
 * @description 动态库卡二发
 * @param { object } resCard
 * @param { object } resFile
 */
export const issueCard = async (resCard, resFile) => {
  if (Vue.prototype.$isPad) {
    /*PAD端兼容代码*/
    return new Promise(function (resolve, reject) {
      // 读卡回调
      let onIssueCard = (resultBean) => {
        // console.log('onIssueCard-resultBean', resultBean)
        resolve(resultBean);
      };
      window.onIssueCard = onIssueCard;
      // console.log('window.onIssueCard', window.onIssueCard)
      AndroidBle.issueCard('onIssueCard',
        resFile.fileContent15.fileContent,
        resFile.fileContent15.startIndex,
        resFile.fileContent15.length,
        resFile.fileContent16.fileContent,
        resFile.fileContent16.startIndex,
        resFile.fileContent16.length);
    });
  } else {
    let rdm = await getRandom();
    if (rdm) {
      console.log('card,resFile:', resFile);
      // return {
      //   code: '0',
      //   msg: '成功'
      // }
      return JSON.parse(
        etcdev.issuecard(
          resCard.cardid,
          resCard.issueversion === '00' ? '10' : resCard.issueversion,
          resFile.fileContent16.fileContent,
          resFile.fileContent16.startIndex,
          resFile.fileContent16.length,
          resFile.fileContent15.fileContent,
          resFile.fileContent15.startIndex,
          resFile.fileContent15.length,
          // regAPPId,
          'network_customer_system',
          store.getters.token,
          // 'token',
          // strRandom
          rdm,
          store.getters.oprtId
        )
      );
    }
  }
};
/**
 * @description 动态库OBU二发
 * @param { object } resOBU
 * @param { object } resFile
 */
export const issueOBU = async (resOBU, resFile) => {
  let rdm = await getRandom();
  if (rdm) {
    console.log('obu,resFile:', resFile);
    // return {
    //   code: '0',
    //   msg: '成功'
    // }
    return JSON.parse(
      etcdev.issueobu(
        resOBU.obuid,
        resFile.fileContentMFEF01.fileContent,
        resFile.fileContentMFEF01.startIndex,
        resFile.fileContentMFEF01.length,
        resFile.fileContentDFEF01.fileContent,
        resFile.fileContentDFEF01.startIndex,
        resFile.fileContentDFEF01.length,
        resOBU.issueversion,
        // regAPPId,
        'network_customer_system',
        store.getters.token,
        // 'token',
        // strRandom
        rdm,
        store.getters.oprtId
      )
    );
  }
};


/**
 * @description 2.16	储值卡充值
 */
export const recharge = async (rechargeObj) => {
  let strRandom = await getRandom();
  // let res = JSON.parse(etcdev.recharge(
  //   rechargeObj.strCardID,
  //   rechargeObj.dPrice,
  //   regAPPId,
  //   token,
  //   strRandom,
  //   strOprtId,
  //   rechargeObj.strWorkId,
  //   rechargeObj.strETCUserId,
  // ));
  let res = {
    code: '0',
    msg: '成功',
    DBDateTime: '20210707',
    EWalletTxid: '11111',
    POSID: '2222',
    TacData: '3333',
    BeforeBalance: 10000,
    AfterBalance: 20000,
    Session: 3,
  };
  return res;
};


/**
 * 读卡
 * @param {*} failObj 读卡失败相关配置
 * @param {*} recall 失败后重复调用的
 * @param {*} loading 触发读卡方法的元素（按钮）的loading状态
 * @param {*} cardInfo 当前卡信息,不需要卡信息传false
 * @param {*} successFunc 读卡成功的操作
 * @returns getCpuIdFF的返回值
 */
export const readCard = async (
  loading,
  cardInfo,
  successFunc = () => { },
  recall = readCard,
  failObj =
    {
      msg: '读卡失败。',
      confirmButtonText: '确认',
      cancelButtonText: '取消',
      distinguishCancelAndClose: false,
      cancelCatch: () => { }
    },
) => {
  loading = true;
  /*PAD端兼容代码*/
  let res = null;
  if (Vue.prototype.$isPad) {
    res = await getCpuIdFFAd();
  } else {
    res = getCpuIdFF();
  }
  if (res) {
    // console.log('readCard999:' + res);
    if (res.code != '0') {
      // 读卡失败
      let msg = failObj.msg;
      MessageBox.confirm(res.msg + '<br>' + msg, '提示', {
        distinguishCancelAndClose: failObj.distinguishCancelAndClose,
        dangerouslyUseHTMLString: true,
        confirmButtonText: failObj.confirmButtonText,
        cancelButtonText: failObj.cancelButtonText,
        type: 'warning',
      })
        .then(() => {
          recall();
        })
        .catch((action) => {
          if (action === 'cancel') {
            failObj.cancelCatch();
          } else if (action === 'close') {
            failObj.closeCatch && failObj.closeCatch();
          }
          loading = false;
        });
      return false;
    } else if (res.code === '0') {
      // 读卡成功
      loading = false;
      // console.log('readCard:' + res0.cardid);
      let notNeedCardInfo = (cardInfo === false);
      if (notNeedCardInfo) {// 不需要判断当前卡信息
        const successRes = successFunc(res);
        return successRes ? res : successRes;
      } else {
        const cardid = res.cardid;
        if (!isEmptyObj(cardInfo)) {
          let cardID = cardInfo.cardID;
          if (cardid !== cardID) {
            console.log('cardID', cardID)
            let msg = failObj.cardIdNotSameMsg || '读取卡号与当前卡号不一致';
            MessageBox.alert(msg, '提示', {
              confirmButtonText: '确定',
              type: 'warning',
            });
            return false;
          } else {
            const successRes = successFunc(res);
            return successRes ? res : successRes;
          }
        } else {
          Message.error('卡信息不存在');
          return false;
        }
      }

    }
  } else {
    MessageBox.confirm(
      '获取读卡接口失败，是否重试？提示信息：' + res,
      '提示',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }
    )
      .then(() => {
        recall();
      })
      .catch(() => {
        loading = false;
      });
    return false;
  }

}

/**
 * 读签
 * @param {*} failObj 读签失败相关配置
 * @param {*} recall 失败后重复调用的
 * @param {*} loading 触发读签方法的元素（按钮）的loading状态
 * @param {*} obuInfo 当前标签信息,不需要卡信息传false
 * @param {*} successFunc 读签成功的操作
 * @returns getObuIdFF的返回值
 */
export const readOBU = (
  loading,
  obuInfo,
  successFunc = () => { },
  recall = readOBU,
  failObj =
    {
      msg: '读签失败。',
      confirmButtonText: '确认',
      cancelButtonText: '取消',
      distinguishCancelAndClose: false,
      cancelCatch: () => { }
    },
) => {
  loading = true;
  const res = getObuIdFF();
  if (res) {
    if (res.code != '0') {
      // 读卡失败
      let msg = failObj.msg;
      MessageBox.confirm(res.msg + '<br>' + msg, '提示', {
        distinguishCancelAndClose: failObj.distinguishCancelAndClose,
        dangerouslyUseHTMLString: true,
        confirmButtonText: failObj.confirmButtonText,
        cancelButtonText: failObj.cancelButtonText,
        type: 'warning',
      })
        .then(() => {
          recall();
        })
        .catch((action) => {
          if (action === 'cancel') {
            failObj.cancelCatch();
          } else if (action === 'close') {
            failObj.closeCatch && failObj.closeCatch();
          }
          loading = false;
        });
      return false;
    } else if (res.code === '0') {
      // 读卡成功
      loading = false;
      let notNeedObuInfo = (obuInfo === false);
      if (notNeedObuInfo) {// 不需要判断当前卡信息
        const successRes = successFunc(res);
        return successRes ? res : successRes;
      } else {
        const obuid = res.obuid;
        if (!isEmptyObj(obuInfo)) {
          let obuID = obuInfo.obuID;
          if (obuid !== obuID) {
            console.log('obuID', obuID)
            let msg = failObj.cardIdNotSameMsg || '读取标签号与当前标签号不一致';
            MessageBox.alert(msg, '提示', {
              confirmButtonText: '确定',
              type: 'warning',
            });
            return false;
          } else {
            const successRes = successFunc(res);
            return successRes ? res : successRes;
          }
        } else {
          Message.error('标签信息不存在');
          return false;
        }
      }

    }
  } else {
    MessageBox.confirm(
      '获取读签接口失败，是否重试？提示信息：' + res,
      '提示',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }
    )
      .then(() => {
        recall();
      })
      .catch(() => {
        loading = false;
      });
    return false;
  }

}


/**
 * 获取卡余额及卡号
 * @param {*} loading 触发读卡方法的元素（按钮）的loading状态
 * @param {*} failObj 读卡失败相关配置 必传
 * @param {*} successObj 读卡成功相关配置 必传
 * @returns getCpuIdFF的返回值
 */
//  failObj = {
//   showMsg: true,
//   msg: '读卡失败。',
//   confirmButtonText: '确认',
//   cancelButtonText: '取消',
//   distinguishCancelAndClose: false,
//   cancelCatch: () => { },
//   recall: readCard,
// },
// successObj = {
//   notNeedCardInfo: true,
//   cardInfo: null,
//   cardIdNotSameMsg: '',
//   successFunc: () => { },
// }
export const readCardAndGetAmount = async (
  needWholeLoading,
  failObj,
  successObj,
) => {
  let loading = null;
  if (needWholeLoading) {
    loading = eLoading();
  }
  let res = null;
  if (Vue.prototype.$isPad) {
    /*PAD端兼容代码*/
  } else {
    res = await getPurchaseRecords();
    writeLog('调用框架2.19读取沪通卡中所有内容，返回值：' + JSON.stringify(res));
  }
  if (res) {
    if (res.code != '0') {
      // 读卡失败
      // loading = false;
      needWholeLoading && loading.close();
      if (failObj.showMsg) {
        let msg = failObj.msg;
        writeLog(msg);
        MessageBox.confirm(res.msg + '<br>' + msg, '提示', {
          distinguishCancelAndClose: failObj.distinguishCancelAndClose,
          dangerouslyUseHTMLString: true,
          confirmButtonText: failObj.confirmButtonText,
          cancelButtonText: failObj.cancelButtonText,
          closeOnClickModal: false,
          closeOnPressEscape: false,
          type: 'warning',
        })
          .then(() => {
            // recall();
          })
          .catch((action) => {
            if (action === 'cancel') {
              failObj.cancelCatch();
            } else if (action === 'close') {
              failObj.closeCatch && failObj.closeCatch();
            }
          });
      }
      return false;
    } else if (res.code === '0') {
      // 读卡成功
      // loading = false;
      needWholeLoading && loading.close();
      if (successObj.notNeedCardInfo) {// 不需要判断当前卡信息
        const successRes = successObj.successFunc(res);
        writeLog('不需要判断当前卡信息:' + JSON.stringify(successRes));
        return successRes ? successRes : res;
      } else {
        //const cardid = '0131002714297278';
        const cardid = res.cardId;
        if (!isEmptyObj(successObj.cardInfo)) {
          let cardID = successObj.cardInfo.cardID;
          if (cardid !== cardID) {
            let msg = successObj.cardIdNotSameMsg || '读取卡号与当前卡号不一致';
            writeLog(msg);
            if (!successObj.cardIdNotSameCancelMsg) {
              MessageBox.alert(msg, '提示', {
                confirmButtonText: '确定',
                closeOnClickModal: false,
                closeOnPressEscape: false,
                type: 'warning',
              });
              return false;
            } else {
              MessageBox.alert(successObj.cardIdNotSameCancelMsg, '提示', {
                confirmButtonText: '确定',
                closeOnClickModal: false,
                closeOnPressEscape: false,
                type: 'warning',
              }).then(() => {
                successObj.cardIdNotSameCancelFunc();
              })
              return false;
            }
          } else {
            successObj.successFunc(res);
            // return successRes ? res : successRes;
            return res;
          }
        } else {
          Message.error('卡信息不存在');
          return false;
        }
      }

    }
  } else {
    if (failObj.showMsg) {
      MessageBox.confirm(
        '获取读卡接口失败，是否重试？提示信息：' + res,
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }
      )
        .then(() => {
          // recall();
        })
        .catch(() => {
          // loading = false;
          needWholeLoading && loading.close();
        });
      return false;
    }
  }

}

/**
 * @description 2.19	读取沪卡通中所有内容
 */
export const getcardinfoall = async () => {
  return JSON.parse(etcdev.getcardinfoall());
  // let res = {
  //   code: '0',
  //   msg: '成功',
  //   '0015Info': '20210707',
  //   '0016Info': '11111',
  //   price: '10.00',
  //   reloadSeq: '0',
  //   debitSeq: '0',
  //   cardId: '123456',
  // };
  // return res;
};

/**
 * @description 2.17 	储值卡扣款
 */
export const deductmoney = async (readInfoObj) => {
  // return JSON.parse(etcdev.deductmoney());
  let res = {
    code: '0',
    msg: '成功',
    DBDateTime: '',
    EWalletTxid: '',
    POSID: '',
    TacData: '',
    BeforeBalance: '200',
    AfterBalance: '100',
    Session: '',
  };
  return res;
};