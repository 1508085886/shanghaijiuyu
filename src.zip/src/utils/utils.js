/**
 * @description 工具方法
 */
import router from '@/router';
/**
* @description 打开新窗口
* @param { String } path
* @param { object } query: { param1: xxx, param2: yyy }
*/
export const openWindow = (pageHrefStr, query) => {
    if (router.resolve({}).href.indexOf(pageHrefStr) > 0) {//当前页，刷新
        router.go(0)
    } else {
        let timestamp = new Date().getTime();
        query.dif = timestamp + pageHrefStr.replace('\/', '-');// 新窗口唯一标识 '1572173440709/licenseverify'
        let { href } = router.resolve({
            // path: '/' + pageHrefStr,
            path: pageHrefStr,
            query: query,
        });
        window.open(href, pageHrefStr);
    }
};

/**
* @description 根据QueryString参数名称获取值 截取url传参
* @param { String } name
* @param { String } url
*/
export const getQueryStringByName = (name, url) => {
    if (url == 'undefined' || typeof url === 'undefined') {
        url = location.search;
    }
    var result = url.match(new RegExp("[\?\&]" + name + "=([^\&]+)", "i"));

    if (result == null || result.length < 1) {
        return "";
    }
    return result[1];
};

/**
 * 字符串打码
 * @param {*} str 需要打码的字符串
 * @param {*} num 需要打码的位数，从末尾开始打码
 * @returns 末尾打码的字符串
 */
export const strPadEnd = (str, num) => {
    let partStr = str.slice(0, -num);
    let newStr = partStr.padEnd(str.length, '*');
    return newStr;
};


/**
 * @description 判断是否为空对象
 * @param {Object} obj 
 * @returns { Boolean }
 */
export const isEmptyObj = (obj) => {
    return !(obj && Object.keys(obj).length >= 1)
}
/**
* @description 金额分转换元，保留2位小数
*/
export const getFormatAmount = (value) => {
    if (value || value === 0) {
        return (value / 100).toFixed(2);
    } else {
        return ''
    }
};
/**
* @description 字符串金额元转换分
*/
export const getFormatAmountYuan2Fen = (str) => {
    var m = 0,
        s1 = str,
        s2 = '100';
    try { m += s1.split(".")[1].length } catch (e) { }
    try { m += s2.split(".")[1].length } catch (e) { }
    return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m)
};
//  /**
//  * @description 金额保留2位小数，自动补充零
//  */
// export const getFormatAmountAutoZero = (value) => {
//     var value=Math.round(parseFloat(value)*100)/100;
//     var xsd=value.toString().split(".");
//     if(xsd.length==1){
//         value=value.toString()+".00";
//         return value;
//     }
//     if(xsd.length>1){
//         if(xsd[1].length<2){
//         value=value.toString()+"0";
//     }
//         return value;
//     }
// };
/**
* @description 手机号格式化，只能是数字,按344分隔
*/
export const getFormatMobile = (value) => {
    return value.replace(/[^\d]/g, '').replace(/(\d{3})(?=\d)/, '$1 ').replace(/(\d{4})(?=\d)/g, '$1 ');
};
/**
* @description 银行账号4位一组，只能是数字
*/
export const getBankId = (value) => {
    return value.replace(/[^\d]/g, '').replace(/(\d{4})(?=\d)/g, '$1 ');
};
// /**
// * @description 身份证号按684分隔，只能是数字
// */
// export const getCardNo = (value) => {
//     return value.replace(/[^\d]/g, '').replace(/(\d{6})(?=\d)/, '$1 ').replace(/(\d{8})(?=\d)/, '$1 ');
// };
/**
* @description 卡号格式化，只能是数字
*/
export const getFormatCardId = (value) => {
    return value.replace(/[^\d]/g, '');
};
/**
* @description OBU号格式化，只能是数字、英文，小写英文转大写
*/
export const getFormatOBUId = (value) => {
    return value.replace(/[^\a-\z\A-\Z\d]/g, '').toLocaleUpperCase();
};
/**
* @description 车牌号号格式化，只能是数字、英文、汉字，小写英文转大写
*/
export const getFormatVehicleNumber = (value) => {
    return value.replace(/[^\a-\z\A-\Z\d\u4E00-\u9FA5]/g, '').toLocaleUpperCase();
};
/**
* @description 证件号码格式化，不能输入中文,身份证号按684分隔
*/
export const getFormatUserCode = (value) => {
    return value.replace(/[\u4E00-\u9FA5]+/, '').replace(/[^\w]/g, '').replace(/(\w{6})(?=\w)/, '$1 ').replace(/(\w{8})(?=\w)/, '$1 ');
};
/**
* @description 卡表面号格式化，只能是数字，4位一组输入
*/
export const getFormatCardFrontId = (value) => {
    return value.replace(/[^\d]/g, '').replace(/(\d{4})(?=\d)/g, '$1 ');
};
/**
* @description 卡号带*格式化，4位一组输入
*/
export const getFormatCardIdw = (value) => {
    return value.replace(/[^\w\*]/g, '').replace(/([\w\*]{4})(?=[\w\*])/g, '$1 ');
};
/**
* @description 标签表面号格式化，标签表面号长度最大为20，有可能不满20，英文+数字，显示时分段显示，按照42218分段
*/
export const getFormatOBUFrontId = (value) => {
    let val;
    // let orginLenth = value.length;
    val = value.replace(/[\u4E00-\u9FA5]+/, '')
        .replace(/ /g, "")
        .replace(/(\w{4})(?=\w)/, "$1 ")
        .replace(/(\w{4} \w{2})(?=\w)/, "$1 ")
        .replace(/(\w{4} \w{2} \w{2})(?=\w)/, "$1 ")
        .replace(/(\w{4} \w{2} \w{2} \w)(?=\w)/, "$1 ")
        .replace(/(\w{8})(?=\w)/, "$1 ")
    // if (value) {
    //     if (value.length <= 4) {
    //         console.log('4')
    //         val = value;
    //     } else if (orginLenth > 4 && orginLenth <= 7) {
    //         console.log('4-7')
    //         val
    //         val = value.substring(0, 4) + ' ' + value.substring(4, orginLenth);
    //         console.log('4-7', val)
    //     } else if (orginLenth > 7 && orginLenth <= 9) {
    //         console.log('6-8')
    //         val = value.substring(0, 4) + ' ' + value.substring(4, 6) + ' ' + value.substring(6, orginLenth);
    //     } else if (orginLenth > 9 && orginLenth <= 10) {
    //         console.log('8-9')
    //         val = value.substring(0, 4) + ' ' + value.substring(4, 6) + ' ' + value.substring(6, 8) + ' ' + value.substring(8, orginLenth);
    //     } else if (orginLenth > 10 && orginLenth <= 21) {
    //         console.log('9-17')
    //         val = value.substring(0, 4) + ' ' + value.substring(4, 6) + ' ' + value.substring(6, 8) + ' ' + value.substring(8, 9) + ' ' + value.substring(8, orginLenth);
    //     } else if (orginLenth > 21 && orginLenth <= 25) {
    //         console.log('17-20')
    //         val = value.substring(0, 4) + ' ' + value.substring(4, 6) + ' ' + value.substring(6, 8) + ' ' + value.substring(8, 9) + ' ' + value.substring(8, 17) + ' ' + value.substring(17, orginLenth);
    //     }
    // }
    return val;
};

/**
* @description 标签表面号带*格式化，标签表面号长度最大为20，有可能不满20，英文+数字，显示时分段显示，按照42218分段
*/
export const getFormatOBUFrontIdw = (value) => {
    let val;
    val = value.replace(/[\u4E00-\u9FA5]+/, '')
        .replace(/ /g, "")
        .replace(/([\w\*]{4})(?=[\w\*])/, "$1 ")
        .replace(/([\w\*]{4} [\w\*]{2})(?=[\w\*])/, "$1 ")
        .replace(/([\w\*]{4} [\w\*]{2} [\w\*]{2})(?=[\w\*])/, "$1 ")
        .replace(/([\w\*]{4} [\w\*]{2} [\w\*]{2} [\w\*])(?=[\w\*])/, "$1 ")
        .replace(/([\w\*]{8})(?=[\w\*])/, "$1 ")
    return val;
};

export const getDatePoint = (value) => {
    return value ? value.replace(/^(\d{4})(\d{2})(\d{2})$/, "$1-$2-$3") : '';
};


export const getTimePoint = (value) => {
    return value ? value.replace(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/, "$1-$2-$3 $4:$5:$6") : '';
};