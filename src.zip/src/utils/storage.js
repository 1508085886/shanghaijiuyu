/**
 * @description 本地存储
*/
const PRE_NAME = 'front_web_'

/**
 * @description 本地永久保存数据
 * @param { string } key 本地保存的名称
 * @param { any } value 本地保存的数据值
*/
export const setLocalStorage = (key, value) => {
  if (window.localStorage) {
    window.localStorage.setItem(PRE_NAME + key, JSON.stringify({
      value
    }))
  }
}

/**
 * @description 获取本地永久保存
 * @param { string } key 要获取的数据在本地保存的名称
 * @returns 保存的值，如果不存在返回 null
*/
export const getLocalStorage = key => {
  if (window.localStorage) {
    const value = window.localStorage.getItem(PRE_NAME + key)
    if (value) {
      return JSON.parse(value).value
    }
    return null
  }
  return null
}

/**
 * @description 删除指定的永久保存的本地数据
 * @param { string } key 要删除的数据名
*/
export const deleteLocalStorage = key => {
  if (window.localStorage) {
    window.localStorage.removeItem(PRE_NAME + key)
  }
}

/**
 * @description 本地会话保存数据
 * @param { string } key 本地保存的名称
 * @param { any } value 本地保存的数据值
*/
export const setSessionStorage = (key, value) => {
  if (window.sessionStorage) {
    window.sessionStorage.setItem(PRE_NAME + key, JSON.stringify({
      value
    }))
  }
}

/**
 * @description 获取本地会话保存
 * @param { string } key 要获取的数据在本地保存的名称
 * @returns 保存的值，如果不存在返回 null
*/
export const getSessionStorage = key => {
  if (window.sessionStorage) {
    const value = window.sessionStorage.getItem(PRE_NAME + key)
    if (value) {
      return JSON.parse(value).value
    }
    return null
  }
  return null
}

/**
 * @description 删除指定的会话保存的本地数据
 * @param { string } key 要删除的数据名
*/
export const deleteSessionStorage = key => {
  if (window.sessionStorage) {
    window.sessionStorage.removeItem(PRE_NAME + key)
  }
}
