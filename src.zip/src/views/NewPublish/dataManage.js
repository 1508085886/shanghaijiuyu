/**
 * @description 新办发行数据管理
*/
import { setSessionStorage, getSessionStorage, deleteSessionStorage } from '@/utils/storage';

const PREFIX = 'newPublishForm_'

/**
 * @description 数据域名
*/
export const publishData = {
  userRegister: 'userRegister'
}

/**
 * @description 获取指定内容的数据
*/
export const getTargetPublishData = key => {
  return getSessionStorage(PREFIX + key)
}

/**
 * @description 保存指定内容的数据
*/
export const setTargetPublishData = (key, data) => {
  return setSessionStorage(PREFIX + key, data)
}

/**
 * @description 清理所有数据
*/
export const clearPublishData = () => {
  for (let name of publishData) {
    deleteSessionStorage(PREFIX + name)
  }
}
