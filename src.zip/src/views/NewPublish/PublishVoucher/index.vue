<!-- 发行业务凭证 -->
<template>
  <div class="offline-publish-voucher">
    <h4 class="offline-publish-voucher_title">用户信息</h4>
    <o-table :info="tables" />
    <h4 class="offline-publish-voucher_title">车辆信息</h4>
    <car-info v-for="i in 2" :key="i" />
    <div class="o-flex mt40">
      <el-row class="o-flex-1" :gutter="50">
        <el-col :md="12">
          <el-form ref="form" :model="form" :rules="rules">
            <el-form-item label="选择安装方式" prop="installType">
              <el-select
                v-model="form.installType"
                placeholder="请选择"
                class="o-width-full"
              >
                <el-option label="蓝色" value="1"></el-option>
                <el-option label="绿色" value="2"></el-option>
              </el-select>
            </el-form-item>
          </el-form>
        </el-col>
        <el-col :md="12">
          <div>费用（元）</div>
          <div class="offline-publish-voucher_total-price">360.00</div>
        </el-col>
      </el-row>
      <autograph />
    </div>
    <div class="clearfix mt20">
      <div class="fr">
        <el-button @click="$router.back()">上一步</el-button>
        <el-button type="primary" @click="onSubmit">设备发行</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import OTable from '@/components/Table';
import CarInfo from '../CarInfo';
import Autograph from '@/components/Autograph';

export default {
  data() {
    return {
      tables: [
        { label: '用户名称', value: '张依琳' },
        { label: '签约银行', value: '光大银行' },
        { label: '证件类型', value: '身份证' },
        { label: '证件号码', value: '310103929048200293' },
      ],
      form: {},
      rules: {
        installType: [
          { required: true, message: '请选择安装方式', trigger: 'blur' },
        ],
      },
    };
  },
  components: {
    OTable,
    CarInfo,
    Autograph,
  },
  methods: {
    onSubmit() {
      let newPath;
      if ('newpublishperson' === self.$router.currentRoute.path.split('/')[1]) {
        newPath = '/newpublishperson/publish';
      } else {
        newPath = '/newpublish/publish';
      }
      // this.$router.push('/newpublish/publish');
      this.$router.push(newPath);
    },
  },
};
</script>
