<!-- 签约银行 -->
<template>
  <div class="offline-bank-sign">
    <div class="o-flex">
      <div class="o-flex-1 mr50">
        <div class="title" style="margin-right: 50px; padding-right: 50px">
          <!-- <h4 v-if="titleShow" style="display: inline">
            选择签约银行&nbsp&nbsp
          </h4> -->
          <span v-if="titleShow" style="font-weight: bold; margin-right: 25px">选择签约银行</span>
          <el-button icon="el-icon-refresh" size="mini" round @click="openFullScreen1"
            v-loading.fullscreen.lock="fullscreenLoading">
            刷新
          </el-button>
        </div>
        <el-row :gutter="25">
          <el-col v-for="channel in channelList" :key="channel.channelId" :xl="xl" :lg="lg" :md="8" :sm="8"
            class="mb20">
            <div ref="channelId" class="offline-bank-sign_bank-item o-flex o-flex-align-center o-flex-justify-center"
              :class="[
                { 'is-active': selectedChannel.name === channel.remarks },
              ]" @click="selectChannel(channel)">
              <!-- <img v-logo="channel.remarks" /> -->

              <img :src="
                  require('../../../assets/images/bank/' +
                    channel.channelId +
                    '.png')
                " />
            </div>
          </el-col>
          <!-- <el-col :xl="6" :lg="8" class="mb20">
            <div
              class="offline-bank-sign_bank-item o-flex o-flex-align-center o-flex-justify-center"
              :class="[{ 'is-active': selectedChannel.name === 'B-type' }]"
              @click="selectChannel('B-type')"
            >
              <img src="../../../assets/images/b-card.png" />
            </div>
          </el-col> -->
        </el-row>
      </div>

      <div v-if="qrLink">
        <h4>二维码展示</h4>
        <div ref="imageWrapper" class="offline-bank-sign_qrcode">
          <no-data class="offline-bank-sign_qrcode-container" message="请先选择签约银行" v-if="!qrLink"></no-data>
          <div class="offline-bank-sign_qrcode-container offline-bank-sign_bank-qrcode" v-if="qrLink != ''">
            <qr-code :text="qrLink" />
            <p>{{ selectedChannel.name }}签约二维码</p>
          </div>
        </div>
      </div>
    </div>
    <div class="clearfix mt20" v-if="!isComponent">
      <div class="fr">
        <!-- <el-button @click="$router.back()">上一步</el-button> -->
        <el-button type="primary" @click="next" v-dbclick="{ timer: '2000' }" :loading="loading"
          :disabled="isButtonDisabled">下一步</el-button>
      </div>
    </div>

    <!-- <complex-table
      title="B类充值账户"
      :visible.sync="accountVisible"
      :columns="tables"
      requestListUrl="/rechargeAccount"
      :requestListParam="{}"
      @getSelected="selectAccount"
      insertListUrl="/departmentAdd"
      :append-to-body="true"
    /> -->
    <o-dialog :visible.sync="signResVisible" title="提示" :append-to-body="true">
      <div class="offline-bank-sign_sq-result pb15">
        <img src="../../../assets/images/pic-ewms.png" />
        <div class="mt30">提示用户扫描屏幕上的二维码完成银行签约</div>
        <el-button class="mt30 mb30" type="primary" @click="haveSign">用户已完成签约，下一步</el-button>
      </div>
    </o-dialog>
  </div>
</template>

<script>
  import { getQueryStringByName } from '@/utils/utils';
  import { mediaUpload } from '@/api/common';
  import html2canvas from 'html2canvas';
  import { NoData } from '@/components/NoData';
  import { getChannelList } from '@/api/newPublish';
  import { getAbbFByullName } from '@/methods/bankName';
  import QrCode from '@/components/QrCode';
  import { applySign } from '@/api/newPublish';
  import { userCheck } from '@/api/user';
  import ComplexTable from '@/components/ComplexTable';
  import ODialog from '@/components/Dialog';
  import { bindVehicle } from '@/api/vehicle.js';
  import { Alert } from 'element-ui';
  export default {
    data() {
      return {
        cflag: true,
        flagg: true,
        isButtonDisabled: false,
        fullscreenLoading: false,
        selectLoading: false,
        skipflag: false,
        channelList: [],
        selectedChannel: {
          channelId: '',
          name: '',
          code: '',
        },
        channelselect: { subChannelId: '', busId: '' },
        etcUserId: '',
        qrLink: '',
        tables: [
          {
            name: '账户编号',
            filed: 'accountNum',
            edit: true,
          },
          {
            name: '账户名称',
            filed: 'accountName',
            edit: true,
          },
          {
            name: '账户余额',
            filed: 'zhye',
            edit: true,
          },
          {
            name: '消费限额',
            filed: 'xfxe',
            edit: true,
          },
          {
            name: '警告限额',
            filed: 'jgxe',
            edit: true,
          },
          {
            name: '可疑未清算金额',
            filed: 'kywqsje',
            edit: true,
          },
        ],
        accountVisible: false,
        signResVisible: false,
      };
    },
    props: {
      isComponent: {
        type: Boolean,
      },
      titleShow: {
        type: Boolean,
        default: true,
      },
      pVehicleId: {
        type: String,
      },
      xl: {
        type: Number,
        default: 8,
      },
      lg: {
        type: Number,
        default: 8,
      },
    },
    directives: {
      logo: {
        inserted: function (el, binding) {
          el.setAttribute(
            'src',
            `https://apimg.alipay.com/combo.png?d=cashier&t=${getAbbFByullName(
              binding.value
            )}`
          );
        },
      },
    },
    methods: {
      openFullScreen1() {
        this.fullscreenLoading = true;
        let timer = setTimeout(() => {
          this.fullscreenLoading = false;
        }, 10000);
        this.getChannelList();
        clearTimeout(timer);
        this.fullscreenLoading = false;
      },
      // 签约完成，下一步
      async haveSign() {
        if (this.isComponent) {
          this.$emit('complete');
        } else {
          //alert(this.channelselect.busId);
          const self = this;
          const vehicles = self.$store.getters.registerVehicle;
          const vehicleId = self.isComponent
            ? self.pVehicleId
            : self.$route.query.vid;
          const currentVehicle = vehicles.find(
            (vehicle) => vehicle.vehicleId === vehicleId
          );
          const userp = self.$store.getters.registerUser.userProperty;
          const discountType = self.channelselect.busId;
          this.close();
          //debugger;
          setTimeout(() => {
            this.flagg = true;
          }, 8000);
          if (this.flagg == true) {
            this.flagg = false;
            const res = await bindVehicle({
              workOrderID: self.$route.query.woid,
              etcUserId: self.$store.getters.registerUser.etcUserId,
              vehicleId: this.$route.query.vid,
              //payChannelId: self.channelselect.subChannelId,
              payChannel: self.channelselect.channelId,
              subPayChannelId: '',
              discountType: discountType + '001',
              userType: self.$store.getters.registerUser.userProperty,
              vehicleNumber: currentVehicle.vehicleNumber,
              vehicleColor: currentVehicle.vehicleColor,
            });
            if (res) {
              // this.signResVisible = false;
              // if (this.isComponent) {
              //   this.$emit('complete');
              // } else {
              this.$router.push({
                // path: '/newpublish/carregister',
                path: '/equipmentissuance',
                query: this.$route.query,
              });
              // }
            }
          }
        }
      },

      async bind() {
        const self = this;
        const vehicles = self.$store.getters.registerVehicle;
        const vehicleId = self.isComponent
          ? self.pVehicleId
          : self.$route.query.vid;
        const currentVehicle = vehicles.find(
          (vehicle) => vehicle.vehicleId === vehicleId
        );
        const discountType = self.channelselect.busId;
        const res = await bindVehicle({
          workOrderID: self.$route.query.woid,
          etcUserId: self.$store.getters.registerUser.etcUserId,
          vehicleId: this.$route.query.vid,
          payChannelId: self.channelselect.subChannelId,
          subPayChannelId: '',
          // userType: self.$store.getters.registerUser.userProperty,
          userType: '1',
          discountType: discountType + '001',
          vehicleNumber: currentVehicle.vehicleNumber,
          vehicleColor: currentVehicle.vehicleColor,
        });
        if (res) {
          this.$router.push({
            path: '/equipmentissuance',
            query: this.$route.query,
          });
          return;
        }
      },
      // 点击下一步
      async next() {
        setTimeout(() => {
          this.cflag = true;
        }, 8000);
        const self = this;
        self.isButtonDisabled = true;
        this.close();
        if (!self.channelselect.channelId) {
          this.$alert('请选择银行', '提示', {
            confirmButtonText: '确定',
            type: 'warning',
          });
          self.isButtonDisabled = false;
          return;
        }
        self.loading = true;
        let timer = setTimeout(() => {
          self.isButtonDisabled = false;
          self.loading = false;
        }, 20000);
        const vehicles = self.$store.getters.registerVehicle;
        const vehicleId = self.isComponent
          ? self.pVehicleId
          : self.$route.query.vid;
        const currentVehicle = vehicles.find(
          (vehicle) => vehicle.vehicleId === vehicleId
        );
        const userp = self.$store.getters.registerUser.userProperty;
        const discountType = self.channelselect.busId;
        if (userp == '1') {
          this.sendpad();
          self.signResVisible = true;
          self.isButtonDisabled = false;
        }
        //对公：直接绑定
        if (userp == '2') {
          if (this.cflag == true) {
            this.cflag = false;
            const res = await bindVehicle({
              workOrderID: self.$route.query.woid,
              etcUserId: self.$store.getters.registerUser.etcUserId,
              vehicleId: this.$route.query.vid,
              payChannel: self.channelselect.channelId,
              subPayChannelId: '',
              userType: self.$store.getters.registerUser.userProperty,
              // userType: '1',
              discountType: discountType + '001',
              vehicleNumber: currentVehicle.vehicleNumber,
              vehicleColor: currentVehicle.vehicleColor,
            });
            if (res) {
              const localUser = this.$store.getters.registerUser;
              console.log(localUser.userPics);
              console.log(localUser.transactorImg);
              this.$router.push({
                path: '/equipmentissuance',
                query: this.$route.query,
              });
            }
          }
          clearTimeout(timer);
          self.isButtonDisabled = false;
          self.loading = false;
          return;
        }
        // const res = await bindVehicle({
        //   workOrderID: self.$route.query.woid,
        //   etcUserId: self.$store.getters.registerUser.etcUserId,
        //   vehicleId,
        //   payChannelId: self.channelselect.subChannelId,
        //   subPayChannelId: '',
        //   discountType: discountType + '001',
        //   userType: self.$store.getters.registerUser.userType,
        //   vehicleNumber: currentVehicle.vehicleNumber,
        //   vehicleColor: currentVehicle.vehicleColor,
        // });
        // if (res) {
        //   self.signResVisible = true;
        // }
        clearTimeout(timer);
        self.isButtonDisabled = false;
        self.loading = false;
        //self.signResVisible = true;
      },
      // 选择B类充值账户类型
      selectAccount() { },

      // 选择渠道
      async selectChannel(channel) {
        const self = this;
        self.qrLink = '';
        const loading = this.$loading({
          lock: true,
          text: 'Loading',
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.7)',
        });
        setTimeout(() => {
          loading.close();
        }, 1100);
        self.channelselect = channel;
        if (typeof channel === 'string') {
          self.selectedChannel.name = channel;
          self.accountVisible = true;
        } else {
          self.selectedChannel.name = channel.remarks;
          // 申请签约
          const param = self.$store.getters.registerVehicle;
          const userProperty = self.$store.getters.registerUser.userProperty;
          console.log('userProperty:' + userProperty);
          if (userProperty == '1') {
            const res = await applySign({
              etcUserId: self.$store.getters.registerUser.etcUserId,
              payChannelId: channel.channelId,
              // subPayChannelId: channel.subChannelId,
              vehicleNumber: param[param.length - 1].vehicleNumber,
              vehicleColor: param[param.length - 1].vehicleColor,
              workOrderId: self.$route.query.woid,
            });
            console.log(res);
            if (res.signUrl != '') {
              if (res.signUrl == '已签约，无需重复签约') {
                self
                  .$confirm('该车辆已签约，无需重复签约', '提示', {
                    confirmButtonText: '确定',
                    type: 'warning',
                  })
                  .then(() => {
                    this.haveSign();
                  });
              }
              self.qrLink = res.signUrl;
              console.log('qrlink');
              console.log(self.qrLink);
              this.channelselect.subChannelId = channel.channelId;
              //alert(this.channelselect.busId);
            }
          } else {
            this.channelselect.subChannelId = channel.channelId;
            this.channelselect.busId = channel.busId;
          }
          // loading.close();
        }
      },
      ////////////////////////////////////////////////////////////////
      close() {
        const self = this;
        // self.timer = setTimeout(() => {
        const b = etcdev.closehangwriting();
        this.$emit('closed');
        this.$emit('update:visible', false);
      },
      sendpad() {
        const self = this;
        // self.oprShow = false;
        // if(!self.oprShow){
        self.$nextTick(() => {
          html2canvas(self.$refs.imageWrapper).then((canvas) => {
            let dataURL = canvas.toDataURL('');
            dataURL = dataURL.replace('data:image/png;base64,', '');
            const pic = self.getpicture(dataURL);
          });
        });
        // }
      },
      getpicture(dataURL) {
        const par = '123';
        window.DisplayDate = (pic, sign) => {
          const result = eval('(' + pic + ')');
          console.log('code::' + result.code);
          if (result.msg !== '签名版打开失败') {
            if (result.code === '0') {
              this.padconfirm(result.pic);
            } else if (result.msg === '签名版打开失败') {
              this.$message({
                message: result.msg,
                type: 'warning',
              });
              this.close();
            } else {
              // this.$message({
              //   message: '用户未确认',
              //   type: 'warning',
              // });
              this.close();
            }
          }
        };
        //const b = etcdev.showhangwriting(dataURL, 'DisplayDate', par, '2');
        //let dif = getQueryStringByName('dif', window.location.href);
        etcdev.showhangwriting(dataURL, 'DisplayDate', par, '2', '0');
      },

      padconfirm(confirmphoto) {
        mediaUpload({
          fileType: '2',
          img: confirmphoto,
        }).then((res) => {
          this.haveSign();
          this.close();
          this.$emit('complete', {
            frontImgid: res.frontImgid,
            img: confirmphoto,
            etx: '2',
          });
        });
      },
      ////////////////////////////////////////////////////////////////
      // 查询签约渠道列表
      async getChannelList() {
        const self = this;
        const userType = this.$store.getters.registerUser.userProperty;
        if (!userType) {
          return;
        }
        // alert('userType:'+userType)
        const res = await getChannelList(userType);
        // const res = await getChannelList('1');
        if (res) {
          // var index = res.channelList.findIndex((item) => {
          //   if (item.remarks === '建设银行') {
          //     return true;
          //   }
          //   res.channelList.splice(index, 1);
          // });
          self.channelList = res.channelList;
          // self.channelList = res.channelList || [];
        }
        //新办发行流程进入银行签约绑定页面后，将自动选中车牌发行校验选择的签约渠道。
        if (this.$store.getters.registerUser.channelId) {
          this.$nextTick(() => {
            this.clickchannel()
          })
        }
      },
      clickchannel() {
        if (this.channelList.length > 0) {
          for (let i = 0; i < this.channelList.length; i++) {
            setTimeout(() => {
              if (this.channelList[i].channelId === this.$store.getters.registerUser.channelId) {
                this.$refs.channelId[i].click()
              }
            }, 200);
          }
        }

      },
    },
    components: {
      NoData,
      QrCode,
      ComplexTable,
      ODialog,
    },
    watch: {
      // skipflag(val) {
      //   if (val) {
      //     this.bind();
      //   }
      // },
    },
    async mounted() {
      // 如果单位直接签约
      this.getChannelList();
      const userp = this.$store.getters.registerUser.userProperty;
      if (userp == '2') {
        this.skipflag = true;
      }
    },
  };
</script>