<!-- 业务发行 -->
<template>
  <div class="offline-publish ml100 mr100 mt40">
    <publish-group>
      <publish-item :step="4"></publish-item>
      <publish-item :step="2"></publish-item>
    </publish-group>
  </div>
</template>

<script>
import { PublishGroup, PublishItem } from '@/components/PublishGroup';

export default {
  components: {
    PublishGroup,
    PublishItem,
  },
};
</script>
