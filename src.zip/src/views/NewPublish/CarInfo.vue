<!-- 车辆信息 -->
<template>
  <div>
    <div
      class="offline-car-register_item mt20"
      :class="[{ bordercss: info.isChecked }]"
    >
      <el-collapse v-model="activeNames">
        <el-collapse-item :name="nameCheck">
          <template slot="title">
            <div
              class="offline-car-register_item-header o-flex o-flex-align-center"
            >
              <div class="mtop">
                <el-checkbox
                  v-model="info.isChecked"
                  size="medium"
                  style="zoom: 200%; padding-right: 10px"
                  :style="{ display: checkboxDisplay }"
                ></el-checkbox>
              </div>
              <h3 class=".o-flex-half">{{ info.vehicleNumber }}</h3>

              <div style="padding-left: 60px; color: blue">
                车辆用户类型：
                <span>{{ vehicleType }}</span>
              </div>
              <div style="padding-left: 60px; color: blue">
                收费车型：
                <span>{{ vehicleClass }}</span>
              </div>
              <div
                class="o-flex o-flex-row offline-car-register_item-header-step"
                v-if="$slots.step"
              >
                <slot name="step"></slot>
              </div>
              <!-- <div v-if="false">
          <loading-icon :loading="true" />
          <span style="font-size: 18px">发行成功</span>
        </div> -->
            </div>
          </template>

          <div class="collapse2">
            <el-row :gutter="10" class="offline-car-register_item-info">
              <el-col :xl="6" :lg="8" :md="12" style="color: blue"
                >车牌颜色：{{ vehicleColor }}</el-col
              >
              <el-col :xl="6" :lg="8" :md="12" style="color: blue"
                >车辆类型：{{ info.dzfpVehicleType }}</el-col
              >
              <el-col :xl="6" :lg="8" :md="12"
                >车辆所有人：{{
                  info.viOwnerInfo ? info.viOwnerInfo.ownerName : ''
                }}</el-col
              >
              <!-- info.viownerInfo ? info.viownerInfo.ownerName : '' -->
              <el-col :xl="6" :lg="8" :md="12"
                >使用性质：{{ info.vehicleSpecies }}</el-col
              >
              <el-col :xl="6" :lg="8" :md="12"
                >品牌型号：{{ info.viModelName }}</el-col
              >
              <el-col :xl="6" :lg="8" :md="12"
                >车辆识别代号：{{ info.vin }}</el-col
              >
              <el-col :xl="6" :lg="8" :md="12"
                >发动机号码：{{ info.engineNum }}</el-col
              >
              <el-col :xl="6" :lg="8" :md="12" style="color: blue"
                >核定载人数：{{ info.approvedAccount }}人</el-col
              >
              <el-col :xl="6" :lg="8" :md="12"
                >总质量：{{ info.viTotalMass }}kg</el-col
              >
              <el-col :xl="6" :lg="8" :md="12"
                >整备质量：{{ info.maintenaceMass }}kg</el-col
              >
              <el-col :xl="6" :lg="8" :md="12"
                >核定载质量：{{ info.permittedWeight }}kg</el-col
              >
              <el-col :xl="6" :lg="8" :md="12"
                >准牵引总质量：{{ info.permittedTowWeight }}kg</el-col
              >
              <el-col :xl="6" :lg="8" :md="12" style="color: blue"
                >外廓尺寸：{{ info.viLength }} x {{ info.viWidth }} x
                {{ info.viHeight }}mm</el-col
              >
              <el-col :xl="6" :lg="8" :md="12"
                >车轴数：{{ info.axleCount }}
              </el-col>

              <el-col :xl="6" :lg="8" :md="12"
                >车轮数：{{ info.wheelCount }}
              </el-col>

              <el-col :xl="6" :lg="8" :md="12"
                >轴距：{{ info.axleDistance }}mm</el-col
              >

              <el-col :xl="6" :lg="6" :md="12"
                >设备费：{{ info.price / 100 }}元</el-col
              >
            </el-row>

            <!-- <el-row :gutter="10" class="offline-car-register_item-info">
        <el-col :xl="6" :lg="6" :md="12">车牌颜色：{{ vehicleColor }}</el-col>
        <el-col :xl="6" :lg="6" :md="12">ETC号：12345678901234567890</el-col>
        <el-col :xl="6" :lg="6" :md="12">obu号：1234567890123</el-col>
        <el-col :xl="6" :lg="6" :md="12">设备费：{{1}}</el-col>
      </el-row>-->

            <div class="clearfix mt5 mr5" v-if="$slots.buttons">
              <div class="fr">
                <slot name="buttons"></slot>
              </div>
            </div>
          </div>
        </el-collapse-item>
      </el-collapse>
    </div>
  </div>
</template>

<script>
import LoadingIcon from '@/components/LoadingIcon';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
} from '@/methods/dics';
export default {
  data() {
    return {
      nameCheck: '1',
      activeNames: ['1'],
      vehicleType: '',
      vehicleClass: '',
      vehicleColor: '',
      isChecked: false,
      // checkboxDisplay: 'inline-block',
      // carInfoCbxStyle: 'zoom: 200%;padding-right:10px;display:none',
    };
  },
  props: {
    // nameCheck1: {
    //   type: Number,
    //   default: 'none',
    // },
    // nameCheck2: {
    //   type: Number,
    //   default: 'none',
    // },
    info: {
      // default: {},
      default: () => {},
      // default: () => {
      //   return {
      //     isChecked:true,
      //     "userId": "36423728002482",
      //     "vehicleId": "23212112132",
      //     "vehicleNumber": "沪A68293",
      //     "vehicleColor": "2",
      //     "takeoffTime": "2018-02-10",
      //     "createTime": "2018-01-10",
      //     "viRegisterDate": "2018-02-01",
      //     "viIssueDate": "2018-02-13",
      //     "vehicleType": "0",
      //     "dzfpVehicleType": "小型客车",
      //     "vehicleSpecies": "家用",
      //     "viModelName": "斯柯达柯米克",
      //     "vin": "SMF238ION872E2323",
      //     "engineNum": "JAPDNJ23i4i2",
      //     "vehicleClass": "1",
      //     "approvedAccount": "5",
      //     "viTotalMass": "1300",
      //     "maintenaceMass": "2000",
      //     "permittedWeight": "700",
      //     "permittedTowWeight": "40000",
      //     "viLength": "2190",
      //     "viWidth": "1021",
      //     "viHeight": "1102",
      //     "wheelCount": "4",
      //     "axleCount": "2",
      //     "axleDistance": "1000"
      //   }
      // },
    },
    checkboxDisplay: {
      default: 'none',
    },
  },
  components: {
    LoadingIcon,
  },
  methods: {
    handleChange(val) {
      console.log(val);
    },
    // 获取车辆用户类型
    async getVehicleTypes() {
      const res = await getDicDesByCode(
        dicKeys.vehicleUserClass,
        this.info.vehicleType
      );
      // if (res) {
      //   this.vehicleType = res;
      // }
      if (res && this.info.vehicleCategory) {
        if (res === '0 - 普通客车/普通货车') {
          if (this.info.vehicleCategory == '1') {
            this.vehicleType = '0 - 普通客车';
          } else {
            this.vehicleType = '0 - 普通货车';
          }
        } else {
          this.vehicleType = res;
        }
      } else {
        this.vehicleType = res;
      }
    },
    // 获取收费车型
    async getVehicleClass() {
      const res = await getDicDesByCode(
        dicKeys.vehicleClass,
        this.info.vehicleClass
      );
      if (res) {
        this.vehicleClass = res;
      }
    },
    // 获取车牌颜色
    async getVehicleColor() {
      const res = await getDicDesByCode(
        dicKeys.vehicleColor,
        this.info.vehicleColor
      );
      if (res) {
        this.vehicleColor = res;
      }
    },
  },
  watch: {
    'info.isChecked'() {
      this.$emit('selectChange');
    },
  },

  mounted() {
    // 获取所有车辆用户类型
    this.getVehicleTypes();
    // 获取收费车型
    this.getVehicleClass();
    // 获取车牌颜色
    this.getVehicleColor();

    console.log(this.info);
    // console.log(this.nameCheck1);
    // console.log(this.nameCheck2);
  },
};
</script>
<style lang="scss">
.bordercss {
  border: 2px solid #1375ef;
}
.el-checkbox__inner {
  margin-right: 8px;
}

.o-flex-half {
  flex: 0.5;
}
</style>
