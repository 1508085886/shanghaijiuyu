<!-- 用户注册凭证 -->
<template>
  <div class="offline-user-register-voucher">
    <h4 class="offline-user-register-voucher_title">用户信息</h4>
    <o-table :info="tables" />
    <!-- <div class="clearfix mt20">
      <autograph class="fr" />
    </div>-->
    <div class="clearfix mt40">
      <div class="fr">
        <el-button @click="$router.back()">上一步</el-button>
        <el-button type="primary" @click="onSubmit">下一步</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import OTable from '@/components/Table';
import Autograph from '@/components/Autograph';
import { getSessionStorage } from '@/utils/storage';
import { userRegister } from '@/api/newPublish';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
} from '@/methods/dics';

export default {
  data() {
    return {
      form: {},
      tables: [
        { label: '用户名称', value: '' },
        { label: '客户类型', value: '' },
        { label: '证件类型', value: '' },
        { label: '证件号码', value: '' },
        { label: '联系地址', value: '' },
        { label: '邮政编码', value: '' },
        { label: '固定联系电话', value: '' },
        { label: '手机号(开票验证)', value: '' },
        // { label: '账户联系人', value: '' },
        { label: '电子邮箱', value: '' },
        { label: '备注', value: '' },
      ],
    };
  },
  components: {
    OTable,
    Autograph,
  },
  methods: {
    async onSubmit() {
      const res = await userRegister(this.form);
      if (res) {
        if (res.errorMsg) {
          // 将接口的指定出参字段提示出来
          this.$alert(res.errorMsg, '提示', {
            confirmButtonText: '确定',
            type: 'error',
          });
          return;
        }
        let newPath;
        if (
          'newpublishperson' === self.$router.currentRoute.path.split('/')[1]
        ) {
          newPath = '/newpublishperson/carregister';
        } else {
          newPath = '/newpublish/carregister';
        }
        this.$router.push({
          // path: '/newpublish/carregister',
          path: newPath,
          query: {
            uid: res.etcUserId,
          },
        });
      }
    },
    // 获取上一页输入的表单数据
    async getFormData() {
      const data = getSessionStorage('newPublishForm_userRegister');
      this.form = data;
      this.tables[0].value = data.userName || '';
      this.tables[1].value = await getDicDesByCode(
        dicKeys.userType,
        data.userProperty
      );
      this.tables[2].value = await getDicDesByCode(
        dicKeys.userCertType,
        data.userCertType
      );
      this.tables[3].value = data.userCode || '';
      this.tables[4].value = data.address || '';
      this.tables[5].value = data.zipCode || '';
      this.tables[6].value = data.userPhone || '';
      this.tables[7].value = data.userPhone2 || '';
      // this.tables[8].value = data.userName || '';
      this.tables[8].value = data.eMail || '';
      this.tables[9].value = data.note || '';
    },
  },
  mounted() {
    // 获取上一页输入的表单数据
    this.getFormData();
  },
};
</script>
