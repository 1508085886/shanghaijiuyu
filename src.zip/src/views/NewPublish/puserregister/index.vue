<!-- 个人新办发行-->
<template>
  <div class="offline-new-publish">
    <div class="offline-new-publish_title-wrap">
      <h4 class="offline-new-publish_title">新办发行</h4>
      <span class="offline-new-publish_title-remark"></span>
    </div>
    <div class="offline-new-publish_container">
      <el-steps :active="step" finish-status="finish">
        <el-step title="用户注册"></el-step>
        <!-- <el-step title="用户注册凭证"></el-step> -->
        <el-step title="车辆注册"></el-step>
        <el-step title="银行签约"></el-step>
        <!-- <el-step title="发行申请"></el-step> -->
      </el-steps>
      <keep-alive>
        <router-view class="mt20"></router-view>
      </keep-alive>
    </div>

    <!-- <! -->
    <div class="pl70 pr70">
      <h3>上传用户证件</h3>
      <div class="o-flex">
        <photograph-block type="userCertTypeP" @complete="complete" ocr :isButtonDisabled="disabled"
          :defaultPics="userPics"></photograph-block>
      </div>
      <el-form ref="form" :model="form" :rules="rules" class="mt30">
        <el-row>
          <el-col>
            <div class="offline-user-register_user-select-cover"></div>
            <el-radio-group v-model="isNew">
              <el-radio label="1">未注册用户</el-radio>
              <el-radio label="2">已注册用户</el-radio>
            </el-radio-group>
          </el-col>
        </el-row>
        <el-row class="mt10" :gutter="20">
          <el-col :sm="24" :md="24" :lg="24">
            <el-form-item label="用户名称" prop="userName" class="jiacu">
              <el-input :readonly="!changeable" v-model="form.userName" spellcheck="false"></el-input>
            </el-form-item>
          </el-col>

          <el-col :md="12" :lg="8">
            <el-form-item label="用户类型" prop="userProperty">
              <type-select :readonly="true" type="userTypeP" v-model="form.userProperty" placeholder="请选择"
                class="o-width-full" />
            </el-form-item>
          </el-col>
          <el-col :md="12" :lg="8">
            <el-form-item label="证件类型" prop="userCertType" class="jiacu">
              <type-select type="userCertTypeP" v-model="form.userCertType" spellcheck="false" placeholder="请选择"
                class="o-width-full" />
              <!-- :del-options="[{ value: '199' }, { value: '299' }]" -->
            </el-form-item>
          </el-col>
          <el-col :md="12" :lg="8">
            <el-form-item label="证件号码" prop="userCode" class="jiacu">
              <el-input v-model="form.userCode" spellcheck="false" placeholder="请输入"></el-input>
            </el-form-item>
          </el-col>

          <el-col :md="12" :lg="8">
            <el-form-item label="邮政编码" prop="zipCode">
              <regex-input v-model="form.zipCode" :maxlength="6" :readonly="!changeable" @mousewheel.native.prevent
                spellcheck="false" type="cardId"></regex-input>
            </el-form-item>
          </el-col>
          <el-col :md="12" :lg="8">
            <el-form-item label="手机号" prop="userPhone2" :class="iclass">
              <el-input v-model="form.userPhone2" :readonly="!changeable" :maxlength="13" placeholder="请输入"
                @mousewheel.native.prevent spellcheck="false"></el-input>
            </el-form-item>
          </el-col>
          <el-col :md="12" :lg="8">
            <el-form-item label="固定联系电话" prop="userPhone">
              <el-input v-model="form.userPhone" :readonly="!changeable" :maxlength="16" placeholder="请输入"
                onkeyup="value=value.replace(^1[3|4|5|6|7|8|9][0-9]{9}$,'')" @mousewheel.native.prevent
                spellcheck="false"></el-input>
            </el-form-item>
          </el-col>
          <!-- <el-col :md="12" :lg="8">
          <el-form-item label="账户联系人">
            <el-input v-model="form.contacts"></el-input>
          </el-form-item>
        </el-col>-->
          <el-col :sm="24" :md="24" :lg="24">
            <el-form-item label="联系地址" prop="address">
              <el-input :readonly="!changeable" v-model="form.address" spellcheck="false"></el-input>
            </el-form-item>
          </el-col>
          <el-col :md="12" :lg="8">
            <el-form-item label="电子邮箱" prop="eMail">
              <el-input :readonly="!changeable" v-model="form.eMail" spellcheck="false"></el-input>
            </el-form-item>
          </el-col>
          <el-col :md="12" :lg="8">
            <el-form-item label="备注" prop="note">
              <el-input :readonly="!changeable" v-model="form.note" spellcheck="false"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <!-- <h3>经办人信息</h3>
      <div class="o-flex">
        <photograph-block
          title="证件上传"
          width="110"
          height="110"
        ></photograph-block>
      </div>-->
        <template v-if="
            transactorImg.length > 0 &&
            form.userProperty === '2' &&
            isNew === '2'
          ">
          <div class="o-flex mt20">
            <photograph-block type="agentCertType" @complete="saveTransactorImg" :defaultPics="transactorImg"
              title="经办人证件"></photograph-block>
          </div>
        </template>
        <template v-if="form.userProperty === '2' && isNew === '1'">
          <div class="o-flex mt20">
            <photograph-block type="agentCertType" @complete="agentComplete" ocr :defaultPics="agentPics" title="代理人证件">
            </photograph-block>
          </div>
          <el-row :gutter="20">
            <el-col :md="12" :lg="8">
              <el-form-item label="分支机构名称" prop="department" class="jiacu">
                <el-input v-model="form.department"></el-input>
              </el-form-item>
            </el-col>
            <el-col :md="12" :lg="8">
              <el-form-item label="代理人姓名" prop="agentName" class="jiacu">
                <el-input v-model="form.agentName" spellcheck="false"></el-input>
              </el-form-item>
            </el-col>
            <el-col :md="12" :lg="8">
              <el-form-item label="代理人证件类型" prop="agentIdType" class="jiacu">
                <type-select type="agentCertType" v-model="form.agentIdType" placeholder="请选择" class="o-width-full"
                  spellcheck="false" />
              </el-form-item>
            </el-col>
            <el-col :md="12" :lg="8">
              <el-form-item label="代理人证件号码" prop="agentIdNum" class="jiacu">
                <el-input v-model="form.agentIdNum" spellcheck="false"></el-input>
              </el-form-item>
            </el-col>
            <el-col :md="12" :lg="8">
              <el-form-item label="代理人手机号码" prop="agentPhoneNum" class="jiacu">
                <el-input v-model="form.agentPhoneNum" type="number" @mousewheel.native.prevent spellcheck="false">
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </template>
        <div class="clearfix mt20">
          <el-button class="fr" type="primary" v-dbclick="{ timer: '1100' }" @click="onSubmit" :loading="loading">下一步
          </el-button>
        </div>
      </el-form>
      <transactor-dialog :visible.sync="transactorDialogVisible" :append-to-body="true"
        @transactorDialogComplete="transactorDialogComplete" />
      <voucher-layer ref="mychild" :visible.sync="voucherVisible" :keys="voucherKeys" :info="voucherData" :column="2"
        @complete="submitVoucher" @cancel="clearForm" />
    </div>
  </div>
</template>

<script>
  import {
    get15info,
    get16info,
    getmf01info,
    purchaserecord,
    getdf01Info,
  } from '@/utils/readcardobu';
  import RegexInput from '@/components/RegexInput';
  import { validPhone, vzz, validGDPhone, validEmail } from '@/utils/validate';
  import { getcodezz } from '@/utils/rules';
  import PhotographBlock from '@/components/PhotographBlock';
  import TransactorDialog from '@/components/TransactorDialog';
  import { qrCode, IDCard1, IDCard2 } from '@/temp/base64';
  // import {
  //   setTargetPublishData,
  //   getTargetPublishData,
  //   publishData,
  // } from '../dataManage';
  import VoucherLayer from '@/components/VoucherLayerConfirm';
  import { userRegister, createWorkOrder } from '@/api/newPublish';
  import { userCheck, loadInfoByCard, userNameConfiger } from '@/api/user';
  import {
    dicKeys,
    getAllDics,
    getDicDesByCode,
    getDicCodeByDes,
  } from '@/methods/dics';
  import store from '@/store';
  import picType from '@/config/picType';
  import { ocrRequest } from '@/api/ocr';

  let etcUserId = '';
  let voucherPic = null;
  let ruleusercode = /^[A-Za-z0-9()-]+$/;
  let isNewQ;
  export default {
    inject: ['reload'],
    data() {
      return {
        newpath: '',
        step: 0,
        newForm: {},
        flagg: true,
        disabled: false,
        loading: false,
        iclass: '',
        isNew: isNewQ,
        // isNew: '1',
        changeable: true,
        ehicleTypeTimer: null,
        form: {
          imageList: [], // 用户身份证照片
          zipCode: '',
          department: '部门管理',
        },
        rules: {
          userName: [
            { required: true, message: '请输入用户名称', trigger: 'blur' },
            { max: 64, message: '长度不能超过64个字符', trigger: 'blur' },
          ],
          userProperty: [
            { required: true, message: '请选择用户类型', trigger: 'blur' },
          ],
          userCertType: [
            { required: true, message: '请选择证件类型', trigger: 'blur' },
          ],
          userCode: [
            {
              required: true,
              message: '证件号码校验失败',
              trigger: 'blur',
            },
            { max: 32, message: '长度不能超过32个字符', trigger: 'blur' },
            {
              validator(rule, value, callback) {
                if (vzz(ruleusercode, value)) {
                  callback();
                } else {
                  callback(new Error('证件格式有误'));
                }
              },
              trigger: 'blur',
            },
          ],
          address: [
            { required: true, message: '请输入联系地址', trigger: 'blur' },
            { max: 64, message: '长度不能超过64个字符', trigger: 'blur' },
          ],
          zipCode: [
            { required: true, message: '请输入邮政编码', trigger: 'blur' },
            { max: 6, message: '长度不能超过6个字符', trigger: 'blur' },
          ],
          userPhone: [
            { required: true, message: '请输入固定联系电话', trigger: 'blur' },
            { max: 16, message: '固定电话号不能超过16个字符', trigger: 'blur' },
            {
              validator(rule, value, callback) {
                if (isNewQ == '1') {
                  if (validGDPhone(value)) {
                    callback();
                  } else {
                    console.log(7777777);
                    callback(new Error('固定电话号格式有误'));
                  }
                } else {
                  callback();
                }
              },
              trigger: 'blur',
            },
          ],
          userPhone2: [
            { required: true, message: '请输入手机号', trigger: 'blur' },
            { max: 13, message: '电话号不能超过11个字符', trigger: 'blur' },
            {
              validator(rule, value, callback) {
                // if (isNew == '1') {
                if (validPhone(value)) {
                  callback();
                } else {
                  callback(new Error('手机号码格式有误'));
                }
                // } else {
                //   callback();
                // }
              },
              trigger: 'blur',
            },
          ],
          eMail: [
            { max: 60, message: '电子邮箱不能超过60个字符', trigger: 'blur' },
            {
              validator(rule, value, callback) {
                if (validEmail(value)) {
                  callback();
                } else {
                  callback(new Error('电子邮箱格式有误'));
                }
              },
              trigger: 'blur',
            },
          ],

          department: [
            { required: true, message: '请输入分支机构', trigger: 'blur' },
            { max: 64, message: '长度不能超过64个字符', trigger: 'blur' },
          ],
          agentName: [
            { required: true, message: '请输入代理人姓名', trigger: 'blur' },
            { max: 64, message: '长度不能超过64个字符', trigger: 'blur' },
          ],
          agentIdType: [
            { required: true, message: '请选择代理人证件类型', trigger: 'blur' },
            { max: 3, message: '长度不能超过3个字符', trigger: 'blur' },
          ],
          agentIdNum: [
            { required: true, message: '请输入代理人证件号码', trigger: 'blur' },
            { max: 32, message: '长度不能超过32个字符', trigger: 'blur' },
            {
              validator(rule, value, callback) {
                if (vzz(ruleusercode, value)) {
                  callback();
                } else {
                  callback(new Error('证件格式有误'));
                }
              },
              trigger: 'blur',
            },
          ],
          agentPhoneNum: [
            { required: true, message: '请输入代理人手机号', trigger: 'blur' },
            { max: 11, message: '长度不能超过11个字符', trigger: 'blur' },
          ],
        },
        voucherKeys: [],
        voucherData: {
          businessType: '用户注册',
        },
        voucherVisible: false,
        transactorDialogVisible: false, // 经办人信息弹窗
        workOrderID: '', // 工单号
        agentPics: [], // 代理人证件图片
        userPics: [], // 用户图片
        transactorImg: [],
      };
    },
    components: {
      PhotographBlock,
      VoucherLayer,
      TransactorDialog,
      RegexInput,
    },
    watch: {
      // 'form.userPhone2'(val) {
      //   if (val.length == 11 && this.changeable === false) {
      //     val = val
      //       .replace(/\s/g, ' ')
      //       .replace(/(\d{3})(\d{4})?(\d{4})?/, '$1 $2 $3');
      //     this.$set(this.form, 'userPhone2', val);
      //   } else if (val.length < 13 && this.changeable === true) {
      //     if (val.length > 3 && val.length < 7) {
      //       val = val
      //         .replace(/\s/g, ' ')
      //         .replace(/[^\d]/g, ' ')
      //         .replace(/(\d{3})(?=\d)/g, '$1 ');
      //     } else if (val.length >= 7) {
      //       val = val
      //         .replace(/\s/g, ' ')
      //         .replace(/[^\d]/g, ' ')
      //         .replace(/(\d{4})(?=\d)/g, '$1 ');
      //     }
      //     this.$set(this.form, 'userPhone2', val);
      //   }
      // },
      'form.userCertType'(val) {
        if (picType[val] && picType[val].belong === 'company') {
          this.$set(this.form, 'userProperty', '2');
        } else {
          this.$set(this.form, 'userProperty', '1');
        }
        this.queryUser();
        // this.changeable = true;
        ruleusercode = getcodezz(val);
        // alert(ruleusercode);
      },

      'form.userCode'(val) {
        // if (this.form.userCertType == '101') {
        //   val = val.replace(/\s/g, '');
        //   var idValue = val;
        //   if (idValue != '') {
        //     var idLength = idValue.length;
        //     if (idLength <= 6) {
        //       idValue = idValue;
        //     } else {
        //       if (idLength <= 10) {
        //         idValue =
        //           idValue.substring(0, 6) + ' ' + idValue.substring(6, idLength);
        //       } else {
        //         if (idLength <= 14) {
        //           idValue =
        //             idValue.substring(0, 6) +
        //             ' ' +
        //             idValue.substring(6, 10) +
        //             ' ' +
        //             idValue.substring(10, idLength);
        //         } else {
        //           idValue =
        //             idValue.substring(0, 6) +
        //             ' ' +
        //             idValue.substring(6, 10) +
        //             ' ' +
        //             idValue.substring(10, 14) +
        //             ' ' +
        //             idValue.substring(14, idLength);
        //         }
        //       }
        //     }
        //   }

        //   // val = val
        //   //   .replace(/\s/g, ' ')
        //   //   .replace(/(\d{6})(\d{4})?(\d{4})?(\d{4})/, '$1 $2 $3 $4');
        //   this.$set(this.form, 'userCode', idValue);
        // }
        // this.changeable = true;
        this.queryUser();
      },
      '$store.getters.registerUser.etcUserId'() {
        this.reshow();
        this.createWorkOrder();
      },
    },
    methods: {
      async queryUser() {
        const self = this;
        if (self.ehicleTypeTimer) clearTimeout(self.ehicleTypeTimer);
        self.ehicleTypeTimer = setTimeout(async () => {
          if (self.form.userCode.replace(/\s/g, '') && self.form.userCertType) {
            const checkRes = await userCheck({
              userCertType: self.form.userCertType,
              userCode: self.form.userCode.replace(/\s/g, ''),
              userName: self.form.userName,
            });
            if (!(checkRes && checkRes.etcUserId)) {
              this.isNew = '1';
              isNewQ = '1';
              self.changeable = true;
              self.$set(self.form, 'department', '部门管理');
              return;
            }
            self.changeable = false;
            this.isNew = '2';
            isNewQ = '2';
            etcUserId = checkRes.etcUserId;

            const userRes = await loadInfoByCard({
              userCertType: self.form.userCertType,
              userCode: self.form.userCode.replace(/\s/g, ''),
              etcUserId: checkRes.etcUserId,
            });
            if (userRes) {
              self.form = {
                ...userRes,
                // userPhone2: userRes.phoneNum,
              };
              //self.form.eMail = '1111';
            }
            // console.log('userRes');
            // console.log(userRes);
          }
        }, 1500);
        // 查询当前用户信息
      },

      // 获取代理人证件图片
      agentComplete(imgs) {
        const self = this;
        self.agentPics = imgs;
        // 获取识别结果，赋值显示
        const currentPic = imgs[imgs.length - 1];
        const ocr = imgs[imgs.length - 1].ocr;
        if (ocr) {
          if (ocr && currentPic.type === '101-1') {
            self.$set(self.form, 'agentName', ocr.userName);
            self.$set(self.form, 'agentIdType', ocr.userCertType.slice(0, -1));
            self.$set(self.form, 'agentIdNum', ocr.userCode);
          }
        }
      },
      // 获取所有图片信息
      getAllPicInfo() {
        const self = this;
        self.form.imageList = [];
        // 开户人证件信息
        self.userPics.forEach((pic) => {
          self.form.imageList.push({
            imgFrontID: pic.frontImgid,
            imgType: pic.type.replace('-', ''),
            mediaType: '1',
          });
        });
        //单位用户
        if (self.form.userProperty === '2') {
          // 代理人证件信息
          self.agentPics.forEach((pic) => {
            self.form.imageList.push({
              imgFrontID: pic.frontImgid,
              imgType: pic.type.replace('-', ''),
              mediaType: '8',
            });
          });
          // 经办人证件信息
          self.$store.getters.transactorImg.forEach((pic) => {
            self.form.imageList.push({
              imgFrontID: pic.frontImgid,
              imgType: pic.type.replace('-', ''),
              mediaType: '4',
            });
          });
        }
        // 用户凭证图片信息
        self.form.imageList.push({
          imgFrontID: voucherPic.frontImgid,
          imgType: '4011',
          mediaType: '5',
        });
      },
      // 选择图片
      async complete(imgs) {
        const self = this;
        self.userPics = imgs;
        // 获取识别结果，赋值显示
        const currentPic = imgs[imgs.length - 1];
        const ocr = imgs[imgs.length - 1].ocr;
        if (ocr) {
          this.disabled = true
          if (ocr && currentPic.type === '101-1') {
            // debugger;
            // if (!ocr.userCode) {
            //   const ocrres = await ocrRequest({
            //     imgType: 1011,
            //     fileType: '1',
            //     img: currentPic.url,
            //   });
            //   alert(currentPic);
            // }
            if (ocr.userName) {
              self.$set(self.form, 'userName', ocr.userName);
            }
            if (ocr.userCertType) {
              self.$set(self.form, 'userCertType', ocr.userCertType.slice(0, -1));
            }
            if (ocr.userCode) {
              self.$set(self.form, 'userCode', ocr.userCode);
            }
            if (ocr.address) {
              self.$set(self.form, 'address', ocr.address);
            }
            self.$set(self.form, 'userCertType', '101');
          } else if (ocr && currentPic.type === '203-1') {
            if (ocr.name) {
              self.$set(self.form, 'userName', ocr.name);
            }
            if (ocr.address) {
              self.$set(self.form, 'address', ocr.address);
            }
            if (ocr.regNum) {
              if (ocr.regNum == self.form.userCode.replace(/\s/g, '')) {
                this.queryUser();
              }
              self.$set(self.form, 'userCode', ocr.regNum);
            }
            self.$set(self.form, 'userProperty', '2');
            self.$set(self.form, 'userCertType', '203');
          }
          this.disabled = false
          return;
        }
      },

      openOcrUnCatch(res) {
        const self = this;
        self
          .$confirm('Ocr识别失败，是否重试', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          })
          .then(() => { })
          .catch(() => { });
      },

      onSubmit() {
        const self = this;
        if (self.userPics.length === 0) {
          this.$alert('请上传证件');
          return;
        }
        // 表单验证
        self.$refs.form.validate(async (valid) => {
          this.createWorkOrder();
          if (valid) {
            let oldForm = JSON.stringify(self.form);
            let newForm = JSON.stringify(self.newForm);
            if (newForm === oldForm) {
              if (!this.workOrderID) {
                this.createWorkOrder();
              }
              let vp = voucherPic;
              this.submitVoucher(vp);
              return;
            }
            self.newForm = { ...self.form };

            let colorgray = '#8B8C8F';
            let colorblue = 'blue';
            let colorchange = '#8B8C8F';
            let fontChange = '';
            if (self.form.userProperty === '1') {
              colorchange = 'blue';
              fontChange = 'bold';
            }
            // 如果是新用户，走注册流程，老用户，未实名，则调用实名，已实名，则直接到车辆注册页面
            const baseVoucherKeys = [
              [{ key: 'businessType', label: '业务类型' }],
              [
                {
                  key: 'userName',
                  label: '用户名称',
                  color: 'blue',
                  fontWeight: 'bold',
                },
                {
                  key: 'userProperty',
                  label: '用户类型',
                  color: 'blue',
                  fontWeight: 'bold',
                },
                {
                  key: 'userCode',
                  label: '证件号码',
                  color: 'blue',
                  fontWeight: 'bold',
                },
                {
                  key: 'userCertType',
                  label: '证件类型',
                  color: 'blue',
                  fontWeight: 'bold',
                },
                { key: 'address', label: '联系地址' },
                { key: 'zipCode', label: '邮政编码' },
                { key: 'userPhone', label: '固定电话' },
                {
                  key: 'userPhone2',
                  label: '手机号码',
                  color: colorchange,
                  fontWeight: fontChange,
                },
                { key: 'eMail', label: '电子邮箱' },
                { key: 'note', label: '备注' },
              ],
            ];
            if (self.form.userProperty === '1') {
              self.voucherKeys = baseVoucherKeys;
            } else {
              if (this.isNew === '1') {
                self.voucherKeys = baseVoucherKeys.concat([
                  [
                    {
                      key: 'department',
                      label: '分支机构名称',
                      labelWidth: '100px',
                      color: 'blue',
                      fontWeight: 'bold',
                    },
                    {
                      key: 'agentName',
                      label: '代理人姓名',
                      labelWidth: '100px',
                      color: 'blue',
                      fontWeight: 'bold',
                    },
                    {
                      key: 'agentIdType',
                      label: '代理人证件类型',
                      labelWidth: '100px',
                      color: 'blue',
                      fontWeight: 'bold',
                    },
                    {
                      key: 'agentIdNum',
                      label: '代理人证件号码',
                      labelWidth: '100px',
                      color: 'blue',
                      fontWeight: 'bold',
                    },
                    {
                      key: 'agentPhoneNum',
                      label: '代理人联系方式',
                      labelWidth: '100px',
                      color: 'blue',
                      fontWeight: 'bold',
                    },
                  ],
                ]);
              } else {
                self.voucherKeys = baseVoucherKeys;
              }
            }
            self.voucherData = {
              ...self.voucherData,
              ...self.form,
              userCertType: await getDicDesByCode(
                dicKeys.userCertType,
                self.form.userCertType
              ),
              userProperty: await getDicDesByCode(
                dicKeys.userType,
                self.form.userProperty
              ),
              agentIdType: await getDicDesByCode(
                dicKeys.userCertType,
                self.form.agentIdType
              ),
            };
            // self.voucherVisible = true;

            self.voucherVisible = true;
            //console.log(voucherPic);
            self.$nextTick(() => {
              //执行调用
              self.$refs.mychild.sendpad();
            });
          } else {
            return false;
          }
        });
      },
      saveTransactorImg(transactorImg) {
        this.$store.dispatch('GetTransactorImg', transactorImg);
      },
      // 点击上传经办人证件提交按钮
      transactorDialogComplete(transactorImg) {
        //保存经办人信息图片
        this.$store.dispatch('GetTransactorImg', transactorImg);
        // this.voucherVisible = true;
        // 发起注册
        this.toRegister();
      },
      // 点击凭证取消按钮
      clearForm() {
        //alert(111);
        this.newForm = {};
      },
      // 点击凭证提交按钮
      async submitVoucher(vp) {
        const self = this;
        const transactorImg = this.$store.getters.transactorImg;
        voucherPic = vp;
        // 如果是单位用户，且没有上传过经办人证件的，弹窗上传经办人证件
        if (self.form.userProperty === '2' && transactorImg.length === 0) {
          this.$confirm(
            '单位用户需要上传经办人证件信息，是否继续？',
            '确认信息',
            {
              distinguishCancelAndClose: true,
              confirmButtonText: '去上传',
              cancelButtonText: '取消',
            }
          ).then(() => {
            self.transactorDialogVisible = true;
          });
        } else {
          self.toRegister();
        }
        console.log(voucherPic);
        return voucherPic;
      },
      // 发起用户注册
      async toRegister() {
        const self = this;
        // const transactorImg = this.$store.getters.transactorImg;
        self.loading = true;
        let timer1 = setTimeout(() => {
          self.loading = false;
        }, 10000);
        if (!self.form.imageList) {
          self.form.imageList = [];
        }

        // 获取所有图片信息
        self.getAllPicInfo();
        const param = {
          workOrderID: self.workOrderID,
          ...self.form,
        };
        param.userPhone2 = self.form.userPhone2.replace(/\s/g, '');
        param.userCode = self.form.userCode.replace(/\s/g, '');
        console.log('param');
        console.log(param);
        setTimeout(() => {
          this.flagg = true;
        }, 8000);
        if (this.flagg == true) {
          this.flagg = false;
          const res = await userRegister(param);

          if (res) {
            if (res.errorMsg) {
              // 将接口的指定出参字段提示出来
              this.$alert(res.errorMsg, '提示', {
                confirmButtonText: '确定',
                type: 'error',
              });
              return;
            }
            self.saveUserInfoThenLeave(res.etcUserId);
            // clearTimeout(timer);
            // self.loading = false;
          }
        }
        // 不再区分新老用户是否实名等情况，统一提交后台验证

        clearTimeout(timer1);
        self.loading = false;
        return;

        if (self.changeable || self.isNew === '1') {
          // 即使是老用户，一旦修改了证件信息，即认为是新用户
          const res = await userRegister(param);
          if (res) {
            if (res.errorMsg) {
              // 将接口的指定出参字段提示出来
              this.$alert(res.errorMsg, '提示', {
                confirmButtonText: '确定',
                type: 'error',
              });
              return;
            }
            self.saveUserInfoThenLeave(res.etcUserId);
          }
        } else if (self.form.identifyFlag === '0') {
          // 老用户已实名
          self.saveUserInfoThenLeave(etcUserId);
        } else {
          this.$confirm('该用户还未实名，是否前往实名？', '提示', {
            confirmButtonText: '去实名',
            cancelButtonText: '取消',
            type: 'warning',
          })
            .then(async () => {
              // 老用户未实名
              const userNameConfigerRes = await userNameConfiger({
                etcUserId,
                workOrderID: this.workOrderID,
                imageList: self.form.imageList,
              });
              if (userNameConfigerRes) {
                self.saveUserInfoThenLeave(etcUserId);
              }
            })
            .catch(() => {
              this.$message({
                type: 'info',
                message: '已取消实名',
              });
            });
        }
      },
      // 保存用户数据，打开车辆注册页面
      saveUserInfoThenLeave(
        etcUserId = this.$store.getters.registerUser.etcUserId
      ) {
        const self = this;

        const pzpic = {
          imgFrontID: voucherPic.frontImgid,
          imgType: '4011',
          mediaType: '5',
          url: voucherPic.img,
        };

        // 保存此次操作数据
        self.$store.dispatch('GetRegisterUser', {
          // ...this.$store.getters.registerUser,
          ...self.form,
          etcUserId,
          // 用户注册图片信息
          userPics: self.userPics,
          // 代理人证件信息
          agentPics: self.agentPics,
          userpzpic: pzpic,
          transactorImg: self.$store.getters.transactorImg,
        });
        console.log('this.$store.getters.registerUser');
        console.log(this.$store.getters.registerUser);
        // let newPath;
        // if ('newpublishperson' === self.$router.currentRoute.path.split('/')[1]) {
        //   newPath = '/newpublishperson/carregisterinput';
        // } else {
        //   newPath = '/newpublish/carregisterinput';
        // }
        // console.log('newPath', newPath);
        // self.$router.push({
        //   // path: '/newpublish/carregisterinput',
        //   path: newPath,
        //   query: {
        //     uct: self.form.userCertType,
        //     uc: self.form.userCode.replace(/\s/g, ''),
        //     euid: etcUserId,
        //     woid: self.workOrderID,
        //   },
        // });

        if ('newpublishperson' === self.$router.currentRoute.path.split('/')[1]) {
          self.newPath = '/newpublishperson/carregisterinput';
        } else {
          self.newPath = '/newpublish/carregisterinput';
        }
        self.$router.push({
          // path: '/newpublish/carregisterinput',
          path: '/vissueverification',
          query: {
            pathh: self.newPath,
            userProperty: self.form.userProperty,
            uct: self.form.userCertType,
            uc: self.form.userCode.replace(/\s/g, ''),
            euid: etcUserId,
            woid: self.workOrderID,
          },
        });
      },

      // 回显保存的数据
      reshow() {
        const localUser = this.$store.getters.registerUser;
        this.form = {
          ...this.form,
          ...localUser,
        };
        // 新老用户判断
        if (localUser.etcUserId) {
          this.$nextTick(() => {
            this.isNew = '2';
            isNewQ = '2';
            this.changeable = false;
          });
        }
        // 用户注册图片信息
        this.userPics = localUser.userPics || [];
        // 代理人证件信息
        this.agentPics = localUser.agentPics || [];
        this.transactorImg = localUser.transactorImg || [];
      },
      // 创建工单
      async createWorkOrder() {
        const res = await createWorkOrder('05');
        this.workOrderID = (res && res.workOrderID) || '';
      },
      get0015info() {
        const res = get15info();
        if (res) {
          console.log('0015info');
          console.log(res);
        }
      },
      get0016info() {
        const res = get16info();
        if (res) {
          console.log('0016info');
          console.log(res);
        }
      },
      getmf01df01() {
        new Promise(function (resolve, reject) {
          const res = getmf01info();
          if (res) {
            console.log('mf01_info');
            console.log(res);
          }
          resolve();
        }).then(function () {
          setTimeout(() => {
            var res2 = getdf01Info();
            if (res2) {
              console.log('df01_info');
              console.log(res2);
            }
            if (!res2) {
              console.log('null');
            }
          }, 1000);
        });
      },
      getpurchaserecord() {
        const res = purchaserecord();
        if (res) {
          console.log('最近五十条记录');
          console.log(res);
        }
      },
      // async getdf01() {
      //   var res = await getdf01Info();
      //   setTimeout(() => {
      //     if (res) {
      //       console.log('df01_info');
      //       console.log(res);
      //     }
      //     if (!res) {
      //       console.log('null');
      //     }
      //   }, 2000);
      // },
    },
    mounted() {
      // self.reload();

      etcUserId = this.$store.getters.registerUser.etcUserId;
      if (etcUserId) {
        isNewQ = '2';
      } else {
        isNewQ = '1';
      }
      this.isNew = isNewQ;
      // 回显数据
      this.reshow();
      // this.get0015info();
      // this.get0016info();
      // this.getmf01df01();
      //this.getdf01();
      //this.getpurchaserecord();
      // 创建工单
      // this.createWorkOrder();
    },
  };
</script>
<style>
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
  }

  input[type='number'] {
    -moz-appearance: textfield;
  }

  .miles {
    height: 80px;
    line-height: 113px;
  }
</style>