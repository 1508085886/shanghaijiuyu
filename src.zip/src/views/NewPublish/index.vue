<!-- 新办发行 -->
<template>
  <div class="offline-new-publish">
    <div class="offline-new-publish_title-wrap">
      <h4 class="offline-new-publish_title">新办发行</h4>
      <span class="offline-new-publish_title-remark"></span>
    </div>
    <div class="offline-new-publish_container">
      <el-steps :active="step" finish-status="finish">
        <el-step title="用户注册"></el-step>
        <!-- <el-step title="用户注册凭证"></el-step> -->
        <el-step title="车辆注册"></el-step>
        <el-step title="银行签约"></el-step>
        <!-- <el-step title="发行申请"></el-step> -->
      </el-steps>
      <keep-alive>
        <router-view class="mt20"></router-view>
      </keep-alive>
    </div>
  </div>
</template>

<script>
import store from '@/store';
export default {
  name: 'NewPublish',
  data() {
    return {};
  },
  computed: {
    step() {
      return this.$route.meta.step || 0;
    },
  },
  // beforeRouteEnter(to, from, next) {
  //   // ...
  //   if (from.path === '/menu') {
  //     store.dispatch('ClearRegisterVehicle');
  //   }
  //   next();
  // },
};
</script>
