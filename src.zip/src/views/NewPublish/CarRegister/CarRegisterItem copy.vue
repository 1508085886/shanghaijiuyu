<!-- 车辆注册 -->
<template>
  <div>
    <div class="o-flex o-flex-align-center pb15">
      <h4>
        当前已录入车辆数：
        <span class="offline-car-register_input-count">{{ info.length }}</span>
      </h4>
      <el-button round size="small ml0" @click="addCarInfo">
        <i class="el-icon-plus"></i> 继续录入车辆
      </el-button>
    </div>
    <div>
      <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
        <el-tab-pane label="未收费" name="first">
          <car-info :info="car" v-for="(car, i) in notpay" :key="i">
            <template slot="buttons">
              <el-button type="primary" size="mini" v-if="false"
                >卡片发行</el-button
              >
              <el-button type="primary" size="mini" v-if="false"
                >标签发行</el-button
              >
            </template>
          </car-info>
          <div>
            <el-row :gutter="20">
              <el-col :span="6">
                <div class="grid-content bg-purple">
                  <h5>请选择付款方式</h5>
                </div>
              </el-col>

              <el-col :span="6" :offset="6">
                <div class="grid-content bg-purple">
                  <h5>设计费合计</h5>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content bg-purple">
                  <h5>安装费合计</h5>
                </div>
              </el-col>
            </el-row>

            <el-row :gutter="20">
              <el-col :span="6">
                <div class="grid-content bg-purple">
                  <el-select v-model="value" placeholder="请选择">
                    <el-option
                      v-for="item in options"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    ></el-option>
                  </el-select>
                </div>
              </el-col>
              <el-col :span="6" :offset="6">
                <div class="grid-content bg-purple">
                  <h3>{{ sumamount }}</h3>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content bg-purple">
                  <h3>101.00元</h3>
                </div>
              </el-col>
            </el-row>

            <div>
              <!-- 
              <el-button @click="$router.back()">上一步</el-button>-->
              <el-button
                type="primary"
                @click="onSubmit"
                style="float: right; right: 10px"
                >发行申请</el-button
              >
            </div>
          </div>
        </el-tab-pane>

        <el-tab-pane label="已收费,代发行" name="second">
          <form ref="form" :model="form">
            <car-info :info="car" v-for="(car, i) in ispay" :key="i">
              <template slot="buttons">
                <el-button type="primary" size="mini" v-if="true"
                  >卡片发行</el-button
                >
                <el-button type="primary" size="mini" v-if="true"
                  >标签发行</el-button
                >
              </template>
            </car-info>
          </form>
          <div style="padding-top: 20px">
            <el-button
              type="primary"
              @click="onSubmit1"
              style="float: right; right: 10px"
              >凭证签名</el-button
            >
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>

    <o-dialog size="large" title="车辆信息录入" :visible.sync="formVisible">
      <div class="pt15 pb15 pl20 pr20">
        <car-register-form ref="form" />
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="formVisible = false">取 消</el-button>
        <el-button type="primary" @click="confirm">确 定</el-button>
      </div>
    </o-dialog>
    <voucher-layer
      :visible.sync="voucherVisible"
      :keys="voucherKeys"
      :info="voucherData"
      :column="3"
      :footer="voucherFooter"
      @complete="toRegister"
    />
  </div>
</template>

<script>
import ODialog from '@/components/Dialog';
import CarRegisterForm from './CarRegisterForm';
import PhotographBlock from '@/components/PhotographBlock';
import { validPhone } from '@/utils/validate';
import CarInfo from '../CarInfo';
import { deviceOrder } from '@/api/order';
import { registerVehicle } from '@/api/vehicle';
import VoucherLayer from '@/components/VoucherLayer';
export default {
  data() {
    return {
      form: {},
      registerList: [],
      formVisible: false,
      activeName: 'first',
      column: [6, 6, 6, 6, 6],
      voucherKeys: [
        [
          { key: 'businessType', label: '业务类型' },
          { key: 'businessType', label: '销售渠道' },
        ],
        [
          { key: 'userName', label: '用户编号' },
          { key: 'userProperty', label: '用户名称' },
          { key: 'userCode', label: '证件号码' },
          { key: 'userCertType', label: '证件类型' },
          { key: 'address', label: '联系地址' },
          { key: 'zipCode', label: '邮政编码' },
          { key: 'userPhone', label: '固定电话' },
          { key: 'userPhone2', label: '手机号码' },
          { key: 'userPhone2', label: '电子邮箱' },
          { key: 'note', label: '备注' },
        ],
        [
          { key: 'userName', label: '卡种' },
          { key: 'userProperty', label: '卡号' },
          { key: 'userCode', label: '卡状态' },
          { key: 'userCertType', label: '卡片有效期', span: '3' },
          { key: 'address', label: '标签ID' },
          { key: 'zipCode', label: '标签表面号' },
          { key: 'zipCode', label: '标签状态' },
          { key: 'zipCode', label: '标签有效期' },
        ],
      ],
      voucherData: {
        businessType: '用户注册',
        userName: '',
        userProperty: '',
        userCode: '',
        userCertType: '',
        address: '',
        zipCode: '',
        userPhone: '',
        userPhone2: '',
        note: '',
      },
      voucherFooter: {
        date: '2020/9/12',
        outletId: '10001',
        operator: '龙傲天',
      },
      voucherVisible: false,
    };
  },
  computed: {
    sumamount() {
      const para = this.info.filter((item) => item.isChecked);
      if (para.length) {
        return para.reduce((total, item) => {
          return total + 1;
        }, 0);
      }
      return 0;
    },

    notpay() {
      return this.info.filter((item) => !item.payflag);
    },

    ispay() {
      return this.info.filter((item) => item.payflag);
    },
  },
  components: {
    ODialog,
    CarRegisterForm,
    CarInfo,
    PhotographBlock,
    VoucherLayer,
  },
  props: {
    info: {
      type: Array,
      default: [],
    },
  },
  watch: {
    info(val) {
      console.log('info', val);
    },
  },
  methods: {
    onSubmit1() {
      const self = this;
      // 表单验证
      // self.$refs.form.validate(async (valid) => {
      //   if (valid) {
      //     self.voucherData = {
      //       ...self.voucherData,
      //       ...self.form,
      //       userCertType: await getDicDesByCode(
      //         dicKeys.userCertType,
      //         self.form.userCertType
      //       ),
      //       userProperty: await getDicDesByCode(
      //         dicKeys.userType,
      //         self.form.userProperty
      //       ),
      //     };
      self.voucherVisible = true;
      //   } else {
      //     return false;
      // }
      // });
    },
    async confirm() {
      const formData = this.$refs.form.getFormData();
      const res = await registerVehicle({
        ...formData,
      });
      if (res && res.errorMsg) {
        // 将接口的指定出参字段提示出来
        this.$alert(res.errorMsg, '提示', {
          confirmButtonText: '确定',
          type: 'error',
        });
        return;
      }
      this.$store.dispatch('GetRegisterVehicle', formData);
      this.formVisible = false;
    },

    async addCarInfo() {
      this.formVisible = true;
    },
    // 发行申请
    publishApply() {
      // const self = this;
      // const query = self.$route.query;
      // const carInfo = (self.info && self.info[0]) || {};
      // // 新办订单申请
      // deviceOrder({
      //   etcUserId: query.euid,
      //   orderId: '', // 申请单编号，目前不确定
      //   deliveryMode: '2', // 配送方式
      //   // deliveryInfo: {}, // 配送信息，目前没有
      //   orderCreateTime: '', // 订单创建时间，目前没有，应该是在注册车辆时生成
      //   orderType: '1', // 订单类型，1为新发订单
      //   vehicleNumber: carInfo.vehicleNumber, // 车牌号码
      //   vehicleColor: carInfo.vehicleColor, // 车牌颜色
      //   deviceAmount: 360, // 设备费用
      //   serviceAmount: 0, // 服务费
      //   deliveryAmount: 0, // 物流费
      //   totalAmount: 360, // 费用总计
      //   payStatus: '2', // 未支付
      //   payChannelId: carInfo.payChannelId, // 支付渠道id
      //   subPayChannelId: carInfo.subPayChannelId, // 给渠道下的子机构使用
      // });
      // this.$router.push('/newpublish/banksign');

      for (let i = 0; i < this.info.length; i++) {
        if (this.info[i].isChecked) {
          this.info[i].payflag = true;
        }
      }
      console.log(this.info);
    },
  },
  mounted() {},
};
</script>


<style>
.div.el-tabs__nav-scroll {
  padding: top 50px;
}
</style>
