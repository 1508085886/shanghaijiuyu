<!-- 车辆注册表单 -->
<template>
  <div>
    <div class="o-flex">
      <photograph-block type="vehicleCertType" @complete="getPhotoInfo" ocr class="mr20" :append-to-body="true" />
    </div>
    <!-- 
    <empty-button
      class="offline-car-register-form_clear-button"
      size="small"
      @click="clear"
      round
    >
      <i class="el-icon-refresh" /> 清除
    </empty-button>-->
    <el-form ref="form" :model="form" :rules="rules" class="mt10">
      <el-row class="offline-car-register-form_ocr mt20">
        <el-col class="offline-car-register-form_ocr-info pt15 pb15 pl20 pr20" :lg="12">
          <h5>行驶证印章页</h5>
          <el-row :gutter="10">
            <el-col :md="12">
              <el-form-item label="车牌号码" prop="vehicleNumber" class="jiacu">
                <el-input v-model="form.vehicleNumber" spellcheck="false"></el-input>
                <!-- <regex-input
                  v-model="form.vehicleNumber"
                  spellcheck="false"
                  type="vehicleNumber"
                ></regex-input> -->
              </el-form-item>
            </el-col>
            <el-col :md="12">
              <el-form-item label="车辆类型" prop="dzfpVehicleType" class="jiacu">
                <el-input v-model="form.dzfpVehicleType" spellcheck="false"></el-input>
              </el-form-item>
            </el-col>
            <!-- <el-col :md="12">
              <el-form-item label="车辆类型" prop="dzfpVehicleType">
                <type-select
                  type="vehicleType"
                  v-model="form.dzfpVehicleType"
                  class="o-width-full"
                  @input="getVehicleType"
                ></type-select>
              </el-form-item>
            </el-col> -->
            <el-col :span="24">
              <el-form-item label="车辆所有人" prop="ownerName">
                <el-input v-model="form.ownerName" class="offline-car-register-form_ownerinfo-input" spellcheck="false">
                  <el-button v-if="fixCarOwnerInfoBtnDisplay" slot="append" @click="openFixCarOwnernfo">车主信息</el-button>
                </el-input>
              </el-form-item>
            </el-col>
            <!-- <el-col :span="4">
              <div style="height: 35px;"></div>
              <el-button
                class="offline-car-register-form_fixuserinfo-button"
                type="primary"
                >车主信息</el-button
              >
            </el-col>-->
            <el-col :span="24">
              <el-form-item label="住址" prop="address">
                <el-input v-model="form.address" spellcheck="false"></el-input>
              </el-form-item>
            </el-col>
            <el-col :md="12">
              <el-form-item label="使用性质" prop="vehicleSpecies">
                <el-input v-model="form.vehicleSpecies" spellcheck="false"></el-input>
              </el-form-item>
            </el-col>
            <el-col :md="12">
              <el-form-item label="品牌型号" prop="viModelName">
                <el-input v-model="form.viModelName" spellcheck="false"></el-input>
              </el-form-item>
            </el-col>
            <el-col :md="24">
              <el-form-item label="车辆识别代号" prop="vin">
                <el-input v-model="form.vin" spellcheck="false"></el-input>
              </el-form-item>
            </el-col>
            <el-col :md="24">
              <el-form-item label="发动机号码" prop="engineNum">
                <el-input v-model="form.engineNum" spellcheck="false"></el-input>
              </el-form-item>
            </el-col>
            <el-col :md="12">
              <el-form-item label="注册日期" prop="viRegisterDate">
                <el-date-picker v-model="form.viRegisterDate" value-format="yyyy-MM-dd" type="date" placeholder="选择日期">
                </el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :md="12">
              <el-form-item label="发证日期" prop="viIssueDate">
                <el-date-picker v-model="form.viIssueDate" type="date" value-format="yyyy-MM-dd" placeholder="选择日期">
                </el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
        </el-col>
        <el-col class="offline-car-register-form_ocr-info pt15 pb15 pl20 pr20" :lg="12">
          <h5>行驶证条码页</h5>
          <el-row :gutter="10">
            <el-col :md="12">
              <el-form-item label="车牌号码" prop="vehicleNumber2" class="jiacu">
                <el-input v-model="form.vehicleNumber2" spellcheck="false"></el-input>
                <!-- <regex-input
                  v-model="form.vehicleNumber"
                  spellcheck="false"
                  type="vehicleNumber"
                ></regex-input> -->
              </el-form-item>
            </el-col>
            <el-col :md="12">
              <el-form-item label="档案编号" prop="viFileNum">
                <el-input v-model="form.viFileNum" spellcheck="false"></el-input>
              </el-form-item>
            </el-col>
            <el-col :md="12">
              <el-form-item label="核定载人数" prop="approvedAccount" :class="iclass">
                <!-- type="number" -->
                <el-input onkeyup="value=value.replace(/[^0-9\-]/g,'')" v-model="form.approvedAccount"
                  @mousewheel.native.prevent spellcheck="false"></el-input>
                <!--   @onInput="form.approvedAccount = $event.target.value" -->
              </el-form-item>
            </el-col>
            <el-col :md="12">
              <el-form-item label="总质量KG" prop="viTotalMass" :class="iclass1">
                <el-input v-model="form.viTotalMass" spellcheck="false" onkeyup="value=value.replace(/[^0-9\-]/g,'')">
                </el-input>
              </el-form-item>
            </el-col>
            <el-col :md="12">
              <el-form-item label="整备质量KG" prop="maintenaceMass">
                <el-input v-model="form.maintenaceMass" onkeyup="value=value.replace(/[^0-9\-]/g,'')"
                  spellcheck="false"></el-input>
              </el-form-item>
            </el-col>
            <el-col :md="12">
              <el-form-item label="核定载质量KG" prop="permittedWeight">
                <el-input v-model="form.permittedWeight" onkeyup="value=value.replace(/[^0-9\-]/g,'')"
                  spellcheck="false"></el-input>
              </el-form-item>
            </el-col>
            <el-col :md="24">
              <!-- <el-form-item label="外廓尺寸" prop="outlineDimension">
                <el-input v-model="form.outlineDimension"></el-input>
              </el-form-item> -->
              <el-row :gutter="10">
                <el-col :span="7">
                  <el-form-item label="车长mm" prop="viLength" class="jiacu">
                    <el-input onkeyup="value=value.replace(/[^0-9]/g,'')" @input="getVehicleType"
                      v-model="form.viLength" type="number" @mousewheel.native.prevent spellcheck="false"
                      :maxlength="5"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="1.5" class="miles"> * </el-col>
                <el-col :span="7">
                  <el-form-item label="车宽mm" prop="viWidth" class="jiacu">
                    <el-input onkeyup="value=value.replace(/[^0-9]/g,'')" v-model="form.viWidth" type="number"
                      @mousewheel.native.prevent spellcheck="false"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="1.5" class="miles"> * </el-col>
                <el-col :span="7">
                  <el-form-item label="车高mm" prop="viHeight" class="jiacu">
                    <el-input onkeyup="value=value.replace(/[^0-9]/g,'')" v-model="form.viHeight" type="number"
                      @mousewheel.native.prevent spellcheck="false"></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-col>
            <el-col :md="12">
              <el-form-item label="准牵引总质量KG" prop="permittedTowWeight">
                <el-input v-model="form.permittedTowWeight" onkeyup="value=value.replace(/[^0-9\-]/g,'')"
                  spellcheck="false"></el-input>
              </el-form-item>
            </el-col>
            <el-col :md="24">
              <el-form-item label="备注" prop="note">
                <el-input type="textarea" :rows="3" v-model="form.note" spellcheck="false"></el-input>
              </el-form-item>
            </el-col>
            <el-col :md="24">
              <el-form-item label="检验记录">
                <el-input type="textarea" :rows="3" v-model="form.testRecord" spellcheck="false"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-col>
      </el-row>
      <el-row class="pt15" :gutter="10">
        <el-col :lg="6" :md="12">
          <el-form-item label="车牌颜色" prop="vehicleColor" class="jiacu">
            <type-select type="vehicleColor" v-model="form.vehicleColor" class="o-width-full"></type-select>
          </el-form-item>
        </el-col>
        <el-col :lg="6" :md="12">
          <el-form-item label="车种" prop="vehicleCategory">
            <type-select placeholder="请选择车种" type="vehicleCategory" v-model="form.vehicleCategory" class="o-width-full"
              :readonly="ReadonlyVehicleCategory" :add-options="[{ description: '不能识别', value: '' }]"></type-select>
          </el-form-item>
        </el-col>
        <el-col :lg="6" :md="12">
          <el-form-item label="收费车型" prop="vehicleClass" class="jiacu">
            <type-select type="vehicleClass" v-model="form.vehicleClass" class="o-width-full" :readonly="true">
            </type-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="10">
        <el-col :md="4" :lg="4">
          <el-form-item class="small-label" label="轴数" prop="axleCount" :class="iclass1">
            <el-input v-model="form.axleCount" type="number" placeholder="请输入" @mousewheel.native.prevent
              spellcheck="false"></el-input>
          </el-form-item>
        </el-col>
        <el-col :md="4" :lg="4">
          <el-form-item class="small-label" label="轮胎数" prop="wheelCount">
            <el-input v-model="form.wheelCount" type="number" placeholder="请输入" @mousewheel.native.prevent
              spellcheck="false"></el-input>
          </el-form-item>
        </el-col>
        <el-col :md="4" :lg="4">
          <el-form-item class="small-label" label="轴距mm" prop="axleDistance">
            <el-input v-model="form.axleDistance" type="number" placeholder="请输入" @mousewheel.native.prevent
              spellcheck="false"></el-input>
          </el-form-item>
        </el-col>

        <el-col :lg="8" :md="8">
          <el-form-item label="车辆用户类型" prop="vehicleType" class="jiacu">
            <type-select type="vehicleUserClass" v-model="form.vehicleType" class="o-width-full"
              :readonly="ReadonlyVehicleType"></type-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <!-- <el-col :lg="12">
          <el-form-item label="参与优惠活动" prop="giver">
            <type-select
              type="giver"
              v-model="form.giver"
              class="o-width-full"
            ></type-select>
          </el-form-item>
        </el-col> -->
      </el-row>
      <el-row v-if="$store.getters.registerUser.userProperty === '2'">
        <el-col :span="12">
          <el-form-item label="分支机构" prop="department">
            <el-input readonly v-model="form.department" spellcheck="false"></el-input>
            <!-- placeholder="请选择" -->
            <!-- @focus="organizationVisible = true" -->
          </el-form-item>
        </el-col>
      </el-row>
      <!-- <div>//////////////////////////////////////////////////</div> 
      <el-row v-if="$store.getters.registerUser.userProperty === '2'">
        <el-col :span="12">
          <el-form-item label="分支机构1" prop="department">
            <el-input
              placeholder="请选择"
              readonly
              v-model="form.department"
              @focus="organizationVisible111 = true"
              spellcheck="false"
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>
       <!-- <div>///////////////////////////////////////////////////////</div> -->
    </el-form>
    <complex-table v-if="$store.getters.registerUser.userProperty === '2'" title="分支机构"
      :visible.sync="organizationVisible" :columns="tables" requestListUrl="/branchQuery" :requestListParam="{
        etcUserId:
          this.$store.getters.registerUser.etcUserId || this.$route.query.euid,
        pageNo: 1,
        pageSize: 10,
      }" :responseListFormat="responseListFormat" @getSelected="selectOrganization" insertListUrl="/departmentAdd"
      :append-to-body="true" :defaultValue="[]" />
    <!-- <div>////////////////////////////////////////////////////////////////</div> 
    <complex-table1
      v-if="$store.getters.registerUser.userProperty === '2'"
      title="分支机构1"
      :visible.sync="organizationVisible111"
      :columns="tables"
      requestListUrl="/branchQuery"
      :requestListParam="{
        etcUserId:
          this.$store.getters.registerUser.etcUserId || this.$route.query.euid,
        pageNo: 1,
        pageSize: 5,
      }"
      :responseListFormat="responseListFormat"
      @getSelected="selectOrganization"
      insertListUrl="/departmentAdd"
      :append-to-body="true"
      :defaultValue="[]"
    />
    <!-- <div>///////////////////////////////////////////////////////////////////////</div> -->
    <o-dialog size="large" title="上传车主证件" :visible.sync="fixCarOwnernfoFormVisible">
      <div class="pt15 pb15 pl20 pr20">
        <fix-car-ownernfo ref="fixCarOwnernfoForm" />
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="fixCarOwnernfoFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="commitFixCarOwnerinfo">确 定</el-button>
      </div>
    </o-dialog>
    <!-- <o-dialog :append-to-body="true" title="分支机构" :visible.sync="organizationVisible">
      <el-table
        ref="multipleTable"
        :data="organizations"
        tooltip-effect="dark"
        style="width: 100%"
        @select="handleSelectionChange"
        @select-all="onSelectAll"
      >
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column prop="name" label="分支机构名称"></el-table-column>
        <el-table-column prop="agent" label="代理人姓名"></el-table-column>
        <el-table-column prop="agentCardType" label="代理人证件类型"></el-table-column>
        <el-table-column prop="agentPhone" label="代理人手机号码"></el-table-column>
      </el-table>
      <div slot="footer" class="dialog-footer">
        <el-button @click="organizationVisible = false">取 消</el-button>
        <el-button type="primary" @click="selectOrganization">确 定</el-button>
      </div>
    </o-dialog>-->
  </div>
</template>

<script>
  import { configDate } from '@/utils/date';
  import { validVehicleNumber } from '@/utils/validate';
  import request from '@/utils/request';
  import ODialog from '@/components/Dialog';
  import PhotographBlock from '@/components/PhotographBlock';

  //import FormatInput from '@/components/FormatInput';

  import {
    getVehicleUserType,
    getVehicleType,
    getVehicleClassByVehicleType2,
  } from '@/api/vehicle';
  import { vehicleModelQuery } from '@/api/newPublish';
  import { loadInfoByCard } from '@/api/user';
  import ComplexTable from '@/components/ComplexTable';
  //import ComplexTable1 from '@/components/ComplexTable1';
  import FixCarOwnernfo from '../../Home/FixCarOwnernfo';
  import {
    dicKeys,
    getAllDics,
    getDicDesByCode,
    getDicCodeByDes,
    getDicCodeByAll,
    getDicDesByAll,
  } from '@/methods/dics';
  import { Alert, Input } from 'element-ui';
  import { datas } from '@/config/localDictionary';
  import RegexInput from '@/components/RegexInput';
  import data from '../../../components/PhotographBlock/data';

  export default {
    data() {
      return {
        result: [],
        iclass: '',
        iclass1: '',
        JiaCuJudge2: '',
        JiaCuJudge1: '',
        ReadonlyVehicleType: true,
        ReadonlyVehicleCategory: false,
        fixCarOwnernfoFormVisible: false,
        fixCarOwnerInfoBtnDisplay: false,
        organizationVisible: false,
        organizationVisible111: false,
        ocrData1: {
          ocr: '',
        }, // 行驶证印章页
        ocrData2: {
          ocr: '',
        }, // 行驶证条码页
        ocrData3: {
          ocr: '',
        }, //机动车登记证OCR
        form: {
          etcUserId: this.$store.getters.registerUser.etcUserId,
          userName: '',
          userType: '',
          viownerInfo: {},
          department: '',
          vehicleType: '',
          vehicleCategory: '',
          imageList: [],
          ownerName: '',
          vehicleNumber: '',
        },
        rules: {
          ownerName: [
            { required: true, message: '请输入车辆所有人', trigger: 'blur' },
            { max: 64, message: '长度不能超过64个字符', trigger: 'blur' },
          ],
          address: [
            { required: true, message: '请输入住址', trigger: 'blur' },
            { max: 100, message: '长度不能超过100个字符', trigger: 'blur' },
          ],
          vehicleNumber: [
            { required: true, message: '请输入车牌号码', trigger: 'blur' },
            { max: 12, message: '长度不能超过12个字符', trigger: 'blur' },
            // {
            //   validator(rule, value, callback) {
            //     if (validVehicleNumber(value)) {
            //       callback();
            //     } else {
            //       callback(new Error('车牌号码格式有误'));
            //     }
            //   },
            //   trigger: 'blur',
            // },
          ],
          vehicleNumber2: [
            { required: true, message: '请输入车牌号码', trigger: 'blur' },
            { max: 12, message: '长度不能超过12个字符', trigger: 'blur' },
            // {
            //   validator(rule, value, callback) {
            //     if (validVehicleNumber(value)) {
            //       callback();
            //     } else {
            //       callback(new Error('车牌号码格式有误'));
            //     }
            //   },
            //   trigger: 'blur',
            // },
          ],
          dzfpVehicleType: [
            { required: true, message: '请输入车辆类型', trigger: 'blur' },
            { max: 32, message: '长度不能超过32个字符', trigger: 'blur' },
          ],
          vehicleSpecies: [
            { required: true, message: '请输入使用性质', trigger: 'blur' },
            { max: 32, message: '长度不能超过32个字符', trigger: 'blur' },
          ],
          viModelName: [
            { required: true, message: '请输入品牌型号', trigger: 'blur' },
            { max: 32, message: '长度不能超过32个字符', trigger: 'blur' },
          ],
          vin: [
            { required: true, message: '请输入车辆识别代码', trigger: 'blur' },
            { max: 17, message: '长度不能超过17个字符', trigger: 'blur' },
          ],
          engineNum: [
            { required: true, message: '请输入发动机号', trigger: 'blur' },
            { max: 50, message: '长度不能超过50个字符', trigger: 'blur' },
          ],
          viRegisterDate: [
            { required: true, message: '请选择注册日期', trigger: 'blur' },
            // {
            //   validator(rule, value, callback) {
            //     if (configDate(value)) {
            //       callback();
            //     } else {
            //       callback(new Error('注册日期格式有误'));
            //     }
            //   },
            //   trigger: 'blur',
            // },
          ],
          viIssueDate: [
            { required: true, message: '请选择发证日期', trigger: 'blur' },
            // {
            //   validator(rule, value, callback) {
            //     if (configDate(value)) {
            //       callback();
            //     } else {
            //       callback(new Error('发证日期格式有误'));
            //     }
            //   },
            //   trigger: 'blur',
            // },
          ],
          // viFileNum: [
          //   { required: true, message: '请输入档案编号', trigger: 'blur' },
          // ],
          approvedAccount: [
            { required: true, message: '请输入核定载人数', trigger: 'blur' },
            { max: 4, message: '长度不能超过4个字符', trigger: 'blur' },
          ],
          viTotalMass: [
            { required: true, message: '请输入总质量', trigger: 'blur' },
            { max: 10, message: '长度不能超过10个字符', trigger: 'blur' },
          ],
          maintenaceMass: [
            { required: true, message: '请输入整备质量', trigger: 'blur' },
            { max: 10, message: '长度不能超过10个字符', trigger: 'blur' },
          ],
          permittedWeight: [
            { required: true, message: '请输入核定载质量', trigger: 'blur' },
            { max: 10, message: '长度不能超过10个字符', trigger: 'blur' },
          ],
          permittedTowWeight: [
            { required: true, message: '请输入准牵引总质量', trigger: 'blur' },
            { max: 10, message: '长度不能超过10个字符', trigger: 'blur' },
          ],
          testRecord: [
            { required: true, message: '请输入检验记录', trigger: 'blur' },
            { max: 50, message: '长度不能超过50个字符', trigger: 'blur' },
          ],
          vehicleColor: [
            { required: true, message: '请选择车牌颜色', trigger: 'blur' },
          ],
          viLength: [
            { required: true, message: '请输入车长', trigger: 'blur' },
            {
              validator(rule, value, callback) {
                if (1000 < value && value < 99999) {
                  callback();
                } else {
                  callback(new Error('车长输入范围[1000-99999]'));
                }
              },
              trigger: 'blur',
            },
          ],
          viWidth: [
            { required: true, message: '请输入车宽', trigger: 'blur' },
            {
              validator(rule, value, callback) {
                if (1000 < value && value < 9999) {
                  callback();
                } else {
                  callback(new Error('车宽输入范围[1000-9999]'));
                }
              },
              trigger: 'blur',
            },
          ],
          viHeight: [
            { required: true, message: '请输入车高', trigger: 'blur' },
            {
              validator(rule, value, callback) {
                if (1000 < value && value < 9999) {
                  callback();
                } else {
                  callback(new Error('车高输入范围[1000-9999]'));
                }
              },
              trigger: 'blur',
            },
          ],
          // outlineDimension: [
          //   { required: true, message: '请输入外廓尺寸', trigger: 'blur' },
          // ],
          axleCount: [
            { required: true, message: '请输入车轴数', trigger: 'blur' },
            // { max: 2, message: '长度不能超过2个字符', trigger: 'blur' },
          ],
          wheelCount: [
            { required: true, message: '请输入车轮数', trigger: 'blur' },
            // { max: 4, message: '长度不能超过4个字符', trigger: 'blur' },
          ],
          axleDistance: [
            { required: true, message: '请输入轴距', trigger: 'blur' },
            // { max: 6, message: '长度不能超过6个字符', trigger: 'blur' },
          ],
          carUserType: [
            { required: true, message: '请选择车辆用户类型', trigger: 'blur' },
          ],
          vehicleCategory: [
            { required: true, message: '请选择车种', trigger: 'blur' },
          ],
          //giver: [{ required: true, message: '请选择优惠活动', trigger: 'blur' }],
          department: [
            { required: false, message: '请选择分支机构', trigger: 'blur' },
          ],
          vehicleClass: [
            { required: true, message: '请选择收费车型', trigger: 'blur' },
          ],
          vehicleType: [{ required: true, message: '请选择车辆用户类型' }],
        },
        organizations: [],
        vehicleColors: [],
        vehicleUserTypes: [
          {
            fieldCode: 'agentIdType',
            fieldName: '证件类型',
            description: '身份证（含临时身份证）',
            value: '101',
          },
          {
            fieldCode: 'agentIdType',
            fieldName: '证件类型',
            description: '护照（限外籍人士）',
            value: '102',
          },
          {
            fieldCode: 'agentIdType',
            fieldName: '证件类型',
            description: '港澳居民来往内地通行证',
            value: '103',
          },
          {
            fieldCode: 'agentIdType',
            fieldName: '证件类型',
            description: '台湾居民来往大陆通行证',
            value: '104',
          },
          {
            fieldCode: 'agentIdType',
            fieldName: '证件类型',
            description: '军官证',
            value: '105',
          },
          {
            fieldCode: 'agentIdType',
            fieldName: '证件类型',
            description: '武警警察身份证',
            value: '106',
          },
          {
            fieldCode: 'agentIdType',
            fieldName: '证件类型',
            description: '澳门永久/非永久居民身份证',
            value: '113',
          },
          {
            fieldCode: 'agentIdType',
            fieldName: '证件类型',
            description: '香港永久/非永久居民身份证',
            value: '114',
          },
          {
            fieldCode: 'agentIdType',
            fieldName: '证件类型',
            description: '统一社会信用代码证书',
            value: '201',
          },
          {
            fieldCode: 'agentIdType',
            fieldName: '证件类型',
            description: '组织机构代码证',
            value: '202',
          },
          {
            fieldCode: 'agentIdType',
            fieldName: '证件类型',
            description: '营业执照',
            value: '203',
          },
          {
            fieldCode: 'agentIdType',
            fieldName: '证件类型',
            description: '事业单位法人证书',
            value: '204',
          },
          {
            fieldCode: 'agentIdType',
            fieldName: '证件类型',
            description: '社会团体法人登记证书',
            value: '205',
          },
          {
            fieldCode: 'agentIdType',
            fieldName: '证件类型',
            description: '律师事务所执业许可证',
            value: '206',
          },
        ],
        userInfo: {},
        ehicleTypeTimer: null,
        ehicleTypeTimer2: null,
        tables: [
          {
            name: '分支机构名称',
            filed: 'department',
            edit: true,
          },
          {
            name: '代理人',
            filed: 'agentName',
            edit: true,
          },
          {
            name: '代理人证件号',
            filed: 'agentIdNum',
            edit: true,
          },
          {
            name: '代理人证件类型',
            filed: 'agentIdType',
            format: (val) => {
              return getDicDesByAll(this.vehicleUserTypes, val);
            },
            edit: true,
          },
          {
            name: '代理人手机号码',
            filed: 'agentPhoneNum',
            edit: true,
          },
          {
            name: '是否需要修改',
            filed: 'notFitrule',
            format: (val) => {
              val;
              if (val) {
                return (val = '是');
              } else {
                return (val = '否');
              }
            },
            edit: true,
          },
          {
            name: '不合格信息',
            filed: 'departmentAberrantData',
          },
        ],
      };
    },
    watch: {
      'form.dzfpVehicleType'() {
        // 查询车种
        this.getVehicleClassByVehicleType();
        this.getVehicleUserType();
      },
      'form.permittedTowWeight'() {
        // 当准牵引总质量发生变化时，需要触发再次识别车种和车辆用户类型
        // 查询车种
        this.getVehicleClassByVehicleType();
        this.getVehicleUserType();
      },
      'form.vehicleClass'() {
        // 查询车种
        if (this.form.vehicleCategory === '1') {
          this.getVehicleModel();
        }
      },
      // 车种变更，查询收费车型和车辆用户类型
      'form.vehicleCategory'(val) {
        this.getVehicleType();
        this.getVehicleUserType();
        if (this.form.vehicleCategory === '1') {
          this.p2wJudge();
          this.getVehicleModel();

          this.iclass = 'jiacu';
          this.iclass1 = '';
        } else {
          this.iclass = '';
          this.iclass1 = 'jiacu';
        }
      },
      'form.vehicleNumber'() {
        this.getVehicleUserType();
        const self = this;
        this.form.vehicleNumber = this.form.vehicleNumber
          .replace(/[^\a-\z\A-\Z\d\u4E00-\u9FA5]/g, '')
          .toLocaleUpperCase();
        clearTimeout(this.timer);
        this.timer = setTimeout(() => {
          //alert(self.ocrData1.ocr);
          let flag = false;
          //-----------------------
          let message =
            '印章页车牌号码:&nbsp&nbsp' +
            this.form.vehicleNumber +
            '&nbsp&nbsp&nbsp&nbsp与';

          if (self.ocrData1.ocr.vehicleNumber) {
            message =
              message +
              '</br></br>行驶证印章页:&nbsp&nbsp' +
              self.ocrData1.ocr.vehicleNumber;
          }
          if (self.ocrData2.ocr.vehicleNumber) {
            message =
              message +
              ' </br></br>行驶证条码页:&nbsp&nbsp' +
              self.ocrData2.ocr.vehicleNumber;
          }
          if (self.ocrData3.ocr.vehicleNumber) {
            message =
              message +
              ' </br></br>机动车登记证:&nbsp&nbsp' +
              self.ocrData3.ocr.vehicleNumber;
          }
          message = message + ' </br></br>不一致,请进行核对。';
          if (
            self.ocrData1.ocr.vehicleNumber &&
            this.form.vehicleNumber &&
            this.form.vehicleNumber !== self.ocrData1.ocr.vehicleNumber
          ) {
            if (!flag) {
              this.$message.error(message);
              // this.$message.error({
              //   width: 500,
              //   message: message,
              //   dangerouslyUseHTMLString: true,

              //   center: true,

              //   //duration: 5000,
              // });
            }

            flag = true;
          }
          ////////////////
          if (
            self.ocrData2.ocr.vehicleNumber &&
            this.form.vehicleNumber &&
            this.form.vehicleNumber !== self.ocrData2.ocr.vehicleNumber
          ) {
            if (!flag) {
              this.$message.error(message);
              // this.$message.error({
              //   width: 500,
              //   message: message,
              //   dangerouslyUseHTMLString: true,

              //   center: true,

              //   //duration: 5000,
              // });
            }
            flag = true;
          }
          ///////////////
          if (
            self.ocrData3.ocr.vehicleNumber &&
            this.form.vehicleNumber &&
            this.form.vehicleNumber !== self.ocrData3.ocr.vehicleNumber
          ) {
            if (!flag) {
              this.$message.error(message);
              // this.$message.error({
              //   width: 500,
              //   message: message,
              //   dangerouslyUseHTMLString: true,

              //   center: true,

              //   //duration: 5000,
              // });
            }
            flag = true;
          }
        }, 1500);
      },
      //////////////////////////////////////////////////
      'form.vehicleNumber2'() {
        //this.getVehicleUserType();
        const self = this;
        this.form.vehicleNumber2 = this.form.vehicleNumber2
          .replace(/[^\a-\z\A-\Z\d\u4E00-\u9FA5]/g, '')
          .toLocaleUpperCase();
        clearTimeout(this.timer);
        this.timer = setTimeout(() => {
          //alert(self.ocrData1.ocr);
          let flag = false;
          //-----------------------
          let message =
            '条码页车牌号码:&nbsp&nbsp' +
            this.form.vehicleNumber2 +
            '&nbsp&nbsp&nbsp&nbsp与';

          if (self.ocrData1.ocr.vehicleNumber) {
            message =
              message +
              '</br></br>行驶证印章页:&nbsp&nbsp' +
              self.ocrData1.ocr.vehicleNumber;
          }
          if (self.ocrData2.ocr.vehicleNumber) {
            message =
              message +
              ' </br></br>行驶证条码页:&nbsp&nbsp' +
              self.ocrData2.ocr.vehicleNumber;
          }
          if (self.ocrData3.ocr.vehicleNumber) {
            message =
              message +
              ' </br></br>机动车登记证:&nbsp&nbsp' +
              self.ocrData3.ocr.vehicleNumber;
          }
          message = message + ' </br></br>不一致,请进行核对。';
          if (
            self.ocrData1.ocr.vehicleNumber &&
            this.form.vehicleNumber2 &&
            this.form.vehicleNumber2 !== self.ocrData1.ocr.vehicleNumber
          ) {
            if (!flag) {
              this.$message.error(message);
              // this.$message.error({
              //   width: 500,
              //   message: message,
              //   dangerouslyUseHTMLString: true,

              //   center: true,

              //   //duration: 5000,
              // });
            }

            flag = true;
          }
          ////////////////
          if (
            self.ocrData2.ocr.vehicleNumber &&
            this.form.vehicleNumber2 &&
            this.form.vehicleNumber2 !== self.ocrData2.ocr.vehicleNumber
          ) {
            if (!flag) {
              this.$message.error(message);
              // this.$message.error({
              //   width: 500,
              //   message: message,
              //   dangerouslyUseHTMLString: true,

              //   center: true,

              //   //duration: 5000,
              // });
            }
            flag = true;
          }
          ///////////////
          if (
            self.ocrData3.ocr.vehicleNumber &&
            this.form.vehicleNumber2 &&
            this.form.vehicleNumber2 !== self.ocrData3.ocr.vehicleNumber
          ) {
            if (!flag) {
              this.$message.error(message);
              // this.$message.error({
              //   width: 500,
              //   message: message,
              //   dangerouslyUseHTMLString: true,

              //   center: true,

              //   //duration: 5000,
              // });
            }
            flag = true;
          }
        }, 1500);
      },
      //////////////////////////////////////////////////
      'form.vehicleColor'() {
        this.getVehicleUserType();
      },

      // 核定载人数变更查询收费车型
      'form.approvedAccount'(val) {
        if (!/^[0-9\-]*$/.test(val)) {
          // 核定载人数如果ocr识别出来是2+3，这个空格就自动清除不填写，操作员发现了这个空格后再手输5
          this.form.approvedAccount = '';
        }
        if (this.form.vehicleCategory === '1') {
          this.getVehicleType();
        }
      },
      'form.viLength'() {
        this.getVehicleType();
      },
      'form.axleCount'() {
        this.getVehicleType();
      },
      'form.maintenaceMass'() {
        if (
          this.form.vehicleCategory === '2' ||
          this.form.vehicleCategory === '3' ||
          this.form.vehicleCategory === '4'
        ) {
          if (
            (this.form.maintenaceMass > '0' && this.form.viTotalMass === '0') ||
            (this.form.maintenaceMass > '0' && this.form.viTotalMass === '--')
          ) {
            //alert(111);
            this.getVehicleType();
          }
        }
      },
      'form.viTotalMass'() {
        if (
          this.form.vehicleCategory === '2' ||
          this.form.vehicleCategory === '3' ||
          this.form.vehicleCategory === '4'
        ) {
          this.getVehicleType();
        }
      },
      'form.ownerName'() {
        const registerUser = this.$store.getters.registerUser;
        if (
          registerUser.userProperty === '2' &&
          registerUser.userName !== this.form.ownerName.trim()
        ) {
          this.fixCarOwnerInfoBtnDisplay = true;
        } else {
          this.fixCarOwnerInfoBtnDisplay = false;
          // this.fixCarOwnerInfoBtnDisplay = true;
        }
      },
    },
    components: {
      PhotographBlock,
      ODialog,
      ComplexTable,
      //ComplexTable1,
      FixCarOwnernfo,
      RegexInput,
      //FormatInput,
    },

    methods: {
      p2wJudge() {
        const self = this;
        if (!self.form.permittedTowWeight) {
          self.form.permittedTowWeight = '0';
        }
      },
      // 根据行驶证车辆类型查询车种
      async getVehicleClassByVehicleType() {
        if (!this.form.dzfpVehicleType) {
          return;
        }
        const res = await getVehicleClassByVehicleType2({
          vehicleType: this.form.dzfpVehicleType,
          permittedTowWeight: this.form.permittedTowWeight,
        });
        if (res) {
          this.$set(this.form, 'vehicleCategory', res.vehicleCategory);
          // this.form.vehicleCategory = res.vehicleCategory;

          if (this.form.vehicleCategory) {
            this.ReadonlyVehicleCategory = true;
          } else {
            this.ReadonlyVehicleCategory = false;
          }
        }
      },
      // 组织机构返回数据处理
      responseListFormat(data) {
        return data.departmentInfo;
        // return data.userAcctList;
      },
      // getPhotoInfo(pics) {
      //   this.form.approvedAccount = '2+3';
      //   this.$set(this.form, 'approvedAccount', '2+3');
      //   console.log('this.form.approvedAccount2', this.form.approvedAccount);
      // },
      // 点击拍照识别得到数据
      async getPhotoInfo(pics) {
        const self = this;
        //console.log(pics);
        let viLength = '';
        let viWidth = '';
        let viHeight = '';
        self.form.imageList = [];
        if (pics && pics.length > 0) {
          let i = pics.length;
          let pic = pics[i - 1];
          pics.forEach((pic) => {
            if (pic.type === '301-1') {
              self['ocrData1'] = pic;
            } else if (pic.type === '301-2') {
              self['ocrData2'] = pic;
              let lwh = pic.ocr.outlineDimension;
              lwh = lwh.replace('mm', '').trim();
              let arr = lwh.split('×');
              if (arr.length > 2) {
                viLength = arr[0];
                viWidth = arr[1];
                viHeight = arr[2];
              }
            } else if (pic.type === '302-1') {
              self['ocrData3'] = pic;
            }
            if (!self.form.imageList) {
              self.form.imageList = [];
            }

            self.form.imageList.push({
              imgFrontID: pic.frontImgid,
              imgType: pic.type.replace('-', ''),
              mediaType: '3',
            });
          });
        }

        let flag = false;
        //-----------------------
        let message =
          '印章页车牌号码:&nbsp&nbsp' +
          this.form.vehicleNumber +
          '&nbsp&nbsp&nbsp&nbsp与';

        if (self.ocrData1.ocr.vehicleNumber) {
          message =
            message +
            '</br></br>行驶证印章页:&nbsp&nbsp' +
            self.ocrData1.ocr.vehicleNumber;
        }
        if (self.ocrData2.ocr.vehicleNumber) {
          message =
            message +
            ' </br></br>行驶证条码页:&nbsp&nbsp' +
            self.ocrData2.ocr.vehicleNumber;
        }
        if (self.ocrData3.ocr.vehicleNumber) {
          message =
            message +
            ' </br></br>机动车登记证:&nbsp&nbsp' +
            self.ocrData3.ocr.vehicleNumber;
        }
        message = message + ' </br></br>不一致,请进行核对。';
        if (
          self.ocrData1.ocr.vehicleNumber &&
          this.form.vehicleNumber &&
          this.form.vehicleNumber !== self.ocrData1.ocr.vehicleNumber
        ) {
          if (!flag) {
            await this.$message.error(message);
            // await this.$message.error({
            //   message: message,
            //   dangerouslyUseHTMLString: true,

            //   center: true,

            //   //duration: 5000,
            // });
          }

          flag = true;
        }
        ////////////////
        if (
          self.ocrData2.ocr.vehicleNumber &&
          this.form.vehicleNumber &&
          this.form.vehicleNumber !== self.ocrData2.ocr.vehicleNumber
        ) {
          if (!flag) {
            await this.$message.error(message);
            // await this.$message.error({
            //   message: message,
            //   dangerouslyUseHTMLString: true,
            //   center: true,
            //   //duration: 5000,
            // });
          }
          flag = true;
        }
        ///////////////
        if (
          self.ocrData3.ocr.vehicleNumber &&
          this.form.vehicleNumber &&
          this.form.vehicleNumber !== self.ocrData3.ocr.vehicleNumber
        ) {
          if (!flag) {
            await this.$message.error(message);
            // await this.$message.error({
            //   message: message,
            //   dangerouslyUseHTMLString: true,
            //   center: true,
            //   //duration: 5000,
            // });
          }
          flag = true;
        }

        /////////////////////////////////////////////////////////////////////////////////
        let flag2 = false;
        let message2 =
          '条码页车牌号码:&nbsp&nbsp' +
          this.form.vehicleNumber2 +
          '&nbsp&nbsp&nbsp&nbsp与';

        if (self.ocrData1.ocr.vehicleNumber) {
          message2 =
            message2 +
            '</br></br>行驶证印章页:&nbsp&nbsp' +
            self.ocrData1.ocr.vehicleNumber;
        }
        if (self.ocrData2.ocr.vehicleNumber) {
          message2 =
            message2 +
            ' </br></br>行驶证条码页:&nbsp&nbsp' +
            self.ocrData2.ocr.vehicleNumber;
        }
        if (self.ocrData3.ocr.vehicleNumber) {
          message2 =
            message2 +
            ' </br></br>机动车登记证:&nbsp&nbsp' +
            self.ocrData3.ocr.vehicleNumber;
        }
        message2 = message2 + ' </br></br>不一致,请进行核对。';
        if (
          self.ocrData1.ocr.vehicleNumber &&
          this.form.vehicleNumber2 &&
          this.form.vehicleNumber2 !== self.ocrData1.ocr.vehicleNumber
        ) {
          if (!flag2) {
            await this.$message.error(message);
            // await this.$message.error({
            //   message: message2,
            //   dangerouslyUseHTMLString: true,

            //   center: true,

            //   //duration: 5000,
            // });
          }

          flag2 = true;
        }
        ////////////////
        if (
          self.ocrData2.ocr.vehicleNumber &&
          this.form.vehicleNumber2 &&
          this.form.vehicleNumber2 !== self.ocrData2.ocr.vehicleNumber
        ) {
          if (!flag2) {
            await this.$message.error(message);
            // await this.$message.error({
            //   message: message2,
            //   dangerouslyUseHTMLString: true,
            //   center: true,
            //   //duration: 5000,
            // });
          }
          flag2 = true;
        }
        ///////////////
        if (
          self.ocrData3.ocr.vehicleNumber &&
          this.form.vehicleNumber2 &&
          this.form.vehicleNumber2 !== self.ocrData3.ocr.vehicleNumber
        ) {
          if (!flag2) {
            await this.$message.error(message);
            // await this.$message.error({
            //   message: message2,
            //   dangerouslyUseHTMLString: true,
            //   center: true,
            //   //duration: 5000,
            // });
          }
          flag2 = true;
        }

        /////////////////////////////////////////////////////////////////////////////////
        //////////////
        let i = pics.length;
        let pic = pics[i - 1];
        if (pic.type === '301-1') {
          console.log('test1');
          console.log(self.form);
          self.form = {
            ...self.form,
            vehicleNumber:
              self.ocrData1.ocr.vehicleNumber || self.form.vehicleNumber,
            dzfpVehicleType:
              self.ocrData1.ocr.vehicleType || self.form.dzfpVehicleType,
            vehicleSpecies:
              self.ocrData1.ocr.vehicleSpecies || self.form.vehicleSpecies,
            viModelName: self.ocrData1.ocr.vehicleNote || self.form.viModelName,
            vin: self.ocrData1.ocr.vin || self.form.vin,
            engineNum: self.ocrData1.ocr.engineNum || self.form.engineNum,
            viRegisterDate:
              configDate(self.ocrData1.ocr.registerDate) ||
              self.form.viRegisterDate,
            viIssueDate:
              configDate(self.ocrData1.ocr.issueDate) || self.form.viIssueDate,
            ownerName: self.ocrData1.ocr.ownerName || self.form.ownerName,
            address: self.ocrData1.ocr.ownerAddress || self.form.address,
          };
          console.log('test1');
          console.log(self.form);
        }
        ////////////////
        if (pic.type === '301-2') {
          self.form = {
            ...self.form,
            vehicleNumber2:
              self.ocrData2.ocr.vehicleNumber || self.form.vehicleNumber,
            viFileNum: self.ocrData2.ocr.fileNum || self.form.viFileNum,
            approvedAccount:
              (self.ocrData2.ocr.approvedCount &&
                self.ocrData2.ocr.approvedCount.replace(/人/g, '')) ||
              self.form.approvedAccount,
            viTotalMass:
              (self.ocrData2.ocr.vehicleTotalMass &&
                self.ocrData2.ocr.vehicleTotalMass.replace(/kg/g, '')) ||
              self.form.viTotalMass,
            maintenaceMass:
              (self.ocrData2.ocr.maintenanceMass &&
                self.ocrData2.ocr.maintenanceMass.replace(/kg/g, '')) ||
              self.form.maintenaceMass,
            permittedWeight:
              (self.ocrData2.ocr.vehicleMaxLadenWeight &&
                self.ocrData2.ocr.vehicleMaxLadenWeight.replace(/kg/g, '')) ||
              self.form.permittedWeight,
            outlineDimension:
              (self.ocrData2.ocr.outlineDimension &&
                self.ocrData2.ocr.outlineDimension.replace(/mm/g, '')) ||
              self.form.outlineDimension,
            permittedTowWeight:
              (self.ocrData2.ocr.vehicleTrainMaxImuweight &&
                self.ocrData2.ocr.vehicleTrainMaxImuweight.replace(/kg/g, '')) ||
              self.form.permittedTowWeight,
            viLength: viLength.length > 0 && viLength,
            viWidth: viWidth.length > 0 && viWidth,
            viHeight: viHeight.length > 0 && viHeight,
            note: self.ocrData2.ocr.note || self.form.note,
            testRecord: self.ocrData2.ocr.testrecord || self.form.testRecord,
          };
        }
        ///////////////
        if (pic.type === '302-1') {
          self.form = {
            ...self.form,
            axleCount: self.ocrData3.ocr.axleCount || self.form.axleCount,
            axleDistance:
              (self.ocrData3.ocr.axleDistance &&
                self.ocrData3.ocr.axleDistance.replace(/mm/g, '')) ||
              self.form.axleDistance,
            wheelCount: self.ocrData3.ocr.wheelCount || self.form.wheelCount,
          };
        }
        //////-车辆注册页面，系统自动识别车种后，不可变更，只在无法识别的情况下，才由操作员手工选择--/////////
        if (self.form.vehicleCategory) {
          this.ReadonlyVehicleCategory = true;
        } else {
          this.ReadonlyVehicleCategory = false;
        }
        // 系统自动识别车辆用户类型后，不可变更，只在无法识别的情况下，才由操作员手工选择
        if (self.form.vehicleType) {
          this.ReadonlyVehicleType = true;
        } else {
          this.ReadonlyVehicleType = false;
        }
        ///////////////
        // self.form = {
        //   ...self.form,
        // vehicleNumber:
        //   self.ocrData1.ocr.vehicleNumber || self.form.vehicleNumber,
        // vehicleNumber2:
        //   self.ocrData2.ocr.vehicleNumber || self.form.vehicleNumber,
        // dzfpVehicleType:
        //   self.ocrData1.ocr.vehicleType || self.form.dzfpVehicleType,

        // vehicleSpecies:
        //   self.ocrData1.ocr.vehicleSpecies || self.form.vehicleSpecies,
        // viModelName: self.ocrData1.ocr.vehicleNote || self.form.viModelName,
        // vin: self.ocrData1.ocr.vin || self.form.vin,
        // engineNum: self.ocrData1.ocr.engineNum || self.form.engineNum,
        // viRegisterDate:
        //   configDate(self.ocrData1.ocr.registerDate) ||
        //   self.form.viRegisterDate,
        // viIssueDate:
        //   configDate(self.ocrData1.ocr.issueDate) || self.form.viIssueDate,
        // viFileNum: self.ocrData2.ocr.fileNum || self.form.viFileNum,
        // approvedAccount:
        //   (self.ocrData2.ocr.approvedCount &&
        //     self.ocrData2.ocr.approvedCount.replace(/人/g, '')) ||
        //   self.form.approvedAccount,
        // viTotalMass:
        //   (self.ocrData2.ocr.vehicleTotalMass &&
        //     self.ocrData2.ocr.vehicleTotalMass.replace(/kg/g, '')) ||
        //   self.form.viTotalMass,
        // maintenaceMass:
        //   (self.ocrData2.ocr.maintenanceMass &&
        //     self.ocrData2.ocr.maintenanceMass.replace(/kg/g, '')) ||
        //   self.form.maintenaceMass,
        // permittedWeight:
        //   (self.ocrData2.ocr.vehicleMaxLadenWeight &&
        //     self.ocrData2.ocr.vehicleMaxLadenWeight.replace(/kg/g, '')) ||
        //   self.form.permittedWeight,
        // outlineDimension:
        //   (self.ocrData2.ocr.outlineDimension &&
        //     self.ocrData2.ocr.outlineDimension.replace(/mm/g, '')) ||
        //   self.form.outlineDimension,
        // axleCount: self.ocrData3.ocr.axleCount || self.form.axleCount,
        // axleDistance:
        //   (self.ocrData3.ocr.axleDistance &&
        //     self.ocrData3.ocr.axleDistance.replace(/mm/g, '')) ||
        //   self.form.axleDistance,
        // wheelCount: self.ocrData3.ocr.wheelCount || self.form.wheelCount,
        // // viLength:
        // //   self.ocrData2.ocr.outlineDimension &&
        // //   parseFloat(self.ocrData2.ocr.outlineDimension),

        // viLength: viLength.length > 0 && viLength,
        // viWidth: viWidth.length > 0 && viWidth,
        // viHeight: viHeight.length > 0 && viHeight,
        // permittedTowWeight:
        //   (self.ocrData2.ocr.vehicleTrainMaxImuweight &&
        //     self.ocrData2.ocr.vehicleTrainMaxImuweight.replace(/kg/g, '')) ||
        //   self.form.permittedTowWeight,

        // note: self.ocrData2.ocr.note || self.form.note,
        // testRecord: self.ocrData2.ocr.testrecord || self.form.testRecord,
        // ownerName: self.ocrData1.ocr.ownerName || self.form.ownerName,
        // address: self.ocrData1.ocr.ownerAddress || self.form.address,
        // // vehicleColor: getDicCodeByAll(self.vehicleColors, data.vehicleColorDes),
        // };
        // this.$refs.form.resetFields();

        // self.$refs.form.validate((valid) => {});
        // 查询车辆用户类型
        // self.getVehicleUserType();
      },
      // 查询车辆用户类型
      async getVehicleUserType() {
        const self = this;
        if (!self.form.dzfpVehicleType) return;
        // if (!self.form.vehicleColor) return;
        // if (!self.form.vehicleNumber) return;
        const colorCode = await getDicCodeByDes(
          dicKeys.vehicleColor,
          self.form.vehicleColor
        );
        const res = await getVehicleUserType({
          vehicleType: self.form.dzfpVehicleType,
          vehicleNumber: self.form.vehicleNumber,
          vehicleColor: self.form.vehicleColor,
          permittedTowWeight: self.form.permittedTowWeight,
        });
        if (res) {
          self.$set(self.form, 'vehicleType', res.vehicleClass);
          // console.log('res-self.form.vehicleType', self.form.vehicleType);
          // 系统自动识别车辆用户类型后，不可变更，只在无法识别的情况下，才由操作员手工选择
          if (self.form.vehicleType) {
            self.ReadonlyVehicleType = true;
          } else {
            self.ReadonlyVehicleType = false;
          }
        }
      },
      // 查询收费车型
      getVehicleType() {
        const self = this;
        let weight = self.form.viTotalMass;
        let zbweight = self.form.maintenaceMass;

        if (!/^[0-9]+$/.test(weight)) {
          weight = '0';
        }
        if (!/^[0-9]+$/.test(zbweight)) {
          zbweight = '0';
        }
        if (self.ehicleTypeTimer)
          //-----------------------------------------------------------
          clearTimeout(self.ehicleTypeTimer);
        self.ehicleTypeTimer = setTimeout(async () => {
          // if (!(self.form.viLength && self.form.vehicleCategory)) {
          //   return;
          // // }
          if (self.form.vehicleCategory === '1') {
            if (!self.form.approvedAccount) {
              return;
            }
          } else if (
            self.form.vehicleCategory === '2' ||
            self.form.vehicleCategory === '3' ||
            self.form.vehicleCategory === '4'
          ) {
            // if (!self.form.viTotalMass) {
            //   return;
            // }
            if (!self.form.axleCount) {
              return;
            }
            if (weight == '0') {
              if (self.form.maintenaceMass > '0') {
                weight = self.form.maintenaceMass;
              }
            }
            //alert(weight);
            // if (!Number.isInteger(self.form.viTotalMass)) {
            //   return;
            // }
          }
          // &&self.form.axleCount
          if (self.form.vehicleCategory && self.form.viLength) {
            // let weight = self.form.viTotalMass;

            const res = await getVehicleType({
              //vehicleType: self.form.dzfpVehicleType,
              vehicleCategory: self.form.vehicleCategory,
              approvedAccount: self.form.approvedAccount,
              viLength: self.form.viLength,
              axleCount: self.form.axleCount,
              // viTotalMass: self.form.viTotalMass,
              viTotalMass: weight,
            });
            if (res) {
              self.$set(self.form, 'vehicleClass', res.vehicleClass);
            }
          }
        }, 500);
      },
      getVehicleModel() {
        const self = this;
        if (self.ehicleTypeTimer2) clearTimeout(self.ehicleTypeTimer2);
        self.ehicleTypeTimer2 = setTimeout(async () => {
          if (self.form.vehicleCategory && self.form.vehicleClass) {
            const res = await vehicleModelQuery({
              //vehicleType: self.form.dzfpVehicleType,
              vehicleCategory: self.form.vehicleCategory,
              vehicleClass: self.form.vehicleClass,
            });
            if (res) {
              self.$set(self.form, 'axleCount', res.axleCount);
              self.$set(self.form, 'wheelCount', res.wheelCount);
              self.$set(self.form, 'axleDistance', res.axleDistance);
            }
          }
        }, 300);
      },

      // 查询车主信息
      async loadUserInfo() {
        const self = this;
        const query = self.$route.query;
        self.form.etcUserId = query.euid;
        const res = await loadInfoByCard({
          // userCertType: query.uct,
          // userCode: query.uc,
          etcUserId: this.$store.getters.registerUser.etcUserId,
          // userCertType: this.$store.getters.registerUser.userCertType,
          // userCode: this.$store.getters.registerUser.userCode,
          //etcUserId: this.$store.getters.searchUserInfo.userID,
        });

        if (res) {
          self.form.etcUserId = res.etcUserId;
          // this.$store.dispatch('GetRegisterUser', {
          //   ...this.$store.getters.registerUser,
          //   etcUserId: res.etcUserId,
          // });
          // alert(this.$store.getters.registerUser.etcUserId);
          // alert(this.$store.getters.registerUser.etcUserId);
          self.form.userType = res.userType;
          self.form.userName = res.userName;
        }
      },
      // selectOrganization(rows) {
      //   // console.dir(this.$refs.multipleTable.selection);
      //   this.form.department = (rows[0] && rows[0].department) || '';
      //   // this.organizationVisible = false;
      // },
      // 获取form数据
      getFormData() {
        const self = this;
        const registerUser = this.$store.getters.registerUser;
        // 如果是个人用户，或者单位用户，但是车主和车辆所有人是同一个人，则主动赋值给车主信息字段
        if (
          registerUser.userProperty === '1' ||
          registerUser.userName === self.form.ownerName.trim()
        ) {
          self.form.viownerInfo = {
            ownerName: registerUser.userName,
            ownerImageList: registerUser.userPics.map((pic) => {
              return {
                imgFrontID: pic.frontImgid,
                mediaType: '2',
                imgType: pic.type.replace('-', ''),
              };
            }),
          };
        }
        self.form.workOrderID = this.$route.query.woid;
        // 检验数据格式
        return new Promise((resolve) => {
          self.$refs.form.validate((valid) => {
            if (valid) {
              resolve(self.form);
            }
          });
        });
      },
      clear() {
        this.$refs.form.resetFields();
      },
      // 打开补充车主信息窗口
      openFixCarOwnernfo() {
        this.fixCarOwnernfoFormVisible = true;
      },
      // 提交补充车主信息
      async commitFixCarOwnerinfo() {
        const self = this;

        const formData = await self.$refs.fixCarOwnernfoForm.getFormData();
        // alert(formData.imgFrontID);
        self.form.viownerInfo = {
          ...formData,
        };

        self.form.ownerName = self.form.viownerInfo.ownerName;
        this.fixCarOwnernfoFormVisible = false;
      },
    },
    mounted() {
      this.form = {
        userName: '',
        userType: '',
        viownerInfo: {},
        department: '',
        imageList: [],
        ownerName: '',
        department: '',
      };
      this.form.department = this.$route.query.department;
      console.log('this.$route.query.department', this.$route.query.department);
      // 查询车主信息
      // this.loadUserInfo();
    },
  };
</script>
<style>
  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
  }

  input[type='number'] {
    -moz-appearance: textfield;
  }

  .miles {
    height: 80px;
    line-height: 113px;
  }
</style>