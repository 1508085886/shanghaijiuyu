<!-- 车辆注册 -->
<template>
  <div>
    <div class="o-flex o-flex-align-center">
      <h4>
        当前已录入车辆数：
        <span class="offline-car-register_input-count">{{ info.length }}</span>
      </h4>
      <el-button round size="small ml0" @click="addCarInfo">
        <i class="el-icon-plus"></i> 继续录入车辆
      </el-button>
    </div>
    <car-info :info="car" v-for="(car, i) in info" :key="i">
      <template slot="buttons">
        <!-- <el-button size="mini">编辑</el-button> -->
        <empty-button @click="delitem(car)" size="mini">删除</empty-button>
      </template>
    </car-info>
    <div class="clearfix mt20">
      <div class="fr">
        <el-button @click="$router.back()">上一步</el-button>
        <el-button type="primary" @click="publishApply">发行申请</el-button>
      </div>
    </div>
    <o-dialog size="large" title="车辆信息录入" :visible.sync="formVisible">
      <div class="pt15 pb15 pl20 pr20">
        <car-register-form ref="registerForm" v-if="dialog === 'form'" />
        <bank-sign
          :p-vehicle-id="pVehicleId"
          ref="banksign"
          v-else-if="dialog === 'bankSign'"
          :is-component="true"
          @complete="signComplete"
        />
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="formVisible = false">取 消</el-button>
        <el-button type="primary" @click="showVoucher">确 定</el-button>
      </div>
    </o-dialog>
    <voucher-layer
      :visible.sync="voucherVisible"
      :keys="voucherKeys"
      :info="voucherData"
      :column="2"
      @complete="inputCarRegisterInfo"
    />
  </div>
</template>

<script>
import ODialog from '@/components/Dialog';
import CarRegisterForm from './CarRegisterForm';
import CarInfo from '../CarInfo';
import { deviceOrder } from '@/api/order';
import { vehicleTakeOff, registerVehicle } from '@/api/vehicle';
import { formatDate } from '@/utils/format';
import BankSign from '../BankSign';
import VoucherLayer from '@/components/VoucherLayerConfirm';

let formData = null;
let voucherPicSingle = null;

export default {
  data() {
    return {
      registerList: [],
      formVisible: false,
      checkboxDisplay: 'none',
      dialog: '',
      pVehicleId: '',
      voucherVisible: false,
      voucherKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'vehicleNumber', label: '车牌号码' },
          { key: 'vehicleColor', label: '车牌颜色' },
          { key: 'vehicleType', label: '车辆用户类型' },
          { key: 'vehicleClass', label: '收费车型' },
          { key: 'ownerName', label: '车辆所有人' },
          { key: 'vehicleSpecies', label: '使用性质' },
          { key: 'viModelName', label: '品牌型号' },
          { key: 'vin', label: '车辆识别代码' },
          { key: 'engineNum', label: '发动机号码' },
          { key: 'approvedAccount', label: '核定载人数' },
          { key: 'viTotalMass', label: '总质量' },
          { key: 'maintenaceMass', label: '整备质量' },
          { key: 'permittedWeight', label: '核定载质量' },
          { key: 'permittedTowWeight', label: '准牵引总质量' },
          { key: 'note', label: '外廓尺寸' },
          { key: 'axleCount', label: '车轴数' },
          { key: 'wheelCount', label: '车轮数' },
          { key: 'axleDistance', label: '轴距' },
        ],
      ],
      voucherData: {},
    };
  },
  components: {
    ODialog,
    CarRegisterForm,
    CarInfo,
    BankSign,
    VoucherLayer,
  },
  props: {
    info: {
      type: Array,
      default: [],
    },
  },
  watch: {
    formVisible(val) {
      if (!val) {
        this.dialog = '';
      } else {
        this.dialog = 'form';
      }
    },
  },
  methods: {
    async delitem(carparam) {
      // debugger;
      //脱绑 5.17
      // const res = await vehicleTakeOff({
      //   etcUserId: this.$store.getters.registerUser.etcUserId,
      //   vehicleID: carparam.vehicleID,
      //   vehicleNumber: carparam.vehicleNumber,
      //   vehicleColor: carparam.vehicleColor,
      //   bizCode: '',
      //   imageList: { mediaType: 1, imgType: 1, imgFrontID },
      // });
      const index = this.info.findIndex((ina) => {
        return ina === carparam;
      });
      //脱绑 5.17
      // const res = await vehicleTakeOff({
      //   etcUserId: this.$store.getters.registerUser.etcUserId,
      //   vehicleID: carparam.vehicleID,
      //   vehicleNumber: carparam.vehicleNumber,
      //   vehicleColor: carparam.vehicleColor,
      //   bizCode: '',
      //   imageList: { mediaType: 1, imgType: 1, imgFrontID: 'b099a3d929fd4672' },
      // });
      // debugger;
      // const index = this.info.findIndex(carparam);
      this.info.splice(index, 1);

      this.$store.dispatch('DelRegisterVehicle', carparam);
    },
    async showVoucher() {
      const self = this;
      if (self.dialog === 'form') {
        const formData = await self.$refs.registerForm.getFormData();
        self.voucherData = {
          businessType: '车辆注册',
          ...formData,
          note: formData.outlineDimension + 'mm',
        };
        this.voucherVisible = true;
      } else {
        self.$refs.banksign.next();
      }
    },
    // 录入车辆信息
    async inputCarRegisterInfo(vp) {
      const self = this;
      const formData = await self.$refs.registerForm.getFormData();
      formData.etcUserId = self.$store.getters.registerUser.etcUserId;
      if (!formData.imageList) {
        formData.imageList = [];
      }

      // const a = [
      //   ...formData.imageList,
      //   { imgFrontID: vp.frontImgid, imgType: '4011', mediaType: '5' },
      // ];
      // 上传用户凭证图片
      formData.imageList.push({
        imgFrontID: vp.frontImgid,
        imgType: '4011',
        mediaType: '5',
      });

      // 注册车辆信息
      const res = await registerVehicle(formData);
      if (res) {
        if (res.errorMsg) {
          // 将接口的指定出参字段提示出来
          this.$alert(res.errorMsg, '提示', {
            confirmButtonText: '确定',
            type: 'error',
          });
          return;
        }
        // 保存注册信息
        self.pVehicleId = res.vehicleId;
        formData.vehicleId = res.vehicleId;
        formData.vehicleClass = res.vehicleClass;
        self.$store.dispatch('GetRegisterVehicle', formData);
        // 切换至银行签约
        self.dialog = 'bankSign';
      }
    },
    // 银行签约完成
    signComplete() {
      const self = this;
      self.formVisible = false;
      self.dialog = 'form';
    },
    addCarInfo() {
      this.formVisible = true;
      this.$nextTick(function () {
        // this.$refs.registerForm.$refs.form.resetFields();
        this.$refs.registerForm.clear(); //清空form
      });
    },
    // 发行申请
    publishApply() {
      const self = this;
      const query = self.$route.query;
      const allPromise = [];
      for (let i = 0; i < this.info.length; i++) {
        const info = this.info[i];
        // 新办订单申请
        allPromise.push(
          deviceOrder({
            etcUserId: self.$store.getters.registerUser.etcUserId,
            //orderId: '', // 申请单编号，目前不确定
            deliveryMode: '2', // 配送方式
            // deliveryInfo: {}, // 配送信息，目前没有
            orderCreateTime: formatDate('"YYYY-MM-DD HH:FF:SS"', new Date())
              .replace('"', '')
              .replace(/[\\]/g, '')
              .replace('"', ''),
            orderType: '1', // 订单类型，1为新发订单
            vehicleNumber: info.vehicleNumber, // 车牌号码
            vehicleColor: info.vehicleColor, // 车牌颜色
            payChannelId: 'ETC_CCB_ZH',
            deviceAmount: 0, // 设备费用
            serviceAmount: 0, // 服务费
            deliveryAmount: 0, // 物流费
            totalAmount: 0, // 费用总计
            payStatus: '2', // 未支付
            // payChannelId: this.info[i].payChannelId, // 支付渠道id
            // subPayChannelId: this.info[i].subPayChannelId, // 给渠道下的子机构使用
          })
        );
      }
      Promise.all(allPromise).then(() => {
        self.$router.push({
          path: '/equipmentissuance',
          query: {
            woid: self.$route.query.woid || '',
          },
        });
      });
    },
  },
  mounted() {},
};
</script>
