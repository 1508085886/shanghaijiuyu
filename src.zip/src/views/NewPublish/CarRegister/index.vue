<!-- 车辆注册 -->
<template>
  <div class="offline-car-register">
    <!-- <template v-if="items.length === 0">
      <car-register-form ref="registerForm" />
      <div class="clearfix mt20">
        <div class="fr">
          <el-button @click="$router.back()">上一步</el-button>
          <el-button type="primary" @click="onSubmit">下一步</el-button>
        </div>
      </div>
    </template>-->
    <car-register-item :info="items" />
  </div>
</template>

<script>
import CarRegisterForm from './CarRegisterForm';
import CarRegisterItem from './CarRegisterItem';

export default {
  data() {
    return {};
  },
  components: {
    CarRegisterForm,
    CarRegisterItem,
  },
  methods: {
    onSubmit() {},
  },
  computed: {
    items() {
      return this.$store.getters.registerVehicle;
    },
  },
  mounted() {},
};
</script>
