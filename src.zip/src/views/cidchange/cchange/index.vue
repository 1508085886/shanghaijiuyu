<!-- 用户注册凭证 -->
<template>
  <div class="offline-registry-voucher">
    <el-form ref="form" label-width="80px"> </el-form>
    <h4 class="offline-registry-voucher_title">单位信息</h4>
    <o-table :info="tables" />
    <h4 class="offline-registry-voucher_title">分支机构</h4>

    <el-table
      v-show="seetable"
      :data="tableData"
      style="width: 100%"
      :row-class-name="tableRowClassName"
    >
      <el-table-column prop="department" label="分支机构名称"></el-table-column>

      <el-table-column
        prop="userAcctId"
        label="账户编号"
        v-if="show"
      ></el-table-column>
      <el-table-column prop="agentName" label="代理人名称"></el-table-column>
      <!--
      <el-table-column prop="ctype" label="代理人证件类型" width="80"></el-table-column>-->
      <el-table-column
        prop="agentIdNum"
        label="代理人证件号码"
        width="200"
      ></el-table-column>
      <el-table-column
        prop="agentPhoneNum"
        label="代理人手机"
      ></el-table-column>
      <el-table-column label="操作" width="200">
        <template slot-scope="scope">
          <el-button
            class="controlbutton_class"
            size="mini"
            type="primary"
            @click="uhandle(scope.$index, scope.row)"
            >用户名称变更</el-button
          >
          <el-button
            class="controlbutton_class"
            size="mini"
            type="primary"
            @click="bhandle(scope.$index, scope.row)"
            >部中心信息修正</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      background
      @current-change="handleCurrentChange"
      :current-page.sync="currentPage"
      :page-size="10"
      layout="total,->,prev, pager, next,slot"
      :total="total"
    >
    </el-pagination>

    <o-dialog
      :append-to-body="true"
      size="medium"
      title="用户名称变更"
      :visible.sync="formVisible1"
    >
      <el-form :model="form" style="padding-top: 40px" label-width="150px">
        <el-form-item label="用户名称:">
          <el-col :span="15">
            <el-input
              class="textarea"
              style="padding-left: 10px"
              v-model="c1name"
            ></el-input>
          </el-col>
          <el-col class="line" :span="1">&nbsp;</el-col>
        </el-form-item>
        <el-divider></el-divider>
        <el-form-item label="手机号码:" style="padding-top: 50px">
          <el-col :span="15">
            <el-input
              class="textarea"
              style="padding-left: 10px"
              v-model="d1tel"
            ></el-input>
          </el-col>
          <el-col class="line" :span="1">&nbsp;</el-col>
        </el-form-item>
        <el-form-item
          label="手机验证码: "
          style="padding-top: 20px; padding-bottom: 20px"
        >
          <el-col :span="15">
            <el-input
              class="textarea"
              style="padding-left: 10px"
              v-model="ifcode1"
            ></el-input>
          </el-col>
          <el-col :span="3">
            <div class="grid-content bg-purple-light">
              <el-button type="info" @click="sendifcode1">发送验证码</el-button>
            </div>
          </el-col>
          <el-col class="line" :span="1">&nbsp;</el-col>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="formVisible1 = false">取 消</el-button>
        <el-button type="primary" @click="userchange" :loading="loading"
          >确 定</el-button
        >
      </div>
    </o-dialog>
    <!---------------------------------------------------------------------------------------------- -->
    <o-dialog
      :append-to-body="true"
      size="medium"
      title="用户名称变更"
      :visible.sync="formVisible2"
    >
      <el-form :model="form" style="padding-top: 40px" label-width="150px">
        <el-form-item label="Openid:">
          <el-col :span="15">
            <el-input
              class="textarea"
              style="padding-left: 10px"
              v-model="openid"
            ></el-input>
          </el-col>
          <el-col class="line" :span="1">&nbsp;</el-col>
        </el-form-item>

        <el-form-item label="AccountID:" style="padding-top: 40px">
          <el-col :span="15">
            <el-input
              class="textarea"
              style="padding-left: 10px"
              v-model="accountid"
            ></el-input>
          </el-col>
          <el-col class="line" :span="1">&nbsp;</el-col>
        </el-form-item>

        <el-form-item label="用户名称:" style="padding-top: 40px">
          <el-col :span="15">
            <el-input
              class="textarea"
              style="padding-left: 10px"
              v-model="c2name"
              :disabled="true"
            ></el-input>
          </el-col>
          <el-col class="line" :span="1">&nbsp;</el-col>
        </el-form-item>
        <el-divider></el-divider>
        <el-form-item label="手机号码:" style="padding-top: 50px">
          <el-col :span="15">
            <el-input
              class="textarea"
              style="padding-left: 10px"
              v-model="d2tel"
            ></el-input>
          </el-col>
          <el-col class="line" :span="1">&nbsp;</el-col>
        </el-form-item>
        <el-form-item
          label="手机验证码: "
          style="padding-top: 20px; padding-bottom: 20px"
        >
          <el-col :span="15">
            <el-input
              class="textarea"
              style="padding-left: 10px"
              v-model="ifcode2"
            ></el-input>
          </el-col>
          <el-col :span="3">
            <div class="grid-content bg-purple-light">
              <el-button type="info" @click="sendifcode2">发送验证码</el-button>
            </div>
          </el-col>
          <el-col class="line" :span="1">&nbsp;</el-col>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="formVisible2 = false">取 消</el-button>
        <el-button type="primary" @click="change" :loading="loading"
          >确 定</el-button
        >
      </div>
    </o-dialog>
  </div>
</template>

<script>
import OTable from '@/components/Table';
import ODialog from '@/components/Dialog';
import { query } from '@/api/pidchange';
//import { getuserlist } from '@/api/pidchange';
import { companynamechange } from '@/api/pidchange';
import { getifcode } from '@/api/pidchange';
import { branchQuery } from '@/api/common';
var etcUserId;
var userAccountId;
var department;
//import { query } from '@/api/pid';
export default {
  data() {
    return {
      loading: false,
      total: 0, //总条数
      seetable: false,
      formVisible1: false,
      formVisible2: false,
      vis: false,
      userName_: '',
      para: '',
      d1tel: '',
      d2tel: '',
      openid: '',
      accountid: '',
      c1name: '',
      c2name: '',
      ifcode1: '',
      ifcode2: '',
      data: {
        base: {},
        baseList: [],
        userAcctList: [],
      },
      form: {
        name: '',
        region: '',
        date1: '',
        date2: '',
        delivery: false,
        type: [],
        resource: '',
        desc: '',
      },
      idtype: '',
      idnumber: '',
      tables: [
        { label: '用户ID', value: '' },
        { label: '用户名称', value: '' },
        { label: '用户类型', value: '' },
        //{ label: '证件类别', value: '身份证' },
        { label: '证件号码', value: '' },
        { label: '联系地址', value: '' },
        //{ label: '邮政编码', value: '200023' },
        //{ label: '固定联系电话', value: '021-53003928' },
        { label: '联系方式', value: '' },
        //{ label: '账户联系人', value: '周峰' },
        //{ label: '电子邮箱', value: '4510099@qq.com' },
      ],
      tableData: [],
    };
  },
  components: {
    OTable,
    ODialog,
  },
  props: {
    accuseVisible: Boolean,
    accuseitem: Object,
  },
  mounted() {
    if (this.$store.getters.registerUser.etcUserId) {
      this.userquery();
    }
  },
  methods: {
    //////////////////////////////////////////
    async handleCurrentChange(val) {
      const pagenum = val;
      const self = this;

      const res = await branchQuery({
        etcUserId: this.$store.getters.registerUser.etcUserId,
        pageNo: pagenum,
        pageSize: 10,
      });
      if (res) {
        this.tableData = res.departmentInfo;
        this.total = res.recNum;
      }
    },
    //////////////////////////////////////////
    async userquery() {
      // if (this.idtype == null || this.idtype.length == 0) {
      //   alert('请填写证件类型');
      //   return;
      // }
      // if (this.idnumber == null || this.idnumber.length == 0) {
      //   alert('请填写证件号');
      //   return;
      // }
      // alert(this.$store.getters.registerUser.userCertType);
      // alert(this.$store.getters.registerUser.userCode);

      // const a = await query(this.idtype, this.idnumber);
      const a = await query(this.$store.getters.registerUser.etcUserId);
      if (a.userProperty != '2') {
        this.$router.push({ path: '../../../pidchange/pchange' });
        // alert('非单位用户,或前往个人信息变更');
        /* this.$alert('非单位用户,或前往个人信息变更', '提示', {
           confirmButtonText: '确定',
           type: 'info',
        });
        return;*/
      }

      etcUserId = a.etcUserId;
      this.tables[0].value = a.etcUserId;
      this.tables[1].value = a.userName;

      switch (a.userProperty) {
        case '1':
          this.tables[2].value = '个人用户';
          break;
        case '2':
          this.tables[2].value = '单位用户';
          break;
      }
      this.tables[3].value = a.userCode;
      this.tables[4].value = a.address;
      this.tables[5].value = a.userPhone2;
      //const b = await getuserlist(this.tables[0].value);//6.5
      const b = await branchQuery({
        etcUserId: this.$store.getters.registerUser.etcUserId,
        pageNo: 1,
        pageSize: 10,
      });
      console.log(b);
      //alert(b.departmentInfo.length);
      if (b) {
        this.total = b.recNum;
        console.log(this.total);
        // for (let i = 0; i < b.departmentInfo.length; i++) {
        //   b.departmentInfo[i].agentName = this.tables[1].value;
        // }

        this.tableData = b.departmentInfo;
      }

      // }
      this.seetable = true;
    },
    // etcUserId, vehicleID, vehicleNumber, vehicleColor, bizCode, imageList
    async sendifcode1() {
      const a = await getifcode(
        etcUserId,
        '2',
        userAccountId,
        department,
        this.d1tel,
        '',
        ''
      );
      if (a) {
        // alert('发送成功');
        this.$alert('短信发送成功', '提示', {
          confirmButtonText: '确定',
          type: 'info',
        });
      }
    },
    async sendifcode2() {
      const a = await getifcode(
        etcUserId,
        '2',
        userAccountId,
        department,
        this.d2tel,
        this.openid,
        this.accountid
      );
      if (a) {
        this.$alert('短信发送成功', '提示', {
          confirmButtonText: '确定',
          type: 'info',
        });
        // alert('发送成功');
      }
    },
    uhandle(index, row) {
      //alert(index + ' ' + row.tel);
      (this.c1name = ''), (this.formVisible1 = true);
      userAccountId = row.userAcctId;
      //this.c2name = row.agentName;
      this.d1tel = row.agentPhoneNum;
      department = row.department;
    },
    bhandle(index, row) {
      console.log(this.tables[1].value);
      (this.c2name = ''), (this.formVisible2 = true);
      userAccountId = row.userAcctId;
      this.c2name = this.tables[1].value;
      this.d2tel = row.agentPhoneNum;
      department = row.department;
    },

    async change() {
      const self = this;
      self.loading = true;
      let timer = setTimeout(() => {
        self.loading = false;
      }, 10000);
      const a = await companynamechange(
        etcUserId,
        department,
        '2',
        '1',
        userAccountId,
        this.c2name.trim(),
        this.d2tel,
        this.ifcode2,
        this.openid,
        this.accountid
      );
      //alert(a.msg);

      if (a) {
        this.$alert('修改成功', '提示', {
          confirmButtonText: '确定',
          type: 'info',
        });
        // alert('修改成功');
        this.formVisible2 = false;
      }
      clearTimeout(timer);
      self.loading = false;
      this.ifcode2 = '';
      this.userquery();
    },

    async userchange() {
      const self = this;
      self.loading = true;
      let timer = setTimeout(() => {
        self.loading = false;
      }, 10000);
      const a = await companynamechange(
        etcUserId,
        department,
        '2',
        '1',
        userAccountId,
        this.c1name.trim(),
        this.d1tel,
        this.ifcode1,
        '',
        ''
      );
      //alert(a.msg);

      if (a) {
        this.$alert('修改成功', '提示', {
          confirmButtonText: '确定',
          type: 'info',
        });
        // alert('修改成功');
        this.formVisible1 = false;
      }
      clearTimeout(timer);
      self.loading = false;
      this.ifcode1 = '';
      this.userquery();
    },

    closeDialog() {
      this.$emit('close-dialogStatus', true);
    },
  },
};
</script>
<style lang='scss'>
@import '@/assets/styles/variables.scss';
.offline-registry-voucher_title {
  color: $offlineGrayBold;
  font-size: 18px;
}
.el-table .warning-row {
  background: oldlace;
}

.el-table .success-row {
  background: #f0f9eb;
}

.el-button.controlbutton_class {
  width: 120px;
  margin-bottom: 5px;
  margin-left: 0px;
}

.el-divider--horizontal {
  margin: 8px 0;
  background: 0 0;
  /* border-top: 1px dashed #e8eaec; */
  border-top: 1px dashed $offlineBlack;
  margin-top: 50px;
}
</style>
<style scoped>
.textarea >>> .el-input__inner {
  font-size: 15px !important;
  /* color: #80b127 !important; */
  font-family: '黑体' !important;
}
</style>