<!-- 个人用户变更 -->
<template>
  <div class="offline-new-publish">
    <div class="offline-new-publish_title-wrap">
      <h4 class="offline-new-publish_title">单位用户变更</h4>
      <span class="offline-new-publish_title-remark"></span>
    </div>
    <div class="offline-new-publish_container">
      <router-view class="mt20"></router-view>
    </div>
  </div>
</template>

<script>
export default {
  name: 'CidChange',
  data() {
    return {};
  },
  computed: {
    step() {
      return this.$route.meta.step || 0;
    },
  },
};
</script>
<style lang='scss'>
@import '@/assets/styles/variables.scss';

.offline-new-publish {
  background: #fff;
  border: 1px solid $offlineBorderColor;
}
.offline-new-publish_title-wrap {
  padding: 12px;
  border-bottom: 1px solid $offlineBorderColor;
}
.offline-new-publish_title {
  color: $offlineGrayBold;
  font-size: 18px;
  display: inline;
  margin-right: 8px;
}
.offline-new-publish_title-remark {
  color: $offlineGrayNormal;
  font-size: 13px;
}
.offline-new-publish_container {
  margin: 15px 50px;
}
</style>