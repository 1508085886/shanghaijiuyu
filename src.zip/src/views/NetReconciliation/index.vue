<!--  -->
<template>
  <el-container class="offline_layout o-font-family is-vertical">
    <layout-header />
    <el-container style="height: 0;">
      <el-main class="o-height-full offline_layout-main o-flex o-flex-column">
        <div class="offline_layout-main-scroll">
          <div class="offline-netreconciliation_wrapper offline-netreconciliation_searchblock">
            <!-- <h3 class="ml35">网点对账</h3> -->
            <el-tabs v-model="activeName" type="card" class="offline-netreconciliation_searchblock-tabs">
              <el-tab-pane :label="label1" name="first">
                <el-form ref="form" :model="form" :rules="rules" :inline="true" label-position="right" label-width="auto" class="offline-netreconciliation_searchblock-form">
                  <el-row class="mt10" :gutter="0">
                    <el-col :md="8" :lg="6">
                      <el-form-item label="查询起止日期：" prop="userName">
                        <el-date-picker
                        v-model="value1"
                        type="daterange"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期"
                        class="offline-netreconciliation_searchblock-form-input">
                      </el-date-picker>
                      </el-form-item>
                    </el-col>
                    <!-- <el-col :md="8" :lg="6">
                      <el-form-item label="网点：" prop="userName">
                        <type-select
                          type="agentCertType"
                          v-model="form.agentIdType"
                          placeholder="请选择"
                          class="offline-netreconciliation_searchblock-form-input"
                        />
                      </el-form-item>
                    </el-col> -->
                    <!-- <el-col :md="8" :lg="6">
                      <el-form-item label="操作员：" prop="userName">
                        <type-select
                          type="agentCertType"
                          v-model="form.agentIdType"
                          placeholder="请选择"
                          class="offline-netreconciliation_searchblock-form-input"
                        />
                      </el-form-item>
                    </el-col> -->
                    <el-col :md="8" :lg="6">
                      <el-button class="" size="small" type="primary" icon="el-icon-search" @click="onSearch" round>搜索</el-button>
                      <el-button class="offline-netreconciliation_searchblock-refresh" size="small" icon="el-icon-refresh-left" @click="refresh" round>重置</el-button>
                    </el-col>
                  </el-row>
                </el-form>
              </el-tab-pane>
              <el-tab-pane :label="label2" name="second">
               <el-form ref="form2" :model="form2" :rules="rules" :inline="true" label-position="right" label-width="auto" class="offline-netreconciliation_searchblock-form">
                <el-row class="mt10" :gutter="0">
                  <el-col :md="8" :lg="6">
                    <el-form-item label="查询起止日期：" prop="userName">
                      <el-date-picker
                      v-model="value1"
                      type="daterange"
                      range-separator="至"
                      start-placeholder="开始日期"
                      end-placeholder="结束日期"
                      class="offline-netreconciliation_searchblock-form-input">
                    </el-date-picker>
                    </el-form-item>
                  </el-col>
                  <!-- <el-col :md="8" :lg="6">
                    <el-form-item label="网点：" prop="userName">
                      <type-select
                        type="agentCertType"
                        v-model="form2.agentIdType"
                        placeholder="请选择"
                        class="offline-netreconciliation_searchblock-form-input"
                      />
                    </el-form-item>
                  </el-col>
                  <el-col :md="8" :lg="6"> -->
                    <!-- <el-form-item label="操作员：" prop="userName">
                      <type-select
                        type="agentCertType"
                        v-model="form2.agentIdType"
                        placeholder="请选择"
                        class="offline-netreconciliation_searchblock-form-input"
                      />
                    </el-form-item>
                  </el-col> -->
                  <el-col :md="8" :lg="6">
                    <el-button class="" size="small" type="primary" icon="el-icon-search" @click="onSearch" round>搜索</el-button>
                    <el-button class="offline-netreconciliation_searchblock-refresh" size="small" icon="el-icon-refresh-left" @click="refresh" round>重置</el-button>
                  </el-col>
                </el-row>
              </el-form>
              </el-tab-pane>
            </el-tabs>
          </div>
          <div class="mt10 offline-netreconciliation_wrapper offline-netreconciliation_tableblock">
            <el-button class="mb10 offline-netreconciliation_tableblock-export" size="medium" @click="exportFundReconciliation" v-show="activeName==='first'">导出</el-button>
            <el-button class="mb10 offline-netreconciliation_tableblock-export" size="medium" @click="exportLogisticsReconciliation" v-show="activeName==='second'">导出</el-button>
            <div class="offline-netreconciliation_tableblock-table" v-show="activeName==='first'">
              <!--  :summary-method="getSummaries"
                show-summary -->
              <el-table
                :data="tableData"
                :span-method="objectSpanMethod"
                border
                style="width: 100%"
                header-cell-class-name="offline-netreconciliation_tableblock-header offline-netreconciliation_tableblock-header1">
                <el-table-column
                  prop="id"
                  label="网点"
                  :align="table1Align"
                  :header-align="table1HeaderAlign"
                  class-name="borderStyle0">
                </el-table-column>
                <el-table-column
                  prop="name"
                  label="操作员"
                  :align="table1Align"
                  :header-align="table1HeaderAlign"
                  class-name="borderStyle1">
                </el-table-column>
                <el-table-column
                  prop="amount1"
                  label="业务类型"
                  :align="table1Align"
                  :header-align="table1HeaderAlign"
                  class-name="borderStyle2">
                </el-table-column>
                <el-table-column
                  prop="amount2"
                  label="支付方式"
                  :align="table1Align"
                  :header-align="table1HeaderAlign"
                  class-name="borderStyle3">
                </el-table-column>
                <el-table-column
                  prop="amount3"
                  label="金额（元）"
                  :align="table1Align"
                  :header-align="table1HeaderAlign"
                  class-name="borderStyle4">
                </el-table-column>
              </el-table>
            </div>
            <div class="offline-netreconciliation_tableblock-table" v-show="activeName==='second'">
              <!--  :summary-method="getSummaries"
                show-summary -->
              <el-table
                :data="tableData2"
                :span-method="objectSpanMethod"
                border
                style="width: 100%"
                header-cell-class-name="offline-netreconciliation_tableblock-header offline-netreconciliation_tableblock-header2">
                <el-table-column
                  prop="id"
                  label="网点"
                  :align="table2Align"
                  :header-align="table2HeaderAlign"
                  class-name="borderStyle0">
                </el-table-column>
                <el-table-column
                  prop="name"
                  label="操作员"
                  :align="table2Align"
                  :header-align="table2HeaderAlign"
                  class-name="borderStyle1">
                </el-table-column>
                <el-table-column
                  prop="amount1"
                  label="业务类型"
                  :align="table2Align"
                  :header-align="table2HeaderAlign"
                  class-name="borderStyle2">
                </el-table-column>
                <el-table-column
                  prop="amount2"
                  label="OBU销售渠道"
                  :align="table2Align"
                  :header-align="table2HeaderAlign"
                  class-name="borderStyle3">
                </el-table-column>
                 <el-table-column
                  prop="amount4"
                  label="是否赠送"
                  :align="table2Align"
                  :header-align="table2HeaderAlign"
                  class-name="borderStyle4">
                </el-table-column>
                <el-table-column
                  prop="amount3"
                  label="数量"
                  :align="table2Align"
                  :header-align="table2HeaderAlign"
                  class-name="borderStyle5">
                </el-table-column>
              </el-table>
            </div>
          </div>
        </div>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import LayoutHeader from '../../layout/components/LayoutHeader';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';
export default {
  data() {
    return {
      label1: '资金对账',
      label2: '物流对账',
      // type1: '1资金对账',
      // type2: '2物流对账',
      activeName: 'first',
      currentPage:1,
      total:0,//总条数
      page:1,//初始显示第几页
      pageSize:10,//每页显示多少数据
      form:{},
      form2:{},
      rules:{},
      table1Align:'center',
      table1HeaderAlign:'center',
      table2Align:'center',
      table2HeaderAlign:'center',
      tableData: [{
          id: '100001-徐汇ETC客服中心',
          name: '龙傲天',
          amount1: '补办OBU',
          amount2: '现金',
          amount3: '700.00'
        }, {
          id: '100001-徐汇ETC客服中心',
          name: '龙傲天',
          amount1: '补办OBU',
          amount2: '现金',
          amount3: '700.00'
        }, {
          id: '100001-徐汇ETC客服中心',
          name: '龙傲天',
          amount1: '小计',
          amount2: '',
          amount3: '700.00'
        }, {
          id: '100001-徐汇ETC客服中心',
          name: '亚丝娜',
          amount1: '补办OBU',
          amount2: '现金',
          amount3: '700.00'
        }, {
          id: '100001-徐汇ETC客服中心',
          name: '亚丝娜',
          amount1: '补办OBU',
          amount2: '现金',
          amount3: '700.00'
        }, {
          id: '100001-徐汇ETC客服中心',
          name: '亚丝娜',
          amount1: '补办OBU',
          amount2: '现金',
          amount3: '700.00'
        }, {
          id: '100001-徐汇ETC客服中心',
          name: '亚丝娜',
          amount1: '小计',
          amount2: '',
          amount3: '700.00'
        }, {
          id: '100001-徐汇ETC客服中心',
          name: '所有操作员 合计',
          amount1: '',
          amount2: '',
          amount3: '700.00'
        }, {
          id: '100002-黄浦ETC客服中心',
          name: '茅场晶',
          amount1: '补办OBU',
          amount2: '现金',
          amount3: '700.00'
        }, {
          id: '100002-黄浦ETC客服中心',
          name: '茅场晶',
          amount1: '补办OBU',
          amount2: '现金',
          amount3: '700.00'
        }, {
          id: '100002-黄浦ETC客服中心',
          name: '王小明',
          amount1: '补办OBU',
          amount2: '现金',
          amount3: '700.00'
        }, {
          id: '100002-黄浦ETC客服中心',
          name: '王小明',
          amount1: '补办OBU',
          amount2: '现金',
          amount3: '700.00'
        }, {
          id: '100002-黄浦ETC客服中心',
          name: '王小明',
          amount1: '小计',
          amount2: '',
          amount3: '700.00'
        }, {
          id: '100002-黄浦ETC客服中心',
          name: '所有操作员 合计',
          amount1: '',
          amount2: '',
          amount3: '700.00'
        }, {
          id: '所有网点 合计',
          name: '',
          amount1: '',
          amount2: '',
          amount3: '700.00'
        }],

        tableData2: [{
          id: '100001-徐汇ETC客服中心',
          name: '龙傲天',
          amount1: '补办OBU',
          amount2: '现金',
          amount4: '现金',
          amount3: '700.00'
        }, {
          id: '100001-徐汇ETC客服中心',
          name: '龙傲天',
          amount1: '补办OBU',
          amount2: '现金',
          amount4: '现金',
          amount3: '700.00'
        }, {
          id: '100001-徐汇ETC客服中心',
          name: '龙傲天',
          amount1: '小计',
          amount2: '',
          amount4: '',
          amount3: '700.00'
        }, {
          id: '100001-徐汇ETC客服中心',
          name: '亚丝娜',
          amount1: '补办OBU',
          amount2: '现金',
          amount4: '现金',
          amount3: '700.00'
        }, {
          id: '100001-徐汇ETC客服中心',
          name: '亚丝娜',
          amount1: '补办OBU',
          amount2: '现金',
          amount4: '现金',
          amount3: '700.00'
        }, {
          id: '100001-徐汇ETC客服中心',
          name: '亚丝娜',
          amount1: '补办OBU',
          amount2: '现金',
          amount4: '现金',
          amount3: '700.00'
        }, {
          id: '100001-徐汇ETC客服中心',
          name: '亚丝娜',
          amount1: '小计',
          amount2: '',
          amount4: '',
          amount3: '700.00'
        }, {
          id: '100001-徐汇ETC客服中心',
          name: '所有操作员 合计',
          amount1: '',
          amount2: '',
          amount4: '',
          amount3: '700.00'
        }, {
          id: '100002-黄浦ETC客服中心',
          name: '茅场晶',
          amount1: '补办OBU',
          amount2: '现金',
          amount4: '现金',
          amount3: '700.00'
        }, {
          id: '100002-黄浦ETC客服中心',
          name: '茅场晶',
          amount1: '补办OBU',
          amount2: '现金',
          amount4: '现金',
          amount3: '700.00'
        }, {
          id: '100002-黄浦ETC客服中心',
          name: '王小明',
          amount1: '补办OBU',
          amount2: '现金',
          amount4: '现金',
          amount3: '700.00'
        }, {
          id: '100002-黄浦ETC客服中心',
          name: '王小明',
          amount1: '补办OBU',
          amount2: '现金',
          amount4: '现金',
          amount3: '700.00'
        }, {
          id: '100002-黄浦ETC客服中心',
          name: '王小明',
          amount1: '小计',
          amount2: '',
          amount4: '',
          amount3: '700.00'
        }, {
          id: '100002-黄浦ETC客服中心',
          name: '所有操作员 合计',
          amount1: '',
          amount2: '',
          amount4: '',
          amount3: '700.00'
        }, {
          id: '所有网点 合计',
          name: '',
          amount1: '',
          amount2: '',
          amount4: '',
          amount3: '700.00'
        }],
        // demoData:[{
        //   msg1: '所有网点 合计1',
        //   msg2: '所有网点 合计',
        //   msg3: '所有网点 合计',
        //   msg4: '所有网点 合计',
        //   msg5: '所有网点 合计',
        //   msg6: '700.00'
        // },{
        //   msg1: '所有网点 合计2',
        //   msg2: '所有网点 合计',
        //   msg3: '所有网点 合计',
        //   msg4: '所有网点 合计',
        //   msg5: '所有网点 合计',
        //   msg6: '700.00'
        // },],
    };
  },
  components: {
    LayoutHeader,
  },
  computed: {
  },
  methods: {
  /*   arraySpanMethod({ row, column, rowIndex, columnIndex }) {
        if (rowIndex % 2 === 0) {
          if (columnIndex === 0) {
            return [1, 2];
          } else if (columnIndex === 1) {
            return [0, 0];
          }
        }
      }, */

      objectSpanMethod({ row, column, rowIndex, columnIndex }) {
        /* if (columnIndex === 0) {
          if (rowIndex % 2 === 0) {
            return {
              rowspan: 2,
              colspan: 1
            };
          } else {
            return {
              rowspan: 0,
              colspan: 0
            };
          }
        } */
        if (columnIndex === 0) {
          if (rowIndex === 0) {
            return {
              rowspan: 8,
              colspan: 1
            };
          } else if (rowIndex === 8) {
            return {
              rowspan: 6,
              colspan: 1
            };
          } else if (rowIndex === 14) {
            return {
              rowspan: 1,
              colspan: 1
            };
          }else{
            return {
              rowspan: 0,
              colspan: 0
            };
          }
        }else if(columnIndex === 1){
          if (rowIndex === 0) {
            return {
              rowspan: 3,
              colspan: 1
            };
          } else if (rowIndex === 3) {
            return {
              rowspan: 4,
              colspan: 1
            };
          }else if (rowIndex === 7) {
            return {
              rowspan: 1,
              colspan: 1
            };
          }else  if (rowIndex === 8) {
            return {
              rowspan: 2,
              colspan: 1
            };
          } else if (rowIndex === 10) {
            return {
              rowspan: 3,
              colspan: 1
            };
          }else if (rowIndex ===13) {
            return {
              rowspan: 1,
              colspan: 1
            };
          }else if (rowIndex ===14) {
            return {
              rowspan: 1,
              colspan: 1
            };
          }else{
            return {
              rowspan: 0,
              colspan: 0
            };
          }
        }
      },
     /*  getSummaries(param) {
        const { columns, data } = param;
        const sums = [];
        columns.forEach((column, index) => {
          if (index === 0) {
            sums[index] = '总价';
            return;
          }
          const values = data.map(item => Number(item[column.property]));
          if (!values.every(value => isNaN(value))) {
            sums[index] = values.reduce((prev, curr) => {
              const value = Number(curr);
              if (!isNaN(value)) {
                return prev + curr;
              } else {
                return prev;
              }
            }, 0);
            sums[index] += ' 元';
          } else {
            sums[index] = 'N/A';
          }
        });

        return sums;
      } */
      exportFundReconciliation(){
        this.$confirm("此操作将导出"+this.label1+"excel文件, 是否继续?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          // this.excelData = this.tableData; //导出的数据list。
          this.export2ExcelFundReconciliation();
        }).catch(() => {});
      },
      export2ExcelFundReconciliation() {
        var that = this;
        require.ensure([], () => {
          const { export_json_to_excel } = require("../../excel/Export2Excel.js"); //必须使用绝对路径
          const tHeader = ["网点", "操作员", "业务类型", "支付方式", "金额（元）"]; // 标题
          const filterVal = ["id", "name", "amount1", "amount2", "amount3"]; // 导出的字段名
          const list = that.tableData;
          const data = that.formatJson(filterVal, list);
          export_json_to_excel(tHeader, data, `${this.label1}报表`);
        });
      },
      formatJson(filterVal, jsonData) {
        return jsonData.map(v => filterVal.map(j => v[j]));
      }
  },
};
</script>
