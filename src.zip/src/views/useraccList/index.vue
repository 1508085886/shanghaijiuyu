<!-- 账户详情 -->
<template>

    <el-container class="offline_layout o-font-family is-vertical">
        <el-main class=" offline_layout-main o-flex o-flex-column offline_useracclist_main">
            <layout-header :link-show="false" :avatar-show="false" :logout-show="false" />
            <div class="offline-useracclist">
                <div class="clearfix">
                    <div class="fl">
                        <h4 class="offline-useracclist_title">账户详情</h4>
                    </div>
                </div>
                <div class="o-flex o-flex-column offline-useracclist_content-wrap">
                    <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
                        <el-tab-pane :label="label1" name="first">
                            <template slot="label">
                                <span>{{ label1 }}
                                </span>
                            </template>
                            <useracc-list :form="form" :readonly="true" />
                        </el-tab-pane>
                        <el-tab-pane name="second">
                            <template slot="label">
                                <span>{{ label2 }}
                                </span>
                            </template>
                            <div class="offline-useraccList_class">
                                <span class="o-font-family offline-useracctlistquery-useracctId">账户编号：</span>
                                <el-input class="offline-useracctlistquery-input" v-model="useracctId"></el-input>
                                <el-radio-group v-model="queryDateType" class="offline-useracctlistquery-radio">
                                    <el-radio label="1">交易日期</el-radio>
                                    <el-radio label="2">结算日期</el-radio>
                                    <el-radio label="3">银行扣款日期</el-radio>
                                </el-radio-group>
                                <el-date-picker v-model="orderDate" type="daterange" range-separator="至"
                                    start-placeholder="开始日期" end-placeholder="结束日期" @change="datePickerChange"
                                    :clearable="false" class="offline-useracctlistquery-form-input"
                                    style="width: 240px;">
                                </el-date-picker>
                                <el-button :loading="tableLoading" class="offline-useracctlistquery_searchblock-search"
                                    size="small" type="primary" icon="el-icon-search" @click="onSearch" round>查询
                                </el-button>
                            </div>
                            <div class="offline-useraccList_form">
                                <el-table :data="tables" tooltip-effect="dark" style="width: auto; "
                                    :header-cell-style="{'background-color': '#D3D6DF',}">
                                    <el-table-column label="账户编号" prop="useracctId">
                                    </el-table-column>
                                    <el-table-column label="交易时间" prop="txtime">
                                    </el-table-column>
                                    <el-table-column label="结算日期" prop="obutxDate">
                                    </el-table-column>
                                    <el-table-column label="银行扣款日期" prop="bankAcctDate">
                                    </el-table-column>
                                    <el-table-column label="交易类型" prop="txcode">
                                    </el-table-column>
                                    <el-table-column label="交易金额" prop="txamount">
                                    </el-table-column>
                                    <el-table-column label="摘要" prop="description">
                                    </el-table-column>
                                    <el-table-column label="交易前余额" prop="befbalance">
                                    </el-table-column>
                                    <el-table-column label="交易后余额" prop="aftbalance">
                                    </el-table-column>
                                    <el-table-column label="车牌号码" prop="vehiclelicencePlatenumber">
                                    </el-table-column>
                                    <el-table-column label="卡号" prop="cardId">
                                    </el-table-column>
                                    <el-table-column label="标签ID" prop="obuId">
                                    </el-table-column>
                                </el-table>
                            </div>
                            <div style="height: 50px" class="clearfix  offline-storagecardrepayment_pagination">
                                <div class="fl offline-useraccList_tableblock-pagination-desc o-font-family"
                                    v-if="total">
                                    第{{ startRecords }}到{{ currentSize }}条，
                                </div>
                                <el-pagination background @size-change="handleSizeChange"
                                    @current-change="handleCurrentChange" :current-page.sync="currentPage"
                                    :page-size="pageSize" layout="total,->,prev, pager, next,slot" :total="total">
                                </el-pagination>
                            </div>
                        </el-tab-pane>
                    </el-tabs>

                </div>
            </div>
        </el-main>

    </el-container>
</template>

<script>
    import UseraccList from '@/components/UseraccList';
    import { queryEtcAcct } from '@/api/user';
    import { getFormatAmount, getFormatAmountYuan2Fen, getDatePoint, getTimePoint } from '@/utils/utils';
    import { useracctlistQuery } from '@/api/user';
    import {
        getFormatCardIdw,
    } from '@/utils/utils';
    import { formatDate } from '@/utils/format';
    import LayoutHeader from '../../layout/components/LayoutHeader';
    import { systemParameterQuery, } from '@/api/common';
    import {
        dicKeys,
        getAllDics,
        getDicDesByCode,
        getDicCodeByDes,
        getDicCodeByAll,
        getDicDesByAll,
    } from '@/methods/dics';
    export default {
        data() {
            return {
                form: {},
                activeName: 'first',
                label1: '账户详情',
                label2: '账户明细',
                useracctId: '',
                queryDateType: '1',
                total: 0, //总条数
                currentPage: 1,
                page: 1, //初始显示第几页
                pageSize: 8, //每页显示多少数据
                currentSize: 0, // 当前页条数
                orderDate: [],
                tableLoading: false,
                tables: [],
                etcUserId: '',
            };
        },
        computed: {
            //起始记录
            startRecords() {
                return (this.page - 1) * this.pageSize + 1;
            },
        },
        components: {
            UseraccList,
            LayoutHeader
        },
        methods: {
            async queryEtcAcct() {
                const resAcct = await queryEtcAcct({
                    etcUserId: this.etcUserId,
                    userAccountId: this.useracctId,
                });
                if (resAcct) {
                    this.form = resAcct
                    console.log(typeof this.form)
                }
            },
            handleSizeChange(val) {
                this.pageSize = val;
                this.onSearch()
                console.log(`每页 ${val} 条`);
            },
            handleCurrentChange(val) {
                this.page = val;
                this.currentPage = val;
                this.onSearch()
                console.log(`当前页: ${val}`);
            },
            handleClick(tab, event) { },
            datePickerChange() { },
            async setDate() {
                this.orderDate = [];
                //用后台接口返回的时间
                const res = await systemParameterQuery({ requestType: '00' });
                let dateString =
                    res.value.substring(0, 4) +
                    '-' +
                    res.value.substring(4, 6) +
                    '-' +
                    res.value.substring(6, 8);
                console.log(dateString);
                let date1 = new Date(dateString);
                this.orderDate.push(date1);
                this.orderDate.unshift(date1);
                console.log(this.orderDate);
                return true;
            },
            async onSearch() {
                const self = this
                //6.9	查询账户交易明细
                let beginDate = formatDate(
                    'YYYYMMDD',
                    new Date(this.orderDate[0].toDateString())
                );
                let endDate = formatDate(
                    'YYYYMMDD',
                    new Date(this.orderDate[1].toDateString())
                );
                const res = await useracctlistQuery({
                    useracctId: this.useracctId,
                    etcUserId: this.etcUserId,
                    queryDateType: this.queryDateType,
                    startDate: beginDate,
                    endDate: endDate,
                    startRecords: this.startRecords,
                    rowNumber: 8
                });
                if (res) {
                    this.tables = res.details
                    for (let i = 0; i < res.details.length; i++) {
                        self.tables[i].useracctId = self.tables[i].useracctId;
                        if (self.tables[i].txtime) {
                            self.tables[i].txtime = self.tables[i].txtime.replace(/(\s*$)/g, "")
                            self.tables[i].txtime = getTimePoint(self.tables[i].txtime);
                        }
                        if (self.tables[i].bankAcctDate) {
                            self.tables[i].bankAcctDate = self.tables[i].bankAcctDate.replace(/(\s*$)/g, "");
                            self.tables[i].bankAcctDate = getDatePoint(self.tables[i].bankAcctDate);
                        }
                        if (self.tables[i].obutxDate) {
                            self.tables[i].obutxDate = self.tables[i].obutxDate.replace(/(\s*$)/g, "")
                            self.tables[i].obutxDate = getDatePoint(self.tables[i].obutxDate);
                        }
                        self.tables[i].befbalance = getFormatAmount(self.tables[i].befbalance);
                        self.tables[i].aftbalance = getFormatAmount(self.tables[i].aftbalance);
                        self.tables[i].txamount = getFormatAmount(self.tables[i].txamount);
                        self.tables[i].txcode = self.tables[i].txcode;
                        self.tables[i].description = self.tables[i].description;
                        self.tables[i].vehiclelicencePlatenumber = self.tables[i].vehiclelicencePlatenumber;
                        if (self.tables[i].vehicleColor) {
                            self.tables[i].vehicleColor = await getDicDesByCode(
                                dicKeys.vehicleColor,
                                self.tables[i].vehicleColor);
                        }
                        if (self.tables[i].obuId) {
                            self.tables[i].obuId = getFormatCardIdw(self.tables[i].obuId);
                        }
                        if (self.tables[i].cardId) {
                            self.tables[i].cardId = getFormatCardIdw(self.tables[i].cardId);
                        }

                    }
                }
                this.total = res.totalRowNumber
                this.currentSize =
                    this.pageSize * this.page >= this.total
                        ? this.total
                        : this.page * this.pageSize;
            }
        },
        async mounted() {
            await this.setDate();
            this.useracctId = this.$route.query.userAcctId
            this.etcUserId = this.$route.query.etcUserId
            this.queryEtcAcct();
        }
    };
</script>