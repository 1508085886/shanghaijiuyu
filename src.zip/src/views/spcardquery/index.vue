<!--白名单查询-->
<template>
  <el-container class="offline_layout o-font-family is-vertical">
    <!-- <layout-header
      :link-show="false"
      :avatar-show="false"
      :logout-show="false"
    /> -->
    <el-container style="height: 0">
      <el-main class="o-height-full offline_layout-main o-flex o-flex-column">
        <div class="offline_layout-main-scroll">
          <div
            class="offline-workordermanagement_wrapper offline-workordermanagement_searchblock"
          >
            <el-form
              ref="form"
              :model="form"
              :rules="rules"
              :inline="true"
              label-position="right"
              label-width="auto"
              class="offline-workordermanagement_searchblock-form"
            >
              <el-row class="mt10" :gutter="0">
                <el-col :md="8" :lg="8">
                  <el-form-item
                    label="车牌号码："
                    prop="vehiclelicencePlatenumber"
                  >
                    <regex-input
                      type="vehiclelicencePlatenumber"
                      placeholder="请输入车牌号"
                      :maxlength="12"
                      v-model="form.vehiclelicencePlatenumber"
                      class="input-with-select offline-workordermanagement_searchblock-form-input"
                    ></regex-input>
                  </el-form-item>
                </el-col>
                <el-col :md="8" :lg="8">
                  <el-form-item label="车牌颜色：" prop="vehicleColor">
                    <type-select
                      type="vehicleColor"
                      v-model="form.vehicleColor"
                      placeholder="请选择"
                      class="offline-workordermanagement_searchblock-form-input"
                    />
                  </el-form-item>
                </el-col>
                <el-col :md="8" :lg="8">
                  <el-button
                    class="offline-workordermanagement_searchblock-search"
                    size="small"
                    type="primary"
                    icon="el-icon-search"
                    @click="onSearch"
                    round
                    >查询</el-button
                  >
                  <el-button
                    class="offline-workordermanagement_searchblock-refresh"
                    size="small"
                    icon="el-icon-refresh-left"
                    @click="refresh"
                    round
                    >清除</el-button
                  >
                </el-col>
              </el-row>
            </el-form>
          </div>
          <div
            class="mt10 offline-workordermanagement_wrapper offline-workordermanagement_tableblock"
          >
            <div class="offline-workordermanagement_tableblock-table">
              <el-table
                :data="tableData"
                style="width: 100%"
                header-cell-class-name="offline-workordermanagement_tableblock-header"
                cell-class-name="offline-workordermanagement_tableblock-cell"
              >
                <el-table-column
                  label="登记时间"
                  prop="registerTime"
                  width="100"
                >
                </el-table-column>
                <el-table-column label="客户编号" prop="userId">
                </el-table-column>
                <el-table-column label="客户手机号" prop="phoneNum">
                </el-table-column>
                <el-table-column label="原公司名称" prop="requestUserName">
                </el-table-column>
                <el-table-column label="当前公司名称" prop="userName">
                </el-table-column>
                <el-table-column label="白名单类型" prop="whiteType">
                </el-table-column>
                <el-table-column label="车辆归属地" prop="vehicleLocation">
                </el-table-column>
                <el-table-column
                  label="车牌号码"
                  prop="vehiclelicencePlatenumber"
                >
                </el-table-column>
                <el-table-column label="车辆颜色" prop="vehicleColor">
                </el-table-column>
                <el-table-column
                  label="车辆用户类型"
                  prop="vehicleType"
                  width="150"
                >
                </el-table-column>
                <el-table-column
                  label="发行状态"
                  prop="issueStatus"
                  width="150"
                >
                </el-table-column>
                <el-table-column label="升级状态" prop="upgradeStatus">
                </el-table-column>
              </el-table>
            </div>
            <div
              class="clearfix offline-workordermanagement_tableblock-pagination"
            >
              <div
                class="fl offline-workordermanagement_tableblock-pagination-desc"
                v-if="total"
              >
                第{{ startRecords }}到{{ currentSize }}条，
              </div>
              <el-pagination
                background
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="currentPage"
                :page-size="pageSize"
                layout="total,->,prev, pager, next,slot"
                :total="total"
              >
              </el-pagination>
            </div>
          </div>
        </div>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
//import LayoutHeader from '../../layout/components/LayoutHeader';
import { queryWhiteList } from '@/api/common';
import { dicKeys, getDicDesByCode } from '@/methods/dics';
import RegexInput from '@/components/RegexInput';
export default {
  data() {
    return {
      currentPage: 1,
      total: 0, //总条数
      page: 1, //初始显示第几页
      pageSize: 10, //每页显示多少数据
      currentSize: 0, // 当前页条数
      form: {
        vehiclelicencePlatenumber: '',
        vehicleColor: '',
      },
      rules: {},
      tableData: [],
      eVoucherTypeDescArr: [],
    };
  },
  components: {
    RegexInput,
  },
  computed: {
    //起始记录
    startRecords() {
      return (this.page - 1) * this.pageSize + 1;
    },
  },

  methods: {
    async onSearch() {
      if (this.form.vehiclelicencePlatenumber) {
        if (!this.form.vehicleColor) {
          this.$message({
            message: '请选择车牌颜色',
            type: 'error',
          });
          return;
        }
      }
      this.page = 1;
      this.currentPage = 1;
      this.getTabelInfo();
    },
    handleSizeChange(val) {
      this.pageSize = val;
      this.getTabelInfo();
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      // 当前为第几页时调用getTabelInfo()显示第几页数据
      this.page = val;
      this.currentPage = val;
      this.getTabelInfo();
      console.log(`当前页: ${val}`);
    },
    async getTabelInfo() {
      const res = await queryWhiteList({
        vehiclelicencePlatenumber: this.form.vehiclelicencePlatenumber,
        vehicleColor: this.form.vehicleColor,
        pageNo: this.currentPage,
        pageSize: 10,
      });
      if (res) {
        let recordListArr = res.whiteInfoList;
        for (let i = 0; i < recordListArr.length; i++) {
          recordListArr[i].whiteType = await getDicDesByCode(
            dicKeys.whiteType,
            recordListArr[i].whiteType
          );
          recordListArr[i].vehicleLocation = await getDicDesByCode(
            dicKeys.vehicleLocation,
            recordListArr[i].vehicleLocation
          );
          recordListArr[i].vehicleColor = recordListArr[i].vehicleColor + '';
          recordListArr[i].vehicleColor = await getDicDesByCode(
            dicKeys.vehicleColor,
            recordListArr[i].vehicleColor
          );
          recordListArr[i].vehicleType = recordListArr[i].vehicleType + '';
          recordListArr[i].vehicleType = await getDicDesByCode(
            dicKeys.vehicleUserClass,
            recordListArr[i].vehicleType
          );
          recordListArr[i].issueStatus = await getDicDesByCode(
            dicKeys.issueStatus,
            recordListArr[i].issueStatus
          );
          recordListArr[i].upgradeStatus = await getDicDesByCode(
            dicKeys.upgradeStatus,
            recordListArr[i].upgradeStatus
          );
        }
        this.tableData = res.whiteInfoList;
        this.total = res.recnum;
        this.currentSize =
          this.pageSize * this.page >= this.total
            ? this.total
            : this.page * this.pageSize;
        console.log(`this.total: ${this.total}`);
      }
    },
    refresh() {
      this.form.vehicleColor = '';
      (this.tableData = []), this.$refs.form.resetFields();
      (this.currentPage = 1),
        (this.total = 0), //总条数
        (this.page = 1), //初始显示第几页
        (this.pageSize = 10), //每页显示多少数据
        (this.currentSize = 0); // 当前页条数
    },
  },

  async mounted() {},
};
</script>
