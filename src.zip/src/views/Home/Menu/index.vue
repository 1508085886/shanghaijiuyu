<!-- 首页 -->
<template>
  <div class="offline-home">
    <div class="clearfix">
      <div class="fl">
        <!-- <el-button type="" @click="testlog">testLog</el-button> -->
        <h4 class="offline-home_title">业务办理</h4>
        <span class="offline-home_title-remark"
          >蓝色按钮表示符合办理条件、灰色按钮表示不符合办理条件</span
        >
      </div>
      <!-- <empty-button
        type="primary"
        round
        size="small"
        class="fr offline-home_publish-log"
      >
        <i class="el-icon-search" /> 发行日志
      </empty-button> -->
    </div>
    <ul>
      <li
        class="o-flex offline-home_menu-list"
        v-for="(item, i) in menus"
        :key="i"
      >
        <template v-if="isArray(item)">
          <div
            class="o-flex o-flex-1"
            v-for="(list, j) in item"
            :key="i + '' + j"
          >
            <div class="offline-home_menu-label">{{ list.label }}</div>
            <div class="o-flex-1 offline-home_menu-item-wrap">
              <empty-button
                type="primary"
                size="small"
                class="offline-home_menu-item"
                v-for="(menu, k) in list.items"
                :key="i + '' + j + k"
                :disabled="!menu.useage"
                @click="openUrl(menu.url)"
                >{{ menu.text }}</empty-button
              >
            </div>
          </div>
        </template>
        <template v-else>
          <div class="offline-home_menu-label">{{ item.label }}</div>
          <div class="o-flex-1 offline-home_menu-item-wrap">
            <empty-button
              type="primary"
              size="small"
              class="offline-home_menu-item"
              v-for="(menu, j) in item.items"
              :key="i + '' + j"
              :disabled="!menu.useage"
              @click="openUrl(menu.url)"
              >{{ menu.text }}</empty-button
            >
          </div>
        </template>
        <!-- <el-divider v-if="i < length - 1"></el-divider> -->
      </li>
    </ul>

    <el-dialog
      :title="dialogTitle"
      class="offline-dialog offline-dialog-medium"
      :visible.sync="dialogVisible"
      :append-to-body="appendToBody"
    >
      <div class="o-flex offline-home_dialog-content-wrap">
        <div
          class="
            o-flex-column
            offline-home_dialog-content offline-home_dialog-content-left
          "
        >
          <div class="mb20">请上传用户身份证（含临时身份证）</div>
          <div class="o-flex mb20">
            <photograph-block
              type="userCertType"
              is-button
              width="104"
              height="104"
              label="本地上传"
              default-type="1011"
              :append-to-body="true"
              no-select="local"
              @complete="selectedPic($event, 'local')"
              class="ml10 mr20"
              ocr
            />
            <photograph-block
              type="userCertType"
              is-button
              width="104"
              height="104"
              label="拍照上传"
              default-type="1011"
              :append-to-body="true"
              no-select="gpy"
              @complete="selectedPic($event, 'gpy')"
            />
          </div>
          <div class="offline-home_dialog-content_pics o-flex o-flex-wrap">
            <photograph-block
              only-pics
              :default-pics="selectedPics"
              @complete="selectedPic($event, 'change')"
            />
          </div>

          <div class="mb20">请上传银行卡</div>
          <div class="o-flex mb20">
            <photograph-block
              type="bankCardType"
              is-button
              width="104"
              height="104"
              label="本地上传"
              default-type="6011"
              :append-to-body="true"
              no-select="local"
              @complete="selectedPic2($event, 'local')"
              class="ml10 mr20"
              ocr
            />
            <photograph-block
              type="bankCardType"
              is-button
              width="104"
              height="104"
              label="拍照上传"
              default-type="6011"
              :append-to-body="true"
              no-select="gpy"
              @complete="selectedPic2($event, 'gpy')"
              ocr
            />
          </div>
          <div class="offline-home_dialog-content_pics o-flex o-flex-wrap">
            <photograph-block
              only-pics
              :default-pics="selectedPics2"
              @complete="selectedPic2($event, 'change')"
            />
          </div>
        </div>
        <div
          class="offline-home_dialog-content offline-home_dialog-content-right"
        >
          <div class="offline-home_dialog-content-right-title">
            证件内容识别
          </div>
          <el-form
            ref="form"
            :model="form"
            :rules="rules"
            class="offline-replacecard_step1-content-right-form"
          >
            <el-row>
              <el-col :md="24" :lg="24">
                <el-form-item label="用户名称" prop="userName">
                  <el-input v-model="form.userName"></el-input>
                </el-form-item>
              </el-col>
              <el-col :md="24" :lg="24">
                <el-form-item label="证件类型" prop="userCertType">
                  <el-input v-model="form.userCertType"></el-input>
                </el-form-item>
              </el-col>
              <el-col :md="24" :lg="24">
                <el-form-item label="证件号码" prop="userCode">
                  <el-input v-model="form.userCode"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="toReplaceCard">确 定</el-button>
      </span>
    </el-dialog>
    <transactor-dialog
      :visible.sync="transactorDialogVisible"
      :append-to-body="true"
      @transactorDialogComplete="transactorDialogComplete"
    />
    <verify-license-dialog
      :visible.sync="devicewriteoffDialogVisible"
      :append-to-body="appendToBody"
      @complete="toDeviceLogout"
    >
    </verify-license-dialog>
    <!-- <photograph-block
          @complete="toDeviceLogout"
          :uploadStyle="radio"
          type="verificationType"
          v-if="false"
        ></photograph-block> -->
  </div>
</template>

<script>
import PhotographBlock from '@/components/PhotographBlock';
import { getProgramDownloadUrl } from '@/api/login';
import VerifyLicenseDialog from '@/components/VerifyLicenseDialog';
import TransactorDialog from '@/components/TransactorDialog';
import EmptyButton from '@/components/EmptyButton';
import Dialog from '@/components/Dialog';
import { isArray } from '@/utils/validate';
import { userCheck } from '@/api/user';
import { unBindQualificationInquiry } from '@/api/writeoff';
import { openWindow } from '@/utils/utils';
import store from '@/store';
import { statusQuery } from '@/api/common';
import { checkQualification } from '@/api/equipment';
import { globalBus } from '@/utils/globalBus';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';
export default {
  data() {
    return {
      length: '',
      devicelogoutLicenseBlocks: [
        {
          id: 1,
          title: '原用户证件',
          darkBorderVisible: false,
        },
        {
          id: 2,
          title: '其它证件',
          darkBorderVisible: false,
        },
      ],
      devicelogoutRradio: 'drivierLicense',
      dialogTitle: '核验证件',
      dialogVisible: false,
      devicewriteoffDialogVisible: false,
      transactorDialogVisible: false, // 经办人信息弹窗
      appendToBody: true,
      // radio: 'uploadByPhoto',
      form: {},
      selectedPics: [],
      selectedPics2: [],
      devicelogoutForm: {},
      rules: {
        userName: [
          { required: true, message: '请输入用户名称', trigger: 'blur' },
        ],
        userCertType: [
          { required: true, message: '请输入证件类型', trigger: 'blur' },
        ],
        userCode: [
          { required: true, message: '请输入证件号码', trigger: 'blur' },
        ],
        vehicleNumber: [
          { required: true, message: '请输入车牌号码', trigger: 'blur' },
        ],
        vehicleType: [
          { required: true, message: '请输入车辆类型', trigger: 'blur' },
        ],
        ownerName: [
          { required: true, message: '请输入所有人', trigger: 'blur' },
        ],
        vehicleSpecies: [
          { required: true, message: '请输入使用性质', trigger: 'blur' },
        ],
        ownerAddress: [
          { required: true, message: '请输入联系地址', trigger: 'blur' },
        ],
      },
      menus: [
        // // {
        // //   label: '充值还款',
        // //   items: [
        // //     { text: '储值卡充值', useage: false },
        // //     { text: '记账账户充值', useage: false },
        // //     { text: '储值卡冲正', useage: false },
        // //     { text: '记账账户冲正', useage: false },
        // //     { text: '充值补卡额', useage: false },
        // //     { text: '多充值处理', useage: false },
        // //     { text: '储值卡挂账还款', useage: false },
        // //   ],
        // // },
        // {
        //   label: '卡片业务',
        //   items: [
        //     { text: '设备发行', useage: true, url: '/equipmentissuance' },
        //     // { text: '挂失解挂', useage: false },
        //     // { text: '补换卡', useage: true, url: '/replacecard' },
        //     // { text: '卡类型变更', useage: false },
        //     // { text: '卡片重写', useage: false },
        //     // { text: '卡片续期', useage: false },
        //     // { text: 'PIN解锁', useage: false },
        //   ],
        // },
        // // {
        // //   label: '标签业务',
        // //   items: [
        // //     { text: '补换签', useage: false },
        // //     { text: '标签重写', useage: false },
        // //     { text: '标签续期', useage: false },
        // //   ],
        // // },
        // {
        //   label: '车辆业务',
        //   items: [
        //     // { text: '车辆档案', useage: false },
        //     // { text: '车辆信息变更', useage: false },
        //     // { text: '设备过户', useage: false },
        //     // { text: '变更ETC账户', useage: false },
        //     // { text: '变更分支机构', useage: false },
        //     // { text: '安装码查询', useage: false },
        //     // { text: '状态名单管理', useage: false },
        //     // { text: '取消预售订单', useage: false },
        //     // { text: '解除车牌占用', useage: false },
        //     { text: '车牌验证', useage: true, url: '/licenseverify' },
        //     { text: '设备注销', useage: true, url: '/devicewriteoff' },
        //     // { text: '部平台报送', useage: false },
        //   ],
        // },
        // [
        //   {
        //     label: '账户及签约',
        //     items: [
        //       // { text: '账户信息管理', useage: false },
        //       // { text: '签约信息管理', useage: false },
        //       { text: '账户注销', useage: true, url: '/accountwriteoff' },
        //     ],
        //   },
        //   {
        //     label: '用户业务',
        //     items: [
        //       // { text: '用户档案', useage: false },
        //       { text: '用户信息变更', useage: true, url: '/pidchange' },
        //       { text: '单位信息变更', useage: true, url: '/cidchange' },
        //       // { text: '分支机构管理', useage: false },
        //       { text: '补车主信息', useage: true, url: '/fixowner' },
        //       { text: '补用户实名', useage: true, url: '/fixuser' },
        //     ],
        //   },
        // ],
        // // {
        // //   label: '查询业务',
        // //   items: [
        // //     { text: '卡片交易查询', useage: false },
        // //     { text: '账户明细查询', useage: false },
        // //   ],
        // // },
      ],
    };
  },
  components: {
    EmptyButton,
    Dialog,
    PhotographBlock,
    VerifyLicenseDialog,
    TransactorDialog,
  },
  created() {
    this.toUrl();
  },
  computed: {
    obuInfo() {
      return this.$store.getters.searchObuInfo;
    },
    cardInfo() {
      return this.$store.getters.searchCardInfo;
    },
    disabledStorageCardRecharge() {
      let flag = true;
      if (this.$store.getters.searchCardInfo.cardType != '0') {
        //卡片卡种不是0-储值卡,储值卡充值菜单为无效
        flag = false;
      }
      if (this.$store.getters.searchAccountInfo.userAcctStatus == '6') {
        //账户状态为6-已结清,储值卡充值菜单为无效
        flag = false;
      }
      if (this.$store.getters.searchCardInfo.cardStatus == '2') {
        //卡片状态为2-已注销,储值卡充值菜单为无效
        flag = false;
      }
      this.setMenuUseage(flag, ['/storagecardrecharge']); // 储值卡充值
      this.setMenuUseage(flag, ['/storagecardcirclerecharge']); // 储值卡圈存
      this.setMenuUseage(flag, ['/storagecardcheckcard']); // 储值卡验卡
      this.setMenuUseage(flag, ['/storedValueCardReverse']); // 储值卡冲正
      this.setMenuUseage(flag, ['/transferAcctReverse']); // 圈存账户冲正
    },
    //账户充值、冲正
    disabledAccountRecharge() {
      let flag = true;
      if (this.$store.getters.searchAccountInfo.userAcctType != '0') {
        //账户类型不为0-记账账户,菜单为无效
        flag = false;
      }
      if (this.$store.getters.searchAccountInfo.userAcctStatus == '6') {
        //账户状态为6-已结清,菜单为无效
        flag = false;
      }
      this.setMenuUseage(flag, ['/accountrecharge']); // 账户充值
      this.setMenuUseage(flag, ['/accountReverse']); // 账户冲正
    },
    disabledStorageCardRepayment() {
      let flag = true;
      if (this.$store.getters.searchCardInfo.cardType != '0') {
        //卡片卡种不是0-储值卡,储值卡充值菜单为无效
        flag = false;
      }
      if (this.$store.getters.searchAccountInfo.userAcctStatus == '6') {
        //账户状态为6-已结清,储值卡充值菜单为无效
        flag = false;
      }
      this.setMenuUseage(flag, ['/storagecardrepayment']); // 储值卡充值
    },
    vehicleInfoChange() {
      // 车辆信息变更 卡 签状态都为1可用
      if (
        this.$store.getters.searchCardInfo.cardStatus == 1 &&
        this.$store.getters.searchObuInfo.obuStatus == 1
      ) {
        this.setMenuUseage(true, ['/vehicleinfochange']); // 车辆信息变更
      } else {
        this.setMenuUseage(false, ['/vehicleinfochange']);
      }
      return this.$store.getters.searchCarInfo;
    },
    vissueverification() {
      if (this.$store.getters.searchUserInfo.userProperty) {
        this.setMenuUseage(true, ['/vissueverification']);
      } else {
        this.setMenuUseage(false, ['/vissueverification']);
      }
      return this.$store.getters.searchUserInfo;
    },
    readcardobu() {
      let flag = false;
      if (
        this.$store.getters.searchCarInfo.vehicleNumber &&
        this.$store.getters.searchCarInfo.vehicleType &&
        this.$store.getters.searchCarInfo.vehicleCategory
      ) {
        flag = true;
      }
      this.setMenuUseage(flag, ['/test1']); // 设备注销
      return this.$store.getters.searchCarInfo.vehicleCategory;
    },
    vehicleInfo() {
      let flag = false;
      if (
        this.$store.getters.searchCarInfo.vehicleNumber &&
        this.$store.getters.searchObuInfo.obuID &&
        this.$store.getters.searchCardInfo.cardID
      ) {
        flag = true;
      }
      this.setMenuUseage(flag, [
        '/devicewriteoff',
        '/changeobu',
        '/changecard',
      ]); // 设备注销
      return this.$store.getters.searchCarInfo;
    },
    userInfo() {
      let flag = false;
      if (this.$store.getters.searchUserInfo.userID) {
        flag = true;
      }
      this.setMenuUseage(flag, ['/licenseverify']); // 车辆验证
      return this.$store.getters.searchUserInfo;
    },
    etcuserid() {
      let flag = false;
      if (this.$store.getters.registerUser.etcUserId) {
        flag = true;
      }
      this.setMenuUseage(flag, ['/equipmentissuance']); // 设备发行
      // this.setMenuUseage(flag, ['/pidchange']);
      // this.setMenuUseage(flag, ['/cidchange']);
      return this.$store.getters.registerUser.etcUserId;
    },
    pidChange() {
      let flag = false;
      if (
        this.$store.getters.registerUser.etcUserId &&
        this.$store.getters.registerUser.userProperty === '1'
      ) {
        flag = true;
      }
      this.setMenuUseage(flag, ['/pidchange']); // 个人信息修改
      return this.$store.getters.registerUser.etcUserId;
    },
    cidChange() {
      let flag = false;
      if (
        this.$store.getters.registerUser.etcUserId &&
        this.$store.getters.registerUser.userProperty !== '1'
      ) {
        flag = true;
      }
      this.setMenuUseage(flag, ['/cidchange']); // 单位信息修改
      return this.$store.getters.registerUser.etcUserId;
    },
    userRegisterP() {
      let flag = true;
      if (this.$store.getters.registerUser.userProperty === '2') {
        flag = false;
      }
      // this.setMenuUseage(flag, ['/puserregister']); // 单位信息修改
      this.setMenuUseage(flag, ['/newpublishperson']); // 单位信息修改
      return this.$store.getters.registerUser.etcUserId;
    },
    userRegisterC() {
      let flag = true;
      if (this.$store.getters.registerUser.userProperty === '1') {
        flag = false;
      }
      this.setMenuUseage(flag, ['/newpublish']); // 单位信息修改
      return this.$store.getters.registerUser.etcUserId;
    },
    cardStatus() {
      let flag = false;
      let flagU = false;
      let flagR = false;
      if (this.$store.getters.searchCardInfo.cardStatus == '1') {
        //卡片挂失只有卡状态为1-已开通时可用
        flag = true;
      }
      if (this.$store.getters.searchCardInfo.cardStatus == '3') {
        //卡片解挂只有卡状态为3-挂失时可用
        flagU = true;
        //补卡，卡状态为3-挂失可用
        flagR = true;
      }
      if (this.$store.getters.searchCardInfo.cardStatus == '0') {
        //补卡，卡状态为0-未发行可用
        flagR = true;
      }
      this.setMenuUseage(flag, ['/reportloss']); // 卡片挂失
      this.setMenuUseage(flagU, ['/untiedhang']); // 卡片解挂
      this.setMenuUseage(flagR, ['/cardReplacement']); // 补卡
      return this.$store.getters.searchCardInfo.cardStatus;
    },
    obuStatus() {
      let flag = false;
      let flagU = false;
      let flagR = false;
      if (this.$store.getters.searchObuInfo.obuStatus == '1') {
        //标签挂失只有卡状态为1-已开通时可用
        flag = true;
      }
      if (this.$store.getters.searchObuInfo.obuStatus == '3') {
        //标签解挂只有卡状态为3-挂失时可用
        flagU = true;
        // 补签，状态为3-挂失可用
        flagR = true;
      }
      if (this.$store.getters.searchObuInfo.obuStatus == '0') {
        //标签挂失只有卡状态为0-未发行可用
        flagR = true;
      }
      this.setMenuUseage(flag, ['/obureportloss']); // 标签挂失
      this.setMenuUseage(flagU, ['/obuuntiedhang']); // 标签解挂
      this.setMenuUseage(flagR, ['/obuReplacement']); // 补签
      return this.$store.getters.searchObuInfo.obuStatus;
    },
    // test1() {
    //   let flag = false;
    //   this.setMenuUseage(flag, ['/test1']); // 变更用户名称
    // },
  },
  methods: {
    // testlog() {
    //   var w = etcdev.getlog('web20210611.log');
    //   console.log(w);
    // },
    // 点击上传经办人证件提交按钮
    transactorDialogComplete(transactorImg) {
      //保存经办人信息图片
      this.$store.dispatch('GetTransactorImg', transactorImg);
      //跳转换卡
      this.$router.push('/changecard-old');
    },
    setMenuUseage(flag, menuArr) {
      for (let i = 0; i < this.menus.length; i++) {
        let it = this.menus[i].items;
        for (let j = 0; j < it.length; j++) {
          for (let k = 0; k < menuArr.length; k++) {
            if (it[j].url === menuArr[k]) {
              it[j].useage = flag;
            }
          }
        }
      }
    },
    selectedPic(pics, type) {
      if (type === 'change') {
        this.selectedPics = [...pics];
      } else {
        this.selectedPics = [...this.selectedPics, ...pics];
      }
    },
    selectedPic2(pics, type) {
      if (type === 'change') {
        this.selectedPics2 = [...pics];
      } else {
        this.selectedPics2 = [...pics];
        const self = this;
        // self.$set(self.form, 'userName','2222');
        // 获取识别结果，赋值显示
        const currentPic = pics[pics.length - 1];
        const ocr = pics[pics.length - 1].ocr;
        console.log('ocr:' + ocr);
        console.log('currentPic:' + currentPic.type);
        if (ocr) {
          if (ocr && currentPic.type === '601-1') {
            self.$set(self.form, 'userName', ocr.bankCardNo);
          }
        }
      }
    },
    isArray(param) {
      return isArray(param);
    },
    toUrl(path) {
      globalBus.$off('clickToUrl');
      globalBus.$on('clickToUrl', (path) => {
        this.openUrl(path);
      });
    },
    async openUrl(path) {
      if (path === '/replacecard') {
        //补换卡弹窗
        this.dialogVisible = true;
      } else if (path === '/devicewriteoff') {
        //脱绑资格查询，返回成功后再进入核验证件的页面
        const res = await unBindQualificationInquiry({
          etcUserId: this.userInfo.etcUserId,
          vehicleNumber: this.vehicleInfo.vehicleNumber,
          vehicleColor: this.vehicleInfo.vehicleColor,
        });
        // const res = {allowTakeOff:'1'};
        const isAllowTakeOff = await getDicCodeByDes(
          dicKeys.allowTakeOff,
          '允许脱绑'
        );
        if (res) {
          // console.log(res.allowTakeOff);
          if (res.allowTakeOff === isAllowTakeOff) {
            //设备注销弹窗
            this.devicewriteoffDialogVisible = true;
          } else {
            this.$alert('不允许脱绑', '提示', {
              confirmButtonText: '确定',
              type: 'warning',
            });
          }
        }
      } else if (path === '/accountwriteoff') {
        if (this.userInfo.userID) {
          this.$router.push(path);
        } else {
          this.$alert('无法获取当前用户信息，请查询', '提示', {
            confirmButtonText: '确定',
            type: 'info',
          });
        }
      } else if (path === '/changecard-old') {
        // //经办人信息弹窗
        // this.transactorDialogVisible = true;
        //跳转换卡
        this.$router.push('/changecard-old');
      } else if (path === '/changecard') {
        // 换卡
        if (this.isEmptyObj(this.cardInfo)) {
          this.$alert('无法获取卡信息，请查询', '提示', {
            confirmButtonText: '确定',
            type: 'info',
          });
          return;
        }
        // 若卡种为0-储值卡或1-A类记账卡或3-A类联名卡或4-B类联名卡，不办理换卡业务。
        if (
          this.cardInfo.cardType == '0' ||
          this.cardInfo.cardType == '1' ||
          this.cardInfo.cardType == '3' ||
          this.cardInfo.cardType == '4'
        ) {
          this.$alert('储值卡/A类记账卡/联名卡，不提供换卡业务。', '提示', {
            confirmButtonText: '确定',
            type: 'info',
          });
          return;
        }
        // 卡状态及是否可办理及提示消息
        if (this.cardInfo.cardStatus == '0') {
          this.$alert('卡片未发行，不能换卡', '提示', {
            confirmButtonText: '确定',
            type: 'info',
          });
          return;
        } else if (this.cardInfo.cardStatus == '2') {
          this.$alert('卡片已注销，不能换卡', '提示', {
            confirmButtonText: '确定',
            type: 'info',
          });
          return;
        } else if (this.cardInfo.cardStatus == '3') {
          this.$alert('卡片已挂失，请办理解挂或挂失补办', '提示', {
            confirmButtonText: '确定',
            type: 'info',
          });
          return;
        } else if (this.cardInfo.cardStatus == '4') {
          this.$alert('卡片已禁用，不能换卡', '提示', {
            confirmButtonText: '确定',
            type: 'info',
          });
          return;
        } else if (this.cardInfo.cardStatus == '6') {
          this.$alert('卡片已休眠，不能换卡', '提示', {
            confirmButtonText: '确定',
            type: 'info',
          });
          return;
        }
        // 调后台的14.10.售后业务办理资格查询，若接口返回false，则不可办理换卡业务
        const bizCode = await getDicCodeByDes(dicKeys.bizCode, '换卡');
        const resCheck = await checkQualification({
          etcUserId: this.userInfo.etcUserId,
          vehicleNumber: this.vehicleInfo.vehicleNumber,
          vehicleColor: this.vehicleInfo.vehicleColor,
          bizCode,
        });
        if (resCheck) {
          this.$router.push(path);
        }
        // this.$router.push(path);
        // 原方案由前端自行查询状态名单的入单原因，确定是否可办理换卡业务，
        // 现改为统一由后台的14.10.售后业务办理资格查询判断
        // // 若卡片在状态名单里，调状态名单的查询接口查询具体的原因
        // if (this.cardInfo.blackStatus == '1') {
        //   if (this.cardInfo.cardID && this.userInfo.etcUserId) {
        //     const res = await statusQuery({
        //       cardId: this.cardInfo.cardID,
        //       etcUserId: this.userInfo.etcUserId,
        //     });
        //     if (res) {
        //       if (
        //         res.cardBlackInfo.reason == '2' ||
        //         res.cardBlackInfo.reason == '4' ||
        //         res.cardBlackInfo.reason == '6' ||
        //         res.cardBlackInfo.reason == '7'
        //       ) {
        //         // 挂失/透支/追缴欠费/账户冻结
        //         this.$alert('卡片在状态名单里，不能换卡', '提示', {
        //           confirmButtonText: '确定',
        //           type: 'info',
        //         });
        //         return;
        //       } else if (
        //         res.cardBlackInfo.reason == '5' &&
        //         res.cardBlackInfo.note == '除无卡注销、设备召回外的'
        //       ) {
        //         // 禁用，除无卡注销、设备召回外的
        //         this.$alert('卡片在状态名单里，不能换卡', '提示', {
        //           confirmButtonText: '确定',
        //           type: 'info',
        //         });
        //         return;
        //       }
        //     }
        //   }
        // }
      } else if (path === '/changeobu') {
        // 换签
        if (this.isEmptyObj(this.obuInfo)) {
          this.$alert('无法获取标签信息，请查询', '提示', {
            confirmButtonText: '确定',
            type: 'info',
          });
          return;
        }
        // 如果是货车、牵引车、专项作业车，卡片如果是1x的，
        // 换签前先提示先换卡或做卡类型变更，卡片换成4x卡后，才可以换签
        // 已注册的车辆，根据收费车型判断（未注册的车辆，综合查询不能成功）
        let vehicleClassArr = [];
        vehicleClassArr.push(
          await getDicCodeByDes(dicKeys.vehicleClassL, '一类客车')
        );
        vehicleClassArr.push(
          await getDicCodeByDes(dicKeys.vehicleClassL, '二类客车')
        );
        vehicleClassArr.push(
          await getDicCodeByDes(dicKeys.vehicleClassL, '三类客车')
        );
        vehicleClassArr.push(
          await getDicCodeByDes(dicKeys.vehicleClassL, '四类客车')
        );
        if (!vehicleClassArr.includes(this.vehicleInfo.vehicleClass)) {
          if (
            this.cardInfo.versionNo == '00' ||
            this.cardInfo.versionNo.startsWith('1')
          ) {
            this.$alert(
              '卡片为1x版本，请先进行卡类型变更或换卡，再更换标签',
              '提示',
              {
                confirmButtonText: '确定',
                type: 'info',
              }
            );
            return;
          }
        }
        // 标签状态及是否可办理及提示消息
        if (this.obuInfo.obuStatus == '0') {
          this.$alert('标签未发行，不能换签', '提示', {
            confirmButtonText: '确定',
            type: 'info',
          });
          return;
        } else if (this.obuInfo.obuStatus == '2') {
          this.$alert('标签已注销，不能换签', '提示', {
            confirmButtonText: '确定',
            type: 'info',
          });
          return;
        } else if (this.obuInfo.obuStatus == '3') {
          this.$alert('标签已挂失，请办理解挂或挂失补办', '提示', {
            confirmButtonText: '确定',
            type: 'info',
          });
          return;
        } else if (this.obuInfo.obuStatus == '4') {
          this.$alert('标签已禁用，不能换签', '提示', {
            confirmButtonText: '确定',
            type: 'info',
          });
          return;
        } else if (this.obuInfo.obuStatus == '6') {
          this.$alert('标签已休眠，不能换签', '提示', {
            confirmButtonText: '确定',
            type: 'info',
          });
          return;
        }
        // 调后台的14.10.售后业务办理资格查询，若接口返回false，则不可办理换签业务
        const bizCode = await getDicCodeByDes(dicKeys.bizCode, '换签');
        const resCheck = await checkQualification({
          etcUserId: this.userInfo.etcUserId,
          vehicleNumber: this.vehicleInfo.vehicleNumber,
          vehicleColor: this.vehicleInfo.vehicleColor,
          bizCode,
        });
        if (resCheck) {
          this.$router.push(path);
        }
        // this.$router.push(path);
        // 原方案由前端自行查询状态名单的入单原因，确定是否可办理换签业务，
        // 现改为统一由后台的14.10.售后业务办理资格查询判断
        // // 若卡片在状态名单里，调状态名单的查询接口查询具体的原因
        // if (this.obuInfo.blackStatus == '1') {
        //   if (this.obuInfo.obuID && this.userInfo.etcUserId) {
        //     const res = await statusQuery({
        //       obuId: this.obuInfo.obuID,
        //       etcUserId: this.userInfo.etcUserId,
        //     });
        //     if (res) {
        //       if (res.cardBlackInfo.reason == '6') {
        //         // 车型不符
        //         this.$alert('标签在状态名单里，不能换签', '提示', {
        //           confirmButtonText: '确定',
        //           type: 'info',
        //         });
        //         return;
        //       }
        //     }
        //   }
        // }
      } else if (path === '/licenseverify') {
        if (this.userInfo.userID) {
          // alert(`this.userInfo.userName:${this.userInfo.userName}`);
          const query = {
            oprtId: this.$store.getters.oprtId,
            token: this.$store.getters.token,
            etcUserId: this.userInfo.etcUserId,
            userName: this.userInfo.userName,
            userCertType: this.userInfo.userCertType,
            userCode: this.userInfo.userCode,
          };
          openWindow(path, query);
        } else {
          this.$alert('无法获取当前用户信息，请查询', '提示', {
            confirmButtonText: '确定',
            type: 'info',
          });
        }
      } else if (path === '/newpublish') {
        // this.$confirm(
        //   '本系统目前只提供“建行”、“对公”车辆的发行，其他发行业务暂不支持。',
        //   '注意！',
        //   {
        //     confirmButtonText: '确定',
        //     cancelButtonText: '取消',
        //     type: 'warning',
        //   }
        // )
        //   .then(() => {
        this.$router.push({
          path: '/newpublish',
        });
        // })
        // .catch(() => {});
      } else if (path === '/cardReplacement') {
        // 补卡
        if (this.isEmptyObj(this.cardInfo)) {
          this.msgDialogInfo('无法获取卡信息，请查询');
          return;
        }
        // 若卡种为0-储值卡或1-A类记账卡或3-A类联名卡或4-B类联名卡，不办理补卡业务。
        if (
          this.cardInfo.cardType == '0' ||
          this.cardInfo.cardType == '1' ||
          this.cardInfo.cardType == '3' ||
          this.cardInfo.cardType == '4'
        ) {
          this.msgDialogInfo('储值卡/A类记账卡/联名卡，不提供补卡业务');
          return;
        }
        // 卡状态及是否可办理及提示消息
        if (this.cardInfo.cardStatus == '1') {
          this.msgDialogInfo('卡片已开通，不能补卡');
          return;
        } else if (this.cardInfo.cardStatus == '2') {
          this.msgDialogInfo('卡片已注销，不能补卡');
          return;
        } else if (this.cardInfo.cardStatus == '4') {
          this.msgDialogInfo('卡片已禁用，不能补卡');
          return;
        } else if (this.cardInfo.cardStatus == '5') {
          this.msgDialogInfo('卡片已制卡，不能补卡');
          return;
        } else if (this.cardInfo.cardStatus == '6') {
          this.msgDialogInfo('卡片已休眠，不能补卡');
          return;
        }
        // 调后台的14.10.售后业务办理资格查询，若接口返回false，则不可办理补卡业务
        const bizCode = await getDicCodeByDes(dicKeys.bizCode, '补卡');
        const resCheck = await checkQualification({
          etcUserId: this.userInfo.etcUserId,
          vehicleNumber: this.vehicleInfo.vehicleNumber,
          vehicleColor: this.vehicleInfo.vehicleColor,
          bizCode,
        });
        if (resCheck) {
          this.$router.push(path);
        }
      } else if (path === '/obuReplacement') {
        // 补签
        if (this.isEmptyObj(this.obuInfo)) {
          this.msgDialogInfo('无法获取标签信息，请查询');
          return;
        }
        // 如果是货车、牵引车、专项作业车，卡片如果是1x的，
        // 换签前先提示先换卡或做卡类型变更，卡片换成4x卡后，才可以换签
        // 已注册的车辆，根据收费车型判断（未注册的车辆，综合查询不能成功）
        let vehicleClassArr = [];
        vehicleClassArr.push(
          await getDicCodeByDes(dicKeys.vehicleClassL, '一类客车')
        );
        vehicleClassArr.push(
          await getDicCodeByDes(dicKeys.vehicleClassL, '二类客车')
        );
        vehicleClassArr.push(
          await getDicCodeByDes(dicKeys.vehicleClassL, '三类客车')
        );
        vehicleClassArr.push(
          await getDicCodeByDes(dicKeys.vehicleClassL, '四类客车')
        );
        if (!vehicleClassArr.includes(this.vehicleInfo.vehicleClass)) {
          if (
            this.cardInfo.versionNo == '00' ||
            this.cardInfo.versionNo.startsWith('1')
          ) {
            this.$alert(
              '卡片为1x版本，请先进行卡类型变更或换卡，再更换补签',
              '提示',
              {
                confirmButtonText: '确定',
                type: 'info',
              }
            );
            return;
          }
        }
        // 标签状态及是否可办理及提示消息
        if (this.obuInfo.obuStatus == '1') {
          this.msgDialogInfo('标签已开通，不能补签');
          return;
        } else if (this.obuInfo.obuStatus == '2') {
          this.msgDialogInfo('标签已注销，不能补签');
          return;
        } else if (this.obuInfo.obuStatus == '4') {
          this.msgDialogInfo('标签已禁用，不能补签');
          return;
        } else if (this.obuInfo.obuStatus == '5') {
          this.msgDialogInfo('标签已制卡，不能补签');
          return;
        } else if (this.obuInfo.obuStatus == '6') {
          this.msgDialogInfo('标签已休眠，不能补签');
          return;
        }
        // 调后台的14.10.售后业务办理资格查询，若接口返回false，则不可办理补签业务
        const bizCode = await getDicCodeByDes(dicKeys.bizCode, '补签');
        const resCheck = await checkQualification({
          etcUserId: this.userInfo.etcUserId,
          vehicleNumber: this.vehicleInfo.vehicleNumber,
          vehicleColor: this.vehicleInfo.vehicleColor,
          bizCode,
        });
        if (resCheck) {
          this.$router.push(path);
        }
      } else if (path === '/storagecardrecharge') {
        // 储值卡充值
        this.$router.push(path);
      } else if (path === '/storedValueCardReverse') {
        // 储值卡冲正
        this.$router.push(path);
      } else if (path === '/transferAcctReverse') {
        // 圈存账户冲正
        this.$router.push(path);
      } else {
        //一般跳转
        this.$router.push(path);
      }
    },
    // radioChange(label) {},
    async toReplaceCard() {
      // 检验用户信息
      const res = await userCheck({
        userCode: this.form.userCode,
        userCertType: this.form.userCertType,
      });
      if (res) {
        this.dialogVisible = false;
        this.$router.push('/replacecard');
      } else {
        this.$alert(res.description, '提示', {
          confirmButtonText: '确定',
          type: 'error',
        });
      }
    },
    // 跳转至设备注销页
    toDeviceLogout(imageInfo) {
      if (imageInfo.length === 0) {
        this.$message.info('请上传核验证件');
      } else {
        this.devicewriteoffDialogVisible = false;
        //保存经办人信息图片
        // console.log(imageInfo);
        this.$store.dispatch('GetVerifyLicenseImg', imageInfo);
        this.$router.push('/devicewriteoff');
        // this.$router.push({path: '/devicewriteoff', query: {verifyLicenseImg: imageInfo}});
      }
    },
    licenseBlockClick(licenseBlock) {
      this.devicelogoutLicenseBlocks.forEach((element) => {
        element.darkBorderVisible = false;
      });
      licenseBlock.darkBorderVisible = true;
    },
    getmenu() {
      const a = this.$store.getters.menuIds;
      for (let i = 0; i < a.length; i++) {
        if (!a[i].children.length) {
          //alert(a[i].children);
          a.splice(i, 1);
          i = i - 1;
        }
        this.length = i;
        const parin = a[i]; //{}
        let parus = {};

        let item = [];

        const parchildren = parin.children;

        for (let j = 0; j < parchildren.length; j++) {
          if (parchildren[j].hidden === '0') {
            let ichildren = {};
            ichildren.text = parchildren[j].title;
            ichildren.url = parchildren[j].url;

            // if (parchildren[j].hidden === '1') {
            //   ichildren.useage = false;
            // } else {
            ichildren.useage = true;
            // }
            item.push(ichildren);
          }
        }
        parus.label = parin.title;
        parus.items = item;
        if (a[i].hidden === '0') {
          this.menus.push(parus);
        }
      }
    },
    msgDialogInfo(textInfo) {
      this.$alert(textInfo, '提示', {
        confirmButtonText: '确定',
        type: 'info',
      });
    },
  },
  mounted() {
    // this.menuIds
    this.getmenu();
  },

  watch: {
    '$store.getters.menuIds'() {
      // if (this.$store.getters.menuIds) {
      this.getmenu();
      // }
    },

    '$store.indexDb.registerUser'() {
      // alert(this.$store.getters.registerUser.etcUserId);
    },
    etcuserid() {},
    userInfo() {},
    vehicleInfo() {},
    pidChange() {},
    cidChange() {},
    readcardobu() {},
    userRegisterC() {},
    userRegisterP() {},
    vehicleInfoChange() {},
    cardStatus() {},
    disabledStorageCardRecharge() {},
    disabledAccountRecharge() {},
    disabledStorageCardRepayment() {},
    vissueverification() {},
    // userAcctStatus() {},
    // cardType() {},
    obuStatus() {},
    // test1() {},
    '$store.getters.registerUser.etcUserId'() {
      // if (!this.$store.getters.registerUser.etcUserId) {
      //   // alert(1);
      // }
      // alert(1);
      // alert(this.$store.getters.registerUser.etcUserId);
    },
  },
};
</script>
<style lang="scss">
@import '@/assets/styles/variables.scss';
/* 
 .el-divider--horizontal {
   margin: 8px 0;s
   background: 0 0;
   border: 1px solid #c0c0c0;
 } */
</style>