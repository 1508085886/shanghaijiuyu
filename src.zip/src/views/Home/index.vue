<!--  -->
<template>
  <div class="offline-main o-flex o-flex-column">
    <current-car-info />
    <div class="o-flex-1 offline-main_router-view">
      <router-transition />
    </div>
  </div>
</template>

<script>
import RouterTransition from '@/components/RouterTransition';
import CurrentCarInfo from './CurrentCarInfo';
export default {
  components: {
    CurrentCarInfo,
    RouterTransition,
  },
};
</script>
