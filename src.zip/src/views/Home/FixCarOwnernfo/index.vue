<!-- 用户注册 -->
<template>
  <div class="m20 mr20 mt40">
    <div class="o-flex">
      <photograph-block
        ocr
        type="OwnerCertType"
        title="拍照识别证件正面"
        :append-to-body="true"
        @complete="complete"
      ></photograph-block>
    </div>
    <el-form ref="form" :model="form" :rules="rules" class="mt30">
      <el-row :gutter="20">
        <el-col :md="12" :lg="8">
          <el-form-item label="车主姓名" prop="ownerName">
            <el-input v-model="form.ownerName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :md="12" :lg="8">
          <el-form-item label="车主类型" prop="ownerType">
            <type-select
              type="userType"
              v-model="form.ownerType"
              placeholder="请选择"
              class="o-width-full"
            />
          </el-form-item>
        </el-col>
        <el-col :md="12" :lg="8">
          <el-form-item label="车主证件类型" prop="ownerCertType">
            <type-select
              type="userCertType"
              v-model="form.ownerCertType"
              placeholder="请选择"
              class="o-width-full"
            />
            <!-- <el-select v-model="form.userCertType" placeholder="请选择" class="o-width-full">
              <el-option
                v-for="type in IDCardTypes"
                :key="type.value"
                :label="type.description"
                :value="type.value"
              />
            </el-select>-->
          </el-form-item>
        </el-col>
        <el-col :md="12" :lg="8">
          <el-form-item label="车主证件号码" prop="ownerCode">
            <el-input v-model="form.ownerCode"></el-input>
          </el-form-item>
        </el-col>
        <el-col :md="12" :lg="8">
          <el-form-item label="车主联系地址" prop="ownerAddress">
            <el-input v-model="form.ownerAddress"></el-input>
          </el-form-item>
        </el-col>

        <el-col :md="12" :lg="8">
          <el-form-item label="车主联系方式" prop="ownerphoneNum">
            <el-input v-model="form.ownerphoneNum"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </div>
</template>

<script>
//import { validPhone } from '@/utils/validate';
import PhotographBlock from '@/components/PhotographBlock';
import { validPhone, vzz } from '@/utils/validate';
import { IDCard1, IDCard2 } from '@/temp/base64';
//import {setTargetPublishData,getTargetPublishData,publishData,} from '../dataManage';
import VoucherLayer from '@/components/VoucherLayer';
//import { userRegister } from '@/api/newPublish';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
} from '@/methods/dics';
let ruleusercode = /^[A-Za-z0-9()-]+$/;
export default {
  data() {
    return {
      form: {
        ownerImageList: [], // 用户身份证照片
      },
      rules: {
        ownerName: [
          { required: true, message: '请输入车主姓名', trigger: 'blur' },
          { max: 64, message: '长度不能超过64个字符', trigger: 'blur' },
        ],
        ownerType: [{ message: '请选择车主类型', trigger: 'blur' }],
        ownerCertType: [
          { message: '请选择车主证件类型', trigger: 'blur' },
          { max: 3, message: '长度不能超过3个字符', trigger: 'blur' },
        ],
        ownerCode: [
          { message: '请输入车主证件号码', trigger: 'blur' },
          { max: 32, message: '长度不能超过32个字符', trigger: 'blur' },
          {
            validator(rule, value, callback) {
              if (vzz(ruleusercode, value)) {
                callback();
              } else {
                callback(new Error('证件格式有误'));
              }
            },
            trigger: 'blur',
          },
        ],
        ownerAddress: [{ message: '请输入车主联系地址', trigger: 'blur' }],
        ownerphoneNum: [
          { message: '请输入车主联系方式', trigger: 'blur' },
          { max: 11, message: '长度不能超过11个字符', trigger: 'blur' },
          {
            validator(rule, value, callback) {
              if (validPhone(value)) {
                callback();
              } else {
                callback(new Error('手机号码格式有误'));
              }
            },
            trigger: 'blur',
          },
        ],
      },
    };
  },
  components: {
    PhotographBlock,
    VoucherLayer,
  },
  watch: {
    'form.ownerCertType'(val) {
      this.form.ownerType = val.substr(0, 1);
    },
  },
  methods: {
    getFormData() {
      return this.form;
    },
    // ocr识别结果
    complete(imgs) {
      const self = this;
      self.form.ownerImageList = imgs.map((img) => {
        let imgtype1;

        if (img.ocr) {
          if (img.type === '101-1') {
            self.$set(self.form, 'ownerName', img.ocr.userName || '');
            self.$set(self.form, 'ownerAddress', img.ocr.address || '');
            self.$set(
              self.form,
              'ownerCertType',
              (img.ocr.userCertType && img.ocr.userCertType.slice(0, -1)) || ''
            );
            self.$set(self.form, 'ownerCode', img.ocr.userCode || '');
          } else if (img.type === '203-1') {
            self.$set(self.form, 'ownerName', img.ocr.name || '');
            self.$set(self.form, 'ownerAddress', img.ocr.address || '');
            self.$set(self.form, 'ownerCertType', '203');
            self.$set(self.form, 'ownerCode', img.ocr.regNum || '');
          }
        }
        if (img.ocr) {
          imgtype1 = img.ocr.userCertType;
        } else {
          imgtype1 = img.type.replace('-', '');
        }
        if (!imgtype1) {
          imgtype1 = img.type.replace('-', '');
        }
        return {
          imgFrontID: img.frontImgid,
          mediaType: '2',
          // imgType: img.ocr.userCertType || img.type.replace('-', ''),
          imgType: imgtype1,
        };
      });
    },
  },
};
</script>
