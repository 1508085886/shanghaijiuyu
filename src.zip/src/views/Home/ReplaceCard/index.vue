<!-- 首页 -->
<template>
  <div class="offline-replacecard">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-replacecard_title">补换卡</h4>
      </div>
    </div>
    <div class="o-flex offline-replacecard_step-block-wrap">
      <!-- <div class="offline-replacecard_step-block">
        <div class="offline-replacecard_step-title-wrap">
          <span class="offline-replacecard_step-title-no">1</span>
          <span class="offline-replacecard_step-title-desc">核验证件</span>
        </div>
        <div class="o-flex-column offline-replacecard_step1-content-wrap">
          <photograph-block
            width="266"
            height="146"
            title="点击拍摄行驶证"
          ></photograph-block>
          <el-form
            ref="form"
            :model="form"
            :rules="rules"
            class="offline-replacecard_step1-content-form"
          >
            <el-row>
              <el-col :md="24" :lg="24">
                <el-form-item label="车牌号码" prop="vehicleNumber">
                  <el-input v-model="form.vehicleNumber"></el-input>
                </el-form-item>
              </el-col>
              <el-col :md="24" :lg="24">
                <el-form-item label="车牌颜色" prop="vehicleColor">
                  <el-input v-model="form.vehicleColor"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
      </div> -->
      <div class="offline-replacecard_step-block">
        <div class="offline-replacecard_step-title-wrap">
          <span class="offline-replacecard_step-title-no">1</span>
          <span class="offline-replacecard_step-title-desc">旧卡核销</span>
        </div>
        <div class="o-flex-column offline-replacecard_step2-content-wrap">
          <el-row :gutter="0" class="offline-replacecard_step-content-select">
            <el-col :xl="8" :lg="8" :md="8">
              <el-radio v-model="radio" label="haveCard" @change="radioChange"
                >旧卡有卡</el-radio
              ></el-col
            >
            <el-col :xl="12" :lg="12" :md="12">
              <el-radio v-model="radio" label="noCard" @change="radioChange"
                >旧卡无卡</el-radio
              ></el-col
            >
          </el-row>
          <el-button
            class="offline-replacecard_step-content-btn"
            size="small"
            type="primary"
            :style="{ display: readCardDisplay }"
            @click="readCard"
            round
          >
            <i class="icon iconfont iconbofang" /> 读卡
          </el-button>
          <div>
            <el-row :gutter="0" class="offline-replacecard_step-content-row">
              <el-col :xl="8" :lg="8" :md="8">旧卡卡号</el-col>
              <el-col :xl="16" :lg="16" :md="16">{{
                oldCard.cardNumber
              }}</el-col>
            </el-row>
            <el-row :gutter="0" class="offline-replacecard_step-content-row">
              <el-col :xl="8" :lg="8" :md="8">旧卡类型</el-col>
              <el-col :xl="16" :lg="16" :md="16">{{ oldCard.cardType }}</el-col>
            </el-row>
            <!-- <el-row :gutter="0" class="offline-replacecard_step-content-row">
            <el-col :xl="8" :lg="8" :md="8">旧卡状态</el-col>
            <el-col :xl="16" :lg="16" :md="16">挂失</el-col>
          </el-row> -->
            <el-row :gutter="0" class="offline-replacecard_step-content-row">
              <el-col :xl="8" :lg="8" :md="8">旧卡版本号</el-col>
              <el-col :xl="16" :lg="16" :md="16">{{
                oldCard.cardVersion
              }}</el-col>
            </el-row>
          </div>
        </div>
        <div class="offline-replacecard_step-bottom">
          <el-popconfirm
            icon="el-icon-info"
            iconColor="red"
            title="卡片核销不能回退，确认要核销吗？"
            @onConfirm="writeOff"
          >
            <el-button
              slot="reference"
              class="offline-replacecard_step-btn offline-replacecard_step2-btn"
              size="medium "
              type="danger "
              :disabled="jkhxDisabled"
              round
            >
              旧卡核销
            </el-button>
          </el-popconfirm>
        </div>
      </div>
      <div class="offline-replacecard_step-block">
        <div class="offline-replacecard_step-title-wrap">
          <span class="offline-replacecard_step-title-no">2</span>
          <span class="offline-replacecard_step-title-desc">新卡发行</span>
        </div>
        <img
          class="offline-replacecard_step-pic"
          src="../../../assets/images/pic_xkfx.png"
        />
        <div class="o-flex-column offline-replacecard_step3-content-wrap">
          <el-row :gutter="0" class="offline-replacecard_step-content-row">
            <el-col :xl="8" :lg="8" :md="8">新卡卡号</el-col>
            <el-col :xl="16" :lg="16" :md="16">03222033334990321</el-col>
          </el-row>
        </div>
        <div class="offline-replacecard_step-bottom">
          <el-button
            class="offline-replacecard_step3-btn"
            size="medium "
            type="primary "
            round
          >
            新卡发行
          </el-button>
        </div>
      </div>
    </div>
    <el-button
      class=""
      size="medium "
      type="primary "
      @click="voucherVisiable = true"
      round
    >
      完成
    </el-button>
    <voucher-layer
      :column="2"
      :info="voucherData"
      :footer="voucherFooter"
      :keys="voucherKeys"
      :visible.sync="voucherVisiable"
      @complete="toHome"
    ></voucher-layer>
  </div>
</template>

<script>
// import PhotographBlock from '@/components/PhotographBlock';
import VoucherLayer from '@/components/VoucherLayer';

export default {
  data() {
    return {
      // form: {},
      // rules: {
      //   vehicleNumber: [
      //     { required: true, message: '请输入车牌号码', trigger: 'blur' },
      //   ],
      //   vehicleColor: [
      //     { required: true, message: '请输入车牌颜色', trigger: 'blur' },
      //   ],
      // },
      radio: 'haveCard',
      readCardDisplay: 'block',
      jkhxDisabled: false,
      oldCard: {
        cardNumber: '',
        cardType: '',
        cardVersion: '',
      },
      voucherData: {
        businessType: '补换卡',
        userName: '张怡宁',
        vehicleNumber: '沪A502102',
        vehicleColor: '0-蓝色',
        cardId: '063100408667568',
        cardType: '23-ETC联名卡',
        cardStatus: '1-已开通',
        stopDate: '',
        lbjmoney: '0.00',
        gbmoney: '0.00',
        total: '0.00',
      },
      voucherFooter: {
        date: '2020/9/12 8:23:31',
        outletId: '10001',
        operator: '龙傲天',
      },
      voucherKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [{ key: 'userName', label: '用户名称' }],
        [
          { key: 'vehicleNumber', label: '车牌号码' },
          { key: 'vehicleColor', label: '车牌颜色' },
        ],
        [
          { key: 'cardId', label: '卡号' },
          { key: 'cardType', label: '卡类型' },
          { key: 'cardStatus', label: '卡状态' },
          { key: 'stopDate', label: '质保截止日' },
        ],
        [
          { key: 'lbjmoney', label: '零部件费用', span: 2 },
          { key: 'gbmoney', label: '工本费' },
          { key: 'total', label: '总计' },
        ],
      ],
      voucherVisiable: false,
    };
  },
  components: {
    // PhotographBlock,
    VoucherLayer,
  },
  watch: {},
  methods: {
    radioChange(label) {
      if (label === 'noCard') {
        this.readCardDisplay = 'none';
        this.oldCard = {
          cardNumber: '03222033334990321',
          cardType: '记账卡',
          cardVersion: '11',
        };
      } else {
        this.readCardDisplay = 'block';
        this.oldCard = {
          cardNumber: '',
          cardType: '',
          cardVersion: '',
        };
      }
    },
    readCard() {
      this.oldCard = {
        cardNumber: '03222033334990321',
        cardType: '记账卡',
        cardVersion: '11',
      };
    },
    writeOff() {
      this.jkhxDisabled = !this.jkhxDisabled;
      this.$alert('旧卡核销成功', '提示', {
        confirmButtonText: '确定',
        type: 'success',
        // callback: action => {
        //   this.$message({
        //     type: 'info',
        //     message: `action: ${action}`,
        //   });
        // },
      });
    },
    // 点击抽屉完成按钮
    async toHome() {
      this.$router.push({
        path: '/menu',
      });
    },
  },
};
</script>
