<!-- 首页 -->
<template >
  <div
    class="offline-equipmentissuance"
    v-loading.fullscreen.lock="fullscreenLoading"
  >
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-equipmentissuance_title">设备发行</h4>
      </div>
      <!-- <div>
        <el-input
          class="searchVal"
          type="text"
          placeholder="输入车牌搜索"
          v-model="searchVal"
        />
      </div> -->
    </div>
    <div class="o-flex o-flex-column offline-equipmentissuance_content-wrap">
      <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
        <el-tab-pane :label="label1" name="first">
          <template slot="label">
            <span
              >{{ label1 }}
              <el-badge class="mark" :value="info.length" :type="tp1"
            /></span>
          </template>
          <div
            class="offline-equipmentissuance_content-beforeissue-info"
            v-if="vif"
          >
            <!-- :nameCheck1="name1Check" -->
            <car-info
              :info="car"
              v-for="(car, i) in info"
              :key="i"
              :checkboxDisplay="beforeissueCheckboxDisplay"
              @selectChange="selectChange"
            >
              <!-- <template slot="buttons">
                <empty-button @click="cancel(car)" type="danger" size="mini"
                  >取消订单</empty-button
                >
              </template> -->
            </car-info>
          </div>
          <div
            class="o-flex o-flex-row offline-equipmentissuance_content-bottom mt30"
          >
            <el-form
              ref="form"
              :model="form"
              :rules="rules"
              class="offline-equipmentissuance_content-form"
            >
              <el-row :gutter="30">
                <!-- <el-form-item label="安装方式" prop="fixType"> -->

                <!-- <el-col :md="12" :lg="12">
                  <el-form-item label="安装方式">
                    <type-select
                      type="fixType"
                      v-model="form.fixType"
                      class="o-width-full"
                    ></type-select>
                  </el-form-item>
                </el-col> -->
                <el-col :md="12" :lg="12">
                  <el-form-item label="支付方式" prop="payMode">
                    <type-select
                      type="payMode"
                      v-model="form.payMode"
                      class="o-width-full"
                    ></type-select>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
            <div
              class="o-flex o-flex-row offline-equipmentissuance_content-settle-wrap"
            >
              <div
                class="o-flex o-flex-column offline-equipmentissuance_content-settle"
              >
                <span class="offline-equipmentissuance_content-settle-desc"
                  >设备费合计（元）</span
                >
                <span class="offline-equipmentissuance_content-settle-money">{{
                  devicePrice
                }}</span>
              </div>
              <div
                class="o-flex o-flex-column offline-equipmentissuance_content-settle"
              >
                <span class="offline-equipmentissuance_content-settle-desc"
                  >安装费合计（元）</span
                >
                <span class="offline-equipmentissuance_content-settle-money">
                  {{ installPrice }}
                </span>
              </div>
            </div>
          </div>
          <div class="offline-equipmentissuance_content-beforeissue-foot">
            <el-button
              type="primary"
              size="medium"
              @click="issuanceApply"
              :loading="loadingsf"
              >收费</el-button
            >
            <!--@click="issuanceApply"-->
          </div>
        </el-tab-pane>
        <el-tab-pane name="second">
          <template slot="label">
            <!-- :value="selectedInfo.length" -->
            <span
              >{{ label2 }}
              <el-badge
                type="primary"
                class="mark"
                :type="tp2"
                :value="selectedInfo.length - dfxlen"
            /></span>
          </template>
          <div class="offline-equipmentissuance_content-waitissue-info">
            <!--  :nameCheck1="name2Check"  -->
            <car-info
              :info="car"
              v-for="(car, i) in selectedInfo"
              :key="i"
              :checkboxDisplay="waitissueCheckboxDisplay"
            >
              <template slot="step">
                <i
                  class="icon iconfont"
                  :class="car.iconfont"
                  :style="{ color: car.iconfontColor }"
                ></i>
                <span>{{ car.stepDesc }}</span>
              </template>
              <template slot="buttons">
                <!-- :disabled="!(car.obuPublished && !car.cardPublished)" -->

                <!-- :disabled="car.cardPublished" -->
                <el-button
                  type="primary"
                  :disabled="car.obuPublished"
                  size="medium"
                  :icon="car.tagIssueLoadingIcon"
                  @click="tagIssue(car)"
                  :loading="loadingobu"
                  >标签发行</el-button
                >

                <el-button
                  type="primary"
                  size="medium"
                  :disabled="!(car.obuPublished && !car.cardPublished)"
                  :icon="car.cardIssueLoadingIcon"
                  @click="cardIssue(car)"
                  :loading="loadingcard"
                  >卡片发行</el-button
                >

                <!-- :disabled="!(car.obuPublished && !car.cardPublished)" -->
              </template>
            </car-info>
          </div>
          <!-- 12.9.修改工单 -->
          <div class="offline-equipmentissuance_content-waitissue-foot">
            <el-button
              type="primary"
              size="medium"
              @click="viewVoucher"
              :disabled="pzqmDisabled"
              :loading="loadingpzqm"
              >凭证签名</el-button
            >
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>
    <voucher-layer
      :column="3"
      ref="mychild"
      :info="voucherData"
      :keys="voucherKeys"
      :visible.sync="voucherVisiable"
      @complete="bizVoucherUpload"
      :footer="voucherFooter"
    ></voucher-layer>
  </div>
</template>

<script>
import VoucherLayer from '@/components/VoucherLayer';
import { dicKeys, getDicDesByCode } from '@/methods/dics';
import { updateWorkOrder, queryInstallCode } from '@/api/common';
import TypeSelect from '@/components/TypeSelect';
import CarInfo from '../../NewPublish/CarInfo';
import { cardIssue, tagIssue } from '@/api/obu';
import { formatDate } from '@/utils/format';
import {
  queryPendingInfo,
  orderCharge,
  priceReckon,
  issueOrderCancel,
  deviceOrder,
  vehicleBatchQuery,
} from '@/api/newPublish';
import { bizVoucherUpload } from '@/api/voucher';
import { systemTime } from '@/api/common';
import { publishCard, publishObu } from '@/methods/publish';

export default {
  inject: ['reload'],
  data() {
    return {
      installCode: '',
      name1Check: '2',
      name2Check: '4',
      searchVal: '',
      fullscreenLoading: false,
      tp1: '',
      tp2: '',
      pzqmDisabled: true,
      vif: true,
      loadingsf: false,
      loadingcard: false,
      loadingobu: false,
      loadingpzqm: false,
      sendarr: [],
      label1: '未收费',
      label2: '已收费待发行',
      dfxlen: 0,
      form: {
        payMode: '',
      },
      rules: {
        fixType: [
          { required: true, message: '请选择安装方式', trigger: 'blur' },
        ],
        payMode: [
          { required: true, message: '请选择支付方式', trigger: 'blur' },
        ],
      },
      activeName: 'first',
      voucherVisiable: false,
      beforeissueCheckboxDisplay: 'inline-block',
      waitissueCheckboxDisplay: 'none',
      voucherData: {
        businessType: '新办发行',
      },
      voucherKeys: [[{ key: 'businessType', label: '新办发行' }]],
      // baseVoucherKeys: [
      //   { key: 'userID', label: '用户编号' },
      //   { key: 'userName', label: '用户名称' },
      //   { key: 'userCertType', label: '证件类型' },
      //   { key: 'userCode', label: '证件号码' },
      //   { key: 'address', label: '联系地址', span: 2 },
      //   { key: 'zipCode', label: '邮政编码' },
      //   { key: 'userPhone', label: '固定电话' },
      //   { key: 'userPhone2', label: '手机号码' },
      //   { key: 'vehicleNumber', label: '车牌号码' },
      //   { key: 'vehicleColor', label: '车牌颜色' },
      //   { key: 'vehicleType', label: '车辆用户类型' },
      //   { key: 'vehicleClass', label: '收费车型' },
      //   { key: 'approvedCount', label: '核定载人数' },
      //   { key: 'vehicleTotalMass', label: '总质量' },
      //   { key: 'cardType', label: '卡种' },
      //   { key: 'cardID', label: '卡号' },
      //   { key: 'cardStatus', label: '卡状态' },
      //   { key: 'cardExpireDate', label: '卡片有效期' },
      //   { key: 'cardFreeEndDate', label: '卡片质保期' },
      //   { key: 'obuID', label: '标签ID' },
      //   { key: 'printID', label: '标签表面号' },
      //   { key: 'obuStatus', label: '标签状态' },
      //   { key: 'obuExpireDate', label: '标签有效期' },
      //   { key: 'obuFreeEndDate', label: '标签质保期' },
      //   // { key: 'workOrderID', label: '单号' },
      // ],

      baseVoucherKeysUser: [
        { key: 'userID', label: '用户编号' },
        {
          key: 'userName',
          label: '用户名称',
          color: 'blue',
          fontWeight: 'bold',
        },
        {
          key: 'userCertType',
          label: '证件类型',
          color: 'blue',
          fontWeight: 'bold',
        },
        {
          key: 'userCode',
          label: '证件号码',
          color: 'blue',
          fontWeight: 'bold',
        },
        { key: 'address', label: '联系地址', span: 2 },
        { key: 'zipCode', label: '邮政编码' },
        { key: 'userPhone', label: '固定电话' },
        { key: 'userPhone2', label: '手机号码' },
        { key: 'bankid', label: '签约渠道' },
        { key: 'discount', label: '优惠活动' },
        { key: 'atel', label: '咨询热线' },
        { key: 'stel', label: '服务热线', span: 2 },
      ],
      baseVoucherKeysCar: [
        {
          key: 'vehicleNumber',
          label: '车牌号码',
          color: 'blue',
          fontWeight: 'bold',
        },
        {
          key: 'vehicleColor',
          label: '车牌颜色',
          color: 'blue',
          fontWeight: 'bold',
        },
        {
          key: 'vehicleType',
          label: '车辆用户类型',
          color: 'blue',
          fontWeight: 'bold',
        },
        {
          key: 'vehicleClass',
          label: '收费车型',
          color: 'blue',
          fontWeight: 'bold',
        },
        {
          key: 'approvedCount',
          label: '核定载人数',
          color: 'blue',
          fontWeight: 'bold',
        },
        { key: 'vehicleTotalMass', label: '总质量' },
      ],
      baseVoucherKeysDev: [
        { key: 'cardType', label: '卡种' },
        { key: 'cardID', label: '卡号', color: 'blue', fontWeight: 'bold' },
        { key: 'cardStatus', label: '卡状态' },
        { key: 'cardExpireDate', label: '卡片有效期' },
        { key: 'cardFreeEndDate', label: '卡片质保期' },
        { key: 'obuID', label: '标签ID' },
        {
          key: 'printID',
          label: '标签表面号',
          color: 'blue',
          fontWeight: 'bold',
        },
        { key: 'obuStatus', label: '标签状态' },
        { key: 'obuExpireDate', label: '标签有效期' },
        { key: 'obuFreeEndDate', label: '标签质保期' },
        // { key: 'workOrderID', label: '单号' },
      ],
      baseVoucherKeysInstallCode: [
        {
          key: 'installCode',
          label: '安装码',
          color: 'blue',
          fontWeight: 'bold',
        },
      ],

      voucherVisiable: false,
      voucherFooter: {},
      allItems: [],
      installPrice: 0,
      devicePrice: 0,
    };
  },
  components: {
    VoucherLayer,
    CarInfo,
    TypeSelect,
  },
  watch: {
    dfxlen: {
      immediate: true,
      handler() {
        if (this.dfxlen > 0) {
          //alert(this.dfxlen);
          this.pzqmDisabled = false;
        }
      },
    },
    info() {
      if (this.info.length == '0') {
        //alert(this.info.length);
        this.tp1 = 'primary';
      } else {
        this.tp1 = '';
      }
    },
    selectedInfo() {
      if (this.selectedInfo.length == '0') {
        this.tp2 = 'primary';
      } else {
        this.tp2 = '';
      }
    },

    '$store.getters.registerUser.etcUserId'() {
      if (this.$store.getters.registerUser.etcUserId) {
        this.loadListData();
      }
    },
    searchVal() {
      clearTimeout(this.timer);
      this.loadListData1();
      this.timer = setTimeout(() => {
        for (let i = 0; this.allItems.length; i++) {
          let NewItems = this.allItems[i].vehicleNumber;
          if (NewItems.includes(this.searchVal) == false && this.searchVal) {
            this.allItems.splice(i, 1);
            i = i - 1;
          }
        }
      }, 2000);
      if (!this.searchVal) {
        this.loadListData1();
      }
      return this.allItems;
    },
  },
  computed: {
    info() {
      return this.allItems.filter((item) => {
        return item.payFlag === '0'; // 未收费：0，已收费：1
      });
    },
    selectedInfo() {
      return this.allItems.filter((item) => {
        if (item.obuStatus === '1' || item.obuStatus === '5') {
          //debugger;
          item.obuPublished = true;
        }
        // if (item.obuStatus === '0') {
        //   item.obuPublished = true;
        // }
        return item.payFlag === '1';
      });
    },
  },
  methods: {
    ///////////////////////////////////////////////////////////////////////////
    clear() {
      const self = this;

      self.form = {}; // 查询条件
      self.userInfoRes = {}; // 用户信息查询结果
      self.userAcctListRes = {}; // 账户列表
      self.vehicleListRes = []; //车辆信息
      self.userNoticeListRes = []; // 用户通知
      self.departmentInfoRes = {}; //分支机构信息
      self.vehicleInfoRes = {}; // 车辆信息
      // 用户注册
      self.$store.dispatch('ClearRegisterUser');
      // 经办人证件
      self.$store.dispatch('ClearTransactorImg');
      // 清空注册车辆信息
      self.$store.dispatch('ClearRegisterVehicle');

      // self.$store.dispatch('GetSearchCardInfo', res.cardInfo || {});

      self.$store.dispatch('GetSearchCardInfo', {});
      self.$store.dispatch('GetSearchUserInfo', {});
      self.$store.dispatch('GetSearchCarInfo', {});
      self.$store.dispatch('GetSearchUserInfo', {});

      // alert(self.$store.getters.searchCarInfo.vehicleNumber);
      self.$store.dispatch('GetSearchObuInfo', {});

      self.reload();
      // this.$router.go(0);
      // location.reload;

      self.$router.push({
        path: '/menu',
        query: {},
      });
    },
    ///////////////////////////////////////////////////////////////////////////
    dsabled() {},
    // 显示凭证
    async viewVoucher() {
      const self = this;
      let timerpzqm = setTimeout(() => {
        self.loadingpzqm = false;
      }, 10000);
      self.loadingpzqm = true;
      let userflag = true;
      self.voucherKeys = [
        [
          { key: 'businessType', label: '业务类型' },
          // { key: 'payWay', label: '销售渠道' },
        ],
      ];
      // 处理数据
      const publishedList = self.selectedInfo.filter(
        (info) => info.cardPublished
      );
      //alert(publishedList.length);
      //----------------------------------------------------------------
      // if (publishedList.length > '0') {
      //   this.$alert('xxxxxx', '提示', {
      //     confirmButtonText: '确定',
      //     type: 'warning',
      //   });
      //   return;
      // }
      //-------------------------------------------------------------------
      const res = await vehicleBatchQuery({
        etcUserId: self.$store.getters.registerUser.etcUserId,
        vehicleList: publishedList,
      });
      // const res = await vehicleBatchQuery({
      //   etcUserId: this.$store.getters.registerUser.etcUserId,
      //   vehicleList: [{ vehicleNumber: '沪AQM039', vehicleColor: '0' }],
      // });
      if (res.userProperty == '2') {
        const resInstallCode = await queryInstallCode({
          etcUserId: this.$store.getters.registerUser.etcUserId,
        });

        if (resInstallCode) {
          this.installCode = resInstallCode.installCode;
        }
      }

      // getDate() {
      const now = new Date();
      let completeTime = await systemTime();
      // },
      this.voucherFooter = {
        // date: `${now.getFullYear()}/${now.getMonth() + 1}/${now.getDate()}`,
        date: completeTime.systemTime,
        outletId: this.$store.getters.netid,
        operator: this.$store.getters.userName,
      };

      clearTimeout(timerpzqm);
      self.loadingpzqm = false;

      if (!res) {
        return '';
      }
      console.log(res);
      let batarr = [];
      let sendwo = {};
      let batchclass = {};

      batchclass = {
        userID: res.userID,
        userName: res.userName,
        userCertType: res.userCertType,
        userCode: res.userCode,
        userPhone: res.userPhone,
        userPhone2: res.userPhone2,
        address: res.address,
        zipCode: res.zipCode,
        note: res.note,
        stel: ' 021-64692025',
        atel: '12319',
      };

      // batarr.push(batchclass);
      // self.voucherKeys.push(
      //     self.baseVoucherKeysUser.map((base) => {
      //       return {
      //         key: base.key + i,
      //         label: base.label,
      //         span: base.span,
      //       };
      //     })
      //   );

      for (let i = 0; i < res.vehicleList.length; i++) {
        let kkk = '';
        if (res.vehicleList[i].subpaychannelName) {
          kkk = res.vehicleList[i].subpaychannelName;
        } else {
          kkk = res.vehicleList[i].paychannelName;
        }
        let v = '';
        if (res.vehicleList[i].vehicleType === '0') {
          if (res.vehicleList[i].vehicleCategory === '1') {
            //console.log(formData.vehicleCategory);

            v = '0 - 普通客车';
          }
          if (res.vehicleList[i].vehicleCategory === '2') {
            v = '0 - 普通货车';
          }
          if (res.vehicleList[i].vehicleCategory === '3') {
            v = '0 - 普通货车';
          }
          if (res.vehicleList[i].vehicleCategory === '4') {
            v = '0 - 普通货车';
          }
        } else {
          v = await getDicDesByCode(
            dicKeys.vehicleUserClass,
            res.vehicleList[i].vehicleType
          );
        }
        batchclass = {
          ...batchclass,
          ...res.vehicleList[i].card,
          ...res.vehicleList[i].obu,
          ...res.vehicleList[i].uesr,
          bankid: kkk,
          installCode: this.installCode,
          discount: res.vehicleList[i].offerType,
          approvedCount: res.vehicleList[i].approvedCount + '人',
          vehicleTotalMass: res.vehicleList[i].vehicleTotalMass + 'kg',
          vehicleNumber: res.vehicleList[i].vehicleNumber,
          userCertType: await getDicDesByCode(
            dicKeys.userCertType,
            res.userCertType
          ),
          vehicleColor: await getDicDesByCode(
            dicKeys.vehicleColor,
            res.vehicleList[i].vehicleColor
          ),
          vehicleType: v,
          vehicleClass: await getDicDesByCode(
            dicKeys.vehicleClass,
            res.vehicleList[i].vehicleClass
          ),
          obuStatus: await getDicDesByCode(
            dicKeys.obuStatus,
            res.vehicleList[i].obu.obuStatus
          ),
          cardStatus: await getDicDesByCode(
            dicKeys.cardStatus,
            res.vehicleList[i].card.cardStatus
          ),
          cardType: await getDicDesByCode(
            dicKeys.cardType2,
            res.vehicleList[i].card.cardType
          ),
        };
        sendwo = {
          workOrderID: res.vehicleList[i].workOrderID,
        };
        batarr.push(batchclass);

        this.sendarr.push(sendwo);
      }

      batarr.forEach((list, i) => {
        if (userflag) {
          self.voucherKeys.push(
            self.baseVoucherKeysUser.map((base) => {
              return {
                key: base.key + i,
                label: base.label,
                span: base.span,
                color: base.color,
                fontWeight: base.fontWeight,
              };
            })
          );
          userflag = false;
        }
        self.voucherKeys.push(
          self.baseVoucherKeysCar.map((base) => {
            return {
              key: base.key + i,
              label: base.label,
              span: base.span,
              color: base.color,
              fontWeight: base.fontWeight,
            };
          })
        );
        self.voucherKeys.push(
          self.baseVoucherKeysDev.map((base) => {
            return {
              key: base.key + i,
              label: base.label,
              span: base.span,
              color: base.color,
              fontWeight: base.fontWeight,
            };
          })
        );
        if (res.userProperty == '2') {
          self.voucherKeys.push(
            self.baseVoucherKeysInstallCode.map((base) => {
              return {
                key: base.key + i,
                label: base.label,
                span: base.span,
                color: base.color,
                fontWeight: base.fontWeight,
              };
            })
          );
        }

        for (let key in list) {
          self.voucherData[key + i] = list[key];
        }
      });
      self.voucherVisiable = true;
      self.$nextTick(() => {
        //执行调用
        self.$refs.mychild.sendpad();
      });
      clearTimeout(timerpzqm);
      self.loadingpzqm = false;
    },
    // 选择计算费用
    async selectChange() {
      return;
      const res = await priceReckon({
        etcUserId: this.$store.getters.registerUser.etcUserId,
        vehicleNumber: this.$store.getters.registerVehicle.vehicleNumber,
        vehicleColor: this.$store.getters.registerVehicle.vehicleColor,
        orderType: '1',
      });
    },
    // 加载列表数据
    async loadListData1() {
      const self = this;
      if (!this.$store.getters.registerUser.etcUserId) {
        return;
      }
      const res = await queryPendingInfo({
        etcUserId:
          // this.$store.getters.registerUser &&
          self.$store.getters.registerUser.etcUserId,
      });

      if (res) {
        this.allItems = res.vehicleList || [];

        (this.vif = false),
          this.$nextTick(() => {
            this.vif = true;
          });
      }
    },
    // 加载列表数据
    async loadListData() {
      const self = this;
      self.fullscreenLoading = true;
      let timer = setTimeout(() => {
        self.fullscreenLoading = false;
      }, 20000);
      if (!this.$store.getters.registerUser.etcUserId) {
        return;
      }
      const res = await queryPendingInfo({
        etcUserId:
          // this.$store.getters.registerUser &&
          self.$store.getters.registerUser.etcUserId,
      });

      if (res) {
        this.allItems = res.vehicleList || [];

        (this.vif = false),
          this.$nextTick(() => {
            this.vif = true;
          });
      }
      // for (let i = 0; i < this.allItems.length; i++) {
      //   if (this.allItems[i].payFlag === '0') {
      //     console.log(this.allItems[i].vehicleNumber);
      //     this.name1Check = '1';
      //     break;
      //   }
      // }
      // for (let i = 0; i < this.allItems.length; i++) {
      //   if (this.allItems[i].payFlag === '1') {
      //     console.log(this.allItems[i].vehicleNumber);
      //     this.name2Check = '1';
      //     break;
      //   }
      // }

      clearTimeout(timer);
      self.fullscreenLoading = false;
    },
    //取消订单
    async cancel(carparam) {
      const res = issueOrderCancel({
        etcUserId: this.$store.getters.registerUser.etcUserId,
        vehicleNumber: carparam.vehicleNumber,
        vehicleColor: carparam.vehicleColor,
      });
      if (res) {
        this.loadListData();
      }

      const index = this.info.findIndex((ina) => {
        return ina === carparam;
      });
      this.info.splice(index, 1);
    },
    // 点击抽屉完成按钮
    async bizVoucherUpload(vp) {
      const self = this;
      let sl = this.sendarr;
      console.log('sl');
      console.log(sl);
      for (let i = 0; i < sl.length; i++) {
        // let par = sl[i],
        if (i == 0) {
          const res0 = await updateWorkOrder({
            workOrderID: sl[i].workOrderID,
            modifyInfo: {
              imagelist: [
                {
                  imgType: '4011',
                  mediaType: '5',
                  fileType: vp.ext,
                  imgFrontID: vp.frontImgid,
                },
              ],
            },
          });
        } else {
          //凭证签名页点击取消，再次显示凭证签名页，确认后重复提交相同凭证图片
          if (sl[i].workOrderID != sl[i - 1].workOrderID) {
            const res0 = await updateWorkOrder({
              workOrderID: sl[i].workOrderID,
              modifyInfo: {
                imagelist: [
                  {
                    imgType: '4011',
                    mediaType: '5',
                    fileType: vp.ext,
                    imgFrontID: vp.frontImgid,
                  },
                ],
              },
            });
          }
        }
        // const res0 = await updateWorkOrder({
        //   workOrderID: sl[i].workOrderID,
        //   modifyInfo: {
        //     imagelist: [
        //       {
        //         imgType: '4011',
        //         mediaType: '5',
        //         fileType: vp.ext,
        //         imgFrontID: vp.frontImgid,
        //       },
        //     ],
        //   },
        // });
      }
      self
        .$confirm('发行成功。是否需要为该用户继续办理业务？', '提示', {
          cancelButtonText: '取消',
          confirmButtonText: '确定',
          type: 'success',
        })
        .then(() => {
          self.$router.push({
            path: '/menu',
          });
        })
        .catch(() => {
          this.clear();
        });

      // this.$alert('发行成功', '提示', {
      //   confirmButtonText: '确定',
      //   type: 'success',
      // });
      // this.$router.push({
      //   path: '/menu',
      // });
      // 修改工单号

      // const res0 = await updateWorkOrder({
      //   workOrderID: this.workOrderIDConfirm,
      //   modifyInfo: {
      //     imageList: [
      //       {
      //         imgType: '4011',
      //         mediaType: '5',
      //         fileType: vp.ext,
      //         imgFrontID: vp.frontImgid,
      //       },
      //     ],
      //   },
      // });

      // await bizVoucherUpload({
      //   etcUserId: self.$store.getters.registerUser.etcUserId,
      //   workOrderID: self.$route.query.woid,
      //   netid: self.$store.getters.netid,
      //   oprtID: self.$store.getters.oprtID,
      //   imageList: [
      //     {
      //       imgType: '4011',
      //       mediaType: '5',
      //       fileType: vp.ext,
      //       imgFrontID: vp.frontImgid,
      //     },
      //   ],
      // });
      //this.$message.success('发行成功');
      // this.$router.push({
      //   path: '/menu',
      // });
    },
    handleClick(tab, event) {},
    // 发行申请
    async issuanceApply() {
      const self = this;
      self.$refs.form.validate(async (valid) => {
        if (valid) {
          let carInfo = self.info.map((item, index) => {
            if (item.isChecked) {
              // self.$set(item, 'isChecked', false);
              item.isChecked = false;
              // this.$set(self.info, index, item);
              // item.isChecked = false;
              return {
                vehicleNumber: item.vehicleNumber,
                vehicleColor: item.vehicleColor,
                orderType: '1',
                // applyType: '',
                price: item.price,
                payMode: this.form.payMode,
                workOrderID: item.workOrderId,
                payChannelId: item.payChannelId,
              };
            } else {
              // return {};
              item.filter;
            }
          });

          carInfo = carInfo.filter((item) => {
            if (item) {
              this.$set(item, 'totalAmount', '0');
              this.$set(item, 'deviceAmount', '0');
              this.$set(item, 'serviceAmount', '0');
              this.$set(item, 'deliveryAmount', '0');
              // this.$set(item, 'payChannelId', 'ETC_CCB_ZH');
              this.$set(item, 'payStatus', '2');
              this.$set(item, 'deliveryMode', '2');
              this.$set(item, 'payMode', this.form.payMode);
              this.$set(item, 'workOrderID', item.workOrderID);
              this.$set(item, 'payChannelId', item.payChannelId);
              this.$set(item, 'isChecked', false);
              if (this.payMode) {
                this.$set(item, 'discountType', this.payMode);
              }

              this.$set(
                item,
                'orderCreateTime',
                formatDate('"YYYY-MM-DD HH:FF:SS"', new Date())
                  .replace('"', '')
                  .replace(/[\\]/g, '')
                  .replace('"', '')
              );
            }
            return item;
          });
          if (carInfo.length === 0) {
            this.$message({
              message: '请选择车辆',
              type: 'warning',
            });
            return false;
          }
          self.loadingsf = true;
          let timersf = setTimeout(() => {
            self.loadingsf = false;
          }, 60000);
          const res = await deviceOrder({
            etcUserId: this.$store.getters.registerUser.etcUserId,
            orderList: carInfo,
          });

          if (res.failMsg) {
            this.$alert('下列车辆收费失败：' + res.failMsg, '提示', {
              confirmButtonText: '确定',
              type: 'info',
            });
            //  self.reload();
            clearTimeout(timersf);
            self.loadingsf = false;
          }
          if (res) {
            this.loadListData();
            // self.reload();
            clearTimeout(timersf);
            self.loadingsf = false;
          }
        } else {
          clearTimeout(timersf);
          self.loadingsf = false;
          return false;
        }
        // carInfo.forEach((element) => {
        //   if (element.isChecked) {
        // element.isChecked = false;
        //   }}
        // element.process = 1;
        // element.stepDesc = '待发行';
        // element.iconfont = 'iconshizhong';
        // element.iconfontColor = '#777777';
        // element.cardIssueBtnDisabled = false;
        //     // element.tagIssueBtnDisabled = false;
        //   }
        // });
        // 显示【已收费未发行】Tab
        // this.activeName = 'second';
        // 保存车辆信息
        // self.$store.dispatch('GetRegisterVehicle', this.selectedInfo);
        // self.loadingsf = false;
      });
    },
    // 卡片发行
    allunchecked() {
      carInfo.forEach((element) => {
        if (element.isChecked) {
          element.isChecked = false;
        }
      });
    },

    async cardIssue(car) {
      const self = this;

      self.loadingcard = true;
      let timercard = setTimeout(() => {
        // this.$message.success('超时');
        self.loadingcard = false;
      }, 60000);
      car.cardPublished = false;
      // self.$set(car, 'stepDesc', '发行中');

      const publishRes = await publishCard({
        orderType: '1',
        etcUserId: self.$store.getters.registerUser.etcUserId,
        msgType: '1',
        vehicleNumber: car.vehicleNumber,
        vehicleColor: car.vehicleColor,
        workOrderID: car.workOrderId,
      });

      if (publishRes.status) {
        // if (true) {
        car.cardPublished = true;
        this.$set(
          this.allItems,
          this.allItems.findIndex((item) => item === car),
          car
        );
        this.$alert('卡片发行成功');

        // const publishedList = self.selectedInfo.filter(
        //   (info) => info.card_Published
        // );
        // alert(self.selectedInfo.length);
        // alert(publishedList.length);
        this.dfxlen = self.dfxlen + 1;
      } else {
        // cardPublished = false;
        // this.$alert('publishRes.msg');
        // this.$message({
        //   type: 'error',
        //   message: publishRes.msg,
        // });

        if (publishRes.msg != '硬件故障：卡片发行失败') {
          this.$confirm(
            '写卡片失败，是否重试？ 提示信息：' + publishRes.msg,
            '提示',
            {
              confirmButtonText: '重试',
              cancelButtonText: '取消',
              type: 'warning',
            }
          ).then(() => {
            this.cardIssue(car);
          });
        }
      }
      clearTimeout(timercard);
      self.loadingcard = false;

      // self.$set(car, 'process', 2);
      // self.$set(car, 'stepDesc', '发行中');
      // self.$set(car, 'iconfont', 'iconshaloudaojishi');
      // self.$set(car, 'iconfontColor', '#FFB11E');
      // self.$set(car, 'cardIssueBtnDisabled', true);
      // self.$set(car, 'cardIssueLoadingIcon', 'el-icon-loading');
      // self.$set(car, 'tagIssueLoadingIcon', '');
      // const res = await cardIssue();
      // if (res) {
      //   self.$set(car, 'process', 3);
      //   self.$set(car, 'cardIssueLoadingIcon', 'el-icon-check');
      //   // 保存车辆信息
      //   // self.$store.dispatch('GetRegisterVehicle', this.selectedInfo);
      // }
    },
    // 标签发行
    async tagIssue(car) {
      const self = this;
      self.loadingobu = true;
      let timerobu = setTimeout(() => {
        // this.$message.success('超时');
        self.loadingobu = false;
      }, 60000);
      const publishRes = await publishObu({
        orderType: '1',
        workOrderID: car.workOrderId,
        vehicleNumber: car.vehicleNumber,
        vehicleColor: car.vehicleColor,
        etcUserId: self.$store.getters.registerUser.etcUserId,
        msgType: '1',
      });

      if (publishRes.status) {
        // if (true) {
        // if (true) {
        car.obuPublished = true;
        this.$set(
          this.allItems,
          this.allItems.findIndex((item) => item === car),
          car
        );
        this.$alert('标签发行成功');

        // alert(!(car.obu_Published && !car.card_Published));
      } else {
        // this.$alert('publishRes.msg');
        // this.$message({
        //   type: 'error',
        //   message: publishRes.msg,
        // });
        if (publishRes.msg != '硬件故障：标签发行失败') {
          this.$confirm(
            '写标签失败，是否重试？ 提示信息：' + publishRes.msg,
            '提示',
            {
              confirmButtonText: '重试',
              cancelButtonText: '取消',
              type: 'warning',
            }
          ).then(() => {
            this.tagIssue(car);
          });
        }
      }
      clearTimeout(timerobu);
      self.loadingobu = false;

      //9.1

      //9.2
      // const self = this;
      // if (car.process === 3) {
      //   self.$set(car, 'process', 4);
      //   self.$set(car, 'tagIssueBtnDisabled', true);
      //   self.$set(car, 'tagIssueLoadingIcon', 'el-icon-loading');
      //   const res = await tagIssue();
      //   if (res) {
      //     self.$set(car, 'process', 5);
      //     self.$set(car, 'stepDesc', '发行成功');
      //     self.$set(car, 'iconfont', 'iconchenggong');
      //     self.$set(car, 'iconfontColor', '#027aff');
      //     self.$set(car, 'tagIssueLoadingIcon', 'el-icon-check');
      //     // 保存车辆信息
      //     // self.$store.dispatch('GetRegisterVehicle', this.selectedInfo);
      //   }
      // }
    },
    // 点击抽屉完成按钮
    async toHome() {
      // this.$alert('发行成功', '提示', {
      //   confirmButtonText: '确定',
      //   type: 'success',
      // });
      this.$router.push({
        path: '/menu',
      });
    },
  },
  mounted() {
    // this.info = this.info.filter(item => {
    //   return !item.process || item.process === 0; // 未收费：0，已收费未发行：1
    // });
    // this.toHome();
    this.loadListData();
  },
};
</script>
