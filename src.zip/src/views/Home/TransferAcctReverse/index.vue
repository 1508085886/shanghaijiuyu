<!-- 首页 -->
<template>
  <div class="offline-transferAcctReverse_css">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-transferAcctReverse_css_title">圈存账户冲正</h4>
      </div>
    </div>
    <div class="offline-transferAcctReverse_css_block">
      <el-form
        ref="repaymentForm1"
        :model="reverseForm"
        class="offline-transferAcctReverse_css_block-form"
      >
        <div class="offline-transferAcctReverse_css_block-readcard-centent">
          <el-col :xl="12" :lg="12" :md="12">
            <el-row>
              <el-form-item prop="userAcctId" ref="userAcctId">
                <el-col :xl="7" :lg="7" :md="7">账户编号：</el-col>
                <el-col :xl="17" :lg="17" :md="17">{{
                  reverseForm.userAcctId
                }}</el-col>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="accountType" ref="accountType">
                <el-col :xl="7" :lg="7" :md="7">账户类型：</el-col>
                <el-col :xl="17" :lg="17" :md="17">{{
                  reverseForm.userAcctType
                }}</el-col>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="accountStatus" ref="accountStatus">
                <el-col :xl="7" :lg="7" :md="7">账户状态：</el-col>
                <el-col :xl="17" :lg="17" :md="17"></el-col>
                {{ reverseForm.userAcctStatus }}
              </el-form-item>
            </el-row>
          </el-col>
          <el-col :xl="12" :lg="12" :md="12">
            <el-row>
              <el-form-item prop="subAcctBalance" ref="subAcctBalance">
                <el-col :xl="8" :lg="8" :md="8">圈存账户余额：</el-col>
                <el-col :xl="16" :lg="16" :md="16">{{
                  reverseForm.inLoadBalance
                }}</el-col>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="acctBalance" ref="acctBalance">
                <el-col :xl="8" :lg="8" :md="8">账户余额：</el-col>
                <el-col :xl="16" :lg="16" :md="16">{{
                  reverseForm.acctBalance
                }}</el-col>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="creditfee" ref="creditfee">
                <el-col :xl="8" :lg="8" :md="8">卡面余额：</el-col>
                <el-col :xl="16" :lg="16" :md="16">{{
                  reverseForm.cardBalance
                }}</el-col>
              </el-form-item>
            </el-row>
          </el-col>
        </div>
      </el-form>
    </div>
    <div class="offline-transferAcctReverse_css_search">
      <el-row :gutter="10">
        <el-col :span="8">
          <div
            class="
              o-flex o-flex-align-baseline
              offline-cardreplacementmain_feeblock-paymode
            "
          >
            <div class="offline-transferAcctReverse_css_feeblock-paymode-desc">
              充值金额：
            </div>
            <el-input v-model="reverseForm.rechargeAmt"></el-input>
          </div>
        </el-col>
        <el-col :span="8">
          <div
            class="
              o-flex o-flex-align-baseline
              offline-cardreplacementmain_feeblock-paymode
            "
          >
            <div class="offline-transferAcctReverse_css_feeblock-paymode-desc">
              充值日期：
            </div>
            <el-date-picker
              v-model="reverseForm.rechargeDate"
              type="date"
              placeholder="选择日期"
              format="yyyy-MM-dd"
              :disabled="!dateauthority ? true : false"
            >
            </el-date-picker>
          </div>
        </el-col>
        <el-col :span="3" class="">
          <el-button
            style="float: right"
            size="small"
            type="primary"
            :loading="cploading"
            icon="el-icon-search"
            round
            @click="queryReverseTrans()"
            >查询
          </el-button>
        </el-col>
      </el-row>
    </div>
    <div class="offline-transferAcctReverse_css_detail">
      <h4 class="offline-transferAcctReverse_css_title2">充值记录</h4>
    </div>
    <div class="offline-transferAcctReverse_css_form">
      <el-table
        :data="tables"
        tooltip-effect="dark"
        style="width: auto"
        :header-cell-style="{ 'background-color': '#D3D6DF' }"
        @selection-change="handleSelectionChange"
        @select-all="onSelectAll"
        ref="tb"
      >
        <el-table-column type="selection" width="45"> </el-table-column>
        <el-table-column label="工单号" prop="workOrderId"> </el-table-column>
        <!-- <el-table-column label="卡号" prop="cardId"> </el-table-column> -->
        <el-table-column label="账户编号" prop="accountId"> </el-table-column>
        <el-table-column label="交易类型" prop="tradeType"> </el-table-column>
        <!-- <el-table-column label="交易日期" prop="tradeTime"> </el-table-column> -->
        <el-table-column label="交易时间" prop="tradeTime"> </el-table-column>
        <el-table-column label="交易金额" prop="txAmount"> </el-table-column>
        <el-table-column label="支付方式" prop="payMode"> </el-table-column>
        <el-table-column label="操作员" prop="operatorid"> </el-table-column>
        <el-table-column label="网点" prop="netid"> </el-table-column>
      </el-table>
      <!-- <div
        style="background: #d3d6df; height: 50px"
        class="clearfix offline-transferAcctReverse_css_pagination"
      >
        <div
          class="fl offline-workordermanagement_tableblock-pagination-desc"
          v-if="total"
        >
          第{{ startRecords }}到{{ currentSize }}条，
        </div>
        <el-pagination
          background
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="currentPage"
          :page-size="pageSize"
          layout="total,->,prev, pager, next,slot"
          :total="total"
        >
        </el-pagination>
      </div> -->
    </div>

    <div class="offline-transferAcctReverse_css_feeblock">
      <el-row :gutter="10">
        <el-col :span="10">
          <div
            class="
              o-flex o-flex-align-baseline
              offline-cardreplacementmain_feeblock-paymode
            "
          >
            <div class="offline-transferAcctReverse_css_feeblock-paymode-desc">
              冲正金额：
            </div>
            <el-input v-model="reverseForm.reverseAmount" disabled></el-input>
          </div>
        </el-col>
        <el-col :span="10" class="">
          <el-button
            style="float: right; width: 132px"
            type="primary"
            :disabled="cardReverseBtn"
            :loading="cploading"
            @click="cardReverseclick"
            >冲正
          </el-button>
        </el-col>
      </el-row>
    </div>

    <voucher-layer-confirm
      ref="mychild1"
      :column="2"
      :info="voucherConfirmData"
      :keys="voucherConfirmKeys"
      :visible.sync="voucherConfirmVisiable"
      @closed="cploading = false"
      @complete="confirmComplete"
    >
    </voucher-layer-confirm>
    <voucher-layer
      ref="mychild2"
      :column="2"
      :info="voucherData"
      :footer="voucherFooter"
      :keys="voucherKeys"
      :visible.sync="voucherVisiable"
      @complete="receiptComplete"
      :cancel-show="false"
    ></voucher-layer>
  </div>
</template>
<script>
import VoucherLayer from '@/components/VoucherLayer';
import { getFormatAmount, getFormatAmountYuan2Fen } from '@/utils/utils';
import VoucherLayerConfirm from '@/components/VoucherLayerConfirm';
import TypeSelect from '@/components/TypeSelect';
import { createOrder, systemTime, updateWorkOrder } from '@/api/common';
import {
  queryCreditRepaymentList,
  creditRepayment,
  queryCreditRepayment,
} from '@/api/repayment';
import {
  queryLists,
  reverseCPCheck,
  cardCircleConfirm,
  acctCircleRectification,
  reverseRecordQuery,
  reverseReceiptQuery,
  preReversal,
} from '@/api/reversebus';
import { queryEtcAcct } from '@/api/user';
import BDialog from '@/components/DialogBlueTitle';
import { orderQuery } from '@/api/order';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';
import {
  getcardinfoall,
  get50Records,
  deductmoney,
  readCardAndGetAmount,
} from '@/utils/dynamic';
export default {
  data() {
    return {
      multipleSelection: [], // 表格选项
      voucherVisiable: false,
      voucherConfirmVisiable: false,
      confirmFlag: false,
      cploading: false,
      total: 0, //总条数
      currentPage: 1,
      page: 1, //初始显示第几页
      pageSize: 5, //每页显示多少数据
      currentSize: 0, // 当前页条数
      payMode: '1',
      cvisible: false,
      title: '',
      appendToBody: false,
      showclose: true,
      confirmFlagc: false,
      cardReverseBtn: true,
      reverseForm: {
        userAcctId: '',
        userAcctType: '',
        userAcctStatus: '',
        inLoadBalance: '',
        acctBalance: '',
        cardBalance: '',
        reverseAmount: '',
        payMode: '',
        rechargeDate: Date.now(),
      },
      dateauthority: false,
      position: '',
      BeforeBalance: '',
      AfterBalance: '',
      createWorkOrderId: '',
      cardIdNotSameMsg: '',
      cardIdNotSameCancelMsg: '',
      tables: [],
      voucherConfirmData: {},
      voucherData: {},
      voucherFooter: {},
      voucherConfirmKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '客户名称' },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'cardId', label: '卡号' },
          { key: 'userAcctId', label: '账户编号' },
          { key: 'userAcctType', label: '账户类型' },
          { key: 'userAcctStatus', label: '账户状态' },
        ],
        [
          { key: 'inLoadBalance', label: '圈存账户余额' },
          { key: 'reverseAmount', label: '冲正金额', color: '#027AFF' },
        ],
      ],
      voucherKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '客户名称' },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'cardId', label: '卡号' },
          { key: 'userAcctId', label: '账户编号' },
          { key: 'userAcctType', label: '账户类型' },
          { key: 'userAcctStatus', label: '账户状态' },
        ],
        [
          {
            key: 'BeforeBalance',
            label: '交易前圈存账户余额',
            labelWidth: '180px',
          },
          { key: 'reverseAmount', label: '冲正金额', color: '#027AFF' },
          {
            key: 'AfterBalance',
            label: '交易后圈存账户余额',
            labelWidth: '180px',
          },
        ],
      ],
    };
  },
  components: {
    BDialog,
    VoucherLayerConfirm,
    TypeSelect,
    VoucherLayer,
  },
  computed: {
    //起始记录
    startRecords() {
      return (this.page - 1) * this.pageSize + 1;
    },
    vehicleInfo() {
      return this.$store.getters.searchCarInfo;
    },
    obuInfo() {
      return this.$store.getters.searchObuInfo;
    },
    cardInfo() {
      return this.$store.getters.searchCardInfo;
    },
    userInfo() {
      return this.$store.getters.searchUserInfo;
    },
    accountInfo() {
      return this.$store.getters.searchAccountInfo;
    },
    departmentInfo() {
      return this.$store.getters.searchDepartmentInfo;
    },
  },
  watch: {},
  methods: {
    handleSizeChange(val) {
      this.pageSize = val;
      this.queryReverseTrans();
      console.log(`每页 ${val} 条`);
    },
    async handleCurrentChange(val) {
      this.page = val;
      this.currentPage = val;
      this.queryReverseTrans();
      console.log(`当前页: ${val}`);
    },
    async toConfirm() {
      this.$writeLog('确认凭证调用');
      // 确认凭证
      let userCertType = await getDicDesByCode(
        dicKeys.userCertType,
        this.userInfo.userCertType
      );
      let useracctType = await getDicDesByCode(
        dicKeys.useracctType,
        this.accountInfo.userAcctType
      );
      let userAcctStatus = await getDicDesByCode(
        dicKeys.userAcctStatus,
        this.accountInfo.userAcctStatus
      );
      console.log('this.accountInfo:', this.accountInfo);
      this.voucherConfirmData = {
        businessType: '圈存账户冲正',
        userName: this.userInfo.userName,
        userCertType: userCertType,
        userCode: this.userInfo.userCode,
        cardId: this.cardInfo.cardID,
        userAcctId: this.accountInfo.userAcctId,
        userAcctType: useracctType,
        userAcctStatus: userAcctStatus,
        inLoadBalance: this.reverseForm.inLoadBalance,
        reverseAmount: this.reverseForm.reverseAmount,
      };
      this.voucherConfirmVisiable = true;
      this.$nextTick(() => {
        //执行调用手写板
        this.$refs.mychild1.sendpad();
      });
    },
    async confirmComplete(resUploadLayerPic) {
      // 确认凭证回调
      this.$writeLog('确认凭证回调');
      // 创建冲正工单
      try {
        const corderResult = await createOrder({
          bizCode: '31',
          oldUserId: '',
          oldUserAcctId: '',
          oldDepartmentName: '',
          oldVehicleId: '',
          oldVehicleNumber: '',
          oldVehicleColor: '',
          oldBuyId: '',
          oldCardId: '',
          oldObuysId: '',
          oldObuId: '',
          oldEtcUserId: '',
          oldUsername: '',
          oldPayChannelName: '',
          oldSubPayChannelName: '',
        });
        console.log('创建冲正工单：', corderResult);
        // 调后台12.9.修改工单接口上传确认凭证
        if (resUploadLayerPic) {
          let imgFrontIDConfirm = resUploadLayerPic.frontImgid;
          // 保存凭证图片
          const mediaType = await getDicCodeByDes(
            dicKeys.mediaType,
            '业务凭证'
          );
          const imgType = await getDicCodeByDes(dicKeys.imgType, '业务凭证');
          const ImageInfoConfirm = {
            mediaType,
            imgType,
            imgFrontID: imgFrontIDConfirm,
          };
          const res0 = await updateWorkOrder({
            workOrderID: corderResult.workOrderId,
            modifyInfo: { imagelist: [ImageInfoConfirm] },
          });
          console.log('修改冲正工单，上传确认凭证:', res0);
          this.createWorkOrderId = corderResult.workOrderId;
        }
        // 10.26 冲正预申请
        const res = await preReversal({
          workOrderId: '',
          etcUserId: '',
          srcWorkOrderId: '',
        });
        if (res) {
          // 10.16 圈存账户冲正申请
          const res = await acctCircleRectification({
            workOrderId: '',
            etcUserId: '',
            srcWorkOrderId: '',
          });
          this.$writeLog('圈存账户冲正申请：' + res);
          console.log('圈存账户冲正申请:', res);
          if (res) {
            this.$alert('圈存账户冲正成功', '提示', {
              confirmButtonText: '确定',
              closeOnClickModal: false,
              closeOnPressEscape: false,
              showClose: false,
              type: 'success',
            }).then(() => {
              // 刷新账户信息，刷新列表数据
              this.getAcctInfo();
              this.queryReverseTrans();
              // 回执签名
              this.toReceiptConfirm();
            });
          } else {
            this.$message.error('圈存账户冲正失败，请重试');
          }
        } else {
          this.$message.error('圈存账户冲正失败，请重试');
        }
        this.cploading = false;
      } catch (error) {
        console.log('冲正失败异常', error);
        this.cploading = false;
      }
    },
    async toReceiptConfirm() {
      this.$writeLog('签名回执调用');
      // 10.22.圈存账户冲正业务回执查询
      const res = await reverseReceiptQuery({
        workOrderId: '',
        etcUserId: '',
      });
      if (res) {
        let completeTime = await systemTime();
        let userCertType = await getDicDesByCode(
          dicKeys.userCertType,
          res.zjlx
        );
        let useracctType = await getDicDesByCode(
          dicKeys.useracctType,
          res.accountType
        );
        let userAcctStatus = await getDicDesByCode(
          dicKeys.userAcctStatus,
          res.accountStatus
        );
        let amountF = getFormatAmount(res.amount);
        let acctBalanceBefF = getFormatAmount(res.acctBalanceBef);
        let acctBalanceAftF = getFormatAmount(res.acctBalanceAft);
        this.voucherData = {
          businessType: '圈存账户冲正',
          userName: res.username,
          userCertType: userCertType,
          userCode: res.userCode,
          cardId: res.cardId,
          userAcctId: res.accountId,
          userAcctType: useracctType,
          userAcctStatus: userAcctStatus,
          BeforeBalance: acctBalanceBefF,
          reverseAmount: amountF,
          AfterBalance: acctBalanceAftF,
        };
        this.voucherFooter = {
          date: completeTime.systemTime,
          outletId: this.$store.getters.netid,
          operator: this.$store.getters.userName,
        };
        this.voucherVisiable = true;
        this.$nextTick(() => {
          //执行调用手写板
          this.$refs.mychild2.sendpad();
        });
      }
      // let completeTime = await systemTime();
      // let userCertType = await getDicDesByCode(
      //   dicKeys.userCertType,
      //   this.userInfo.userCertType
      // );
      // let useracctType = await getDicDesByCode(
      //   dicKeys.useracctType,
      //   this.accountInfo.userAcctType
      // );
      // let userAcctStatus = await getDicDesByCode(
      //   dicKeys.userAcctStatus,
      //   this.accountInfo.userAcctStatus
      // );
      // this.voucherData = {
      //   businessType: '圈存账户冲正',
      //   userName: this.userInfo.userName,
      //   userCertType: userCertType,
      //   userCode: this.userInfo.userCode,
      //   cardId: this.cardInfo.cardID,
      //   userAcctId: this.accountInfo.userAcctId,
      //   userAcctType: useracctType,
      //   userAcctStatus: userAcctStatus,
      //   cardBalance: this.reverseForm.cardBalance,
      //   BeforeBalance: this.BeforeBalance,
      //   reverseAmount: this.reverseForm.reverseAmount,
      //   AfterBalance: this.AfterBalance,
      // };
      // this.voucherFooter = {
      //   date: completeTime.systemTime,
      //   outletId: this.$store.getters.netid,
      //   operator: this.$store.getters.userName,
      // };
      // this.voucherVisiable = true;
      // this.$nextTick(() => {
      //   //执行调用手写板
      //   this.$refs.mychild2.sendpad();
      // });
    },
    async receiptComplete(resUploadLayerPic) {
      // 回执签名回调
      // 调后台12.9.修改工单接口上传确认凭证
      this.$writeLog('签名回执回调');
      if (resUploadLayerPic) {
        let imgFrontIDConfirm = resUploadLayerPic.frontImgid;
        // 保存凭证图片
        const mediaType = await getDicCodeByDes(dicKeys.mediaType, '业务凭证');
        const imgType = await getDicCodeByDes(dicKeys.imgType, '业务凭证');
        const ImageInfoConfirm = {
          mediaType,
          imgType,
          imgFrontID: imgFrontIDConfirm,
        };
        const res0 = await updateWorkOrder({
          workOrderID: this.createWorkOrderId,
          modifyInfo: { imagelist: [ImageInfoConfirm] },
        });
        console.log('修改圈存账户冲正工单，上传回执凭证:', res0);
        if (res0) {
          // 返回主页
          this.$writeLog('返回主页');
          this.$router.push({
            path: '/menu',
          });
        }
        // // 之后的操作是 刷新页面，还是返回主菜单 todo
        // // 回执签名后弹框提示“充值成功”。
        // this.$alert('圈存账户冲正成功', '提示', {
        //   confirmButtonText: '确定',
        //   closeOnClickModal: false,
        //   closeOnPressEscape: false,
        //   showClose: false,
        //   type: 'success',
        // }).then(() => {
        //   this.wLoading = null;
        //   // 返回主页
        //   this.$writeLog('返回主页');
        //   this.$router.push({
        //     path: '/menu',
        //   });
        // });
      }
    },
    async toReadCard(needWholeLoading, readAgain, notNeedCardInfo) {
      console.log('读卡');
      this.cardIdNotSameMsg =
        '当前卡号和主页查询的卡号不一致，请清除后重新查询';
      let failObj = {
        showMsg: false,
      };
      let successObj = {
        notNeedCardInfo,
        cardInfo: this.cardInfo,
        cardIdNotSameMsg: this.cardIdNotSameMsg,
        cardIdNotSameCancelMsg: this.cardIdNotSameCancelMsg,
        cardIdNotSameCancelFunc: '',
        successFunc: (successRes) => {
          // 自动读卡，显示卡面余额
          this.reverseForm.cardBalance = getFormatAmount(successRes.price);
        },
      };
      const res = await readCardAndGetAmount(
        needWholeLoading,
        failObj,
        successObj
      );
      console.log('重复读卡：', res);
      this.readAgainTimes++;
      if (readAgain) {
        // 若是前端自行回读的，需判断回读的卡号，卡号不一致，提示“回读余额失败，请调整卡片位置后重试”。
        this.cardIdNotSameMsg = '回读余额失败，请调整卡片位置后重试';
        // 若回读余额失败，自动重试回读，最多回读3次
        if (res && this.readAgainTimes <= 3) {
          this.$writeLog('回读成功：' + JSON.stringify(res));
          return res;
        } else if (!res && this.readAgainTimes >= 3) {
          // 第3次失败后，提示“回读余额失败，请调整卡片位置，重试”
          this.$writeLog('回读余额失败，回读次数>=3：' + JSON.stringify(res));
          this.$confirm('回读余额失败，请调整卡片位置，重试', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            closeOnClickModal: false,
            closeOnPressEscape: false,
            type: 'warning',
          })
            .then(() => {
              //若点击确定则再次回读
              this.toReadCard(false, true);
            })
            .catch(() => {
              // 若点击取消，弹出提示“冲正失败请重试”
              this.$message.error('冲正失败请重试');
              return;
            });
        } else if (this.readAgainTimes < 3) {
          this.$writeLog('回读余额失败，回读次数<3，继续回读');
          this.toReadCard(false, true);
        }
      } else {
        this.$writeLog('不回读：' + JSON.stringify(res));
        return res;
      }
    },
    async readcard() {
      this.$writeLog('进入readcard方法');
      const res = await this.toReadCard(true, false, false);
      console.log('res:', res);
      let isShow = false;
      if (res) {
        // 非管理员可无卡操作
        if (res.code !== '0' && this.position !== '4') {
          isShow = true;
        }
      } else {
        // 管理员可无卡操作
        if (this.position !== '4') {
          isShow = true;
        }
      }
      if (isShow) {
        this.$confirm('读卡失败，请重试', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          closeOnClickModal: false,
          closeOnPressEscape: false,
          type: 'warning',
        })
          .then(() => {
            // 确定重读
            this.readcard();
          })
          .catch(() => {
            // 若点击取消，回到主页
            this.$router.push({
              path: '/menu',
            });
            return;
          });
      }
    },
    async queryReverseTrans() {
      this.$writeLog('10.23可冲正记录查询');
      const self = this;
      self.tables = [];
      const res = await queryLists({
        etcUserId: this.userInfo.etcUserId,
        userAcctid: this.accountInfo.userAcctId,
        cardId: '',
        txAmount: '',
        payDate: '',
        oprtId: '',
        netId: '',
        unLoadType: '2', // 1-储值卡充值冲正 两条 2-圈存账户充值冲正 一条 3-多充值处理 两条
      });
      if (res) {
        let dataList = [];
        dataList = res.chargeList;
        self.tables = dataList;
        this.total = dataList.length;
        this.currentSize = res.totalRowNumber;
        this.pageSize * this.page >= this.total
          ? this.total
          : this.page * this.pageSize;
        if (dataList.length > 0) {
          for (let i = 0; i < dataList.length; i++) {
            dataList[i].txAmount = getFormatAmount(dataList[i].txAmount);
            dataList[i].tradeType = await getDicDesByCode(
              dicKeys.tradeType,
              dataList[i].tradeType
            );
            dataList[i].payMode = await getDicDesByCode(
              dicKeys.payMode1,
              dataList[i].payMode
            );
          }
          self.tables = dataList;
          // // 自动填写冲正金额
          // this.reverseForm.reverseAmount = dataList[0].txAmount;
          // // 冲正按钮有效
          // this.cardReverseBtn = false;
        } else {
          this.$message.error('未查到该储值卡账户有圈存账户充值记录');
        }
      }
    },
    async cardReverseclick() {
      this.$writeLog('点击冲正按钮');
      this.cploading = true;
      // 读卡验卡
      this.readcard();
      this.$writeLog('可冲正工单查询');
      // 10.27冲正记录查询
      const orderList = await reverseRecordQuery({
        srcWorkOrderId: '', // 原充值工单号
        etcUserId: '', // etc用户id必填
        useracctId: '', // 账户号
        oprtId: '', // 操作员号，必填
        netId: '', // 网点编码，必填
      });
      this.$writeLog('可冲正工单查询:' + orderList);
      console.log('工单查询返回：', orderList);
      if (orderList) {
        let recordArry = [];
        recordArry = orderList.purchaseList;
        if (recordArry.length > 0) {
          // 若工单状态为0-业务未申请或1-进行中,无需确认，10.16圈存账户冲正申请
          if (
            recordArry[0].workrderStatus === '0' ||
            recordArry[0].workrderStatus === '1'
          ) {
            // 10.16圈存账户冲正申请
            const res = await acctCircleRectification({
              workOrderId: '',
              etcUserId: '',
              srcWorkOrderId: '',
            });
            this.$writeLog('圈存账户冲正申请：' + res);
            console.log('圈存账户冲正申请:', res);
            if (res) {
              // 成功，提示圈存账户冲正成功，6.1账户查询刷新账户信息、列表
              // this.toReceiptConfirm();
              this.$alert('圈存账户冲正成功', '提示', {
                confirmButtonText: '确定',
                closeOnClickModal: false,
                closeOnPressEscape: false,
                showClose: false,
                type: 'success',
              }).then(() => {
                // 刷新账户信息，刷新列表数据
                this.getAcctInfo();
                this.queryReverseTrans();
                // 回执签名
                this.toReceiptConfirm();
              });
            } else {
              // 失败，提示圈存账户冲正失败，请重试
              this.$message.error('圈存账户冲正失败，请重试');
            }
          } else if (recordArry[0].workrderStatus === '2') {
            // 工单状态已完成
            this.$message.error('该圈存账户充值交易已冲正，不可再冲正');
          }
          this.cploading = false;
        } else {
          // 未查到圈存账户冲正工单---确认凭证
          this.toConfirm();
        }
      }
    },
    async getAcctInfo() {
      this.$writeLog('调用6.1.ETC账户查询接口');
      const resAcct = await queryEtcAcct({
        etcUserId: this.userInfo.etcUserId,
        userAccountId: this.accountInfo.userAcctId,
      });
      if (resAcct) {
        this.$writeLog('调用6.1.	ETC账户查询接口成功');
        this.reverseForm.inLoadBalance = getFormatAmount(resAcct.consumeLimit);
        this.reverseForm.acctBalance = getFormatAmount(resAcct.balance);

        let userAcctTypeStr = await getDicDesByCode(
          dicKeys.useracctType,
          resAcct.useracctType
        );
        let userAcctStatusStr = await getDicDesByCode(
          dicKeys.userAcctStatus,
          resAcct.useracctStatus
        );
        this.reverseForm.userAcctId = this.accountInfo.userAcctId;
        this.reverseForm.userAcctType = userAcctTypeStr;
        this.reverseForm.userAcctStatus = userAcctStatusStr;
        this.position = this.$store.position;
      } else {
        this.$writeLog('6.1.	ETC账户查询接口报错');
      }
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
      if (this.multipleSelection.length > 1) {
        this.$refs.tb.clearSelection();
        this.$refs.tb.toggleRowSelection(val.pop());
      }
      if (this.multipleSelection.length > 0) {
        // 选中充值记录，自动填写冲正金额
        this.reverseForm.reverseAmount = this.multipleSelection[0].txAmount;
        this.cardReverseBtn = false;
      } else {
        this.cardReverseBtn = true;
      }
    },
    onSelectAll() {
      this.$refs.tb.clearSelection();
    },
    getPageAuthority() {
      // 圈存账户冲正日期权限
      let elementPermissionsMenu = this.$store.getters.elementPermissions;
      let continueType = 'transferAcctReverse';
      let arPage = elementPermissionsMenu.find(
        (obj) => obj.menu == '/' + continueType
      );
      if (arPage.permissions.dateauthority) {
        this.dateauthority = arPage.permissions.dateauthority;
      }
      console.log('是否有日期权限:', this.dateauthority);
    },
  },
  mounted() {
    this.$writeLog('圈存账户冲正页面进入');
    // 获取账户信息
    this.getAcctInfo();
    // 页面加载读卡
    this.readcard();
    // 页面加载冲正交易查询
    this.queryReverseTrans();
    // 获取日期权限
    this.getPageAuthority();
  },
  destroyed() {
    // clearTimeout(this.timer1);
  },
};
</script>