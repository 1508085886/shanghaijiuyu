<!-- 首页 -->
<template>
  <div class="offline-accountreverse_css">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-accountreverse_css_title">账户冲正</h4>
      </div>
    </div>
    <div class="offline-accountreverse_css_feeblock">
      <el-row :gutter="10">
        <el-col :span="8">
          <div
            class="
              o-flex o-flex-align-baseline
              offline-cardreplacementmain_feeblock-paymode
            "
          >
            <div class="offline-accountreverse_css_feeblock-paymode-desc">
              充值金额：
            </div>
            <el-input v-model="reverseForm.rechargeAmt"></el-input>
          </div>
        </el-col>
        <el-col :span="8">
          <div
            class="
              o-flex o-flex-align-baseline
              offline-cardreplacementmain_feeblock-paymode
            "
          >
            <div class="offline-accountreverse_css_feeblock-paymode-desc">
              充值日期：
            </div>
            <el-date-picker
              v-model="reverseForm.rechargeDate"
              type="date"
              placeholder="选择日期"
              format="yyyy-MM-dd"
              :disabled="!dateauthority ? true : false"
            >
            </el-date-picker>
          </div>
        </el-col>
        <el-col :span="2" class="">
          <el-button
            style="float: right"
            size="small"
            type="primary"
            :loading="cploading"
            icon="el-icon-search"
            round
            @click="queryReverseTrans()"
            >查询
          </el-button>
        </el-col>
      </el-row>
    </div>
    <div class="offline-accountreverse_css_block">
      <el-form
        ref="repaymentForm1"
        :model="reverseForm"
        class="offline-accountreverse_css_block-form"
      >
        <div class="offline-accountreverse_css_block-readcard-centent">
          <el-col :xl="8" :lg="8" :md="8">
            <el-row>
              <el-form-item prop="userAcctId" ref="userAcctId">
                <el-col :xl="8" :lg="8" :md="8">账户编号：</el-col>
                <el-col :xl="12" :lg="12" :md="12">{{
                  reverseForm.userAcctId
                }}</el-col>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="accountType" ref="accountType">
                <el-col :xl="8" :lg="8" :md="8">账户类型：</el-col>
                <el-col :xl="12" :lg="12" :md="12">{{
                  reverseForm.userAcctType
                }}</el-col>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="accountStatus" ref="accountStatus">
                <el-col :xl="8" :lg="8" :md="8">账户状态：</el-col>
                <el-col :xl="12" :lg="12" :md="12"></el-col>
                {{ reverseForm.userAcctStatus }}
              </el-form-item>
            </el-row>
          </el-col>
          <el-col :xl="8" :lg="8" :md="8">
            <el-row>
              <el-form-item prop="subAcctBalance" ref="subAcctBalance">
                <el-col :xl="8" :lg="8" :md="8">消费限额：</el-col>
                <el-col :xl="16" :lg="16" :md="16">{{
                  reverseForm.overLimit
                }}</el-col>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="acctBalance" ref="acctBalance">
                <el-col :xl="8" :lg="8" :md="8">警告限额：</el-col>
                <el-col :xl="16" :lg="16" :md="16">{{
                  reverseForm.noticeLimit
                }}</el-col>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="creditfee" ref="creditfee">
                <el-col :xl="8" :lg="8" :md="8">账户余额：</el-col>
                <el-col :xl="16" :lg="16" :md="16">{{
                  reverseForm.acctBalance
                }}</el-col>
              </el-form-item>
            </el-row>
          </el-col>
          <el-col :xl="8" :lg="8" :md="8">
            <el-row>
              <el-form-item prop="isInvoice" ref="isInvoice">
                <el-checkbox v-model="reverseForm.isInvoice"
                  >部平台开票
                </el-checkbox>
              </el-form-item>
            </el-row>
          </el-col>
        </div>
      </el-form>
    </div>
    <!-- <div class="offline-accountreverse_css_detail">
      <h4 class="offline-accountreverse_css_title2">充值记录</h4>
    </div> -->
    <div class="offline-accountreverse_css_form">
      <el-table
        :data="tables"
        tooltip-effect="dark"
        style="width: auto"
        :header-cell-style="{ 'background-color': '#D3D6DF' }"
        @selection-change="handleSelectionChange"
        ref="tb"
        @select-all="onSelectAll"
      >
        <el-table-column type="selection" width="45"> </el-table-column>
        <el-table-column label="工单号" prop="workOrderId"> </el-table-column>
        <el-table-column label="账户编号" prop="accountId"> </el-table-column>
        <el-table-column label="交易日期" prop="tradeTime"> </el-table-column>
        <el-table-column label="交易时间" prop="tradeTime"> </el-table-column>
        <el-table-column label="交易类型" prop="tradeType"> </el-table-column>
        <el-table-column label="交易金额" prop="txAmount"> </el-table-column>
        <el-table-column label="支付方式" prop="payMode"> </el-table-column>
        <el-table-column label="操作员" prop="operatorid"> </el-table-column>
        <el-table-column label="网点" prop="netid"> </el-table-column>
      </el-table>
      <div
        style="background: #d3d6df; height: 50px"
        class="clearfix offline-storagecardrepayment_pagination"
      >
        <div
          class="fl offline-workordermanagement_tableblock-pagination-desc"
          v-if="total"
        >
          第{{ startRecords }}到{{ currentSize }}条，
        </div>
        <el-pagination
          background
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="currentPage"
          :page-size="pageSize"
          layout="total,->,prev, pager, next,slot"
          :total="total"
        >
        </el-pagination>
      </div>
    </div>

    <div class="offline-accountreverse_css_feeblock">
      <el-row :gutter="10">
        <el-col :span="10">
          <div
            class="
              o-flex o-flex-align-baseline
              offline-cardreplacementmain_feeblock-paymode
            "
          >
            <div class="offline-accountreverse_css_feeblock-paymode-desc">
              冲正金额：
            </div>
            <el-input v-model="reverseForm.reverseAmount" disabled></el-input>
          </div>
        </el-col>
        <el-col :span="10" class="">
          <el-button
            style="float: right; width: 132px"
            type="primary"
            :disabled="cardReverseBtn"
            :loading="cploading"
            @click="accountReverseclick"
            >冲正
          </el-button>
        </el-col>
      </el-row>
    </div>
    <voucher-layer-confirm
      ref="mychild1"
      :column="2"
      :info="voucherConfirmData"
      :keys="voucherConfirmKeys"
      :visible.sync="voucherConfirmVisiable"
      @closed="cploading = false"
      @complete="confirmComplete"
    >
    </voucher-layer-confirm>
    <voucher-layer
      ref="mychild2"
      :column="2"
      :info="voucherData"
      :footer="voucherFooter"
      :keys="voucherKeys"
      :visible.sync="voucherVisiable"
      @complete="receiptComplete"
      :cancel-show="false"
    ></voucher-layer>
    <voucher-layer-format
      ref="mychildf"
      :column="2"
      :info="voucherData"
      :footer="voucherFooter"
      :keys="voucherKeys"
      voucherType="invoice"
      :visible.sync="voucherFormatVisiable"
      :cancel-show="false"
      @complete="receiptComplete"
    ></voucher-layer-format>
  </div>
</template>
<script>
import { getMenuItems, getElementPermissions } from '@/methods/account';
import VoucherLayer from '@/components/VoucherLayer';
import { getFormatAmount, getFormatAmountYuan2Fen } from '@/utils/utils';
import VoucherLayerConfirm from '@/components/VoucherLayerConfirm';
import VoucherLayerFormat from '@/components/VoucherLayerFormat';
import TypeSelect from '@/components/TypeSelect';
import { createOrder, systemTime, updateWorkOrder } from '@/api/common';
import {
  queryCreditRepaymentList,
  creditRepayment,
  queryCreditRepayment,
} from '@/api/repayment';
import {
  queryLists,
  reverseCPCheck,
  cardCircleConfirm,
  accountReversal,
} from '@/api/reversebus';
import { etcAccountQuery } from '@/api/user';
import BDialog from '@/components/DialogBlueTitle';
import { orderQuery } from '@/api/order';
import { formatDate } from '@/utils/format';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';
import {
  getcardinfoall,
  get50Records,
  deductmoney,
  readCardAndGetAmount,
} from '@/utils/dynamic';
export default {
  data() {
    return {
      multipleSelection: [], // 表格选项
      dateauthority: false, // 日期权限
      voucherVisiable: false,
      voucherConfirmVisiable: false,
      voucherFormatVisiable: false,
      confirmFlag: false,
      cploading: false,
      total: 0, //总条数
      currentPage: 1,
      page: 1, //初始显示第几页
      pageSize: 1, //每页显示多少数据
      currentSize: 0, // 当前页条数
      payMode: '1',
      cvisible: false,
      title: '',
      appendToBody: false,
      showclose: true,
      confirmFlagc: false,
      cardReverseBtn: true,
      reverseForm: {
        userAcctId: '',
        userAcctType: '',
        userAcctStatus: '',
        inLoadBalance: '',
        acctBalance: '',
        cardBalance: '',
        reverseAmount: '',
        payMode: '',
        isInvoice: false,
        rechargeDate: Date.now(),
        rechargeAmt: '',
        overLimit: '',
        noticeLimit: '',
      },
      BeforeBalance: '',
      AfterBalance: '',
      createWorkOrderId: '',
      cardIdNotSameMsg: '',
      cardIdNotSameCancelMsg: '',
      tables: [],
      voucherConfirmData: {},
      voucherData: {},
      voucherFooter: {},
      voucherConfirmKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '客户名称' },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'userAcctId', label: '账户编号' },
          { key: 'userAcctType', label: '账户类型' },
          { key: 'userAcctStatus', label: '账户状态' },
          { key: 'acctBalance', label: '账户余额', color: '#027AFF' },
        ],
        [{ key: 'reverseAmount', label: '冲正金额', color: '#027AFF' }],
      ],
      voucherKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '客户名称' },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'userAcctId', label: '账户编号' },
          { key: 'userAcctType', label: '账户类型' },
          { key: 'userAcctStatus', label: '账户状态' },
        ],
        [
          {
            key: 'BeforeBalance',
            label: '交易前账户余额',
            labelWidth: '180px',
          },
          { key: 'reverseAmount', label: '冲正金额', color: '#027AFF' },
          { key: 'AfterBalance', label: '交易后账户余额', labelWidth: '180px' },
        ],
      ],
    };
  },
  components: {
    BDialog,
    VoucherLayerConfirm,
    TypeSelect,
    VoucherLayer,
    VoucherLayerFormat,
  },
  computed: {
    //起始记录
    startRecords() {
      return (this.page - 1) * this.pageSize + 1;
    },
    vehicleInfo() {
      return this.$store.getters.searchCarInfo;
    },
    obuInfo() {
      return this.$store.getters.searchObuInfo;
    },
    cardInfo() {
      return this.$store.getters.searchCardInfo;
    },
    userInfo() {
      return this.$store.getters.searchUserInfo;
    },
    accountInfo() {
      return this.$store.getters.searchAccountInfo;
    },
    departmentInfo() {
      return this.$store.getters.searchDepartmentInfo;
    },
  },
  watch: {},
  methods: {
    handleSizeChange(val) {
      this.pageSize = val;
      this.queryReverseTrans();
      console.log(`每页 ${val} 条`);
    },
    async handleCurrentChange(val) {
      this.page = val;
      this.currentPage = val;
      this.queryReverseTrans();
      console.log(`当前页: ${val}`);
    },
    async toConfirm() {
      this.$writeLog('确认凭证调用');
      // 确认凭证
      let userCertType = await getDicDesByCode(
        dicKeys.userCertType,
        this.userInfo.userCertType
      );
      let useracctType = await getDicDesByCode(
        dicKeys.useracctType,
        this.accountInfo.userAcctType
      );
      let userAcctStatus = await getDicDesByCode(
        dicKeys.userAcctStatus,
        this.accountInfo.userAcctStatus
      );
      this.voucherConfirmData = {
        businessType: '冲正',
        userName: this.userInfo.userName,
        userCertType: userCertType,
        userCode: this.userInfo.userCode,
        userAcctId: this.accountInfo.userAcctId,
        userAcctType: useracctType,
        userAcctStatus: userAcctStatus,
        acctBalance: this.reverseForm.acctBalance,
        reverseAmount: this.reverseForm.reverseAmount,
      };
      this.voucherConfirmVisiable = true;
      this.$nextTick(() => {
        //执行调用手写板
        this.$refs.mychild1.sendpad();
      });
    },
    async confirmComplete(resUploadLayerPic) {
      // 确认凭证回调
      this.$writeLog('确认凭证调用');
      try {
        // 调后台12.9.修改工单接口上传确认凭证
        if (resUploadLayerPic) {
          let imgFrontIDConfirm = resUploadLayerPic.frontImgid;
          // 保存凭证图片
          const mediaType = await getDicCodeByDes(
            dicKeys.mediaType,
            '业务凭证'
          );
          const imgType = await getDicCodeByDes(dicKeys.imgType, '业务凭证');
          const ImageInfoConfirm = {
            mediaType,
            imgType,
            imgFrontID: imgFrontIDConfirm,
          };
          const res0 = await updateWorkOrder({
            workOrderID: '',
            modifyInfo: { imagelist: [ImageInfoConfirm] },
          });
          console.log('修改冲正工单，上传确认凭证:', res0);
        }
        // 账户冲正申请
        const res = await accountReversal({
          workOrderId: '',
          etcUserId: '',
          srcWorkOrderId: '',
        });
        if (res) {
          // 回执签名调用
          this.toReceiptConfirm();
        } else {
          this.$message.error('冲正失败，请重试');
        }
      } catch (error) {
        console.log('冲正失败异常', error);
        this.$message.error('冲正失败，请重试');
        this.cploading = false;
      }
    },
    async toReceiptConfirm() {
      this.$writeLog('签名回执调用');
      // 回执签名
      let completeTime = await systemTime();
      let userCertType = await getDicDesByCode(
        dicKeys.userCertType,
        this.userInfo.userCertType
      );
      let useracctType = await getDicDesByCode(
        dicKeys.useracctType,
        this.accountInfo.userAcctType
      );
      let userAcctStatus = await getDicDesByCode(
        dicKeys.userAcctStatus,
        this.accountInfo.userAcctStatus
      );
      this.voucherData = {
        businessType: '账户冲正',
        userName: this.userInfo.userName,
        userCertType: userCertType,
        userCode: this.userInfo.userCode,
        userAcctId: this.accountInfo.userAcctId,
        userAcctType: useracctType,
        userAcctStatus: userAcctStatus,
        BeforeBalance: this.BeforeBalance,
        reverseAmount: this.reverseForm.reverseAmount,
        AfterBalance: this.AfterBalance,
      };
      this.voucherFooter = {
        date: completeTime.systemTime,
        outletId: this.$store.getters.netid,
        operator: this.$store.getters.userName,
      };
      this.$writeLog('账户冲正回执凭证显示');
      this.reverseForm.isInvoice
        ? (this.voucherFormatVisiable = true)
        : (this.voucherVisiable = true);
      this.$nextTick(() => {
        //执行调用手写板
        this.reverseForm.isInvoice
          ? this.$refs.mychildf.sendpad()
          : this.$refs.mychild2.sendpad();
      });
    },
    async receiptComplete(resUploadLayerPic) {
      // 回执签名回调
      // 调后台12.9.修改工单接口上传确认凭证
      this.$writeLog('签名回执回调');
      if (resUploadLayerPic) {
        let imgFrontIDConfirm = resUploadLayerPic.frontImgid;
        // 保存凭证图片
        const mediaType = await getDicCodeByDes(dicKeys.mediaType, '业务凭证');
        const imgType = await getDicCodeByDes(dicKeys.imgType, '业务凭证');
        const ImageInfoConfirm = {
          mediaType,
          imgType,
          imgFrontID: imgFrontIDConfirm,
        };
        const res0 = await updateWorkOrder({
          workOrderID: this.createWorkOrderId,
          modifyInfo: { imagelist: [ImageInfoConfirm] },
        });
        console.log('修改冲正工单，上传回执凭证:', res0);
        // 之后的操作是 刷新页面，还是返回主菜单 todo
        // 回执签名后弹框提示“充值成功”。
        this.$alert('冲正成功', '提示', {
          confirmButtonText: '确定',
          closeOnClickModal: false,
          closeOnPressEscape: false,
          showClose: false,
          type: 'success',
        }).then(() => {
          this.wLoading = null;
          // 返回主页
          this.$writeLog('返回主页');
          this.$router.push({
            path: '/menu',
          });
        });
      }
    },
    async cutPaymentOperation() {
      // 2.17 储值卡扣款（框架）圈提
      const cardCPayment = await deductmoney({
        strCardID: '',
        dPrice: '',
        regAPPId: '',
        token: '',
        strRandom: '',
        strOprtId: '',
        strWorkId: '',
        strETCUserId: '',
      });
      this.$writeLog('动态库储值卡扣款圈提');
      console.log('框架圈提:', cardCPayment);
      if (cardCPayment.code === '0') {
        let afterAmt;
        if (cardCPayment.AfterBalance) {
          afterAmt = cardCPayment.AfterBalance;
        } else {
          // 未返回余额 读卡获取余额判断是否扣款成功  回读失败可重复3次 后提示 回读余额失败，请调整卡片位置后重试
          const res = this.toReadCard(false, true);
          if (res) {
            afterAmt = res.price;
          }
        }
        // 根据余额判断是否圈提成功
        if (afterAmt < cardCPayment.BeforeBalance) {
          // 圈提成功，10.7 储值卡圈提确认接口
          const isReust = await cardCircleConfirm({
            workOrderId: '',
            etcUserId: '',
            tradeTime: '',
            cardBalance: '',
            cardTxSeq: '',
            terminalTxSeq: '',
            tac: '',
          });
          this.$writeLog('储值卡圈提确认');
          console.log('圈提确认:', isReust);
          if (isReust) {
            // 成功，弹出回执签名页面
            console.log('冲正成功，弹出回执签名页面');
            this.cploading = false;
            this.BeforeBalance = getFormatAmount(cardCPayment.BeforeBalance);
            this.AfterBalance = getFormatAmount(cardCPayment.AfterBalance);
            this.toReceiptConfirm();
          } else {
            // 失败提示
            this.cploading = false;
            this.$message.error('冲正失败，请重试');
          }
        } else {
          this.cploading = false;
          this.$message.error('冲正失败，请重试');
        }
      } else {
        this.$message.error('冲正失败，请重试');
      }
    },
    async toReadCard(needWholeLoading, readAgain, notNeedCardInfo) {
      console.log('读卡');
      this.cardIdNotSameMsg =
        '当前卡号和主页查询的卡号不一致，请清除后重新查询';
      let failObj = {
        showMsg: false,
      };
      let successObj = {
        notNeedCardInfo,
        cardInfo: this.cardInfo,
        cardIdNotSameMsg: this.cardIdNotSameMsg,
        cardIdNotSameCancelMsg: this.cardIdNotSameCancelMsg,
        cardIdNotSameCancelFunc: '',
        successFunc: (successRes) => {
          // 自动读卡，显示卡面余额
          this.reverseForm.cardBalance = getFormatAmount(successRes.price);
        },
      };
      const res = await readCardAndGetAmount(
        needWholeLoading,
        failObj,
        successObj
      );
      console.log('重复读卡：', res);
      this.readAgainTimes++;
      if (readAgain) {
        // 若是前端自行回读的，需判断回读的卡号，卡号不一致，提示“回读余额失败，请调整卡片位置后重试”。
        this.cardIdNotSameMsg = '回读余额失败，请调整卡片位置后重试';
        // 若回读余额失败，自动重试回读，最多回读3次
        if (res && this.readAgainTimes <= 3) {
          this.$writeLog('回读成功：' + JSON.stringify(res));
          return res;
        } else if (!res && this.readAgainTimes >= 3) {
          // 第3次失败后，提示“回读余额失败，请调整卡片位置，重试”
          this.$writeLog('回读余额失败，回读次数>=3：' + JSON.stringify(res));
          this.$confirm('回读余额失败，请调整卡片位置，重试', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            closeOnClickModal: false,
            closeOnPressEscape: false,
            type: 'warning',
          })
            .then(() => {
              //若点击确定则再次回读
              this.toReadCard(false, true);
            })
            .catch(() => {
              // 若点击取消，弹出提示“冲正失败请重试”
              this.$message.error('冲正失败请重试');
              return;
            });
        } else if (this.readAgainTimes < 3) {
          this.$writeLog('回读余额失败，回读次数<3，继续回读');
          this.toReadCard(false, true);
        }
      } else {
        this.$writeLog('不回读：' + JSON.stringify(res));
        return res;
      }
    },
    async readcard(isFailTips) {
      // 读沪卡通内容
      const cardInfoAll = await getcardinfoall();
      this.$writeLog('读卡');
      console.log('cardInfoAll:', cardInfoAll);
      if (cardInfoAll.code === '0') {
        if (cardInfoAll.cardId !== this.cardInfo.cardId) {
          // 获取卡号和余额
          cardInfoAll.cardId;
          this.reverseForm.cardBalance = getFormatAmount(cardInfoAll.price);
        } else {
          this.$message.error(
            '当前卡号和主页查询的卡号不一致，请清除后重新查询'
          );
        }
      } else if (isFailTips === '1') {
        this.$message.error('读卡失败');
      }
    },
    async queryReverseTrans() {
      let searchDate = formatDate(
        'YYYYMMDD',
        new Date(this.reverseForm.rechargeDate)
      );
      const self = this;
      self.tables = [];
      const res = await queryLists({
        etcUserId: this.userInfo.etcUserId,
        userAcctid: this.accountInfo.userAcctId,
        cardId: this.cardInfo.cardId,
        unLoadType: '1', // 1-储值卡充值冲正 两条 2-圈存账户充值冲正 一条 3-多充值处理 两条
        startDate: searchDate, // 充值日期
        txAmount: this.reverseForm.rechargeAmt, // 充值金额
      });
      this.$writeLog('可冲正记录查询');
      if (res) {
        let dataList = [];
        dataList = res.chargeList;
        self.tables = dataList;
        this.total = dataList.length;
        this.currentSize = res.totalRowNumber;
        this.pageSize * this.page >= this.total
          ? this.total
          : this.page * this.pageSize;
        if (dataList.length > 0) {
          dataList.forEach(function (item, index, arr) {
            dataList[index].txAmount = getFormatAmount(
              dataList[index].txAmount
            );
          });
          // self.tables = dataList;
          // 自动填写冲正金额
          // this.reverseForm.reverseAmount = dataList[0].txAmount;
          // 冲正按钮有效
          // this.cardReverseBtn = false;
        } else {
          this.$message.error('未查到该卡今天在本网点有充值记录');
          // 冲正按钮无效 todo
          this.cardReverseBtn = true;
        }
      }
    },
    async accountReverseclick() {
      this.$writeLog('点击冲正按钮');
      this.cploading = true;
      // 确认凭证
      this.toConfirm();
      // // 读卡加载余额
      // this.readcard('1');
      // // 若卡余额<充值金额
      // if (this.reverseForm.cardBalance < this.reverseForm.reverseAmount) {
      //   this.$message.error('卡面余额不足，不能冲正');
      //   this.cploading = false;
      //   return;
      // }
      // // 读取卡50条记录
      // const cardR50 = await get50Records();
      // this.$writeLog('读取卡50条记录');
      // // 调用12.8工单查询，是否有进行中的多充值扣款工单
      // const orderList = await orderQuery({
      //   beginDate: '', // 当天
      //   endDate: '',
      //   bizCode: '', //业务类型
      //   cardId: '',
      //   localNetFlag: '1', //本网点
      //   netId: '', //网点编号
      //   startRecords: '',
      //   rowNumber: '',
      // });
      // 1.0 有进行的工单
      // 1.1 调用10.24冲正扣款校验接口
      // 1.1.1 已扣款，10.7圈提确认
      // 1.1.2 未扣款，框架2.17圈提，10.7圈提确认
      // 1.1.3 不能冲正，提示不能冲正
      // 1.2 回执签名
      // this.$writeLog('工单查询，判断是否有进行中的冲正工单');
      // console.log('工单查询返回：', orderList);
      // if (orderList && false) {
      //   let recordArry = [];
      //   recordArry = orderList.recordList;
      //   if (recordArry.length > 0) {
      //     // 10.24冲正扣款校验接口
      //     const rcpCheckResult = await reverseCPCheck({
      //       workOrderId: '',
      //       etcUserId: '',
      //       record: cardR50.info,
      //     });
      //     this.$writeLog('冲正扣款校验：' + rcpCheckResult);
      //     console.log('10.24冲正扣款校验接口:', rcpCheckResult);
      //     // 冲正扣款校验结果，1.不能冲正 2.未扣款 3.已扣款
      //     if (rcpCheckResult.unloadResult === '1') {
      //       this.$message.error('不能冲正');
      //       this.cploading = false;
      //       return;
      //     } else if (rcpCheckResult.unloadResult === '3') {
      //       // 3.已扣款 调用10.7储值卡圈提确认
      //       const circleConfirmResult = await cardCircleConfirm({
      //         workOrderId: '',
      //         etcUserId: '',
      //         tradeTime: '',
      //         cardBalance: '',
      //         cardTxSeq: '',
      //         terminalTxSeq: '',
      //         tac: '',
      //       });
      //       this.$writeLog('储值卡圈提确认');
      //       console.log('10.7储值卡圈提确认:', circleConfirmResult);
      //       if (rcpCheckResult) {
      //         // 弹出回执签名
      //         console.log('冲正成功，弹出签名回执');
      //         this.cploading = false;
      //       }
      //     } else if (rcpCheckResult.unloadResult === '2') {
      //       // 未扣款，走扣款流程
      //       this.cutPaymentOperation();
      //     }
      //   }
      // } else {
      //   // 2.0 无进行进行中冲正工单
      //   // 2.1 10.24扣款
      //   // 2.2 确认凭证
      //   // 2.3 调用创建工单接口bizcode=31
      //   // 2.4 2.17 储值卡扣款（框架）
      //   // 2.5 10.7 圈提确认
      //   // 2.6 回执签名

      //   // 2.1 10.24冲正扣款校验接口
      //   const rcpCheckResult = await reverseCPCheck({
      //     workOrderId: '',
      //     etcUserId: '',
      //     record: cardR50.info,
      //   });
      //   console.log('无进行中冲正工单');
      //   console.log('10.24冲正扣款校验:', rcpCheckResult);
      //   // 冲正扣款校验结果，1.不能冲正 2.未扣款 3.已扣款
      //   if (rcpCheckResult.unloadResult === '2') {
      //     // 2.2 确认凭证
      //     this.toConfirm();
      //   } else {
      //     this.$message.error('不能冲正');
      //     this.cploading = false;
      //     return;
      //   }
      // }
    },
    getPageAuthority() {
      // 账户冲正日期权限
      let elementPermissionsMenu = this.$store.getters.elementPermissions;
      let continueType = 'accountReverse';
      let arPage = elementPermissionsMenu.find(
        (obj) => obj.menu == '/' + continueType
      );
      if (arPage.permissions.dateauthority) {
        this.dateauthority = arPage.permissions.dateauthority;
      }
      console.log('是否有日期权限:', this.dateauthority);
    },
    async getAcctInfo() {
      let userAcctTypeStr = await getDicDesByCode(
        dicKeys.useracctType,
        this.accountInfo.userAcctType
      );
      let userAcctStatusStr = await getDicDesByCode(
        dicKeys.userAcctStatus,
        this.accountInfo.userAcctStatus
      );
      this.reverseForm.userAcctId = this.accountInfo.userAcctId;
      this.reverseForm.userAcctType = userAcctTypeStr;
      this.reverseForm.userAcctStatus = userAcctStatusStr;
      this.reverseForm.acctBalance = getFormatAmount(this.accountInfo.balance);
      const res = await etcAccountQuery({
        etcUserId: this.userInfo.etcUserId,
        userAccountId: this.cardInfo.userAcctId,
      });
      if (res) {
        this.reverseForm.overLimit = getFormatAmount(res.overLimit);
        this.reverseForm.noticeLimit = getFormatAmount(res.noticeLimit);
      }
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
      if (this.multipleSelection.length > 1) {
        this.$refs.tb.clearSelection();
        this.$refs.tb.toggleRowSelection(val.pop());
      }
      if (this.multipleSelection.length > 0) {
        // 选中充值记录，自动填写冲正金额
        this.reverseForm.reverseAmount = this.multipleSelection[0].txAmount;
        this.cardReverseBtn = false;
      } else {
        this.cardReverseBtn = true;
      }
    },
    onSelectAll() {
      this.$refs.tb.clearSelection();
    },
  },
  mounted() {
    this.$writeLog('账户冲正，页面进入');
    // 获取账户信息
    this.getAcctInfo();
    // 页面加载读卡
    // this.readcard('0');
    // 获取日期权限
    this.getPageAuthority();
    // 页面加载冲正交易查询
    this.queryReverseTrans();
  },
  destroyed() {
    // clearTimeout(this.timer1);
  },
};
</script>