<!-- 换签 -->
<template>
  <div class="offline-changeobu offline-changeobumain">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-changeobuindex_title">换签</h4>
      </div>
    </div>
    <!-- <template class="o-flex offline-changeobumain_blocks-wrap">
      <div class="offline-changeobumain_block"></div>
      <div class="offline-changeobumain_block"></div>
    </template> -->
    <el-row :gutter="10" class="mt20">
      <el-col :span="12"
        ><div class="offline-changeobumain_block">
          <el-form
            ref="oldOBUForm"
            :model="oldOBUForm"
            class="offline-changeobumain_block-readobu-form"
          >
            <div class="o-flex">
              <loading-button
                class="offline-changeobumain_block-readobu-btn"
                size="small"
                type="primary"
                @click="readOldOBU"
                :loading="loadingReadOld"
                :disabled="disabledReadOld"
                round
              >
                <i class="icon iconfont iconbofang" /> 读旧签
              </loading-button>

              <el-form-item prop="destroy" ref="destroy">
                <el-checkbox
                  v-model="oldOBUForm.destroy"
                  :disabled="disabledDestroy"
                  class="offline-changeobumain_block-readobu-checkbox"
                  >标签人为损坏</el-checkbox
                >
              </el-form-item>
              <el-form-item prop="expird" ref="expird">
                <!-- <el-checkbox
                  v-model="oldOBUForm.expird"
                  disabled
                  class="offline-changeobumain_block-readobu-checkbox"
                  >标签过保修期</el-checkbox
                > -->
                <span
                  v-show="oldOBUForm.expird"
                  class="offline-changeobumain_block-readobu-span"
                  >标签过保修期</span
                >
              </el-form-item>
            </div>

            <div class="offline-changeobumain_block-readobu-centent">
              <el-row class="offline-changeobumain_block-readobu-centent-row">
                <el-form-item prop="obuSysID" ref="obuSysID">
                  <el-col :xl="7" :lg="7" :md="7">旧标签ID：</el-col>
                  <el-col :xl="17" :lg="17" :md="17">{{
                    oldOBUForm.obuSysID
                  }}</el-col>
                </el-form-item>
              </el-row>
              <el-row class="offline-changeobumain_block-readobu-centent-row">
                <el-form-item prop="printID" ref="printID">
                  <el-col :xl="7" :lg="7" :md="7">旧标签表面号：</el-col>
                  <el-col :xl="17" :lg="17" :md="17">
                    <!-- <input
                    placeholder="请输入卡片背面的卡号"
                    :value="oldOBUForm.printID"
                  /> -->
                    <regex-input
                      ref="printIdInput"
                      type="obuFrontId"
                      :placeholder="placeholderFrontId"
                      :readonly="readonlyFrontId"
                      @focus="focusFrontId"
                      v-model="oldOBUForm.printID"
                    ></regex-input>
                    <loading-button
                      class=""
                      type="primary"
                      size="small"
                      :disabled="disabledConfirmPrintId"
                      @click="confirmPrintId"
                      round
                    >
                      确认
                    </loading-button>
                  </el-col>
                </el-form-item>
              </el-row>
              <el-row class="offline-changeobumain_block-readobu-centent-row">
                <el-form-item prop="issueVersion" ref="issueVersion">
                  <el-col :xl="7" :lg="7" :md="7">旧标签版本号：</el-col>
                  <el-col :xl="17" :lg="17" :md="17">{{
                    oldOBUForm.issueVersion
                  }}</el-col>
                </el-form-item>
              </el-row>
              <el-row class="offline-changeobumain_block-readobu-centent-row">
                <el-form-item prop="txType" ref="txType">
                  <el-col :xl="7" :lg="7" :md="7">旧标签状态：</el-col>
                  <el-col :xl="17" :lg="17" :md="17"></el-col>
                  <!-- {{ oldOBUForm.txType }} -->
                </el-form-item>
              </el-row>
            </div>
          </el-form>
        </div></el-col
      >
      <el-col :span="12"
        ><div class="offline-changeobumain_block">
          <el-form
            ref="newOBUForm"
            :model="newOBUForm"
            class="offline-changeobumain_block-readobu-form"
          >
            <loading-button
              class="offline-changeobumain_block-readobu-btn"
              size="small"
              type="primary"
              @click="readNewOBU"
              :loading="loadingReadNew"
              :disabled="disabledReadNew"
              round
            >
              <i class="icon iconfont iconbofang" /> 读新签
            </loading-button>
            <div class="offline-changeobumain_block-readobu-centent">
              <el-row class="offline-changeobumain_block-readobu-centent-row">
                <el-col class="no-bottom-border">
                  <el-radio-group
                    ref="radioNewCardType"
                    v-model="newOBUForm.txType"
                    disabled
                    class="offline-changeobumain_block-readobu-radio"
                  >
                    <!-- <el-radio label="5">自有标签</el-radio> -->
                    <el-radio label="2">新购标签</el-radio>
                  </el-radio-group>
                </el-col>
              </el-row>
              <el-row class="offline-changeobumain_block-readobu-centent-row">
                <el-col :xl="7" :lg="7" :md="7">新标签版本号：</el-col>
                <el-col :xl="17" :lg="17" :md="17">{{
                  newOBUForm.issueVersion
                }}</el-col>
              </el-row>
            </div>
          </el-form>
        </div></el-col
      >
    </el-row>
    <div class="offline-changeobumain_feeblock">
      <el-row :gutter="10" class="">
        <el-col :span="12"
          ><div class="offline-changeobumain_feeblock-due">
            <div class="offline-changeobumain_feeblock-desc">应收（元）</div>
            <div class="offline-changeobumain_feeblock-amount">
              {{ due }}
            </div>
          </div>
          <div class="offline-changeobumain_feeblock-receive">
            <div class="offline-changeobumain_feeblock-desc">实收（元）</div>
            <div class="offline-changeobumain_feeblock-amount">
              {{ receive }}
            </div>
          </div></el-col
        >
        <el-col :span="12" class="o-flex o-flex-column">
          <div class="o-flex o-flex-space-between">
            <div
              class="
                o-flex o-flex-align-baseline
                offline-changeobumain_feeblock-paymode
              "
            >
              <div class="offline-changeobumain_feeblock-paymode-desc">
                支付方式：
              </div>
              <type-select
                type="payMode"
                v-model="payMode"
                :disabled="isUsePayMode"
                placeholder="请选择"
                class="offline-changeobumain_feeblock-paymode-select"
              />
            </div>
            <loading-button
              type="primary"
              class="offline-changeobumain_feeblock-btn"
              :disabled="disabledFee"
              @click="fee"
              >收费
            </loading-button>
          </div>
          <el-checkbox
            @change="specialFreeChange"
            v-model="specialFree"
            :disabled="!hasSpecialFreeAuth ? true : disabledFee"
            class="offline-changeobumain_block-specialfree-checkbox"
            >特许免费</el-checkbox
          >
        </el-col>
      </el-row>
    </div>
    <div class="offline-changeobumain_tip">
      {{ tip }}
    </div>
    <el-row :gutter="10" class="offline-changeobumain_bottom">
      <el-col :span="12">
        <loading-button
          type="primary"
          class="offline-changeobumain_bottom-btn"
          :disabled="disabledDistroyOld"
          :loading="loadingDistroyOld"
          :clickNoLoading="clickNoLoading"
          @click="confirmFlagc ? writeOff() : toConfirm()"
          round
          >核销旧签
        </loading-button>
      </el-col>
      <el-col :span="12">
        <loading-button
          type="primary"
          class="offline-changeobumain_bottom-btn"
          :disabled="disabledChangeNew"
          :loading="loadingChangeNew"
          @click="changeNew"
          round
          >更换新签
        </loading-button>
      </el-col>
    </el-row>
    <voucher-layer-confirm
      ref="mychild1"
      :column="2"
      :tip="confirmTip"
      :info="voucherConfirmData"
      :keys="voucherConfirmKeys"
      :visible.sync="voucherConfirmVisiable"
      :confirmFlag.sync="confirmFlagc"
      @closed="disabledDistroyOld = false"
      @complete="writeOff"
    ></voucher-layer-confirm>
    <!-- <el-button @click="loadingReadOld = false">test </el-button> -->
    <addbranch-block
      :visible.sync="addvisble"
      :append-to-body="true"
      popuptype="addbranch"
      :showclose="false"
      @addbranchs="improveBranch(methodType)"
    ></addbranch-block>
  </div>
</template>
<script>
import VoucherLayerConfirm from '@/components/VoucherLayerConfirm';
import RegexInput from '@/components/RegexInput';
import { issueOBU, readOBU } from '@/utils/dynamic';
import { systemParameterQuery, updateWorkOrder } from '@/api/common';
import {
  changeValidityApply,
  changeValidityConfrim,
  renewalValidity,
  changeValidityRenewalConfrim,
} from '@/api/writeoff';
import { requestCompre } from '@/api/compre';
import { v1PreIssueApply, v1PreIssueConfirm } from '@/api/publish';
import {
  queryCardObuOneSendInfo,
  calculateObuReplacement,
  orderCharges,
  changeObu,
  checkSurfaceCode,
} from '@/api/equipment';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicEasyDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';
import { getFormatAmount, getFormatAmountYuan2Fen } from '@/utils/utils';
import { perfectVehicleDepartment } from '@/api/branch';
import AddbranchBlock from '@/components/AddbranchBlock';
export default {
  data() {
    return {
      // step: '',
      addbranchsMethod: '', // 新建分支结构回调
      methodType: '', // 新建分支结构回调方法类型
      isValidity: '',
      addvisble: false, // 新建分支结构弹窗
      timer: null,
      tip: '',
      confirmTip: '标签一旦核销，将无法使用，且不能反悔，您确认要核销吗？',
      voucherConfirmData: {},
      voucherConfirmKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '用户名称' },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'vehicleNumber', label: '车牌号码' },
          { key: 'vehicleColor', label: '车牌颜色' },
          { key: 'vehicleType', label: '车辆用户类型' },
          { key: 'vehicleClass', label: '收费车型' },
          { key: 'approvedAccount', label: '核定载人数' },
          { key: 'viTotalMass', label: '总质量' },
        ],
        [
          // { key: 'cardType', label: '卡类型' },
          { key: 'obuId', label: '标签ID' },
          { key: 'obuStatus', label: '标签当前状态' },
          { key: 'obuFreeEndDate', label: '标签保修期' },
        ],
      ],
      voucherConfirmVisiable: false,
      payMode: '',
      specialFree: false, // 特许免费
      hasSpecialFreeAuth: false, // 特许免费权限
      // specialFreeDisabled: false, // 特许免费禁用
      oldOBUForm: {
        destroy: false,
        expird: false,
        obuSysID: '',
        // printID: '3101 0322 2033 3349 9032',
        printID: '',
        issueVersion: '',
        txType: '',
      },
      newOBUForm: {
        obuSysID: '',
        txType: '',
        issueVersion: '',
        printID: '',
      },
      loadingReadOld: false,
      loadingReadNew: false,
      loadingChangeNew: false,
      loadingDistroyOld: false,
      disabledReadOld: false, // 读旧卡禁用
      disabledDestroy: false, // 人为损坏勾选禁用
      clickNoLoading: false, // 点击但不触发Loading
      disabledConfirmPrintId: true,
      disabledReadNew: true,
      disabledFee: true,
      disabledDistroyOld: true,
      disabledChangeNew: true,
      checked: false,
      flagConfirmPrintId: false,
      confirmFlagc: false, // 确认凭证是否被确认
      readonlyFrontId: true,
      isGood: true,
      oldIsDestroyed: false, // 旧卡已核销
      placeholderFrontId: '',
      due: '0.00', // 应收
      oldDue: '',
      receive: '0.00', // 实收
      price: 0, // 收费金额，单位为分
      workOrderID: '', // 工单号
      isUsePayMode: false, // 支付方式是否使用
      changeOBUData: {}, // 继续办理换签数据
      cdif: '',
      isChangeOBU: '',
      oprice: 0, // 已有工单收费价格
      continueSysId: '', // 继续办理获取的设备号
      etcUserId: '',
      newVehicleNumber: '',
      newVehicleColor: '',
      newPrice: 0,
      isFree: '',
    };
  },
  components: {
    RegexInput,
    VoucherLayerConfirm,
    AddbranchBlock,
  },
  watch: {
    // 'oldOBUForm.printID'(val) {
    //   if (val.length === 24 && this.flagConfirmPrintId) {
    //     // 卡表面号（加4个空格）输入完整，达到24位
    //     this.disabledConfirmPrintId = false;
    //   } else {
    //     this.disabledConfirmPrintId = true;
    //   }
    // },
    addbranchsMethod(val) {
      console.log('watch-addbranchsMethod');
      if (val == 'mainChange') {
        this.mainChange();
      } else if (val == 'badChange') {
        this.badChange();
      } else if (val == 'retryCancelChange') {
        this.retryCancelChange();
      }
    },
    disabledReadNew(val) {
      console.log('watch-disabledReadNew');
      if (!val) {
        this.readonlyFrontId = true;
      }
    },
  },
  computed: {
    vehicleInfo() {
      return this.$store.getters.searchCarInfo;
    },
    obuInfo() {
      return this.$store.getters.searchObuInfo;
    },
    cardInfo() {
      return this.$store.getters.searchCardInfo;
    },
    userInfo() {
      return this.$store.getters.searchUserInfo;
    },
  },
  methods: {
    // 主流程换卡/签流程
    async mainChange() {
      etcdev.writelog('主流程换卡/签流程-mainChange()');
      console.log('mainChange()');
      //-------换签改有效期的时候，出现ffff导致的无限loading的问题还没有解决，为了明天正常上线，暂时先改成旧签核销的时候不改有效期---
      const resChange = await changeObu({
        etcUserId: this.userInfo.etcUserId,
        workOrderId: this.workOrderID,
        oldObuId: this.oldOBUForm.obuSysID,
        newObuId: this.newOBUForm.obuSysID,
        vehicleNumber: this.vehicleInfo.vehicleNumber,
        vehicleColor: this.vehicleInfo.vehicleColor,
        price: this.price,
        payMode: this.payMode,
        userName: this.userInfo.userName,
        userCode: this.userInfo.userCode,
        userCertType: this.userInfo.userCertType,
        deliveryMode: '2',
        buyChannel: this.newOBUForm.txType === '5' ? '1' : '2', //1-自带 2-新购
        freeEndDate: this.obuInfo.freeEndDate,
        isDmage: this.oldOBUForm.destroy ? '2' : '1',
        isBartender: this.oldOBUForm.expird ? '2' : '1',
        isValidity: this.isValidity, // 在坏卡/坏签的情况下，是不去改有效期的，此时传否
        newObuVersion: this.newOBUForm.issueVersion,
        oldObuVersion: this.oldOBUForm.issueVersion,
      });
      if (resChange) {
        etcdev.writelog('主流程换卡/签流程-核销完成后更换新卡按钮变为可用');
        // 核销完成后更换新卡按钮变为可用。
        this.loadingDistroyOld = false;
        this.disabledDistroyOld = true;
        this.disabledChangeNew = false;
      } else {
        etcdev.writelog('主流程换卡/签流程-14.6 换签业务申请报错');
        //接口异常
        this.loadingDistroyOld = false;
        this.disabledDistroyOld = false;
        this.disabledChangeNew = true;
      }
      //------【原代码】，正常流程部分----
      // const resChange0 = await changeObu({
      //   etcUserId: this.userInfo.etcUserId,
      //   workOrderId: this.workOrderID,
      //   oldObuId: this.oldOBUForm.obuSysID,
      //   newObuId: this.newOBUForm.obuSysID,
      //   vehicleNumber: this.vehicleInfo.vehicleNumber,
      //   vehicleColor: this.vehicleInfo.vehicleColor,
      //   price: this.price,
      //   payMode: this.payMode,
      //   userName: this.userInfo.userName,
      //   userCode: this.userInfo.userCode,
      //   userCertType: this.userInfo.userCertType,
      //   deliveryMode: '2',
      //   buyChannel: this.newOBUForm.txType === '5' ? '1' : '2', //1-自带 2-新购
      //   freeEndDate: this.obuInfo.freeEndDate,
      //   isDmage: this.oldOBUForm.destroy ? '2' : '1',
      //   isBartender: this.oldOBUForm.expird ? '2' : '1',
      //   isValidity: this.isValidity, // 改有效期成功了才去调换卡/换签接口，也就是这里始终是传‘2’
      //   newObuVersion: this.newOBUForm.issueVersion,
      //   oldObuVersion: this.oldOBUForm.issueVersion,
      // });
      // if (resChange0) {
      //   // 核销完成后更换新卡按钮变为可用。
      //   this.loadingDistroyOld = false;
      //   this.disabledDistroyOld = true;
      //   this.disabledChangeNew = false;
      // } else {
      //   // 如果14.6 换签业务申请接口返回失败，且旧卡是好卡，则恢复卡片效期
      //   const resRenewal = await this.renewal(res);
      //   if (resRenewal) {
      //     this.loadingDistroyOld = false;
      //     this.disabledDistroyOld = false;
      //     this.disabledChangeNew = true;
      //   }
      // }
    },
    // 坏设备换卡/签流程
    async badChange() {
      etcdev.writelog('坏设备换卡/签流程-badChange()');
      console.log('badChange()');
      const res4 = await changeObu({
        etcUserId: this.userInfo.etcUserId,
        workOrderId: this.workOrderID,
        oldObuId: this.oldOBUForm.obuSysID,
        newObuId: this.newOBUForm.obuSysID,
        vehicleNumber: this.vehicleInfo.vehicleNumber,
        vehicleColor: this.vehicleInfo.vehicleColor,
        price: this.price,
        payMode: this.payMode,
        userName: this.userInfo.userName,
        userCode: this.userInfo.userCode,
        userCertType: this.userInfo.userCertType,
        deliveryMode: '2',
        buyChannel: this.newOBUForm.txType === '5' ? '1' : '2', //1-自带 2-新购
        freeEndDate: this.obuInfo.freeEndDate,
        isDmage: this.oldOBUForm.destroy ? '2' : '1',
        isBartender: this.oldOBUForm.expird ? '2' : '1',
        isValidity: this.isValidity, // 在坏卡/坏签的情况下，是不去改有效期的，此时传否
        newObuVersion: this.newOBUForm.issueVersion,
        oldObuVersion: this.oldOBUForm.issueVersion,
      });
      if (res4) {
        etcdev.writelog('坏设备换卡/签流程-核销完成后更换新卡按钮变为可用。');
        // 核销完成后更换新卡按钮变为可用。
        this.loadingDistroyOld = false;
        this.disabledDistroyOld = true;
        this.disabledChangeNew = false;
      } else {
        etcdev.writelog('坏设备换卡/签流程-14.6 换签业务申请报错');
        //接口异常
        this.loadingDistroyOld = false;
        this.disabledDistroyOld = false;
        this.disabledChangeNew = true;
      }
    },
    // 取消重试设备换卡/签流程
    async retryCancelChange() {
      etcdev.writelog('取消重试设备换卡/签流程-retryCancelChange()');
      console.log('retryCancelChange()');
      const resChange = await await changeObu({
        etcUserId: this.userInfo.etcUserId,
        workOrderId: this.workOrderID,
        oldObuId: this.oldOBUForm.obuSysID,
        newObuId: this.newOBUForm.obuSysID,
        vehicleNumber: this.vehicleInfo.vehicleNumber,
        vehicleColor: this.vehicleInfo.vehicleColor,
        price: this.price,
        payMode: this.payMode,
        userName: this.userInfo.userName,
        userCode: this.userInfo.userCode,
        userCertType: this.userInfo.userCertType,
        deliveryMode: '2',
        buyChannel: this.newOBUForm.txType === '5' ? '1' : '2', //1-自带 2-新购
        freeEndDate: this.obuInfo.freeEndDate,
        isDmage: this.oldOBUForm.destroy ? '2' : '1',
        isBartender: this.oldOBUForm.expird ? '2' : '1',
        isValidity: this.isValidity, // 改有效期标志传否
        newObuVersion: this.newOBUForm.issueVersion,
        oldObuVersion: this.oldOBUForm.issueVersion,
      });
      if (resChange) {
        etcdev.writelog(
          '取消重试设备换卡/签流程-核销完成后更换新卡按钮变为可用'
        );
        // 核销完成后更换新卡按钮变为可用。
        this.loadingDistroyOld = false;
        this.disabledDistroyOld = true;
        this.disabledChangeNew = false;
      } else {
        etcdev.writelog('取消重试设备换卡/签流程-14.6 换签业务申请报错');
        // 接口异常
        this.loadingDistroyOld = false;
        this.disabledDistroyOld = false;
        this.disabledChangeNew = true;
      }
    },
    // 特许免费
    specialFreeChange(val) {
      // 勾选后应收费用变为0元
      if (val) {
        this.due = '0.00';
      } else {
        this.due = this.oldDue;
      }
    },
    async improveBranch(methodType) {
      etcdev.writelog('重复调用improveBranch，methodType:' + methodType);
      console.log('重复调用improveBranch，methodType:', methodType); // 新建完分支机构后，再次调后台4.12.完善分支机构接口
      // 点击确定后调用后台4.12.完善分支机构接口，由系统自动进行完善处理
      let resPer, loading;
      try {
        loading = this.$loading();
        etcdev.writelog('开始loading，调用4.12.完善分支机构接口');
        resPer = await perfectVehicleDepartment({
          etcUserId: this.userInfo.etcUserId,
          vehicleId: this.vehicleInfo.vehicleId,
        });
        loading.close();
        etcdev.writelog('loading结束');
      } catch (error) {
        etcdev.writelog('4.12.完善分支机构接口异常，可能原因：超时');
        loading.close();
        etcdev.writelog('loading结束');
      }
      if (resPer) {
        etcdev.writelog('4.12.完善分支机构接口返回不报错');
        if (resPer.exCode == '9002') {
          etcdev.writelog('4.12.完善分支机构接口返回9002');
          // 如果4.12.完善分支机构接口返回9002，前端提示“该用户名下无有效默认分支机构，请新建”
          this.$confirm('该用户名下无有效默认分支机构，请新建', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            closeOnClickModal: false,
            closeOnPressEscape: false,
            type: 'warning',
          })
            .then(() => {
              etcdev.writelog(
                '提示“该用户名下无有效默认分支机构，请新建”-点击确定'
              );
              // 点击确定后自动弹出新建分支机构的页面，引导操作员完成新建分支机构
              // this.methodType = 'mainChange';
              this.methodType = methodType;
              this.addvisble = true;
            })
            .catch(() => {
              etcdev.writelog(
                '提示“该用户名下无有效默认分支机构，请新建”-点击取消，暂停业务'
              );
              // 暂停业务
              this.loadingDistroyOld = false;
              this.disabledDistroyOld = false;
              this.disabledChangeNew = true;
              return;
            });
        }
        if (!resPer.exCode) {
          etcdev.writelog(
            '4.12.完善分支机构接口返回成功，再调一次14.6换签业务申请接口，后续流程继续'
          );
          // 如果4.12.完善分支机构接口返回成功，再调一次14.6换签业务申请接口，后续流程继续
          console.log('完善分支机构没问题-!exCode');
          this.addbranchsMethod = methodType;
        }
      } else {
        etcdev.writelog('4.12.完善分支机构接口报错');
        //接口异常
        this.loadingDistroyOld = false;
        this.disabledDistroyOld = false;
        this.disabledChangeNew = true;
      }
    },
    // 读旧卡
    async readOldOBU() {
      // this.$refs.oldOBUForm.resetFields();
      this.$refs.expird.resetField();
      this.$refs.obuSysID.resetField();
      this.$refs.printID.resetField();
      this.$refs.issueVersion.resetField();
      this.$refs.txType.resetField();
      let failObj = {
        msg: '读标签失败。<br>点[重试]按钮重试，点[取消]按钮手动输入标签表面号并回车，当坏标签处理。',
        confirmButtonText: '重试',
        cancelButtonText: '取消',
        distinguishCancelAndClose: true,
        cancelCatch: async () => {
          // 若点击取消，旧标签表面号后面的输入栏变为可输入状态，显示灰色提示文字”请输入标签I表面号“
          this.readonlyFrontId = false;
          this.placeholderFrontId = '请输入标签I表面号';
          this.disabledConfirmPrintId = false; // 同时显示确定按钮，状态为可用
          this.flagConfirmPrintId = true; // 只有此时才可触发确认按钮
        },
        closeCatch: () => {
          //若既不需要重试也不需要手动输入卡号，则点提示框右上角的×关闭提示框
        },
        cardIdNotSameMsg: '标签不一致，请清除首页信息重新查询',
      };
      let btnLoading = this.loadingReadOld;
      let successFunc = async (res) => {
        // 若读标签成功，读取到旧标签ID和旧标签版本号并显示，
        this.oldOBUForm.obuSysID = res.obuid;
        this.oldOBUForm.issueVersion = res.issueversion;
        // 当前日期（当前日期需通过后台接口查询）超卡片保修期时，自动勾选“卡片过保修期”
        let time = this.obuInfo.freeEndDate; // 用综合查询的保修期
        const res0 = await systemParameterQuery({ requestType: '00' });
        if (res0) {
          if (time < res0.value) {
            this.oldOBUForm.expird = true;
          }
        }
        // 调用后台7.3.查询卡/OBU一发信息接口查询，显示旧卡表面号和旧卡状态
        const res1 = await queryCardObuOneSendInfo({
          obuSysID: this.oldOBUForm.obuSysID,
        });
        if (res1) {
          const txType = await getDicEasyDesByCode(dicKeys.txType, res1.txType);
          // 读完旧卡或输入表面号，查询出旧卡状态时，若旧卡状态为2-已核销，
          // 则核验新卡完成后，核销旧卡按钮保持不可用，更换新卡按钮变为可用。
          const _txType = await getDicCodeByDes(dicKeys.txType, '已核销');
          if (res1.txType === _txType) {
            // if (true) {
            this.oldIsDestroyed = true;
          }
          this.oldOBUForm.txType = txType;
          this.oldOBUForm.printID = res1.printID;
          // this.disabledDestroy = true;
          this.disabledReadOld = true;
          this.disabledReadNew = false;
          // 读卡成功的，记录好卡标志；读卡失败，通过输入表面号查询的，记录坏卡标志
          this.isGood = true;
        }
        // console.log('$trim', this.$trim(this.oldOBUForm.printID));
      };
      let obuInfo = this.obuInfo.obuID
        ? this.obuInfo
        : { obuID: this.continueSysId }; // 当从继续办理进入该业务，已核销的设备没有设备号，需要通过工单管理里返回的设备号来校验
      const res = readOBU(
        btnLoading,
        // this.obuInfo,
        obuInfo,
        successFunc,
        this.readOldOBU,
        failObj
      );
    },
    async confirmPrintId() {
      if (this.isEmptyObj(this.obuInfo)) {
        this.$message.error('无法获取标签信息');
        return;
      } else {
        // 输入完成后点击确定按钮，调用后台7.3.查询卡/OBU一发信息接口，
        // 通过表面号查询到卡号、卡片版本号和卡状态并显示
        const res1 = await queryCardObuOneSendInfo({
          printID: this.$trim(this.oldOBUForm.printID),
        });
        if (res1) {
          const txType = await getDicEasyDesByCode(dicKeys.txType, res1.txType);
          // 核对此处卡号和首页综合查询的卡号是否一致
          if (res1.obuSysID == this.obuInfo.obuID) {
            // 当前日期（当前日期需通过后台接口查询）超卡片保修期时，自动勾选“卡片过保修期”
            let time = this.obuInfo.freeEndDate; // 如果是通过表面号查询的，只要核对过查询出来的卡号和综合查询的卡号一致，就用综合查询的保修期
            const res0 = await systemParameterQuery({ requestType: '00' });
            if (res0) {
              if (time < res0.value) {
                this.oldOBUForm.expird = true;
              }
            }
            this.oldOBUForm.obuSysID = res1.obuSysID;
            this.oldOBUForm.issueVersion = res1.issueVersion;
            this.oldOBUForm.txType = txType;
            // 读完旧卡或输入表面号，查询出旧卡状态时，若旧卡状态为2-已核销，
            // 则核验新卡完成后，核销旧卡按钮保持不可用，更换新卡按钮变为可用。
            const _txType = await getDicCodeByDes(dicKeys.txType, '已核销');
            if (res1.txType === _txType) {
              // if (true) {
              this.oldIsDestroyed = true;
            }
            // 核验旧卡按钮状态变为不可用，核验新卡按钮状态变为可用
            // this.disabledDestroy = true;
            this.disabledReadOld = true;
            this.disabledReadNew = false;
            // 读卡成功的，记录好卡标志；读卡失败，通过输入表面号查询的，记录坏卡标志
            this.isGood = false;
          } else {
            this.$alert('标签不一致，请清除首页信息重新查询', '提示', {
              confirmButtonText: '确定',
              type: 'warning',
            });
          }
        }
      }
    },
    focusFrontId() {
      if (this.flagConfirmPrintId && !this.readonlyFrontId) {
        // 鼠标点击进入输入状态时，灰色文字消失
        // this.oldOBUForm.printID = this.$printIdBefore;
        this.$refs.printIdInput.focus();
      }
    },
    // 读新卡
    async readNewOBU() {
      this.disabledDestroy = true;
      this.$refs.newOBUForm.resetFields();
      let failObj = {
        msg: '读标签失败。<br>点[重试]按钮重试。',
        confirmButtonText: '重试',
        cancelButtonText: '取消',
        cancelCatch: () => {},
      };
      let btnLoading = this.loadingReadNew;
      let successFunc = async (res) => {
        console.log('readNewOBU-successFunc-issueversion', res.issueversion);
        // 读标签成功后
        // 读标签成功后，判断新标签的版本号，需要满足以下条件
        // const vehicleCategory = await getDicCodeByDes(
        //   dicKeys.vehicleCategoryL,
        //   '普通客车'
        // );
        // 已注册的车辆，根据收费车型判断（未注册的车辆，综合查询不能成功）
        let vehicleClassArr = [];
        vehicleClassArr.push(
          await getDicCodeByDes(dicKeys.vehicleClassL, '一类客车')
        );
        vehicleClassArr.push(
          await getDicCodeByDes(dicKeys.vehicleClassL, '二类客车')
        );
        vehicleClassArr.push(
          await getDicCodeByDes(dicKeys.vehicleClassL, '三类客车')
        );
        vehicleClassArr.push(
          await getDicCodeByDes(dicKeys.vehicleClassL, '四类客车')
        );
        if (vehicleClassArr.includes(this.vehicleInfo.vehicleClass)) {
          // 车种为客车时
          // 新标签版本号必须和卡片版本号一致
          let newIssueVersionStart = '';
          if (res.issueversion == '00') {
            newIssueVersionStart = '1';
          } else if (res.issueversion.startsWith('1')) {
            newIssueVersionStart = '1';
          } else if (res.issueversion.startsWith('4')) {
            newIssueVersionStart = '4';
          }
          let oldIssueVersionStart = '';
          if (this.cardInfo.versionNo == '00') {
            oldIssueVersionStart = '1';
          } else if (this.cardInfo.versionNo.startsWith('1')) {
            oldIssueVersionStart = '1';
          } else if (this.cardInfo.versionNo.startsWith('4')) {
            oldIssueVersionStart = '4';
          }
          if (!(newIssueVersionStart == oldIssueVersionStart)) {
            // 若不一致，提示“新标签版本号需和卡片版本号一致”，流程结束
            this.$alert('新标签版本号需和卡片版本号一致', '提示', {
              confirmButtonText: '确定',
              type: 'warning',
            });
            return;
          }
        } else {
          // 车种不是客车（货车、牵引车、专项作业车中的任意一种）
          const cardType = await getDicCodeByDes(dicKeys.cardType, '储值卡');
          if (this.cardInfo.cardType == cardType) {
            // 若卡片的卡种为0-储值卡
            // 提示“卡片为储值卡，请先进行卡类型变更后再更换标签”，流程结束
            this.$alert(
              '卡片为储值卡，请先进行卡类型变更后再更换标签',
              '提示',
              {
                confirmButtonText: '确定',
                type: 'warning',
              }
            );
            return;
          } else {
            // 卡片不是储值卡时，流程继续
            if (!res.issueversion.startsWith('4')) {
              // 新标签只支持4x（版本号4开头）
              // 标签版本号不是4x时提示“货车、牵引车、专项作业车只能更换4x版本标签”，流程结束
              this.$alert(
                '货车、牵引车、专项作业车只能更换4x版本标签',
                '提示',
                {
                  confirmButtonText: '确定',
                  type: 'warning',
                }
              );
              return;
            }
          }
        }
        // 调后台7.3.查询卡/OBU一发信息接口，txType=2表示是新购卡片；txType=5表示是自有卡
        const res1 = await queryCardObuOneSendInfo({ obuSysID: res.obuid });
        if (res1) {
          if (res1.txType == '2') {
            // 先调后台14.21.换签表面号校验接口，
            // 将旧标签和新标签的表面号前3位判断，新旧标签的机型是否符合规则，符合规则则流程继续
            const oldPrintIdStartStr = this.oldOBUForm.printID.substring(0, 3);
            const newPrintIdStartStr = res1.printID.substring(0, 3);
            const resCheck = await checkSurfaceCode({
              oldPrintIdStartStr,
              newPrintIdStartStr,
            });
            if (!resCheck) {
              // 若接口返回失败
              // 提示“旧标签表面号前三位为***，只能更换表面号前三位为***的标签，请换一只新标签”
              this.$alert(
                '旧标签表面号前三位为' +
                  oldPrintIdStartStr +
                  '，只能更换表面号前三位为' +
                  resCheck.matchPrintIdStartStr.substring(0, 3) +
                  '的标签，请换一只新标签',
                '提示',
                {
                  confirmButtonText: '确定',
                  type: 'warning',
                }
              );
              return;
            } else {
              this.newOBUForm.txType = res1.txType;
              // this.newOBUForm.issueVersion = res1.issueVersion;
              this.newOBUForm.issueVersion = res.issueversion;
              this.newOBUForm.printID = res1.printID;
              this.newOBUForm.obuSysID = res.obuid;
              this.disabledReadOld = true;
              this.disabledReadNew = false;
            }
          } else {
            // txType!=2提示“该标签已发行过，请换一个新标签”
            this.$alert('该标签已发行过，请换一个新标签', '提示', {
              confirmButtonText: '确定',
              type: 'warning',
            });
            return;
          }
          //  else if (res1.txType == '3') {
          //   // txType=3提示“该卡已发行，不可更换”
          //   this.$alert('该标签已发行，不可更换', '提示', {
          //     confirmButtonText: '确定',
          //     type: 'warning',
          //   });
          //   return;
          // } else if (res1.txType == '4') {
          //   // txType=4提示“该卡已核销，不可更换”
          //   this.$alert('该标签已核销，不可更换', '提示', {
          //     confirmButtonText: '确定',
          //     type: 'warning',
          //   });
          //   return;
          // }
        } else {
          return;
        }
        // 若txType为2，调用14.5换签计费接口计算该笔业务费用，并在页面显示
        const res2 = await calculateObuReplacement({
          etcUserId: this.userInfo.etcUserId,
          vehicleNumber: this.vehicleInfo.vehicleNumber,
          vehicleColor: this.vehicleInfo.vehicleColor,
          newObuVersion: this.newOBUForm.issueVersion,
          oldObuVersion: this.oldOBUForm.issueVersion,
          newObuId: res.obuid,
          oldObuId: this.oldOBUForm.obuSysID,
          buyChannel: this.newOBUForm.txType === '5' ? '1' : '2', //1-自带 2-新购,
          freeEndDate: this.obuInfo.freeEndDate, // 旧卡片保修期截止日
          isDmage: this.oldOBUForm.destroy ? '2' : '1', //1-否,2-是
        });
        if (res2) {
          // 收费按钮状态变为可用
          this.disabledReadOld = true;
          this.disabledReadNew = true;
          this.disabledConfirmPrintId = true;
          if (this.oldIsDestroyed) {
            // 旧卡已核销，旧卡核销是在收费后面的，所以不需要再收费了
            this.disabledFee = true;
            this.disabledDistroyOld = true;
            this.disabledChangeNew = false;
            this.due = getFormatAmount(res2.price);
            this.oldDue = this.due;
          } else {
            // 旧卡可核销，需要收费
            this.price = res2.price;
            this.due = getFormatAmount(res2.price);
            this.oldDue = this.due;
            this.disabledFee = false;
          }
          // this.newPrice = getFormatAmount(res2.price);
          if (this.isChangeOBU) {
            this.newPrice = res2.price;
            this.initChangeOBU();
          }
        }
      };
      const res = readOBU(
        btnLoading,
        false,
        successFunc,
        this.readNewOBU,
        failObj
      );
    },
    // 收费
    async fee() {
      //TODO 支付方式后台获取还是写在前台?
      if (!this.payMode) {
        this.$alert('请选择支付方式', '提示', {
          confirmButtonText: '确定',
          type: 'warning',
        });
        return;
      }
      // 选择支付方式，点击收费按钮，调后台8.4.订单收费接口完成收费记账
      const applyType = await getDicCodeByDes(dicKeys.applyType, '换签');
      const orderType = await getDicCodeByDes(dicKeys.orderType, '售后订单');
      const res = await orderCharges({
        etcUserId: this.userInfo.etcUserId,
        workOrderId: this.workOrderID,
        vehicleNumber: this.vehicleInfo.vehicleNumber,
        vehicleColor: this.vehicleInfo.vehicleColor,
        orderType,
        applyType,
        price: getFormatAmountYuan2Fen(this.due),
        payMode: this.payMode,
        isFree: this.specialFree ? '1' : '0', // 0-	收费，1-	免费
      });
      if (res) {
        // 收费前实收是0，收费后实收就和应收一样
        this.receive = this.due;
        // 收费完成后，核验新卡按钮状态变为不可用，核销旧卡按钮变为可用
        this.disabledFee = true;
        this.disabledReadNew = true;
        this.disabledDistroyOld = false;
      }
    },
    // 确认凭证
    async toConfirm() {
      etcdev.writelog('换签-核销旧签-开始确认凭证');
      this.disabledDistroyOld = true;
      // 一些传值获取确认
      let userCertType = await getDicDesByCode(
        dicKeys.userCertType,
        this.userInfo.userCertType
      );
      let vehicleColor = await getDicDesByCode(
        dicKeys.vehicleColor,
        this.vehicleInfo.vehicleColor
      );
      let vehicleType = await getDicDesByCode(
        dicKeys.vehicleUserClass,
        this.vehicleInfo.vehicleType
      );
      if (vehicleType) {
        if (vehicleType === '0 - 普通客车/普通货车') {
          if (this.vehicleInfo.vehicleCategory == '1') {
            vehicleType = '0 - 普通客车';
          } else if (this.vehicleInfo.vehicleCategory == '') {
            vehicleType = '';
          } else {
            vehicleType = '0 - 普通货车';
          }
        }
      }
      console.log('this.vehicleInfo.vehicleType', this.vehicleInfo.vehicleType);
      console.log('vehicleType', vehicleType);
      let vehicleClass = await getDicDesByCode(
        dicKeys.vehicleClass,
        this.vehicleInfo.vehicleClass
      );
      // let cardType = await getDicDesByCode(
      //   dicKeys.cardType,
      //   this.cardInfo.cardType
      // );
      let obuStatus = await getDicDesByCode(
        dicKeys.obuStatus,
        this.obuInfo.obuStatus
      );
      this.voucherConfirmData = {
        businessType: '标签核销',
        userName: this.userInfo.userName,
        userCertType,
        userCode: this.userInfo.userCode,
        vehicleNumber: this.vehicleInfo.vehicleNumber,
        vehicleColor,
        vehicleType,
        vehicleClass,
        approvedAccount: this.vehicleInfo.approvedAccount,
        viTotalMass: this.vehicleInfo.viTotalMass,
        // cardType,
        obuId: this.obuInfo.obuID,
        obuStatus,
        obuFreeEndDate: this.obuInfo.freeEndDate,
      };
      this.voucherConfirmVisiable = true;
      etcdev.writelog('换签-核销旧签-终端显示确认凭证');
      this.$nextTick(() => {
        //执行调用手写板
        this.$refs.mychild1.sendpad();
        etcdev.writelog('换签-核销旧签-手写板显示确认凭证');
      });
    },
    // 核销旧卡（用户在手写板上确认或操作员代用户确认后）
    async writeOff(resUploadLayerPic) {
      etcdev.writelog('换签-核销旧签-开始核销旧签');
      try {
        this.disabledDistroyOld = true;
        this.clickNoLoading = true;
        this.loadingDistroyOld = true;
        // 调后台12.9.修改工单接口上传确认凭证
        // let imgFrontIDConfirm = '';
        if (resUploadLayerPic) {
          let imgFrontIDConfirm = resUploadLayerPic.frontImgid;
          // 保存凭证图片
          const mediaType = await getDicCodeByDes(
            dicKeys.mediaType,
            '业务凭证'
          );
          const imgType = await getDicCodeByDes(dicKeys.imgType, '业务凭证');
          const ImageInfoConfirm = {
            mediaType,
            imgType,
            imgFrontID: imgFrontIDConfirm,
          };
          const res0 = await updateWorkOrder({
            workOrderID: this.workOrderID,
            modifyInfo: { imagelist: [ImageInfoConfirm] },
          });
          etcdev.writelog('换签-核销旧签-修改工单');
        }
        if (this.isGood) {
          etcdev.writelog('好签，需要读签');
          // 好卡，需要读卡，改有效期
          // 再次读卡，确认读取到的卡号和第（1）步核验旧卡步骤中的卡号是否一致
          const self = this;
          const res = (function writeOffReadOBU() {
            let failObj = {
              msg: '读标签失败。<br>点[重试]按钮重试。',
              confirmButtonText: '重试',
              cancelButtonText: '取消',
              cancelCatch: async () => {
                return;
              },
            };
            let successFunc = (res) => {
              etcdev.writelog('读签成功');
              if (res.obuid != self.oldOBUForm.obuSysID) {
                etcdev.writelog('标签ID不一致，请确认旧标签');
                // 若不一致，提示“卡号不一致，请确认旧卡片“
                self
                  .$alert('标签ID不一致，请确认旧标签', '提示', {
                    confirmButtonText: '确定',
                    showClose: false,
                    type: 'warning',
                  })
                  .catch(() => {
                    return false;
                  });
                return false;
              } else {
                return true;
              }
            };
            const res = readOBU(
              self.loadingDistroyOld,
              false,
              successFunc,
              self.writeOff,
              failObj
            );
            return res;
          })();
          // 若核验卡号一致，且旧卡如果是好卡，需要改旧卡有效期。只要能读出来的，都要改有效期
          if (res) {
            etcdev.writelog(
              '核验标签号一致，暂时先改成旧签核销的时候不改有效期，直接核销，调用14.6.	换签业务申请接口'
            );
            // 换签改有效期的时候，出现ffff导致的无限loading的问题还没有解决，为了明天正常上线，暂时先改成旧签核销的时候不改有效期
            // 直接核销
            this.isValidity = '1';
            const resChange = await changeObu({
              etcUserId: this.userInfo.etcUserId,
              workOrderId: this.workOrderID,
              oldObuId: this.oldOBUForm.obuSysID,
              newObuId: this.newOBUForm.obuSysID,
              vehicleNumber: this.vehicleInfo.vehicleNumber,
              vehicleColor: this.vehicleInfo.vehicleColor,
              price: this.price,
              payMode: this.payMode,
              userName: this.userInfo.userName,
              userCode: this.userInfo.userCode,
              userCertType: this.userInfo.userCertType,
              deliveryMode: '2',
              buyChannel: this.newOBUForm.txType === '5' ? '1' : '2', //1-自带 2-新购
              freeEndDate: this.obuInfo.freeEndDate,
              isDmage: this.oldOBUForm.destroy ? '2' : '1',
              isBartender: this.oldOBUForm.expird ? '2' : '1',
              isValidity: this.isValidity, // 在坏卡/坏签的情况下，是不去改有效期的，此时传否
              newObuVersion: this.newOBUForm.issueVersion,
              oldObuVersion: this.oldOBUForm.issueVersion,
            });
            if (resChange) {
              etcdev.writelog('14.6.	换签业务申请接口返回不报错');
              if (resChange.exCode == '9001') {
                etcdev.writelog('14.6.	换签业务申请接口返回9001');
                // 如果14.3 换卡业务申请接口返回9001
                this.$confirm(
                  '代理人信息异常，正在完善分支机构，请稍等',
                  '提示',
                  {
                    confirmButtonText: '确定',
                    showCancelButton: false,
                    closeOnClickModal: false,
                    closeOnPressEscape: false,
                    showClose: false,
                    type: 'warning',
                  }
                )
                  .then(async () => {
                    etcdev.writelog(
                      '提示：代理人信息异常，正在完善分支机构，请稍等-点击确定'
                    );
                    this.improveBranch('mainChange');
                    // // 点击确定后调用后台4.12.完善分支机构接口，由系统自动进行完善处理
                    // const resPer = await perfectVehicleDepartment({
                    //   etcUserId: this.userInfo.etcUserId,
                    //   vehicleId: this.vehicleInfo.vehicleId,
                    // });
                    // if (resPer) {
                    //   if (resPer.exCode == '9002') {
                    //     // 如果4.12.完善分支机构接口返回9002，前端提示“该用户名下无有效默认分支机构，请新建”
                    //     this.$alert(
                    //       '该用户名下无有效默认分支机构，请新建',
                    //       '提示',
                    //       {
                    //         confirmButtonText: '确定',
                    //         showClose: false,
                    //         type: 'warning',
                    //       }
                    //     ).then(() => {
                    //       // 点击确定后自动弹出新建分支机构的页面，引导操作员完成新建分支机构
                    //       this.methodType = 'mainChange';
                    //       this.addvisble = true;
                    //     });
                    //   }
                    //   if (!resPer.exCode) {
                    //     console.log('完善分支机构没问题-!exCode');
                    //     this.mainChange();
                    //   }
                    // } else {
                    //   //接口异常
                    //   this.loadingDistroyOld = false;
                    //   this.disabledDistroyOld = false;
                    //   this.disabledChangeNew = true;
                    // }
                  })
                  .catch(() => {
                    etcdev.writelog(
                      '提示：代理人信息异常，正在完善分支机构，请稍等-点击取消'
                    );
                    // 暂停业务
                    this.loadingDistroyOld = false;
                    return;
                  });
              }
              if (!resChange.exCode) {
                etcdev.writelog(' 核销完成后更换新卡按钮变为可用');
                // 核销完成后更换新卡按钮变为可用。
                this.loadingDistroyOld = false;
                this.disabledDistroyOld = true;
                this.disabledChangeNew = false;
              }
            } else {
              etcdev.writelog('14.6.	换签业务申请接口返回报错');
              //接口异常
              this.loadingDistroyOld = false;
              this.disabledDistroyOld = false;
              this.disabledChangeNew = true;
            }
            // // 以下是【原代码】，正常流程
            // // 调后台9.3.有效期过期申请接口申请数据
            // const res1 = await changeValidityApply({
            //   vehicleNumber: this.vehicleInfo.vehicleNumber,
            //   vehicleColor: this.vehicleInfo.vehicleColor,
            //   obuId: res.obuid,
            //   obuVerNo: res.issueversion,
            //   // obuId: '0131002714297278',
            //   // obuVerNo: '00',
            // });
            // if (res1) {
            //   // 调客户端框架的2.6 卡二发接口，将卡片有效期改为已过期
            //   const resTry = await this.reTryIssueOBU(res, res1, 'writeOff');
            //   if (!this.isEmptyObj(resTry) && resTry.code == '0') {
            //     // if (true) {
            //     // 再调后台的9.4.有效期过期确认接口，完成修改有效期操作。
            //     const res3 = await changeValidityConfrim({
            //       vehicleNumber: this.vehicleInfo.vehicleNumber,
            //       vehicleColor: this.vehicleInfo.vehicleColor,
            //       obuId: res.obuid,
            //     });
            //     if (res3 && res3.result == '1') {
            //       // 前端继续调后台14.6 换签业务申请接口。
            //       this.isValidity = '2';
            //       const res2 = await changeObu({
            //         etcUserId: this.userInfo.etcUserId,
            //         workOrderId: this.workOrderID,
            //         oldObuId: this.oldOBUForm.obuSysID,
            //         newObuId: this.newOBUForm.obuSysID,
            //         vehicleNumber: this.vehicleInfo.vehicleNumber,
            //         vehicleColor: this.vehicleInfo.vehicleColor,
            //         price: this.price,
            //         payMode: this.payMode,
            //         userName: this.userInfo.userName,
            //         userCode: this.userInfo.userCode,
            //         userCertType: this.userInfo.userCertType,
            //         deliveryMode: '2',
            //         buyChannel: this.newOBUForm.txType === '5' ? '1' : '2', //1-自带 2-新购
            //         freeEndDate: this.obuInfo.freeEndDate,
            //         isDmage: this.oldOBUForm.destroy ? '2' : '1',
            //         isBartender: this.oldOBUForm.expird ? '2' : '1',
            //         isValidity: this.isValidity, // 改有效期成功了才去调换卡/换签接口，也就是这里始终是传‘2’
            //         newObuVersion: this.newOBUForm.issueVersion,
            //         oldObuVersion: this.oldOBUForm.issueVersion,
            //       });
            //       if (res2) {
            //         if (res2.exCode == '9001') {
            //           // 如果14.3 换卡业务申请接口返回9001
            //           this.$confirm(
            //             '代理人信息异常，正在完善分支机构，请稍等',
            //             '提示',
            //             {
            //               confirmButtonText: '确定',
            //               cancelButtonText: '取消',
            //               type: 'warning',
            //             }
            //           )
            //             .then(async () => {
            //               this.improveBranch('mainChange');
            //               // // 点击确定后调用后台4.12.完善分支机构接口，由系统自动进行完善处理
            //               // const resPer = await perfectVehicleDepartment({
            //               //   etcUserId: this.userInfo.etcUserId,
            //               //   vehicleId: this.vehicleInfo.vehicleId,
            //               // });
            //               // if (resPer) {
            //               //   if (resPer.exCode == '9002') {
            //               //     // 如果4.12.完善分支机构接口返回9002，前端提示“该用户名下无有效默认分支机构，请新建”
            //               //     this.$alert(
            //               //       '该用户名下无有效默认分支机构，请新建',
            //               //       '提示',
            //               //       {
            //               //         confirmButtonText: '确定',
            //               //         showClose: false,
            //               //         type: 'warning',
            //               //       }
            //               //     ).then(() => {
            //               //       // 点击确定后自动弹出新建分支机构的页面，引导操作员完成新建分支机构
            //               //       this.methodType = 'mainChange';
            //               //       this.addvisble = true;
            //               //     });
            //               //   }
            //               //   if (!resPer.exCode) {
            //               //     console.log('完善分支机构没问题-!exCode');
            //               //     this.mainChange();
            //               //   }
            //               // } else {
            //               //   //接口异常
            //               //   this.loadingDistroyOld = false;
            //               //   this.disabledDistroyOld = false;
            //               //   this.disabledChangeNew = true;
            //               // }
            //             })
            //             .catch(() => {
            //               // 暂停业务
            //               this.loadingDistroyOld = false;
            //               return;
            //             });
            //         }
            //         if (!res2.exCode) {
            //           // 核销完成后更换新卡按钮变为可用。
            //           this.loadingDistroyOld = false;
            //           this.disabledDistroyOld = true;
            //           this.disabledChangeNew = false;
            //         }
            //       } else {
            //         // 如果14.6 换签业务申请接口返回失败，且旧卡是好卡，则恢复卡片效期
            //         const resRenewal = await this.renewal(res);
            //         if (resRenewal) {
            //           this.loadingDistroyOld = false;
            //           this.disabledDistroyOld = false;
            //           this.disabledChangeNew = true;
            //         }
            //       }
            //     } else {
            //       //接口异常
            //       this.loadingDistroyOld = false;
            //       this.disabledDistroyOld = false;
            //       this.disabledChangeNew = true;
            //     }
            //   }
            // }
          } else {
            etcdev.writelog('标签ID不一致，请确认旧标签后可重新核销旧签');
            // 标签ID不一致，请确认旧标签后可重新核销旧签
            this.loadingDistroyOld = false;
            this.disabledDistroyOld = false;
          }
        } else {
          etcdev.writelog('坏标签');
          console.log('坏标签');
          // 坏卡，不需要读卡，不用改有效期。
          // （旧卡是坏卡的话，因为前端无法修改有效期，后台接口内部需要下黑名单。）
          etcdev.writelog('坏标签，调用14.6.	换签业务申请接口');
          this.isValidity = '1';
          const res4 = await changeObu({
            etcUserId: this.userInfo.etcUserId,
            workOrderId: this.workOrderID,
            oldObuId: this.oldOBUForm.obuSysID,
            newObuId: this.newOBUForm.obuSysID,
            vehicleNumber: this.vehicleInfo.vehicleNumber,
            vehicleColor: this.vehicleInfo.vehicleColor,
            price: this.price,
            payMode: this.payMode,
            userName: this.userInfo.userName,
            userCode: this.userInfo.userCode,
            userCertType: this.userInfo.userCertType,
            deliveryMode: '2',
            buyChannel: this.newOBUForm.txType === '5' ? '1' : '2', //1-自带 2-新购
            freeEndDate: this.obuInfo.freeEndDate,
            isDmage: this.oldOBUForm.destroy ? '2' : '1',
            isBartender: this.oldOBUForm.expird ? '2' : '1',
            isValidity: this.isValidity, // 在坏卡/坏签的情况下，是不去改有效期的，此时传否
            newObuVersion: this.newOBUForm.issueVersion,
            oldObuVersion: this.oldOBUForm.issueVersion,
          });
          if (res4) {
            etcdev.writelog('14.6.	换签业务申请接口返回不报错');
            if (res4.exCode == '9001') {
              etcdev.writelog('14.6.	换签业务申请接口返回9001');
              // 如果14.3 换卡业务申请接口返回9001
              this.$confirm(
                '代理人信息异常，正在完善分支机构，请稍等',
                '提示',
                {
                  confirmButtonText: '确定',
                  showCancelButton: false,
                  closeOnClickModal: false,
                  closeOnPressEscape: false,
                  showClose: false,
                  type: 'warning',
                }
              )
                .then(async () => {
                  etcdev.writelog(
                    '提示：代理人信息异常，正在完善分支机构，请稍等-点击确定'
                  );
                  this.improveBranch('badChange');
                  // // 点击确定后调用后台4.12.完善分支机构接口，由系统自动进行完善处理
                  // const resPer = await perfectVehicleDepartment({
                  //   etcUserId: this.userInfo.etcUserId,
                  //   vehicleId: this.vehicleInfo.vehicleId,
                  // });
                  // if (resPer) {
                  //   if (resPer.exCode == '9002') {
                  //     // 如果4.12.完善分支机构接口返回9002，前端提示“该用户名下无有效默认分支机构，请新建”
                  //     this.$alert(
                  //       '该用户名下无有效默认分支机构，请新建',
                  //       '提示',
                  //       {
                  //         confirmButtonText: '确定',
                  //         showClose: false,
                  //         type: 'warning',
                  //       }
                  //     ).then(() => {
                  //       // 点击确定后自动弹出新建分支机构的页面，引导操作员完成新建分支机构
                  //       this.methodType = 'badChange';
                  //       this.addvisble = true;
                  //     });
                  //   }
                  //   if (!resPer.exCode) {
                  //     console.log('完善分支机构没问题-!exCode');
                  //     this.badChange();
                  //   }
                  // } else {
                  //   //接口异常
                  //   this.loadingDistroyOld = false;
                  //   this.disabledDistroyOld = false;
                  //   this.disabledChangeNew = true;
                  // }
                })
                .catch(() => {
                  etcdev.writelog(
                    '提示：代理人信息异常，正在完善分支机构，请稍等-点击取消-暂停业务'
                  );
                  // 暂停业务
                  this.loadingDistroyOld = false;
                  return;
                });
            }
            if (!res4.exCode) {
              etcdev.writelog('核销完成后更换新签按钮变为可用。');
              // 核销完成后更换新卡按钮变为可用。
              this.loadingDistroyOld = false;
              this.disabledDistroyOld = true;
              this.disabledChangeNew = false;
            }
          } else {
            etcdev.writelog('坏标签，调用14.6.	换签业务申请接口报错');
            //接口异常
            this.loadingDistroyOld = false;
            this.disabledDistroyOld = false;
            this.disabledChangeNew = true;
          }
        }
      } catch (error) {
        etcdev.writelog(
          '坏标签，调用14.6.	换签业务申请接口异常，可能原因：超时'
        );
        console.log('核销旧签异常', error);
        this.loadingDistroyOld = false;
        this.disabledDistroyOld = false;
        this.disabledChangeNew = true;
      }
    },
    // 更换新卡
    changeNew() {
      let failObj = {
        msg: '读标签失败。<br>点[重试]按钮重试。',
        confirmButtonText: '重试',
        cancelButtonText: '取消',
        cancelCatch: () => {},
      };
      let btnLoading = this.loadingChangeNew;
      let successFunc = async (res) => {
        // 点击更换新卡按钮，若卡号和核验新卡时读取的卡号不一致
        // 再次调后台7.3.查询卡/OBU一发信息接口判断，该新卡属于自有卡还是新购卡片
        if (res.obuid != this.newOBUForm.obuSysID) {
          const res1 = await queryCardObuOneSendInfo({ obuSysID: res.obuid });
          // res1.txType = '5';
          if (res1.txType != this.newOBUForm.txType) {
            // 若此处新卡类型和核验新卡时的类型不一致，
            // 提示“本次换卡按照***收费，当前卡片为***，不能发行”（***替换成自有卡/新购卡片）
            const oldTxType = await getDicEasyDesByCode(
              dicKeys.newOBUType,
              this.newOBUForm.txType
            );
            const newTxType = await getDicEasyDesByCode(
              dicKeys.newOBUType,
              res1.txType
            );
            this.tip = `本次换签按照${oldTxType}收费，当前标签为${newTxType}，不能发行`;
          }
        } else {
          // 若一致，调后台9.1.设备空发/激活数据申请接口申请空发数据，
          const orderType = await getDicCodeByDes(
            dicKeys.orderType,
            '售后订单'
          );
          const msgType = await getDicCodeByDes(dicKeys.msgType, '空发申请');
          const res2 = await v1PreIssueApply({
            etcUserId: this.userInfo.etcUserId,
            workOrderID: this.workOrderID,
            orderType,
            vehicleNumber: this.vehicleInfo.vehicleNumber,
            vehicleColor: this.vehicleInfo.vehicleColor,
            msgType,
            obuId: this.newOBUForm.obuSysID,
            obuVerNo: this.newOBUForm.issueVersion,
            obuSign: '2',
          });
          if (res2) {
            // 然后调客户端框架2.6卡二发接口完成发行
            const resTry = await this.reTryIssueOBU(res, res2, 'changeNew');
            if (!this.isEmptyObj(resTry) && resTry.code == '0') {
              // 调2.6 卡二发接口成功
              // 再调后台9.2. 设备空发/激活确认接口完成空发确认
              const orderType = await getDicCodeByDes(
                dicKeys.orderType,
                '售后订单'
              );
              const msgType = await getDicCodeByDes(
                dicKeys.msgType,
                '空发申请'
              );
              const ensureRes = await v1PreIssueConfirm({
                etcUserId: this.userInfo.etcUserId,
                workOrderID: this.workOrderID,
                orderType,
                vehicleNumber: this.vehicleInfo.vehicleNumber,
                vehicleColor: this.vehicleInfo.vehicleColor,
                obuId: this.newOBUForm.obuSysID,
                msgType,
              });
              if (ensureRes) {
                if (ensureRes.result == '1') {
                  // 成功
                  this.$alert('换签成功', '提示', {
                    confirmButtonText: '确定',
                    showClose: false,
                    type: 'success',
                  }).then(async () => {
                    this.disabledChangeNew = true;
                    this.$router.push({
                      path: '/changeobu',
                      query: {
                        obuSysID: this.newOBUForm.obuSysID,
                        obuId: this.newOBUForm.printID,
                        step: 'changeobumain',
                        // rtn: 'changeobumain',
                        workOrderID: this.workOrderID,
                        cdif: this.cdif,
                        changeOBUData: this.changeOBUData,
                        isChangeOBU: this.isChangeOBU,
                        etcUserId: this.etcUserId,
                        newVehicleNumber: this.newVehicleNumber,
                        newVehicleColor: this.newVehicleColor,
                        specialfree: this.$route.query.specialfree,
                      },
                    });
                  });
                } else {
                  // 失败
                  this.$alert('更换新标签失败', '提示', {
                    confirmButtonText: '确定',
                    type: 'warning',
                  });
                }
              }
              this.loadingChangeNew = false;
            }
          }
        }
      };
      const res = readOBU(
        btnLoading,
        false,
        successFunc,
        this.changeNew,
        failObj
      );
    },
    async reTryIssueOBU(resOBU, resFile, methodType) {
      if (this.isEmptyObj(resFile.fileContentDFEF01)) {
        let fileContentDFEF01 = {};
        fileContentDFEF01.fileContent = '';
        fileContentDFEF01.startIndex = '0';
        fileContentDFEF01.length = '0';
        resFile.fileContentDFEF01 = fileContentDFEF01;
      }
      const issueOBURes = await issueOBU(resOBU, resFile);
      this.timer = setTimeout(() => {
        console.log('定时器-issueOBURes', issueOBURes);
        // if (!issueOBURes) {
        this.loadingDistroyOld = false;
        this.loadingChangeNew = false;
        // this.disabledDistroyOld = true;
        // this.disabledChangeNew = false;
        //   this.$alert('标签发行失败，请重试', '提示', {
        //     confirmButtonText: '确定',
        //     type: 'warning',
        //   });
        return;
        // }
      }, 20000);
      // clearTimeout(timer);
      console.log('issueOBURes', issueOBURes);
      if (!issueOBURes || issueOBURes.code != '0') {
        // if (true) {
        await this.$confirm(
          '调标签发行接口失败，是否重试？提示信息：' +
            (issueOBURes && issueOBURes.msg),
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
        )
          .then(() => {
            if (methodType === 'renewal') {
              this.renewal(resOBU);
              this.loadingDistroyOld = true;
            } else {
              if (methodType === 'writeOff') {
                this.loadingDistroyOld = true;
              } else if (methodType === 'changeNew') {
                this.loadingChangeNew = true;
              }
              this.reTryIssueOBU(resOBU, resFile, methodType);
            }
            // return 'loading';
          })
          .catch(async (err) => {
            if (methodType === 'writeOff') {
              // 这里给操作员是否重试的选项，
              // 操作员选择否，就不改有效期了，调换卡业务申请接口，改有效期标志传否
              this.isValidity = '1';
              const resChange = await await changeObu({
                etcUserId: this.userInfo.etcUserId,
                workOrderId: this.workOrderID,
                oldObuId: this.oldOBUForm.obuSysID,
                newObuId: this.newOBUForm.obuSysID,
                vehicleNumber: this.vehicleInfo.vehicleNumber,
                vehicleColor: this.vehicleInfo.vehicleColor,
                price: this.price,
                payMode: this.payMode,
                userName: this.userInfo.userName,
                userCode: this.userInfo.userCode,
                userCertType: this.userInfo.userCertType,
                deliveryMode: '2',
                buyChannel: this.newOBUForm.txType === '5' ? '1' : '2', //1-自带 2-新购
                freeEndDate: this.obuInfo.freeEndDate,
                isDmage: this.oldOBUForm.destroy ? '2' : '1',
                isBartender: this.oldOBUForm.expird ? '2' : '1',
                isValidity: this.isValidity, // 改有效期标志传否
                newObuVersion: this.newOBUForm.issueVersion,
                oldObuVersion: this.oldOBUForm.issueVersion,
              });
              if (resChange) {
                if (resChange.exCode == '9001') {
                  // 如果14.3 换卡业务申请接口返回9001
                  this.$confirm(
                    '代理人信息异常，正在完善分支机构，请稍等',
                    '提示',
                    {
                      confirmButtonText: '确定',
                      showCancelButton: false,
                      closeOnClickModal: false,
                      closeOnPressEscape: false,
                      showClose: false,
                      type: 'warning',
                    }
                  )
                    .then(async () => {
                      this.improveBranch('retryCancelChange');
                      // // 点击确定后调用后台4.12.完善分支机构接口，由系统自动进行完善处理
                      // const resPer = await perfectVehicleDepartment({
                      //   etcUserId: this.userInfo.etcUserId,
                      //   vehicleId: this.vehicleInfo.vehicleId,
                      // });
                      // if (resPer) {
                      //   if (resPer.exCode == '9002') {
                      //     // 如果4.12.完善分支机构接口返回9002，前端提示“该用户名下无有效默认分支机构，请新建”
                      //     this.$alert(
                      //       '该用户名下无有效默认分支机构，请新建',
                      //       '提示',
                      //       {
                      //         confirmButtonText: '确定',
                      //         showClose: false,
                      //         type: 'warning',
                      //       }
                      //     ).then(() => {
                      //       // 点击确定后自动弹出新建分支机构的页面，引导操作员完成新建分支机构
                      //       this.methodType = 'retryCancelChange';
                      //       this.addvisble = true;
                      //     });
                      //   }
                      //   if (!resPer.exCode) {
                      //     console.log('完善分支机构没问题-!exCode');
                      //     this.retryCancelChange();
                      //   }
                      // } else {
                      //   //接口异常
                      //   this.loadingDistroyOld = false;
                      //   this.disabledDistroyOld = false;
                      //   this.disabledChangeNew = true;
                      // }
                    })
                    .catch(() => {
                      // 暂停业务
                      this.loadingDistroyOld = false;
                      return;
                    });
                }
                if (!resChange.exCode) {
                  // 核销完成后更换新卡按钮变为可用。
                  this.loadingDistroyOld = false;
                  this.disabledDistroyOld = true;
                  this.disabledChangeNew = false;
                }
              } else {
                // 接口异常
                this.loadingDistroyOld = false;
                this.disabledDistroyOld = false;
                this.disabledChangeNew = true;
              }
            } else if (methodType === 'renewal') {
              // 操作员在是否重试写设备的时候，
              // 操作员选择否
              this.loadingDistroyOld = false;
              this.disabledDistroyOld = false;
              this.disabledChangeNew = true;
            } else if (methodType === 'changeNew') {
              // 操作员在是否重试写设备的时候，
              // 操作员选择否
              this.loadingChangeNew = false;
              this.disabledDistroyOld = true;
              this.disabledChangeNew = false;
            }
            // return false;
            // return err;
          });
      } else {
        return issueOBURes;
      }
    },
    // 有效期续期
    async renewal(resOBU) {
      // 依次调后台9.5.有效期续期申请
      const resCardExpiryDate = await renewalValidity({
        vehicleNumber: this.vehicleInfo.vehicleNumber,
        vehicleColor: this.vehicleInfo.vehicleColor,
        obuId: resOBU.obuid,
        obuVerNo: resOBU.issueversion,
      });
      // let fileContentDFEF01 = {};
      // fileContentDFEF01.fileContent = '';
      // fileContentDFEF01.startIndex = '0';
      // fileContentDFEF01.length = '0';
      // resCardExpiryDate.fileContentDFEF01 = fileContentDFEF01;
      if (resCardExpiryDate) {
        // 客户端框架的2.6 卡二发
        const resTry = await this.reTryIssueOBU(
          resOBU,
          resCardExpiryDate,
          'renewal'
        );
        // console.log('resTryresTryresTry', resTry);
        if (!this.isEmptyObj(resTry) && resTry.code == '0') {
          // 调2.6 卡二发接口成功
          // 和后台的9.6.有效期续期确认接口,将旧卡恢复有效期
          const res4 = await changeValidityRenewalConfrim({
            vehicleNumber: this.vehicleInfo.vehicleNumber,
            vehicleColor: this.vehicleInfo.vehicleColor,
            obuId: resOBU.obuid,
          });
          if (res4 && res4.result === '1') {
            this.$alert('旧标签核销失败，标签已恢复有效期', '提示', {
              confirmButtonText: '确定',
              type: 'warning',
            });
          }
          return true;
        }
      } else {
        return true;
      }
    },
    async initChangeOBU() {
      // 初始化继续办理换签数据
      if (this.changeOBUData.workOrderInfo.isCharge === '1') {
        console.log('加载继续办理换签数据');
        this.disabledFee = true;
        this.isUsePayMode = true;
        this.payFlag = this.$route.query.payFlag;
        this.isFree = this.$route.query.isFree;
        if (this.isFree == '1') {
          // 是特许免费
          this.specialFree = true;
        } else {
          this.specialFree = false;
        }
        this.payMode = this.payMode;
        this.oprice = this.$route.query.price;
        this.receive = this.oprice;
        console.log('price:', this.oprice);
        // 实收显示工单费用
        this.receive = getFormatAmount(this.oprice);
        // 应收显示计算费用
        if (this.specialFree) {
          this.due = '0.00'; // 特许免费，不管计费接口计算出来是多少，特许免费勾选后，应收都是0元
        } else {
          this.due = getFormatAmount(this.newPrice);
        }
        // if (this.newPrice.toString() !== this.oprice.toString()) {
        if (this.due != this.receive && !this.specialFree) {
          // 同时不是特许免费时
          this.disabledChangeNew = true;
          const tiptext =
            '本次换签按照' +
            this.due +
            '元收费，当前标签需收费' +
            this.receive +
            '元，不能发行';
          this.$confirm(tiptext, '提示', {
            confirmButtonText: '返回上级',
            cancelButtonText: '继续操作',
            type: 'warning',
            showClose: false,
          })
            .then(async () => {
              // 返回上级
              console.log('跳转抽屉页面');
              this.$router.push({
                path: '/changeobu',
                query: {
                  isChangeOBU: this.isChangeOBU,
                  workOrderID: this.workOrderID,
                  payFlag: this.payFlag,
                  price: this.oprice,
                  payMode: this.payMode,
                  changeOBUData: this.changeOBUData,
                  cdif: this.cdif,
                  etcUserId: this.etcUserId,
                  newVehicleNumber: this.newVehicleNumber,
                  newVehicleColor: this.newVehicleColor,
                },
              });
            })
            .catch(() => {
              // 继续操作
              this.newOBUForm.obuSysID = '';
              this.newOBUForm.txType = '';
              this.newOBUForm.issueVersion = '';
              this.disabledReadNew = false;
              this.due = '0.00';
              this.receive = '0.00';
            });
        } else {
          // 旧卡是否已核销
          if (this.changeOBUData.oldObuInfo.status === '2') {
            this.disabledDistroyOld = true;
            this.disabledChangeNew = false;
          } else {
            this.disabledDistroyOld = false;
            this.disabledChangeNew = true;
          }
        }
        // 旧卡是否已核销
        // if (this.changeOBUData.oldObuInfo.status === '2') {
        //   this.disabledDistroyOld = true;
        //   this.disabledChangeNew = false;
        // } else {
        //   this.disabledDistroyOld = false;
        //   this.disabledChangeNew = true;
        // }
      }
    },
  },
  async mounted() {
    // if (this.isEmptyObj(this.userInfo)) {
    //   this.$message.error('无法获取用户信息');
    // } else {
    // }
    if (!this.$route.query.workOrderID) {
      this.$message.error('不存在该工单号');
    } else {
      this.workOrderID = this.$route.query.workOrderID;
    }
    this.hasSpecialFreeAuth = this.$route.query.specialfree; // 特许免费是否有权限
    // this.hasSpecialFreeAuth = false; // 特许免费是否有权限
    console.log('hasSpecialFreeAuth', this.hasSpecialFreeAuth);
    // 继续办理换签初始化
    this.changeOBUData = this.$route.query.changeOBUData;
    this.payFlag = this.$route.query.payFlag;
    this.payMode = this.$route.query.payMode;
    this.payMode = '1';
    this.oprice = this.$route.query.price;
    this.cdif = this.$route.query.cdif;
    this.isChangeOBU = this.$route.query.isChangeOBU;
    this.etcUserId = this.$route.query.etcUserId;
    this.newVehicleNumber = this.$route.query.newVehicleNumber;
    this.newVehicleColor = this.$route.query.newVehicleColor;
  },
  destroyed() {
    clearTimeout(this.timer);
  },
};
</script>