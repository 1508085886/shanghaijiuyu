<!-- 补签 -->
<template>
  <div class="offline-obureplacement">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-obureplacementindex_title">补签（证件上传）</h4>
      </div>
    </div>
    <template v-if="userUploadShow">
      <div class="offline-obureplacementdocupload_subtitle mt23">用户证件</div>
      <div class="o-flex">
        <photograph-block
          @complete="userPhotosComplete"
          width="104"
          height="104"
          type="userCertType"
          :defaultPics="imageInfoUser"
          :picsMaxLength="2"
          :append-to-body="true"
          :no-edit="view"
          class="mt12"
        ></photograph-block>
      </div>
    </template>
    <template v-if="agentUploadShow">
      <div class="offline-obureplacementdocupload_subtitle mt23">
        上传经办人证件
      </div>
      <div class="o-flex">
        <photograph-block
          @complete="agentPhotosComplete"
          width="104"
          height="104"
          type="agentCertType"
          :defaultPics="imageInfoAgent"
          :picsMaxLength="2"
          :append-to-body="true"
          :no-edit="view"
          class="mt12"
        ></photograph-block>
      </div>
    </template>
    <template v-if="otherUploadShow">
      <div class="offline-obureplacementdocupload_subtitle">
        上传其他证件资料
      </div>
      <div class="o-flex">
        <photograph-block
          @complete="otherPhotosComplete"
          width="104"
          height="104"
          type="agentCertType"
          :defaultPics="imageInfoOther"
          :append-to-body="true"
          :no-edit="view"
          class="mt12"
        ></photograph-block>
      </div>
    </template>
    <div class="o-flex offline-obureplacementdocupload_rtn-button-wrap">
      <loading-button
        type="primary"
        class="offline-obureplacementdocupload_rtn-button"
        @click="view ? back() : submit()"
        >确定
      </loading-button>
    </div>
  </div>
</template>
<script>
import { createOrderv, updateWorkOrder, startTblWork } from '@/api/common';
import PhotographBlock from '@/components/PhotographBlock';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';
import { orderImg } from '@/api/order';
export default {
  data() {
    return {
      step: '',
      imageInfoUser: [],
      imageInfoAgent: [],
      imageInfoOther: [],
      userUploadShow: false,
      agentUploadShow: false,
      otherUploadShow: false,
      isCompany: false,
      workOrderID: '', // 工单号
      cdif: '',
      isContinue: '',
      changeOBUData: '',
      payFlag: '',
      price: '',
      payMode: '',
      etcUserId: '',
      newVehicleNumber: '',
      newVehicleColor: '',
    };
  },
  components: {
    PhotographBlock,
  },
  computed: {
    vehicleInfo() {
      return this.$store.getters.searchCarInfo;
    },
    obuInfo() {
      return this.$store.getters.searchObuInfo;
    },
    cardInfo() {
      return this.$store.getters.searchCardInfo;
    },
    userInfo() {
      return this.$store.getters.searchUserInfo;
    },
    accountInfo() {
      return this.$store.getters.searchAccountInfo;
    },
    departmentInfo() {
      return this.$store.getters.searchDepartmentInfo;
    },
    view() {
      return !!this.$route.query.view;
    },
  },
  methods: {
    userPhotosComplete(imgs) {
      this.imageInfoUser = imgs;
    },
    agentPhotosComplete(imgs) {
      this.imageInfoAgent = imgs;
      // console.log('imgs', this.imageInfoAgent);
    },
    otherPhotosComplete(imgs) {
      this.imageInfoOther = imgs;
    },
    // 编辑状态，点击【确定】即提交
    async submit() {
      if (!this.isCompany && !this.imageInfoUser.length) {
        this.$alert('请上传用户证件', '提示', {
          confirmButtonText: '确定',
          type: 'warning',
        });
        return;
      }
      if (this.isCompany && !this.imageInfoAgent.length) {
        this.$alert('请上传经办人证件', '提示', {
          confirmButtonText: '确定',
          type: 'warning',
        });
        return;
      }
      // 照片数据保存在idb
      // this.$store.dispatch('idbChangeObu/ClearAgentImg');
      this.$store.dispatch('idbCardReplacement/GetUserImg', this.imageInfoUser);
      this.$store.dispatch(
        'idbCardReplacement/GetAgentImg',
        this.imageInfoAgent
      );
      this.$store.dispatch(
        'idbCardReplacement/GetOtherImg',
        this.imageInfoOther
      );
      // 上传的图片，自动保存到主页的证件上传区域。
      this.$store.dispatch('ClearSearchAgentImg');
      this.$store.dispatch('ClearSearchUserImg');
      this.$store.dispatch('ClearSearchOtherImg');
      this.$store.dispatch('GetSearchUserImg', this.imageInfoUser);
      this.$store.dispatch('GetSearchAgentImg', this.imageInfoAgent);
      this.$store.dispatch('GetSearchOtherImg', this.imageInfoOther);

      // // 首先调后台12.13.创建工单接口，此时工单状态为0-预处理。
      const bizCode = await getDicCodeByDes(dicKeys.bizCode, '补签');
      const res0 = await createOrderv({
        bizCode,
        oldUserId: this.userInfo.userID,
        oldUserAcctId: this.accountInfo.userAcctId,
        oldDepartmentName: this.departmentInfo.department,
        oldBuyId: this.accountInfo.signOrderNo,
        oldVehicleId: this.vehicleInfo.vehicleId,
        oldVehicleNumber: this.vehicleInfo.vehicleNumber,
        oldVehicleColor: this.vehicleInfo.vehicleColor,
        oldCardId: this.cardInfo.cardID,
        oldObuysId: this.obuInfo.printID,
        oldObuId: this.obuInfo.obuID,
        oldEtcUserId: this.userInfo.etcUserId,
        oldUsername: this.userInfo.userName,
        oldPayChannelName: this.accountInfo.paychannelName,
        oldSubPayChannelName: this.accountInfo.subPaychannelName,
      }); // TODO 缺少bizCode
      if (res0) {
        // 然后调后台12.9.修改工单接口将上传的图片id和工单进行绑定，绑定时后台接口自动将工单状态变更为1-进行中
        // let allImgs = [...this.imageInfoAgent, ...this.imageInfoOther];
        // let imagelist = [];
        // allImgs.forEach((pic) => {
        //   imagelist.push({
        //     imgFrontID: pic.frontImgid,
        //     imgType: '1011',
        //     mediaType: '4',
        //   });
        // });
        // 改为经办人证件上传代码为4/1011，其他证件上传代码为10/8011
        let imagelist = [];
        this.imageInfoUser.forEach((pic) => {
          console.log('imageInfoUser:', pic.type);
          imagelist.push({
            imgFrontID: pic.frontImgid,
            imgType: pic.type.replace('-', ''),
            mediaType: '4',
          });
        });
        this.imageInfoAgent.forEach((pic) => {
          imagelist.push({
            imgFrontID: pic.frontImgid,
            imgType: '1011',
            mediaType: '4',
          });
        });
        this.imageInfoOther.forEach((pic) => {
          imagelist.push({
            imgFrontID: pic.frontImgid,
            imgType: '8011',
            mediaType: '10',
          });
        });
        this.workOrderID = res0.workOrderID;
        const resStartWork = await startTblWork({
          workOrderId: this.workOrderID,
        });
        if (resStartWork) {
          const res2 = await updateWorkOrder({
            workOrderID: this.workOrderID,
            modifyInfo: { imagelist },
          });
          if (res2) {
            this.$router.push({
              path: '/obuReplacement',
              query: {
                rtn: 'docupload',
                step: this.step,
                cardId: this.cardId,
                workOrderID: this.workOrderID,
                specialfree: this.$route.query.specialfree,
              },
            });
          }
        }
      }
    },
    // 查看状态，点击【确定】即返回
    back() {
      this.$router.push({
        path: '/obuReplacement',
        query: {
          rtn: 'docupload',
          step: this.step,
          cardId: this.cardId,
          workOrderID: this.workOrderID,
          cdif: this.cdif,
          isContinue: this.isContinue,
          payFlag: this.payFlag,
          payMode: this.payMode,
          price: this.price,
          changeOBUData: this.changeOBUData,
          etcUserId: this.etcUserId,
          newVehicleNumber: this.newVehicleNumber,
          newVehicleColor: this.newVehicleColor,
          specialfree: this.$route.query.specialfree,
        },
      });
    },
  },
  async mounted() {
    if (this.isEmptyObj(this.userInfo)) {
      this.$message.error('无法获取用户信息');
    } else {
      this.step = this.$route.query.step;
      this.cardId = this.$route.query.cardId;
      this.workOrderID = this.$route.query.workOrderID;
      this.cdif = this.$route.query.cdif;
      this.isContinue = this.$route.query.isContinue;
      this.changeOBUData = this.$route.query.changeOBUData;
      this.price = this.$route.query.price;
      this.payFlag = this.$route.query.payFlag;
      this.payMode = this.$route.query.payMode;
      this.etcUserId = this.$route.query.etcUserId;
      this.newVehicleNumber = this.$route.query.newVehicleNumber;
      this.newVehicleColor = this.$route.query.newVehicleColor;
      if (this.$route.query.view) {
        // 工单号存在，是通过‘已完成’进来的
        this.imageInfoUser = this.$store.getters.obuReplacementUserImg;
        this.imageInfoOther = this.$store.getters.obuReplacementOtherImg;
        this.imageInfoAgent = this.$store.getters.obuReplacementAgentImg;
        // 调用工单图片查询接口
        const res = await orderImg({
          workOrderID: this.workOrderID,
        });
        const imgInfoList = res.imageList;
        // console.log('imglist:' + imgInfoList[0].mediaType);
        if (imgInfoList) {
          let imageUList = [];
          let imageAlist = [];
          let imageOList = [];
          imgInfoList.forEach((pic) => {
            let imgeUserStr = {
              frontImgid: '',
              ocr: '',
              type: '',
              url: '',
            };
            let imgeAgentStr = {
              frontImgid: '',
              ocr: '',
              type: '',
              url: '',
            };
            let imgeOtherStr = {
              frontImgid: '',
              ocr: '',
              type: '',
              url: '',
            };
            // console.log("pic.mediaType:" + pic.mediaType);
            // console.log("pic.eVoucherType:" + pic.eVoucherType);
            if (pic.eVoucherType === '4') {
              imgeAgentStr.url = 'data:image/png;base64,' + pic.imageInfo;
              imageAlist.push(imgeAgentStr);
            } else if (pic.eVoucherType !== '5') {
              imgeOtherStr.url = 'data:image/png;base64,' + pic.imageInfo;
              imageOList.push(imgeOtherStr);
            } else if (pic.eVoucherType === '1') {
              imgeUserStr.url = 'data:image/png;base64,' + pic.imageInfo;
              imageUList.push(imgeUserStr);
            }
          });
          console.log('imageAlist:', imageAlist);
          console.log('imageOList:', imageOList);
          this.imageInfoAgent = imageAlist;
          this.imageInfoOther = imageOList;
          this.imageInfoUser = imageUList;
        }
      } else {
        // 工单号不存在，是从主页进来的，办理新业务
        this.$store.dispatch('idbObuReplacement/ClearUserImg');
        this.$store.dispatch('idbObuReplacement/ClearAgentImg');
        this.$store.dispatch('idbObuReplacement/ClearOtherImg');
        this.imageInfoUser = [];
        this.imageInfoOther = [];
        this.imageInfoAgent = [];

        // 加载主页上传的用户证件图片
        let userImgs = JSON.parse(
          JSON.stringify(this.$store.getters.searchUserImg)
        );
        this.$store.dispatch('idbObuReplacement/GetUserImg', userImgs);
        this.imageInfoUser = userImgs;
        // 加载主页上传的经办人证件图片
        let agentImgs = JSON.parse(
          JSON.stringify(this.$store.getters.searchAgentImg)
        );
        this.$store.dispatch('idbObuReplacement/GetAgentImg', agentImgs);
        this.imageInfoAgent = agentImgs;
        // 加载主页上传的其他证件图片
        let otherImgs = JSON.parse(
          JSON.stringify(this.$store.getters.searchOtherImg)
        );
        this.$store.dispatch('idbObuReplacement/GetOtherImg', otherImgs);
        this.imageInfoOther = otherImgs;
      }
      const person = await getDicCodeByDes(dicKeys.userType, '个人');
      const company = await getDicCodeByDes(dicKeys.userType, '单位');
      if (this.userInfo.userProperty == person) {
        // 对私用户，可上传的证件类型为其他证件资料
        this.isCompany = false;
      } else if (this.userInfo.userProperty == company) {
        // 对公用户，可上传的证件类型为经办人证件和其他证件资料
      }
      this.userUploadShow = true;
      this.agentUploadShow = true;
      this.otherUploadShow = true;
    }
  },
};
</script>