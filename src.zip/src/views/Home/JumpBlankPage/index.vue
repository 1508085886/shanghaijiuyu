<!-- 跳转空白页 -->
<template>
  <div class="offline-changecardindex"></div>
</template>
<script>
import VoucherLayer from '@/components/VoucherLayer';
import Drawer from '@/components/Drawer';
import { updateWorkOrder, systemTime, addBranch } from '@/api/common';
import showQrcode from '@/utils/qrcode';
import { globalBus } from '@/utils/globalBus';

export default {
  data() {
    return {
      query: {},
      continueType: '',
      isChangeCard: '',
      isChangeOBU: '',
      workOrderID: '',
      payFlag: '',
      price: '',
      payMode: '',
      cdif: '',
      etcUserId: '',
      newVehicleNumber: '',
      newVehicleColor: '',
    };
  },
  methods: {
    jumpToPage() {
      if (this.isChangeCard) {
        let newQuery = { isChangeCard: true };
        console.log('this.query', this.query);
        // 跳转换卡页面
        this.$router.push({
          path: '/changecard',
          // query: {
          //   isChangeCard: true,
          //   workOrderID: this.workOrderID,
          //   payFlag: this.payFlag,
          //   price: this.price,
          //   payMode: this.payMode,
          //   cdif: this.cdif,
          //   etcUserId: this.etcUserId,
          //   newVehicleNumber: this.newVehicleNumber,
          //   newVehicleColor: this.newVehicleColor,
          // },
          query: { ...newQuery, ...this.query },
        });
      } else if (this.isChangeOBU) {
        let newQuery = { isChangeOBU: true };
        // 跳转换签页面
        this.$router.push({
          path: '/changeobu',
          query: { ...newQuery, ...this.query },
          // query: {
          //   isChangeOBU: true,
          //   workOrderID: this.workOrderID,
          //   payFlag: this.payFlag,
          //   price: this.price,
          //   payMode: this.payMode,
          //   cdif: this.cdif,
          //   etcUserId: this.etcUserId,
          //   newVehicleNumber: this.newVehicleNumber,
          //   newVehicleColor: this.newVehicleColor,
          // },
        });
      } else if (this.continueType) {
        let newQuery = { isContinue: true };
        // 跳转其他售后业务页面
        this.$router.push({
          path: '/' + this.continueType,
          query: { ...newQuery, ...this.query },
          // query: {
          //   isContinue: true,
          //   workOrderID: this.workOrderID,
          //   payFlag: this.payFlag,
          //   price: this.price,
          //   payMode: this.payMode,
          //   cdif: this.cdif,
          //   etcUserId: this.etcUserId,
          //   newVehicleNumber: this.newVehicleNumber,
          //   newVehicleColor: this.newVehicleColor,
          // },
        });
      } else {
        // 跳转到 车辆信息变更 继续办理
        this.continuePageForVehi();
      }
    },

    continuePageForVehi() {
      let queryData = this.$route.query;
      this.$router.push({
        path: '/convehiclechange',
        query: {
          ...queryData,
        },
      });
    },
  },
  mounted() {
    this.continueType = this.$route.query.continueType;
    this.isChangeCard = this.$route.query.isChangeCard;
    this.isChangeOBU = this.$route.query.isChangeOBU;
    this.workOrderID = this.$route.query.workOrderID;
    this.payFlag = this.$route.query.payFlag;
    this.price = this.$route.query.price;
    this.payMode = this.$route.query.payMode;
    this.cdif = this.$route.query.cdif;
    this.etcUserId = this.$route.query.etcUserId;
    this.newVehicleNumber = this.$route.query.newVehicleNumber;
    this.newVehicleColor = this.$route.query.newVehicleColor;
    // query
    this.query = this.$route.query;
    console.log('isChangeCard:', this.isChangeCard);
    // 判断跳转页面
    this.jumpToPage();
  },
};
</script>
