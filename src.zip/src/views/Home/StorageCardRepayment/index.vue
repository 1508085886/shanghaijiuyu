<!-- 首页 -->
<template>
    <div class="offline-storagecardrepayment">
        <div class="clearfix">
            <div class="fl">
                <h4 class="offline-storagecardrepayment_title">储值卡挂账还款</h4>
            </div>
        </div>
        <div class="offline-storagecardrepayment_block">
            <el-form ref="repaymentForm1" :model="repaymentForm" class="offline-storagecardrepayment_block-form">
                <div class="offline-storagecardrepayment_block-readcard-centent">
                    <el-col :xl="12" :lg="12" :md="12">
                        <el-row>
                            <el-form-item prop="userAcctId" ref="userAcctId">
                                <el-col :xl="7" :lg="7" :md="7">账户编号：</el-col>
                                <el-col :xl="17" :lg="17" :md="17">{{
                                    repaymentForm.userAcctId
                                    }}</el-col>
                            </el-form-item>
                        </el-row>
                        <el-row>
                            <el-form-item prop="accountType" ref="accountType">
                                <el-col :xl="7" :lg="7" :md="7">账户类型：</el-col>
                                <el-col :xl="17" :lg="17" :md="17">{{
                                    repaymentForm.accountType
                                    }}</el-col>
                            </el-form-item>
                        </el-row>
                        <el-row>
                            <el-form-item prop="accountStatus" ref="accountStatus">
                                <el-col :xl="7" :lg="7" :md="7">账户状态：</el-col>
                                <el-col :xl="17" :lg="17" :md="17"></el-col>
                                {{ repaymentForm.accountStatus }}
                            </el-form-item>
                        </el-row>
                    </el-col>
                    <el-col :xl="12" :lg="12" :md="12">
                        <el-row>
                            <el-form-item prop="acctBalance" ref="acctBalance">
                                <el-col :xl="8" :lg="8" :md="8">账户余额：</el-col>
                                <el-col :xl="16" :lg="16" :md="16">{{
                                    repaymentForm.acctBalance
                                    }}</el-col>
                            </el-form-item>
                        </el-row>
                        <el-row>
                            <el-form-item prop="subAcctBalance" ref="subAcctBalance">
                                <el-col :xl="8" :lg="8" :md="8">圈存账户余额：</el-col>
                                <el-col :xl="16" :lg="16" :md="16">{{
                                    repaymentForm.subAcctBalance
                                    }}</el-col>
                            </el-form-item>
                        </el-row>
                        <el-row>
                            <el-form-item prop="creditfee" ref="creditfee">
                                <el-col :xl="8" :lg="8" :md="8">挂账金额：</el-col>
                                <el-col :xl="16" :lg="16" :md="16">{{
                                    repaymentForm.creditfee
                                    }}</el-col>
                            </el-form-item>
                        </el-row>
                    </el-col>
                </div>
            </el-form>
        </div>
        <div class="offline-storagecardrepayment_detail">
            <h4 class="offline-storagecardrepayment_title2">挂账明细</h4>
        </div>
        <div class="offline-storagecardrepayment_form">
            <el-table :data="tables" tooltip-effect="dark" style="width: auto;"
                :header-cell-style="{'background-color': '#D3D6DF',}">
                <el-table-column label="清算时间" prop="obutxDate">
                </el-table-column>
                <el-table-column label="接收时间" prop="systemDate">
                </el-table-column>
                <el-table-column label="车牌" prop="vehicleNumber">
                </el-table-column>
                <el-table-column label="车牌颜色" prop="vehicleColor">
                </el-table-column>
                <el-table-column label="卡号" prop="cardId">
                </el-table-column>
                <el-table-column label="OBU号码" prop="obuId">
                </el-table-column>
                <el-table-column label="交易金额" prop="fee">
                </el-table-column>
                <el-table-column label="卡面扣费金额" prop="transfee">
                </el-table-column>
                <el-table-column label="入口车道编号" prop="entolllaneid">
                </el-table-column>
                <el-table-column label="入口时间" prop="entime">
                </el-table-column>
                <el-table-column label="入口站名称" prop="entollstationname">
                </el-table-column>
            </el-table>
            <div style="background:#D3D6DF;height: 50px" class="clearfix  offline-storagecardrepayment_pagination">
                <div class="fl offline-useraccList_tableblock-pagination-desc " v-if="total">
                    第{{ startRecords }}到{{ currentSize }}条，
                </div>
                <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange"
                    :current-page.sync="currentPage" :page-size="pageSize" layout="total,->,prev, pager, next,slot"
                    :total="total">
                </el-pagination>
            </div>
        </div>

        <div class="offline-storagecardrepayment_feeblock">
            <el-row :gutter="10">
                <el-col :span="8">
                    <div class="offline-storagecardrepayment_feeblock-due">
                        <div class="offline-storagecardrepayment_feeblock-desc ">
                            还款金额（元）
                        </div>
                        <div class="offline-storagecardrepayment_feeblock-amount">
                            {{repaymentForm.creditfee}}
                        </div>
                    </div>
                </el-col>
                <el-col :span="8">
                    <div class=" o-flex o-flex-align-baseline offline-cardreplacementmain_feeblock-paymode">
                        <div class="offline-storagecardrepayment_feeblock-paymode-desc">
                            支付方式：
                        </div>
                        <type-select type="payMode1" v-model="repaymentForm.payMode" placeholder="请选择"
                            class="offline-cardreplacementmain_feeblock-paymode-select" />
                    </div>
                </el-col>
                <el-col :span="8" class="">
                    <el-button style="float: right;width: 132px;" type="primary" :loading="oloading"
                        @click="repaymentBtn">还款
                    </el-button>
                    <!-- <loading-button style="float: right;" type="primary"
                        class="offline-storagecardrepayment_feeblock-btn" @click="repaymentBtn">还款
                    </loading-button> -->
                </el-col>
            </el-row>
        </div>

        <voucher-layer-confirm ref="mychild1" :column="2" :info="voucherConfirmData" :keys="voucherConfirmKeys"
            :visible.sync="voucherConfirmVisiable" @complete="confirmComplete">
        </voucher-layer-confirm>
        <voucher-layer-old-work-order ref="mychild3" :column="2" :info="voucherOldWorkOrderData" :tip="continueTip"
            :keys="voucherOldWorkOrderKeys" :visible.sync="voucherOldWorkOrderVisiable"
            @complete="continueOldWorkOrder">
        </voucher-layer-old-work-order>
        <voucher-layer ref="mychild2" :column="2" :info="voucherData" :hasFooter="false" :keys="voucherKeys"
            :visible.sync="voucherVisiable" @complete="receiptComplete"></voucher-layer>
    </div>

</template>
<script>
    import { formatDate } from '@/utils/format';
    import {
        getFormatCardIdw,
    } from '@/utils/utils';
    import VoucherLayer from '@/components/VoucherLayer';
    import { getFormatAmount, getFormatAmountYuan2Fen, getDatePoint, getTimePoint } from '@/utils/utils';
    import VoucherLayerConfirm from '@/components/VoucherLayerConfirm';
    import VoucherLayerOldWorkOrder from '@/components/VoucherLayerOldWorkOrder';
    import TypeSelect from '@/components/TypeSelect';
    import { createOrderv, systemTime, updateWorkOrder, systemParameterQuery } from '@/api/common';
    import { queryCreditRepaymentList, creditRepayment, queryCreditRepayment, creditRepaymentQuery } from '@/api/repayment';
    import { etcAccountQuery } from '@/api/user';
    import BDialog from '@/components/DialogBlueTitle'
    import { orderQuery } from '@/api/order';
    import {
        dicKeys,
        getAllDics,
        getDicDesByCode,
        getDicCodeByDes,
        getDicCodeByAll,
        getDicDesByAll,
    } from '@/methods/dics';
    export default {
        data() {
            return {
                continueTip: '该储值卡有未完成的挂账还款交易，请继续',
                voucherOldWorkOrderVisiable: false,
                voucherVisiable: false,
                voucherConfirmVisiable: false,
                confirmFlag: false,
                oloading: false,
                total: 0, //总条数
                currentPage: 1,
                page: 1, //初始显示第几页
                pageSize: 5, //每页显示多少数据
                currentSize: 0, // 当前页条数

                cvisible: false,
                title: '其他还款渠道锁定挂账明细',
                appendToBody: false,
                showclose: true,
                oldRes: '',
                repaymentForm: {
                    userAcctId: '',
                    accountType: '',
                    accountStatus: '',
                    subAcctBalance: '',
                    acctBalance: '',
                    creditfee: '1111',
                    isInvoice: false,
                    txAmount: '',
                    payMode: '1',
                    num: '',
                    transType: '0',
                },
                tables: [],
                voucherConfirmData: {},
                voucherOldWorkOrderData: {},
                voucherData: {},
                voucherFooter: {},
                workOrderID1015: '',
                voucherOldWorkOrderKeys: [
                    //原工单内容
                    [{ key: 'businessType', label: '挂账还款' }],
                    [
                        { key: 'workOrderId', label: '工单号' },
                        { key: 'oldCardId', label: '卡号' },
                        { key: 'oldUserAcctId', label: '账户编号' },
                        { key: 'bizCode', label: '工单类型' },
                    ],
                    [
                        { key: 'registerTime', label: '交易时间' },
                    ],
                    [
                        { key: 'creditfee', label: '挂账金额' },
                        { key: 'amount', label: '还款金额' },
                        { key: 'payMode', label: '支付方式' },
                    ],
                    [
                        { key: 'oprtId', label: '操作员' },
                        { key: 'netId', label: '网点' },
                        { key: 'status', label: '工单状态' },
                    ],
                ],
                voucherConfirmKeys: [
                    [{ key: 'businessType', label: '挂账还款' }],
                    // [{ key: 'etcUserId', label: 'ETC用户ID' }],
                    [
                        { key: 'userName', label: '客户名称' },
                        { key: 'userCertType1', label: '证件类型' },
                        { key: 'userCode', label: '证件号码' },
                    ],
                    [
                        { key: 'cardId', label: '卡号' },
                        { key: 'userAcctId', label: '账户编号' },
                        { key: 'useracctType1', label: '账户类型' },
                        { key: 'userAcctStatus1', label: '账户状态' },

                    ],
                    [
                        { key: 'creditfee', label: '挂账金额' },
                        { key: 'amount', label: '挂账还款金额' },
                        // { key: 'note2', label: '备注2' },
                    ],
                ],
                voucherKeys: [
                    [{ key: 'businessType', label: '挂账还款' }],
                    // [{ key: 'etcUserId', label: 'ETC用户ID' }],
                    [
                        { key: 'userName', label: '客户名称' },
                        { key: 'userCertType', label: '证件类型' },
                        { key: 'userCode', label: '证件号码' },
                    ],
                    [
                        { key: 'cardId', label: '卡号' },
                        { key: 'userAcctId', label: '账户编号' },
                        { key: 'useracctType', label: '账户类型' },
                        { key: 'accountStatus', label: '账户状态' },

                    ],
                    [
                        { key: 'oweBalanceBef', label: '挂账金额' },
                        { key: 'amount', label: '还款金额' },
                        { key: 'payMode', label: '支付方式' },
                        // { key: 'note2', label: '备注2' },
                    ],
                ],
            };
        },
        components: {
            BDialog,
            VoucherLayerConfirm,
            TypeSelect,
            VoucherLayer,
            VoucherLayerOldWorkOrder
        },
        computed: {
            //起始记录
            startRecords() {
                return (this.page - 1) * this.pageSize + 1;
            },
            vehicleInfo() {
                return this.$store.getters.searchCarInfo;
            },
            obuInfo() {
                return this.$store.getters.searchObuInfo;
            },
            cardInfo() {
                return this.$store.getters.searchCardInfo;
            },
            userInfo() {
                return this.$store.getters.searchUserInfo;
            },
            accountInfo() {
                console.log(this.$store.getters.searchAccountInfo)
                return this.$store.getters.searchAccountInfo;
            },
            departmentInfo() {
                return this.$store.getters.searchDepartmentInfo;
            },
        },
        watch: {},
        methods: {
            async accInfoSearch() {
                let useracctType0 = await getDicDesByCode(
                    dicKeys.useracctType,
                    this.accountInfo.userAcctType
                );
                let userAcctStatus0 = await getDicDesByCode(
                    dicKeys.useracctStatus,
                    this.accountInfo.userAcctStatus
                );
                this.repaymentForm.userAcctId = this.accountInfo.userAcctId
                this.repaymentForm.accountType = useracctType0
                this.repaymentForm.accountStatus = userAcctStatus0
                this.repaymentForm.acctBalance = getFormatAmount(this.accountInfo.balance)
                this.repaymentForm.subAcctBalance = getFormatAmount(this.accountInfo.consumeLimit)
                this.repaymentForm.creditfee = getFormatAmount(this.accountInfo.oweBalance)

            },
            async repaymentSearch() {
                //页面加载时，调前置10.13.查询挂账明细接口查询，显示账户当前挂账明细（列表）
                const self = this;
                self.tables = [];
                //10.13
                const res = await queryCreditRepaymentList({
                    workOrderId: this.vehicleInfo.workOrderId,
                    etcUserId: this.userInfo.etcUserId,
                    userAcctid: this.accountInfo.userAcctId,
                    payStatus: '9',
                    startRecords: this.startRecords,
                    rowNumber: 5
                }
                );
                if (res) {
                    self.tables = res.detailsList
                    for (let i = 0; i < res.detailsList.length; i++) {
                        self.tables[i].obutxDate = self.tables[i].obutxDate.replace(/(\s*$)/g, "")
                        self.tables[i].obutxDate = getDatePoint(self.tables[i].obutxDate);
                        self.tables[i].systemDate = getTimePoint(self.tables[i].systemDate);
                        self.tables[i].cardId = getFormatCardIdw(self.tables[i].cardId);
                        self.tables[i].obuId = getFormatCardIdw(self.tables[i].obuId);
                        self.tables[i].fee = getFormatAmount(self.tables[i].fee);
                        self.tables[i].transfee = getFormatAmount(self.tables[i].transfee);
                        self.tables[i].entime = getTimePoint(self.tables[i].entime.replace(/(\s*$)/g, ""));
                        self.tables[i].vehicleColor = await getDicDesByCode(
                            dicKeys.vehicleColor,
                            self.tables[i].vehicleColor
                        );
                    }
                    this.total = res.totalRowNumber
                    this.currentSize =
                        this.pageSize * this.page >= this.total
                            ? this.total
                            : this.page * this.pageSize;
                }
            },
            handleSizeChange(val) {
                this.pageSize = val;
                this.repaymentSearch();
                console.log(`每页 ${val} 条`);
            },
            async handleCurrentChange(val) {
                this.page = val;
                this.currentPage = val;
                this.repaymentSearch();
                console.log(`当前页: ${val}`);
            },
            //还款按钮
            async repaymentBtn() {
                //alert(this.repaymentForm.payMode)
                const self = this
                self.oloading = true
                let timer = setTimeout(() => {
                    self.oloading = false;
                }, 10000);
                let completeTime = await systemTime();
                //调10.28.挂账记录查询接口，查询是否有进行中的挂账还款工单。
                //查询限定本操作员、本网点、当天。
                this.$writeLog('调查询系统时间接口');
                const resSpq = await systemParameterQuery({ requestType: '00' });
                var res1 = await creditRepaymentQuery({
                    etcUserId: this.userInfo.etcUserId,
                    workOrderStatus: '1',
                    netId: this.$store.getters.netid,
                    oprtId: this.$store.getters.oprtId,
                    startDate: resSpq.value,
                    expireDate: resSpq.value,
                })
                if (res1) {
                    if (res1.repaymentList.length > 0) {
                        self.confirmFlag = true //有进行中的挂账还款工单
                    }
                }
                self.oldRes = res1;
                /////////////////////////////////////
                // self.confirmFlag = false
                /////////////////////////////////////
                if (self.confirmFlag == true) {
                    //有进行中的挂账还款工单
                    self.toOldWorkOrder();
                } else {
                    //弹出用户确认凭证
                    self.toConfirm();
                }
                self.oloading = false;
            },
            // 确认凭证
            async toConfirm() {
                let userCertType1 = await getDicDesByCode(
                    dicKeys.userCertType,
                    this.userInfo.userCertType
                );
                let useracctType1 = await getDicDesByCode(
                    dicKeys.useracctType,
                    this.accountInfo.userAcctType
                );
                let userAcctStatus1 = await getDicDesByCode(
                    dicKeys.useracctStatus,
                    this.accountInfo.userAcctStatus
                );
                console.log(this.userInfo)
                this.voucherConfirmData = {
                    businessType: '挂账还款',
                    userName: this.userInfo.userName,
                    userCertType1,
                    userCode: this.userInfo.userCode,
                    cardId: getFormatCardIdw(this.cardInfo.cardID),
                    userAcctId: this.accountInfo.userAcctId,
                    useracctType1,
                    userAcctStatus1,
                    creditfee: this.repaymentForm.creditfee,
                    amount: this.repaymentForm.creditfee,
                };
                this.voucherConfirmVisiable = true;
                this.$nextTick(() => {
                    //执行调用手写板
                    this.$refs.mychild1.sendpad();
                });
            },
            async confirmComplete() {
                //前端调前置的12.13.接口创建挂账还款工单，bizcode=33。
                const res2 = await createOrderv({
                    bizCode: '33',
                    oldUserId: this.userInfo.userID,
                    oldUserAcctId: this.accountInfo.userAcctId,
                    oldDepartmentName: this.departmentInfo.department,
                    oldBuyId: this.accountInfo.signOrderNo,
                    oldVehicleId: this.vehicleInfo.vehicleId,
                    oldVehicleNumber: this.vehicleInfo.vehicleNumber,
                    oldVehicleColor: this.vehicleInfo.vehicleColor,
                    oldCardId: this.cardInfo.cardID,
                    oldObuysId: this.obuInfo.printID,
                    oldObuId: this.obuInfo.obuID,
                    oldEtcUserId: this.userInfo.etcUserId,
                    oldUsername: this.userInfo.userName,
                    oldPayChannelName: this.accountInfo.paychannelName,
                    oldSubPayChannelName: this.accountInfo.subPaychannelName,
                })
                if (res2) {
                    this.workOrderID1015 = res2.workOrderID;
                    //前端调前置10.14.挂账还款申请接口。
                    const res = await creditRepayment({
                        workOrderId: res2.workOrderID,
                        etcUserId: this.userInfo.etcUserId,
                        cardId: this.cardInfo.cardID,
                        userAcctId: this.accountInfo.userAcctId,
                        txAmount: getFormatAmountYuan2Fen(this.repaymentForm.creditfee),
                        payMode: this.repaymentForm.payMode,
                        describe: this.cardInfo.cardID,
                    })
                    if (res) {
                        //前端收到前置返回成功后，弹出提示“挂账还款成功”。
                        this.$alert('挂账还款成功', '提示', {
                            confirmButtonText: '确定',
                            showClose: false,
                            type: 'success',
                        }).then(async () => {
                            //调前置10.15.挂账还款回执查询接口，获取回执凭证内容，弹出回执签名凭证。
                            const resQuery = await queryCreditRepayment({
                                workOrderId: this.workOrderID1015,
                                etcUserId: this.userInfo.etcUserId,
                            })
                            console.log(resQuery)
                            if (resQuery) {
                                let completeTime = await systemTime();
                                // self.voucherFooter = {
                                //     date: completeTime.systemTime,
                                //     outletId: this.$store.getters.netid,
                                //     operator: this.$store.getters.oprtId,
                                // };
                                // console.log(self.voucherFooter)
                                let userCertType = await getDicDesByCode(
                                    dicKeys.userCertType,
                                    resQuery.zjlx
                                );
                                let useracctType = await getDicDesByCode(
                                    dicKeys.useracctType,
                                    resQuery.accountType,
                                );
                                this.voucherData = {
                                    businessType: '挂账还款',
                                    userName: resQuery.username,
                                    userCertType,
                                    userCode: resQuery.userCode,
                                    cardId: resQuery.cardId,
                                    userAcctId: resQuery.accountId,
                                    useracctType,
                                    accountStatus: resQuery.accountStatus,
                                    amount: resQuery.amount,
                                    oweBalanceBef: resQuery.oweBalanceBef,
                                    payMode: resQuery.payMode,
                                };
                                this.voucherVisiable = true
                            }
                        });
                        //this.$message.error(res)
                    } else {
                        //如果前端没收到前置返回或前置返回失败，提示“挂账还款异常，请重试”，再次点击挂账还款按钮，重新来过。
                        this.$message.error('挂账还款异常，请重试');
                        return
                    }
                }
            },
            async receiptComplete() {
            },
            async toOldWorkOrder() {
                //若有进行中的工单，弹出窗口显示原工单内容，显示内容包括：工单号、卡号、账户编号、
                //工单类型、交易日期、交易时间、挂账金额、还款金额、支付方式、操作员、网点、工单状态。
                //页面显示文字“该储值卡有未完成的挂账还款交易，请继续”，提供“继续”按钮。
                console.log('oldres:', this.oldRes.repaymentList[0])
                let oldpayMode = await getDicDesByCode(
                    dicKeys.payMode1,
                    this.oldRes.repaymentList[0].payMode);
                this.voucherOldWorkOrderData = {
                    businessType: '挂账还款',
                    workOrderId: this.oldRes.repaymentList[0].workOrderId,
                    oldCardId: getFormatCardIdw(this.oldRes.repaymentList[0].cardId),
                    oldUserAcctId: this.oldRes.repaymentList[0].accountId,
                    bizCode: this.oldRes.repaymentList[0].bizCode,
                    registerTime: getTimePoint(this.oldRes.repaymentList[0].tradeTime),
                    creditfee: getFormatAmount(this.oldRes.repaymentList[0].unpayAmount),//挂账金额
                    amount: getFormatAmount(this.oldRes.repaymentList[0].repayAmount),//还款金额
                    payMode: oldpayMode,//支付方式
                    oprtId: this.oldRes.repaymentList[0].operatorid,
                    netId: this.oldRes.repaymentList[0].netid,
                    status: this.oldRes.repaymentList[0].workrderStatus,
                }
                this.voucherOldWorkOrderVisiable = true;
                this.$nextTick(() => {
                    //执行调用手写板
                    this.$refs.mychild3.sendpad();
                });
            },
            async continueOldWorkOrder() {
                //点击继续按钮后，弹窗页面消失，后续流程参考4（3）-4（5）。
                //4(3)前端调前置10.14.挂账还款申请接口。
                const res = await creditRepayment({
                    workOrderId: this.oldRes.repaymentList[0].workOrderId,//工单号
                    etcUserId: this.userInfo.etcUserId,//ETC用户ID
                    cardId: this.oldRes.repaymentList[0].cardId,//Etc卡号
                    userAcctId: this.oldRes.repaymentList[0].accountId,//账户编号
                    txAmount: this.oldRes.repaymentList[0].repayAmount,//还款金额
                    payMode: this.oldRes.repaymentList[0].payMode,//支付方式
                    describe: this.oldRes.repaymentList[0].cardId,//交易描述
                })
                //4(4)
                if (res) {
                    if (res) {
                        //前端收到前置返回成功后，弹出提示“挂账还款成功”。
                        this.$alert('挂账还款成功', '提示', {
                            confirmButtonText: '确定',
                            showClose: false,
                            type: 'success',
                        }).then(async () => {
                            //4(5)
                            //调前置10.15.挂账还款回执查询接口，获取回执凭证内容，弹出回执签名凭证。
                            const oldresQuery = await queryCreditRepayment({
                                workOrderId: this.oldRes.repaymentList[0].workOrderId,
                                etcUserId: this.userInfo.etcUserId,
                            })
                            console.log(oldresQuery)
                            if (oldresQuery) {
                                let completeTime = await systemTime();
                                let userCertType = await getDicDesByCode(
                                    dicKeys.userCertType,
                                    oldresQuery.zjlx
                                );
                                let useracctType = await getDicDesByCode(
                                    dicKeys.useracctType,
                                    oldresQuery.accountType,
                                );
                                this.voucherData = {
                                    businessType: '挂账还款',
                                    userName: oldresQuery.username,
                                    userCertType,
                                    userCode: oldresQuery.userCode,
                                    cardId: oldresQuery.cardId,
                                    userAcctId: oldresQuery.accountId,
                                    useracctType,
                                    accountStatus: oldresQuery.accountStatus,
                                    amount: oldresQuery.amount,
                                    oweBalanceBef: oldresQuery.oweBalanceBef,
                                    payMode: oldresQuery.payMode,
                                };
                                this.voucherVisiable = true
                            }
                        });
                    }
                    //this.$message.error(res)
                } else {
                    //如果前端没收到前置返回或前置返回失败，提示“挂账还款异常，请重试”，再次点击挂账还款按钮，重新来过。
                    this.$message.error('挂账还款异常，请重试');
                    return
                }
            },

        },
        mounted() {
            this.$writeLog('储值卡挂账还款进入');
            this.accInfoSearch();
            this.repaymentSearch();
        },
        destroyed() {
            // clearTimeout(this.timer1);
        },
    };
</script>