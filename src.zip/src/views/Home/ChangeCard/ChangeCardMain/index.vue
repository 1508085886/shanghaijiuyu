<!-- 换卡 -->
<template>
  <div class="offline-changecard offline-changecardmain">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-changecardindex_title">换卡</h4>
      </div>
    </div>
    <!-- <template class="o-flex offline-changecardmain_blocks-wrap">
      <div class="offline-changecardmain_block"></div>
      <div class="offline-changecardmain_block"></div>
    </template> -->
    <el-row :gutter="10" class="mt20">
      <el-col :span="12"
        ><div class="offline-changecardmain_block">
          <el-form
            ref="oldCardForm"
            :model="oldCardForm"
            class="offline-changecardmain_block-readcard-form"
          >
            <div class="o-flex">
              <loading-button
                class="offline-changecardmain_block-readcard-btn"
                size="small"
                type="primary"
                @click="readOldCard"
                :loading="loadingReadOld"
                :disabled="disabledReadOld"
                round
              >
                <i class="icon iconfont iconbofang" /> 读旧卡
              </loading-button>

              <el-form-item prop="destroy" ref="destroy">
                <el-checkbox
                  v-model="oldCardForm.destroy"
                  :disabled="disabledDestroy"
                  class="offline-changecardmain_block-readcard-checkbox"
                  >卡片人为损坏</el-checkbox
                >
              </el-form-item>
              <el-form-item prop="expird" ref="expird">
                <!-- <el-checkbox
                  v-model="oldCardForm.expird"
                  disabled
                  class="offline-changecardmain_block-readcard-checkbox"
                  >卡片过保修期</el-checkbox
                > -->
                <span
                  v-show="oldCardForm.expird"
                  class="offline-changecardmain_block-readcard-span"
                  >卡片过保修期</span
                >
              </el-form-item>
            </div>

            <div class="offline-changecardmain_block-readcard-centent">
              <el-row class="offline-changecardmain_block-readcard-centent-row">
                <el-form-item prop="obuSysID" ref="obuSysID">
                  <el-col :xl="7" :lg="7" :md="7">旧卡卡号：</el-col>
                  <el-col :xl="17" :lg="17" :md="17">{{
                    oldCardForm.obuSysID
                  }}</el-col>
                </el-form-item>
              </el-row>
              <el-row class="offline-changecardmain_block-readcard-centent-row">
                <el-form-item prop="printID" ref="printID">
                  <el-col :xl="7" :lg="7" :md="7">旧卡表面号：</el-col>
                  <el-col :xl="17" :lg="17" :md="17">
                    <!-- <input
                    placeholder="请输入卡片背面的卡号"
                    :value="oldCardForm.printID"
                  /> -->
                    <regex-input
                      ref="printIdInput"
                      type="cardFrontId"
                      :placeholder="placeholderFrontId"
                      :readonly="readonlyFrontId"
                      @focus="focusFrontId"
                      v-model="oldCardForm.printID"
                    ></regex-input>
                    <loading-button
                      class=""
                      type="primary"
                      size="small"
                      :disabled="disabledConfirmPrintId"
                      @click="confirmPrintId"
                      round
                    >
                      确认
                    </loading-button>
                  </el-col>
                </el-form-item>
              </el-row>
              <el-row class="offline-changecardmain_block-readcard-centent-row">
                <el-form-item prop="issueVersion" ref="issueVersion">
                  <el-col :xl="7" :lg="7" :md="7">旧卡版本号：</el-col>
                  <el-col :xl="17" :lg="17" :md="17">{{
                    oldCardForm.issueVersion
                  }}</el-col>
                </el-form-item>
              </el-row>
              <el-row class="offline-changecardmain_block-readcard-centent-row">
                <el-form-item prop="txType" ref="txType">
                  <el-col :xl="7" :lg="7" :md="7">旧卡状态：</el-col>
                  <el-col :xl="17" :lg="17" :md="17"></el-col>
                  <!-- {{oldCardForm.txType}} -->
                </el-form-item>
              </el-row>
            </div>
          </el-form>
        </div></el-col
      >
      <el-col :span="12"
        ><div class="offline-changecardmain_block">
          <el-form
            ref="newCardForm"
            :model="newCardForm"
            class="offline-changecardmain_block-readcard-form"
          >
            <loading-button
              class="offline-changecardmain_block-readcard-btn"
              size="small"
              type="primary"
              @click="readNewCard"
              :loading="loadingReadNew"
              :disabled="disabledReadNew"
              round
            >
              <i class="icon iconfont iconbofang" /> 读新卡
            </loading-button>
            <div class="offline-changecardmain_block-readcard-centent">
              <el-row class="offline-changecardmain_block-readcard-centent-row">
                <el-col class="no-bottom-border">
                  <el-radio-group
                    ref="radioNewCardType"
                    v-model="newCardForm.txType"
                    disabled
                    class="offline-changecardmain_block-readcard-radio"
                  >
                    <!-- <el-radio label="5">自有卡</el-radio> -->
                    <el-radio label="2">新购卡片</el-radio>
                  </el-radio-group>
                </el-col>
              </el-row>
              <el-row class="offline-changecardmain_block-readcard-centent-row">
                <el-col :xl="7" :lg="7" :md="7">新卡版本号：</el-col>
                <el-col :xl="17" :lg="17" :md="17">{{
                  newCardForm.issueVersion
                }}</el-col>
              </el-row>
            </div>
          </el-form>
        </div></el-col
      >
    </el-row>
    <div class="offline-changecardmain_feeblock">
      <el-row :gutter="10" class="">
        <el-col :span="12"
          ><div class="offline-changecardmain_feeblock-due">
            <div class="offline-changecardmain_feeblock-desc">应收（元）</div>
            <div class="offline-changecardmain_feeblock-amount">
              {{ due }}
            </div>
          </div>
          <div class="offline-changecardmain_feeblock-receive">
            <div class="offline-changecardmain_feeblock-desc">实收（元）</div>
            <div class="offline-changecardmain_feeblock-amount">
              {{ receive }}
            </div>
          </div></el-col
        >
        <el-col :span="12" class="o-flex o-flex-column">
          <div class="o-flex o-flex-space-between">
            <div
              class="
                o-flex o-flex-align-baseline
                offline-changecardmain_feeblock-paymode
              "
            >
              <div class="offline-changecardmain_feeblock-paymode-desc">
                支付方式：
              </div>
              <type-select
                type="payMode"
                v-model="payMode"
                :disabled="isUsePayMode"
                placeholder="请选择"
                class="offline-changecardmain_feeblock-paymode-select"
              />
            </div>
            <loading-button
              type="primary"
              class="offline-changecardmain_feeblock-btn"
              :disabled="disabledFee"
              @click="fee"
              >收费
            </loading-button>
          </div>
          <el-checkbox
            @change="specialFreeChange"
            v-model="specialFree"
            :disabled="!hasSpecialFreeAuth ? true : disabledFee"
            class="offline-changecardmain_block-specialfree-checkbox"
            >特许免费</el-checkbox
          >
        </el-col>
      </el-row>
    </div>
    <div class="offline-changecardmain_tip">
      {{ tip }}
    </div>
    <el-row :gutter="10" class="offline-changecardmain_bottom">
      <el-col :span="12">
        <loading-button
          type="primary"
          class="offline-changecardmain_bottom-btn"
          :disabled="disabledDistroyOld"
          :loading="loadingDistroyOld"
          :clickNoLoading="clickNoLoading"
          @click="confirmFlagc ? writeOff() : toConfirm()"
          round
          >核销旧卡
        </loading-button>
      </el-col>
      <el-col :span="12">
        <loading-button
          type="primary"
          class="offline-changecardmain_bottom-btn"
          :disabled="disabledChangeNew"
          :loading="loadingChangeNew"
          @click="changeNew"
          round
          >更换新卡
        </loading-button>
      </el-col>
    </el-row>
    <voucher-layer-confirm
      ref="mychild1"
      :column="2"
      :tip="confirmTip"
      :info="voucherConfirmData"
      :keys="voucherConfirmKeys"
      :visible.sync="voucherConfirmVisiable"
      :confirmFlag.sync="confirmFlagc"
      @closed="disabledDistroyOld = false"
      @complete="writeOff"
    ></voucher-layer-confirm>
    <!-- <el-button @click="loadingReadOld = false">test </el-button> -->
    <addbranch-block
      :visible.sync="addvisble"
      :append-to-body="true"
      popuptype="addbranch"
      :showclose="false"
      @addbranchs="improveBranch(methodType)"
    ></addbranch-block>
    <!--  @addbranchs="
        () => {
          this.addbranchsMethod = this.methodType;
        }
      " -->
  </div>
</template>
<script>
import VoucherLayerConfirm from '@/components/VoucherLayerConfirm';
import RegexInput from '@/components/RegexInput';
import { issueCard, readCard, getCpuIdFF } from '@/utils/dynamic';
import { systemParameterQuery, updateWorkOrder } from '@/api/common';
import { requestCompre } from '@/api/compre';
import {
  changeValidityApply,
  changeValidityConfrim,
  renewalValidity,
  changeValidityRenewalConfrim,
} from '@/api/writeoff';
import { v1PreIssueApply, v1PreIssueConfirm } from '@/api/publish';
import {
  queryCardObuOneSendInfo,
  calculateCardReplacement,
  orderCharges,
  changeCard,
} from '@/api/equipment';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicEasyDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';
import { getFormatAmount, getFormatAmountYuan2Fen } from '@/utils/utils';
import { perfectVehicleDepartment } from '@/api/branch';
import AddbranchBlock from '@/components/AddbranchBlock';
export default {
  data() {
    return {
      // step: '',
      addbranchsMethod: '', // 新建分支结构回调
      methodType: '', // 新建分支结构回调方法类型
      isValidity: '',
      addvisble: false, // 新建分支结构弹窗
      timer: null,
      tip: '',
      confirmTip: '卡片一旦核销，将无法使用，且不能反悔，您确认要核销吗？',
      voucherConfirmData: {
        businessType: '卡片核销',
        userName: '',
        userCertType: '',
        userCode: '',
        vehicleNumber: '沪A502102',
        vehicleColor: '0-蓝色',
        vehicleType: '',
        vehicleClass: '',
        approvedAccount: '',
        viTotalMass: '',
        cardType: '23-ETC联名卡',
        obuSysID: '063100408667568',
        txType: '1-已开通',
        cardFreeEndDate: '',
      },
      voucherConfirmKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '用户名称' },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'vehicleNumber', label: '车牌号码' },
          { key: 'vehicleColor', label: '车牌颜色' },
          { key: 'vehicleType', label: '车辆用户类型' },
          { key: 'vehicleClass', label: '收费车型' },
          { key: 'approvedAccount', label: '核定载人数' },
          { key: 'viTotalMass', label: '总质量' },
        ],
        [
          { key: 'cardType', label: '卡类型' },
          { key: 'cardId', label: '卡号' },
          { key: 'cardStatus', label: '卡片当前状态' },
          { key: 'cardFreeEndDate', label: '卡片保修期' },
        ],
      ],
      voucherConfirmVisiable: false,
      payMode: '',
      specialFree: false, // 特许免费
      hasSpecialFreeAuth: false, // 特许免费权限
      oldCardForm: {
        destroy: false,
        expird: false,
        obuSysID: '',
        // printID: '3101 0322 2033 3349 9032',
        printID: '',
        issueVersion: '',
        txType: '',
      },
      newCardForm: {
        obuSysID: '',
        txType: '',
        issueVersion: '',
      },
      loadingReadOld: false,
      loadingReadNew: false,
      loadingChangeNew: false,
      loadingDistroyOld: false,
      disabledReadOld: false, // 读旧卡禁用
      disabledDestroy: false, // 人为损坏勾选禁用
      clickNoLoading: false, // 点击但不触发Loading
      disabledConfirmPrintId: true,
      disabledReadNew: true,
      disabledFee: true,
      disabledDistroyOld: true,
      disabledChangeNew: true,
      checked: false,
      flagConfirmPrintId: false,
      confirmFlagc: false, // 确认凭证是否被确认
      readonlyFrontId: true,
      isGood: true,
      oldIsDestroyed: false, // 旧卡已核销
      placeholderFrontId: '',
      due: '0.00', // 应收
      oldDue: '',
      receive: '0.00', // 实收
      price: 0, // 收费金额，单位为分
      workOrderID: '', // 工单号
      isUsePayMode: false, // 支付方式是否使用
      changeCardData: {}, // 继续办理换卡数据
      cdif: '',
      isChangeCard: '',
      oprice: 0, // 已有工单收费价格
      continueSysId: '', // 继续办理获取的设备号
      etcUserId: '',
      newVehicleNumber: '',
      newVehicleColor: '',
      newPrice: 0,
      isFree: '',
    };
  },
  components: {
    RegexInput,
    VoucherLayerConfirm,
    AddbranchBlock,
  },
  watch: {
    'oldCardForm.printID'(val) {
      if (val.length === 24 && this.flagConfirmPrintId) {
        // 卡表面号（加4个空格）输入完整，达到24位
        this.disabledConfirmPrintId = false;
      } else {
        this.disabledConfirmPrintId = true;
      }
    },
    addbranchsMethod(val) {
      console.log('watch-addbranchsMethod');
      if (val == 'mainChange') {
        this.mainChange();
      } else if (val == 'badChange') {
        this.badChange();
      } else if (val == 'retryCancelChange') {
        this.retryCancelChange();
      }
    },
    disabledReadNew(val) {
      console.log('watch-disabledReadNew');
      if (!val) {
        this.readonlyFrontId = true;
      }
    },
  },
  computed: {
    vehicleInfo() {
      return this.$store.getters.searchCarInfo;
    },
    obuInfo() {
      return this.$store.getters.searchObuInfo;
    },
    cardInfo() {
      return this.$store.getters.searchCardInfo;
    },
    userInfo() {
      return this.$store.getters.searchUserInfo;
    },
  },
  methods: {
    // 主流程换卡/签流程
    async mainChange() {
      console.log('mainChange()');
      const resChange0 = await changeCard({
        etcUserId: this.userInfo.etcUserId,
        workOrderId: this.workOrderID,
        oldCardId: this.oldCardForm.obuSysID,
        newCardId: this.newCardForm.obuSysID,
        vehicleNumber: this.vehicleInfo.vehicleNumber,
        vehicleColor: this.vehicleInfo.vehicleColor,
        price: this.price,
        payMode: this.payMode,
        userName: this.userInfo.userName,
        userCode: this.userInfo.userCode,
        userCertType: this.userInfo.userCertType,
        deliveryMode: '2',
        buyChannel: this.newCardForm.txType === '5' ? '1' : '2', //1-自带 2-新购
        freeEndDate: this.cardInfo.freeEndDate,
        isDmage: this.oldCardForm.destroy ? '2' : '1',
        isBartender: this.oldCardForm.expird ? '2' : '1',
        isValidity: this.isValidity, // 改有效期成功了才去调换卡/换签接口，也就是这里始终是传‘2’
        newCardVersion: this.newCardForm.issueVersion,
        oldCardVersion: this.oldCardForm.issueVersion,
      });
      if (resChange0) {
        // 核销完成后更换新卡按钮变为可用。
        this.loadingDistroyOld = false;
        this.disabledDistroyOld = true;
        this.disabledChangeNew = false;
      } else {
        // console.log('resRenewal-resRenewal');
        // 如果14.3 换卡业务申请接口返回失败，且旧卡是好卡，则恢复卡片效期
        const resRenewal = await this.renewal(res);
        if (resRenewal) {
          this.loadingDistroyOld = false;
          this.disabledDistroyOld = false;
          this.disabledChangeNew = true;
        }
      }
    },
    // 坏设备换卡/签流程
    async badChange() {
      console.log('badChange()');
      const res4 = await changeCard({
        etcUserId: this.userInfo.etcUserId,
        workOrderId: this.workOrderID,
        oldCardId: this.oldCardForm.obuSysID,
        newCardId: this.newCardForm.obuSysID,
        vehicleNumber: this.vehicleInfo.vehicleNumber,
        vehicleColor: this.vehicleInfo.vehicleColor,
        price: this.price,
        payMode: this.payMode,
        userName: this.userInfo.userName,
        userCode: this.userInfo.userCode,
        userCertType: this.userInfo.userCertType,
        deliveryMode: '2',
        buyChannel: this.newCardForm.txType === '5' ? '1' : '2', //1-自带 2-新购
        freeEndDate: this.cardInfo.freeEndDate,
        isDmage: this.oldCardForm.destroy ? '2' : '1',
        isBartender: this.oldCardForm.expird ? '2' : '1',
        isValidity: this.isValidity, // 在坏卡/坏签的情况下，是不去改有效期的，此时传否
        newCardVersion: this.newCardForm.issueVersion,
        oldCardVersion: this.oldCardForm.issueVersion,
      });
      if (res4) {
        // 核销完成后更换新卡按钮变为可用。
        this.loadingDistroyOld = false;
        this.disabledDistroyOld = true;
        this.disabledChangeNew = false;
      } else {
        //接口异常
        this.loadingDistroyOld = false;
        this.disabledDistroyOld = false;
        this.disabledChangeNew = true;
      }
    },
    // 取消重试设备换卡/签流程
    async retryCancelChange() {
      console.log('retryCancelChange()');
      const resChange = await changeCard({
        etcUserId: this.userInfo.etcUserId,
        workOrderId: this.workOrderID,
        oldCardId: this.oldCardForm.obuSysID,
        newCardId: this.newCardForm.obuSysID,
        vehicleNumber: this.vehicleInfo.vehicleNumber,
        vehicleColor: this.vehicleInfo.vehicleColor,
        price: this.price,
        payMode: this.payMode,
        userName: this.userInfo.userName,
        userCode: this.userInfo.userCode,
        userCertType: this.userInfo.userCertType,
        deliveryMode: '2',
        buyChannel: this.newCardForm.txType === '5' ? '1' : '2', //1-自带 2-新购
        freeEndDate: this.cardInfo.freeEndDate,
        isDmage: this.oldCardForm.destroy ? '2' : '1',
        isBartender: this.oldCardForm.expird ? '2' : '1',
        isValidity: this.isValidity, // 改有效期标志传否
        newCardVersion: this.newCardForm.issueVersion,
        oldCardVersion: this.oldCardForm.issueVersion,
      });
      if (resChange) {
        // 核销完成后更换新卡按钮变为可用。
        this.loadingDistroyOld = false;
        this.disabledDistroyOld = true;
        this.disabledChangeNew = false;
      } else {
        // 接口异常
        this.loadingDistroyOld = false;
        this.disabledDistroyOld = false;
        this.disabledChangeNew = true;
      }
    },
    // 特许免费
    specialFreeChange(val) {
      // 勾选后应收费用变为0元
      if (val) {
        this.due = '0.00';
      } else {
        this.due = this.oldDue;
      }
    },
    aaa(e) {
      console.log('eeeee', e);
      // oldCardForm.printID = $target.event.value;
    },
    // 读旧卡
    async readOldCard() {
      // this.$refs.oldCardForm.resetFields();
      this.$refs.expird.resetField();
      this.$refs.obuSysID.resetField();
      this.$refs.printID.resetField();
      this.$refs.issueVersion.resetField();
      this.$refs.txType.resetField();
      let failObj = {
        msg: '读卡失败。<br>点[重试]按钮重试，点[取消]按钮手动输入卡号并回车，当坏卡处理。',
        confirmButtonText: '重试',
        cancelButtonText: '取消',
        distinguishCancelAndClose: true,
        cancelCatch: async () => {
          // 若点击取消，旧卡表面号后面的输入栏变为可输入状态，显示灰色提示文字”请输入卡片背面的卡号“
          this.readonlyFrontId = false;
          this.placeholderFrontId = '请输入卡片背面的卡号';
          this.flagConfirmPrintId = true; // 只有此时才可触发确认按钮
        },
        closeCatch: () => {
          //若既不需要重试也不需要手动输入卡号，则点提示框右上角的×关闭提示框
        },
        cardIdNotSameMsg: '卡号不一致，请清除首页信息重新查询',
      };
      let btnLoading = this.loadingReadOld;
      let successFunc = async (res) => {
        // 若读卡成功，读取到旧卡卡号和旧卡版本号并显示，
        this.oldCardForm.obuSysID = res.cardid;
        this.oldCardForm.issueVersion = res.issueversion;
        // 当前日期（当前日期需通过后台接口查询）超卡片保修期时，自动勾选“卡片过保修期”
        let time = this.cardInfo.freeEndDate; // 用综合查询的保修期
        const res0 = await systemParameterQuery({ requestType: '00' });
        if (res0) {
          if (time < res0.value) {
            this.oldCardForm.expird = true;
          }
        }
        // 调用后台7.3.查询卡/OBU一发信息接口查询，显示旧卡表面号和旧卡状态
        const res1 = await queryCardObuOneSendInfo({
          obuSysID: this.oldCardForm.obuSysID,
        });
        if (res1) {
          const txType = await getDicEasyDesByCode(dicKeys.txType, res1.txType);
          // 读完旧卡或输入表面号，查询出旧卡状态时，若旧卡状态为2-已核销，
          // 则核验新卡完成后，核销旧卡按钮保持不可用，更换新卡按钮变为可用。
          const _txType = await getDicCodeByDes(dicKeys.txType, '已核销');
          if (res1.txType === _txType) {
            // if (true) {
            this.oldIsDestroyed = true;
          }
          this.oldCardForm.txType = txType;
          this.oldCardForm.printID = res1.printID;
          // this.disabledDestroy = true;
          this.disabledReadOld = true;
          this.disabledReadNew = false;
          // this.readonlyFrontId = true;
          // console.log('this.readonlyFrontId', this.readonlyFrontId);
          // 读卡成功的，记录好卡标志；读卡失败，通过输入表面号查询的，记录坏卡标志
          this.isGood = true;
        }
        // console.log('$trim', this.$trim(this.oldCardForm.printID));
      };
      let cardInfo = this.cardInfo.cardID
        ? this.cardInfo
        : { cardID: this.continueSysId }; // 当从继续办理进入该业务，已核销的设备没有设备号，需要通过工单管理里返回的设备号来校验
      const res = readCard(
        btnLoading,
        // this.cardInfo,
        cardInfo,
        successFunc,
        this.readOldCard,
        failObj
      );
    },
    async confirmPrintId() {
      if (this.isEmptyObj(this.cardInfo)) {
        this.$message.error('无法获取卡片信息');
        return;
      } else {
        // 输入完成后点击确定按钮，调用后台7.3.查询卡/OBU一发信息接口，
        // 通过表面号查询到卡号、卡片版本号和卡状态并显示
        const res1 = await queryCardObuOneSendInfo({
          printID: this.$trim(this.oldCardForm.printID),
        });
        if (res1) {
          const txType = await getDicEasyDesByCode(dicKeys.txType, res1.txType);
          // 核对此处卡号和首页综合查询的卡号是否一致
          if (res1.obuSysID == this.cardInfo.cardID) {
            // 当前日期（当前日期需通过后台接口查询）超卡片保修期时，自动勾选“卡片过保修期”
            let time = this.cardInfo.freeEndDate; // 如果是通过表面号查询的，只要核对过查询出来的卡号和综合查询的卡号一致，就用综合查询的保修期
            const res0 = await systemParameterQuery({ requestType: '00' });
            if (res0) {
              if (time < res0.value) {
                this.oldCardForm.expird = true;
              }
            }
            this.oldCardForm.obuSysID = res1.obuSysID;
            this.oldCardForm.issueVersion = res1.issueVersion;
            this.oldCardForm.txType = txType;
            // 读完旧卡或输入表面号，查询出旧卡状态时，若旧卡状态为2-已核销，
            // 则核验新卡完成后，核销旧卡按钮保持不可用，更换新卡按钮变为可用。
            const _txType = await getDicCodeByDes(dicKeys.txType, '已核销');
            if (res1.txType === _txType) {
              // if (true) {
              this.oldIsDestroyed = true;
            }
            // 核验旧卡按钮状态变为不可用，核验新卡按钮状态变为可用
            // this.disabledDestroy = true;
            this.disabledReadOld = true;
            this.disabledReadNew = false;
            // this.readonlyFrontId = true;
            // 读卡成功的，记录好卡标志；读卡失败，通过输入表面号查询的，记录坏卡标志
            this.isGood = false;
          } else {
            this.$alert('卡号不一致，请清除首页信息重新查询', '提示', {
              confirmButtonText: '确定',
              type: 'warning',
            });
          }
        }
      }
    },
    focusFrontId() {
      if (this.flagConfirmPrintId && !this.readonlyFrontId) {
        // 鼠标点击进入输入状态时，灰色文字消失，开头自动显示黑色3101，引导操作员输入后面16位的卡号
        this.oldCardForm.printID = this.$printIdBefore;
        this.$refs.printIdInput.focus();
      }
    },
    // 读新卡
    async readNewCard() {
      this.disabledDestroy = true;
      this.$refs.newCardForm.resetFields();
      let failObj = {
        msg: '读卡失败。<br>点[重试]按钮重试。',
        confirmButtonText: '重试',
        cancelButtonText: '取消',
        cancelCatch: () => {},
      };
      let btnLoading = this.loadingReadNew;
      let successFunc = async (res) => {
        console.log('readNewCard-successFunc-issueversion', res.issueversion);
        // 读卡成功后，判断新卡的版本号，需要满足以下条件，才可更换
        // const vehicleCategory = await getDicCodeByDes(
        //   dicKeys.vehicleCategoryL,
        //   '普通客车'
        // );
        // 已注册的车辆，根据收费车型判断（未注册的车辆，综合查询不能成功）
        let vehicleClassArr = [];
        vehicleClassArr.push(
          await getDicCodeByDes(dicKeys.vehicleClassL, '一类客车')
        );
        vehicleClassArr.push(
          await getDicCodeByDes(dicKeys.vehicleClassL, '二类客车')
        );
        vehicleClassArr.push(
          await getDicCodeByDes(dicKeys.vehicleClassL, '三类客车')
        );
        vehicleClassArr.push(
          await getDicCodeByDes(dicKeys.vehicleClassL, '四类客车')
        );
        if (vehicleClassArr.includes(this.vehicleInfo.vehicleClass)) {
          // 车种为客车时
          // const resCompre = await requestCompre({ cardId: res.cardid });
          // if (resCompre) {
          // 新卡版本号必须和标签版本号一致
          let newIssueVersionStart = '';
          if (res.issueversion == '00') {
            newIssueVersionStart = '1';
          } else if (res.issueversion.startsWith('1')) {
            newIssueVersionStart = '1';
          } else if (res.issueversion.startsWith('4')) {
            newIssueVersionStart = '4';
          }
          let oldIssueVersionStart = '';
          if (this.obuInfo.versionNo == '00') {
            oldIssueVersionStart = '1';
          } else if (this.obuInfo.versionNo.startsWith('1')) {
            oldIssueVersionStart = '1';
          } else if (this.obuInfo.versionNo.startsWith('4')) {
            oldIssueVersionStart = '4';
          }
          if (!(newIssueVersionStart == oldIssueVersionStart)) {
            // 若不一致，提示“新卡版本号需和标签版本号一致”，流程结束
            this.$alert('新卡版本号需和标签版本号一致', '提示', {
              confirmButtonText: '确定',
              type: 'warning',
            });
            return;
          }
          // } else {
          //   return;
          // }
        } else {
          // 车种不是客车（货车、牵引车、专项作业车中的任意一种）
          // 新卡必须是4x版本（版本号4开头）
          if (!res.issueversion.startsWith('4')) {
            // 新卡版本号不是4x时，提示“货车、牵引车、专项作业车只能更换4x版本卡片”，流程结束
            this.$alert('货车、牵引车、专项作业车只能更换4x版本卡片', '提示', {
              confirmButtonText: '确定',
              type: 'warning',
            });
            return;
          }
        }
        // 调后台7.3.查询卡/OBU一发信息接口，txType=2表示是新购卡片；txType=5表示是自有卡
        const res1 = await queryCardObuOneSendInfo({ obuSysID: res.cardid });
        if (res1) {
          if (res1.txType == '2') {
            this.newCardForm.txType = res1.txType;
            // this.newCardForm.issueVersion = res1.issueVersion;
            this.newCardForm.issueVersion = res.issueversion;
            this.newCardForm.obuSysID = res.cardid;
            this.disabledReadOld = true;
            this.disabledReadNew = false;
          } else {
            // txType!=2提示“新卡已发行过，请换一张新卡”
            this.$alert('新卡已发行过，请换一张新卡', '提示', {
              confirmButtonText: '确定',
              type: 'warning',
            });
            return;
          }
          // else if (res1.txType == '3') {
          //   // txType=3提示“该卡已发行，不可更换”
          //   this.$alert('该卡已发行，不可更换', '提示', {
          //     confirmButtonText: '确定',
          //     type: 'warning',
          //   });
          //   return;
          // } else if (res1.txType == '4') {
          //   // txType=4提示“该卡已核销，不可更换”
          //   this.$alert('该卡已核销，不可更换', '提示', {
          //     confirmButtonText: '确定',
          //     type: 'warning',
          //   });
          //   return;
          // }
        } else {
          return;
        }
        // 若txType为2或5，调用14.2 换卡计费接口计算该笔业务费用，并在页面显示
        const res2 = await calculateCardReplacement({
          etcUserId: this.userInfo.etcUserId,
          vehicleNumber: this.vehicleInfo.vehicleNumber,
          vehicleColor: this.vehicleInfo.vehicleColor,
          newCardVersion: this.newCardForm.issueVersion,
          oldCardVersion: this.oldCardForm.issueVersion,
          newCardId: res.cardid,
          oldCardId: this.oldCardForm.obuSysID,
          buyChannel: this.newCardForm.txType === '5' ? '1' : '2', //1-自带 2-新购,
          freeEndDate: this.cardInfo.freeEndDate, // 旧卡片保修期截止日
          isDmage: this.oldCardForm.destroy ? '2' : '1', //1-否,2-是
        });
        if (res2) {
          // 收费按钮状态变为可用
          this.disabledReadOld = true;
          this.disabledReadNew = true;
          this.disabledConfirmPrintId = true;
          if (this.oldIsDestroyed) {
            // 旧卡已核销，旧卡核销是在收费后面的，所以不需要再收费了
            this.disabledFee = true;
            this.disabledDistroyOld = true;
            this.disabledChangeNew = false;
            this.due = getFormatAmount(res2.price);
            this.oldDue = this.due;
          } else {
            // 旧卡可核销，需要收费
            this.price = res2.price;
            this.due = getFormatAmount(res2.price);
            this.disabledFee = false;
            this.oldDue = this.due;
          }
          if (this.isChangeCard) {
            this.newPrice = res2.price;
            this.initChangeCard();
          }
        }
      };
      const res = readCard(
        btnLoading,
        false,
        successFunc,
        this.readNewCard,
        failObj
      );
    },
    // 收费
    async fee() {
      //TODO 支付方式后台获取还是写在前台?
      if (!this.payMode) {
        this.$alert('请选择支付方式', '提示', {
          confirmButtonText: '确定',
          type: 'warning',
        });
        return;
      }
      // 选择支付方式，点击收费按钮，调后台8.4.订单收费接口完成收费记账
      const applyType = await getDicCodeByDes(dicKeys.applyType, '换卡');
      const orderType = await getDicCodeByDes(dicKeys.orderType, '售后订单');
      const res = await orderCharges({
        etcUserId: this.userInfo.etcUserId,
        workOrderId: this.workOrderID,
        vehicleNumber: this.vehicleInfo.vehicleNumber,
        vehicleColor: this.vehicleInfo.vehicleColor,
        orderType,
        applyType,
        price: getFormatAmountYuan2Fen(this.due),
        payMode: this.payMode,
        isFree: this.specialFree ? '1' : '0', // 0-	收费，1-	免费
      });
      if (res) {
        // 收费前实收是0，收费后实收就和应收一样
        this.receive = this.due;
        // 收费完成后，核验新卡按钮状态变为不可用，核销旧卡按钮变为可用
        this.disabledFee = true;
        this.disabledReadNew = true;
        this.disabledDistroyOld = false;
      }
    },
    // 确认凭证
    async toConfirm() {
      this.disabledDistroyOld = true;
      // 一些传值获取确认
      let userCertType = await getDicDesByCode(
        dicKeys.userCertType,
        this.userInfo.userCertType
      );
      let vehicleColor = await getDicDesByCode(
        dicKeys.vehicleColor,
        this.vehicleInfo.vehicleColor
      );
      let vehicleType = await getDicDesByCode(
        dicKeys.vehicleUserClass,
        this.vehicleInfo.vehicleType
      );
      if (vehicleType) {
        if (vehicleType === '0 - 普通客车/普通货车') {
          if (this.vehicleInfo.vehicleCategory == '1') {
            vehicleType = '0 - 普通客车';
          } else if (this.vehicleInfo.vehicleCategory == '') {
            vehicleType = '';
          } else {
            vehicleType = '0 - 普通货车';
          }
        }
      }
      let vehicleClass = await getDicDesByCode(
        dicKeys.vehicleClass,
        this.vehicleInfo.vehicleClass
      );
      let cardType = await getDicDesByCode(
        dicKeys.cardType,
        this.cardInfo.cardType
      );
      let cardStatus = await getDicDesByCode(
        dicKeys.cardStatus,
        this.cardInfo.cardStatus
      );
      this.voucherConfirmData = {
        businessType: '卡片核销',
        userName: this.userInfo.userName,
        userCertType,
        userCode: this.userInfo.userCode,
        vehicleNumber: this.vehicleInfo.vehicleNumber,
        vehicleColor,
        vehicleType,
        vehicleClass,
        approvedAccount: this.vehicleInfo.approvedAccount,
        viTotalMass: this.vehicleInfo.viTotalMass,
        cardType,
        cardId: this.cardInfo.cardID,
        cardStatus,
        cardFreeEndDate: this.cardInfo.freeEndDate,
      };
      this.voucherConfirmVisiable = true;
      this.$nextTick(() => {
        //执行调用手写板
        this.$refs.mychild1.sendpad();
      });
    },
    async improveBranch(methodType) {
      console.log('重复调用improveBranch，methodType:', methodType); // 新建完分支机构后，再次调后台4.12.完善分支机构接口
      // 点击确定后调用后台4.12.完善分支机构接口，由系统自动进行完善处理
      let resPer, loading;
      try {
        loading = this.$loading();
        resPer = await perfectVehicleDepartment({
          etcUserId: this.userInfo.etcUserId,
          vehicleId: this.vehicleInfo.vehicleId,
        });
        loading.close();
      } catch (error) {
        loading.close();
      }
      if (resPer) {
        if (resPer.exCode == '9002') {
          // 如果4.12.完善分支机构接口返回9002，前端提示“该用户名下无有效默认分支机构，请新建”
          this.$confirm('该用户名下无有效默认分支机构，请新建', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            closeOnClickModal: false,
            closeOnPressEscape: false,
            type: 'warning',
          })
            .then(() => {
              // 点击确定后自动弹出新建分支机构的页面，引导操作员完成新建分支机构
              // this.methodType = 'mainChange';
              this.methodType = methodType;
              this.addvisble = true;
            })
            .catch(() => {
              //点击取消暂停业务
              this.loadingDistroyOld = false;
              this.disabledDistroyOld = false;
              this.disabledChangeNew = true;
              return;
            });
        }
        if (!resPer.exCode) {
          // 如果4.12.完善分支机构接口返回成功，再调一次14.3 换卡业务申请接口，后续流程继续
          console.log('完善分支机构没问题-!exCode');
          this.addbranchsMethod = methodType;
        }
      } else {
        //接口异常
        this.loadingDistroyOld = false;
        this.disabledDistroyOld = false;
        this.disabledChangeNew = true;
      }
    },
    // 核销旧卡（用户在手写板上确认或操作员代用户确认后）
    async writeOff(resUploadLayerPic) {
      try {
        this.disabledDistroyOld = true;
        this.clickNoLoading = true;
        this.loadingDistroyOld = true;
        // 调后台12.9.修改工单接口上传确认凭证
        // let imgFrontIDConfirm = '';
        if (resUploadLayerPic) {
          let imgFrontIDConfirm = resUploadLayerPic.frontImgid;
          // 保存凭证图片
          const mediaType = await getDicCodeByDes(
            dicKeys.mediaType,
            '业务凭证'
          );
          const imgType = await getDicCodeByDes(dicKeys.imgType, '业务凭证');
          const ImageInfoConfirm = {
            mediaType,
            imgType,
            imgFrontID: imgFrontIDConfirm,
          };
          const res0 = await updateWorkOrder({
            workOrderID: this.workOrderID,
            modifyInfo: { imagelist: [ImageInfoConfirm] },
          });
        }
        if (this.isGood) {
          // 好卡，需要读卡，改有效期
          // 再次读卡，确认读取到的卡号和第（1）步核验旧卡步骤中的卡号是否一致
          const self = this;
          const res = (function writeOffReadCard() {
            let failObj = {
              msg: '读卡失败。<br>点[重试]按钮重试。',
              confirmButtonText: '重试',
              cancelButtonText: '取消',
              cancelCatch: async () => {
                return;
              },
            };
            let successFunc = (res) => {
              if (res.cardid != self.oldCardForm.obuSysID) {
                // 若不一致，提示“卡号不一致，请确认旧卡片“
                self
                  .$alert('卡号不一致，请确认旧卡片', '提示', {
                    confirmButtonText: '确定',
                    showClose: false,
                    type: 'warning',
                  })
                  .catch(() => {
                    return false;
                  });
                return false;
              } else {
                return true;
              }
            };
            const res = readCard(
              self.loadingDistroyOld,
              false,
              successFunc,
              self.writeOff,
              failObj
            );
            return res;
          })();
          // 若核验卡号一致，且旧卡如果是好卡，需要改旧卡有效期。只要能读出来的，都要改有效期
          if (res) {
            // 调后台9.3.有效期过期申请接口申请数据
            const res1 = await changeValidityApply({
              vehicleNumber: this.vehicleInfo.vehicleNumber,
              vehicleColor: this.vehicleInfo.vehicleColor,
              cardId: res.cardid,
              cardVerNo: res.issueversion,
              // cardId: '0131002714297278',
              // cardVerNo: '00',
            });
            if (res1) {
              // 调客户端框架的2.6 卡二发接口，将卡片有效期改为已过期
              const resTry = await this.reTryIssueCard(res, res1, 'writeOff');
              console.log('resTry', resTry);
              if (!this.isEmptyObj(resTry) && resTry.code == '0') {
                // 调2.6 卡二发接口成功
                // 再调后台的9.4.有效期过期确认接口，完成修改有效期操作。
                const res3 = await changeValidityConfrim({
                  vehicleNumber: this.vehicleInfo.vehicleNumber,
                  vehicleColor: this.vehicleInfo.vehicleColor,
                  cardId: res.cardid,
                });
                if (res3 && res3.result == '1') {
                  // 前端继续调后台14.3 换卡业务申请接口。
                  this.isValidity = '2';
                  const res2 = await changeCard({
                    etcUserId: this.userInfo.etcUserId,
                    workOrderId: this.workOrderID,
                    oldCardId: this.oldCardForm.obuSysID,
                    newCardId: this.newCardForm.obuSysID,
                    vehicleNumber: this.vehicleInfo.vehicleNumber,
                    vehicleColor: this.vehicleInfo.vehicleColor,
                    price: this.price,
                    payMode: this.payMode,
                    userName: this.userInfo.userName,
                    userCode: this.userInfo.userCode,
                    userCertType: this.userInfo.userCertType,
                    deliveryMode: '2',
                    buyChannel: this.newCardForm.txType === '5' ? '1' : '2', //1-自带 2-新购
                    freeEndDate: this.cardInfo.freeEndDate,
                    isDmage: this.oldCardForm.destroy ? '2' : '1',
                    isBartender: this.oldCardForm.expird ? '2' : '1',
                    isValidity: this.isValidity, // 改有效期成功了才去调换卡/换签接口，也就是这里始终是传‘2’
                    newCardVersion: this.newCardForm.issueVersion,
                    oldCardVersion: this.oldCardForm.issueVersion,
                  });
                  if (res2) {
                    if (res2.exCode == '9001') {
                      // 如果14.3 换卡业务申请接口返回9001
                      this.$confirm(
                        '代理人信息异常，正在完善分支机构，请稍等',
                        '提示',
                        {
                          confirmButtonText: '确定',
                          showCancelButton: false,
                          closeOnClickModal: false,
                          closeOnPressEscape: false,
                          showClose: false,
                          type: 'warning',
                        }
                      )
                        .then(async () => {
                          this.improveBranch('mainChange');
                          // // 点击确定后调用后台4.12.完善分支机构接口，由系统自动进行完善处理
                          // const resPer = await perfectVehicleDepartment({
                          //   etcUserId: this.userInfo.etcUserId,
                          //   vehicleId: this.vehicleInfo.vehicleId,
                          // });
                          // if (resPer) {
                          //   if (resPer.exCode == '9002') {
                          //     // 如果4.12.完善分支机构接口返回9002，前端提示“该用户名下无有效默认分支机构，请新建”
                          //     this.$alert(
                          //       '该用户名下无有效默认分支机构，请新建',
                          //       '提示',
                          //       {
                          //         confirmButtonText: '确定',
                          //         showClose: false,
                          //         type: 'warning',
                          //       }
                          //     ).then(() => {
                          //       // 点击确定后自动弹出新建分支机构的页面，引导操作员完成新建分支机构
                          //       this.methodType = 'mainChange';
                          //       this.addvisble = true;
                          //     });
                          //   }
                          //   if (!resPer.exCode) {
                          //     console.log('完善分支机构没问题-!exCode');
                          //     this.mainChange();
                          //   }
                          // } else {
                          //   //接口异常
                          //   this.loadingDistroyOld = false;
                          //   this.disabledDistroyOld = false;
                          //   this.disabledChangeNew = true;
                          // }
                        })
                        .catch(() => {
                          // 暂停业务
                          this.loadingDistroyOld = false;
                          return;
                        });
                    }
                    if (!res2.exCode) {
                      // if (false) {
                      // 核销完成后更换新卡按钮变为可用。
                      this.loadingDistroyOld = false;
                      this.disabledDistroyOld = true;
                      this.disabledChangeNew = false;
                    }
                  } else {
                    // console.log('resRenewal-resRenewal');
                    // 如果14.3 换卡业务申请接口返回失败，且旧卡是好卡，则恢复卡片效期
                    const resRenewal = await this.renewal(res);
                    if (resRenewal) {
                      this.loadingDistroyOld = false;
                      this.disabledDistroyOld = false;
                      this.disabledChangeNew = true;
                    }
                  }
                } else {
                  //接口异常
                  this.loadingDistroyOld = false;
                  this.disabledDistroyOld = false;
                  this.disabledChangeNew = true;
                }
              }
            }
          } else {
            // 标签ID不一致，请确认旧标签后可重新核销旧签
            this.loadingDistroyOld = false;
            this.disabledDistroyOld = false;
          }
        } else {
          console.log('坏卡坏卡');
          // 坏卡，不需要读卡，不用改有效期。
          // （旧卡是坏卡的话，因为前端无法修改有效期，后台接口内部需要下黑名单。）
          this.isValidity = '1';
          const res4 = await changeCard({
            etcUserId: this.userInfo.etcUserId,
            workOrderId: this.workOrderID,
            oldCardId: this.oldCardForm.obuSysID,
            newCardId: this.newCardForm.obuSysID,
            vehicleNumber: this.vehicleInfo.vehicleNumber,
            vehicleColor: this.vehicleInfo.vehicleColor,
            price: this.price,
            payMode: this.payMode,
            userName: this.userInfo.userName,
            userCode: this.userInfo.userCode,
            userCertType: this.userInfo.userCertType,
            deliveryMode: '2',
            buyChannel: this.newCardForm.txType === '5' ? '1' : '2', //1-自带 2-新购
            freeEndDate: this.cardInfo.freeEndDate,
            isDmage: this.oldCardForm.destroy ? '2' : '1',
            isBartender: this.oldCardForm.expird ? '2' : '1',
            isValidity: this.isValidity, // 在坏卡/坏签的情况下，是不去改有效期的，此时传否
            newCardVersion: this.newCardForm.issueVersion,
            oldCardVersion: this.oldCardForm.issueVersion,
          });
          if (res4) {
            if (res4.exCode == '9001') {
              // 如果14.3 换卡业务申请接口返回9001
              this.$confirm(
                '代理人信息异常，正在完善分支机构，请稍等',
                '提示',
                {
                  confirmButtonText: '确定',
                  showCancelButton: false,
                  closeOnClickModal: false,
                  closeOnPressEscape: false,
                  showClose: false,
                  type: 'warning',
                }
              )
                .then(async () => {
                  this.improveBranch('badChange');
                  //   // 点击确定后调用后台4.12.完善分支机构接口，由系统自动进行完善处理
                  //   const resPer = await perfectVehicleDepartment({
                  //     etcUserId: this.userInfo.etcUserId,
                  //     vehicleId: this.vehicleInfo.vehicleId,
                  //   });
                  //   if (resPer) {
                  //     if (resPer.exCode == '9002') {
                  //       // 如果4.12.完善分支机构接口返回9002，前端提示“该用户名下无有效默认分支机构，请新建”
                  //       this.$alert(
                  //         '该用户名下无有效默认分支机构，请新建',
                  //         '提示',
                  //         {
                  //           confirmButtonText: '确定',
                  //           showClose: false,
                  //           type: 'warning',
                  //         }
                  //       ).then(() => {
                  //         // 点击确定后自动弹出新建分支机构的页面，引导操作员完成新建分支机构
                  //         this.methodType = 'badChange';
                  //         this.addvisble = true;
                  //       });
                  //     }
                  //     if (!resPer.exCode) {
                  //       console.log('完善分支机构没问题-!exCode');
                  //       this.badChange();
                  //     }
                  //   } else {
                  //     //接口异常
                  //     this.loadingDistroyOld = false;
                  //     this.disabledDistroyOld = false;
                  //     this.disabledChangeNew = true;
                  //   }
                })
                .catch(() => {
                  // 暂停业务
                  this.loadingDistroyOld = false;
                  return;
                });
            }
            if (!res4.exCode) {
              // 核销完成后更换新卡按钮变为可用。
              this.loadingDistroyOld = false;
              this.disabledDistroyOld = true;
              this.disabledChangeNew = false;
            }
          } else {
            //接口异常
            this.loadingDistroyOld = false;
            this.disabledDistroyOld = false;
            this.disabledChangeNew = true;
          }
        }
      } catch (error) {
        console.log('核销旧卡异常', error);
        this.loadingDistroyOld = false;
        this.disabledDistroyOld = false;
        this.disabledChangeNew = true;
      }
    },
    // 新建分支机构回调方法
    // addbranchsMethod(callBack) {
    //   callBack();
    // },

    // 更换新卡
    changeNew() {
      let failObj = {
        msg: '读卡失败。<br>点[重试]按钮重试。',
        confirmButtonText: '重试',
        cancelButtonText: '取消',
        cancelCatch: () => {},
      };
      let btnLoading = this.loadingChangeNew;
      let successFunc = async (res) => {
        // 点击更换新卡按钮，若卡号和核验新卡时读取的卡号不一致
        // 再次调后台7.3.查询卡/OBU一发信息接口判断，该新卡属于自有卡还是新购卡片
        if (res.cardid != this.newCardForm.obuSysID) {
          const res1 = await queryCardObuOneSendInfo({ obuSysID: res.cardid });
          // res1.txType = '5';
          if (res1.txType != this.newCardForm.txType) {
            // 若此处新卡类型和核验新卡时的类型不一致，
            // 提示“本次换卡按照***收费，当前卡片为***，不能发行”（***替换成自有卡/新购卡片）
            const oldTxType = await getDicEasyDesByCode(
              dicKeys.newCardType,
              this.newCardForm.txType
            );
            const newTxType = await getDicEasyDesByCode(
              dicKeys.newCardType,
              res1.txType
            );
            this.tip = `本次换卡按照${oldTxType}收费，当前卡片为${newTxType}，不能发行`;
          }
        } else {
          // 若一致，调后台9.1.设备空发/激活数据申请接口申请空发数据，
          const orderType = await getDicCodeByDes(
            dicKeys.orderType,
            '售后订单'
          );
          const msgType = await getDicCodeByDes(dicKeys.msgType, '空发申请');
          const res2 = await v1PreIssueApply({
            etcUserId: this.userInfo.etcUserId,
            workOrderID: this.workOrderID,
            orderType,
            vehicleNumber: this.vehicleInfo.vehicleNumber,
            vehicleColor: this.vehicleInfo.vehicleColor,
            msgType,
            cardId: this.newCardForm.obuSysID,
            cardVerNo: this.newCardForm.issueVersion,
            obuSign: '2',
          });
          if (res2) {
            // 然后调客户端框架2.6卡二发接口完成发行
            const resTry = await this.reTryIssueCard(res, res2, 'changeNew');
            console.log('resTry0', resTry);
            if (!this.isEmptyObj(resTry) && resTry.code == '0') {
              console.log('resTry1', resTry);
              // 调2.6 卡二发接口成功
              // 再调后台9.2. 设备空发/激活确认接口完成空发确认
              const orderType = await getDicCodeByDes(
                dicKeys.orderType,
                '售后订单'
              );
              const msgType = await getDicCodeByDes(
                dicKeys.msgType,
                '空发申请'
              );
              const ensureRes = await v1PreIssueConfirm({
                etcUserId: this.userInfo.etcUserId,
                workOrderID: this.workOrderID,
                orderType,
                vehicleNumber: this.vehicleInfo.vehicleNumber,
                vehicleColor: this.vehicleInfo.vehicleColor,
                cardId: this.newCardForm.obuSysID,
                msgType,
              });
              if (ensureRes) {
                if (ensureRes.result == '1') {
                  // 成功
                  this.$alert('换卡成功', '提示', {
                    confirmButtonText: '确定',
                    showClose: false,
                    type: 'success',
                  }).then(async () => {
                    this.disabledChangeNew = true;
                    // // 通过综合查询，获取新卡信息，并缓存
                    // const resCompre = await requestCompre({
                    //   cardId: this.newCardForm.obuSysID,
                    // });
                    // if (resCompre) {
                    //   await this.$store.dispatch(
                    //     'idbChangeCard/GetNewCard',
                    //     resCompre.cardInfo
                    //   );
                    // }
                    this.$router.push({
                      path: '/changecard',
                      query: {
                        cardId: this.newCardForm.obuSysID,
                        // amount: this.receive,
                        // payMode: this.payMode,
                        step: 'changecardmain',
                        // rtn: 'changsecardmain',
                        workOrderID: this.workOrderID,
                        cdif: this.cdif,
                        changeCardData: this.changeCardData,
                        isChangeCard: this.isChangeCard,
                        etcUserId: this.etcUserId,
                        newVehicleNumber: this.newVehicleNumber,
                        newVehicleColor: this.newVehicleColor,
                        specialfree: this.$route.query.specialfree,
                      },
                    });
                  });
                } else {
                  // 失败
                  this.$alert('更换新卡失败', '提示', {
                    confirmButtonText: '确定',
                    type: 'warning',
                  });
                }
              }
              this.loadingChangeNew = false;
            }
            // else if (resTry === false) {
            //   // 操作员在是否重试写设备的时候，
            //   // 操作员选择否
            //   this.loadingChangeNew = false;
            //   this.disabledDistroyOld = true;
            //   this.disabledChangeNew = false;
            // }
          }
        }
      };
      const res = readCard(
        btnLoading,
        false,
        successFunc,
        this.changeNew,
        failObj
      );
    },
    async reTryIssueCard(resCard, resFile, methodType) {
      if (this.isEmptyObj(resFile.fileContent16)) {
        let fileContent16 = {};
        fileContent16.fileContent = '';
        fileContent16.startIndex = '0';
        fileContent16.length = '0';
        resFile.fileContent16 = fileContent16;
      }
      let issueCardRes = undefined;
      this.timer = setTimeout(() => {
        console.log('定时器-issueCardRes', issueCardRes);
        this.loadingDistroyOld = false;
        this.loadingChangeNew = false;
        return;
      }, 20000);
      issueCardRes = await issueCard(resCard, resFile);
      // console.log('定时器后后后-issueCardRes', issueCardRes);
      if (!issueCardRes || issueCardRes.code != '0') {
        await this.$confirm(
          '调卡片发行接口失败，是否重试？提示信息：' +
            (issueCardRes && issueCardRes.msg),
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
        )
          .then(() => {
            if (methodType === 'renewal') {
              this.renewal(resCard);
              this.loadingDistroyOld = true;
            } else {
              if (methodType === 'writeOff') {
                this.loadingDistroyOld = true;
              } else if (methodType === 'changeNew') {
                this.loadingChangeNew = true;
              }
              this.reTryIssueCard(resCard, resFile, methodType);
            }
            // return 'reTry';
            // resolve(true);
          })
          .catch(async (err) => {
            if (methodType === 'writeOff') {
              // 这里给操作员是否重试的选项，
              // 操作员选择否，就不改有效期了，调换卡业务申请接口，改有效期标志传否
              this.isValidity = '1';
              const resChange = await changeCard({
                etcUserId: this.userInfo.etcUserId,
                workOrderId: this.workOrderID,
                oldCardId: this.oldCardForm.obuSysID,
                newCardId: this.newCardForm.obuSysID,
                vehicleNumber: this.vehicleInfo.vehicleNumber,
                vehicleColor: this.vehicleInfo.vehicleColor,
                price: this.price,
                payMode: this.payMode,
                userName: this.userInfo.userName,
                userCode: this.userInfo.userCode,
                userCertType: this.userInfo.userCertType,
                deliveryMode: '2',
                buyChannel: this.newCardForm.txType === '5' ? '1' : '2', //1-自带 2-新购
                freeEndDate: this.cardInfo.freeEndDate,
                isDmage: this.oldCardForm.destroy ? '2' : '1',
                isBartender: this.oldCardForm.expird ? '2' : '1',
                isValidity: this.isValidity, // 改有效期标志传否
                newCardVersion: this.newCardForm.issueVersion,
                oldCardVersion: this.oldCardForm.issueVersion,
              });
              if (resChange) {
                if (resChange.exCode == '9001') {
                  // 如果14.3 换卡业务申请接口返回9001
                  this.$confirm(
                    '代理人信息异常，正在完善分支机构，请稍等',
                    '提示',
                    {
                      confirmButtonText: '确定',
                      showCancelButton: false,
                      closeOnClickModal: false,
                      closeOnPressEscape: false,
                      showClose: false,
                      type: 'warning',
                    }
                  )
                    .then(async () => {
                      this.improveBranch('retryCancelChange');
                      // // 点击确定后调用后台4.12.完善分支机构接口，由系统自动进行完善处理
                      // const resPer = await perfectVehicleDepartment({
                      //   etcUserId: this.userInfo.etcUserId,
                      //   vehicleId: this.vehicleInfo.vehicleId,
                      // });
                      // if (resPer) {
                      //   if (resPer.exCode == '9002') {
                      //     // 如果4.12.完善分支机构接口返回9002，前端提示“该用户名下无有效默认分支机构，请新建”
                      //     this.$alert(
                      //       '该用户名下无有效默认分支机构，请新建',
                      //       '提示',
                      //       {
                      //         confirmButtonText: '确定',
                      //         showClose: false,
                      //         type: 'warning',
                      //       }
                      //     ).then(() => {
                      //       // 点击确定后自动弹出新建分支机构的页面，引导操作员完成新建分支机构
                      //       this.methodType = 'retryCancelChange';
                      //       this.addvisble = true;
                      //     });
                      //   }
                      //   if (!resPer.exCode) {
                      //     console.log('完善分支机构没问题-!exCode');
                      //     this.retryCancelChange();
                      //   }
                      // } else {
                      //   //接口异常
                      //   this.loadingDistroyOld = false;
                      //   this.disabledDistroyOld = false;
                      //   this.disabledChangeNew = true;
                      // }
                    })
                    .catch(() => {
                      // 暂停业务
                      this.loadingDistroyOld = false;
                      return;
                    });
                }
                if (!resChange.exCode) {
                  // 核销完成后更换新卡按钮变为可用。
                  this.loadingDistroyOld = false;
                  this.disabledDistroyOld = true;
                  this.disabledChangeNew = false;
                }
              } else {
                // 接口异常
                this.loadingDistroyOld = false;
                this.disabledDistroyOld = false;
                this.disabledChangeNew = true;
              }
            } else if (methodType === 'renewal') {
              // 操作员在是否重试写设备的时候，
              // 操作员选择否
              this.loadingDistroyOld = false;
              this.disabledDistroyOld = false;
              this.disabledChangeNew = true;
            } else if (methodType === 'changeNew') {
              // 操作员在是否重试写设备的时候，
              // 操作员选择否
              this.loadingChangeNew = false;
              this.disabledDistroyOld = true;
              this.disabledChangeNew = false;
            }
            // return false;
            // return err;
          });
      } else {
        console.log('else-issueCardRes', issueCardRes);
        return issueCardRes;
      }
    },
    // 有效期续期
    async renewal(resCard) {
      // 依次调后台9.5.有效期续期申请
      const resCardExpiryDate = await renewalValidity({
        vehicleNumber: this.vehicleInfo.vehicleNumber,
        vehicleColor: this.vehicleInfo.vehicleColor,
        cardId: resCard.cardid,
        cardVerNo: resCard.issueversion,
      });
      if (resCardExpiryDate) {
        // let fileContent16 = {};
        // fileContent16.fileContent = '';
        // fileContent16.startIndex = '0';
        // fileContent16.length = '0';
        // resCardExpiryDate.fileContent16 = fileContent16;
        // 客户端框架的2.6 卡二发
        const resTry = await this.reTryIssueCard(
          resCard,
          resCardExpiryDate,
          'renewal'
        );
        if (!this.isEmptyObj(resTry) && resTry.code == '0') {
          // 调2.6 卡二发接口成功
          // 和后台的9.6.有效期续期确认接口,将旧卡恢复有效期
          const res4 = await changeValidityRenewalConfrim({
            vehicleNumber: this.vehicleInfo.vehicleNumber,
            vehicleColor: this.vehicleInfo.vehicleColor,
            cardId: resCard.cardid,
          });
          if (res4 && res4.result === '1') {
            this.$alert('旧卡核销失败，卡片已恢复有效期', '提示', {
              confirmButtonText: '确定',
              type: 'warning',
            });
          }
          return true;
        }
        //  else if (resTry === false) {
        //   // 操作员在是否重试写设备的时候，
        //   // 操作员选择否
        //   return 'resTrycancel';
        // }
      } else {
        return true;
      }
    },
    async initChangeCard() {
      // 初始化继续办理换卡数据
      if (this.changeCardData.workOrderInfo.isCharge === '1') {
        console.log('加载继续办理换卡数据');
        this.disabledFee = true;
        this.isUsePayMode = true;
        this.payFlag = this.$route.query.payFlag;
        this.isFree = this.$route.query.isFree;
        if (this.isFree == '1') {
          // 是特许免费
          this.specialFree = true;
        } else {
          this.specialFree = false;
        }
        this.payMode = this.payMode;
        this.oprice = this.$route.query.price;
        console.log('price:', this.oprice);
        // 实收显示工单费用
        this.receive = getFormatAmount(this.oprice);
        // 应收显示计算费用
        if (this.specialFree) {
          this.due = '0.00'; // 特许免费，不管计费接口计算出来是多少，特许免费勾选后，应收都是0元
        } else {
          this.due = getFormatAmount(this.newPrice);
        }
        // if (this.newPrice.toString() !== this.oprice.toString()) {
        if (this.due != this.receive && !this.specialFree) {
          // 同时不是特许免费时
          this.disabledChangeNew = true;
          const tiptext =
            '本次换卡按照' +
            this.due +
            '元收费，当前卡片需收费' +
            this.receive +
            '元，不能发行';
          this.$confirm(tiptext, '提示', {
            confirmButtonText: '返回上级',
            cancelButtonText: '继续操作',
            type: 'warning',
            showClose: false,
          })
            .then(async () => {
              // 返回上级
              console.log('跳转抽屉页面');
              this.$router.push({
                path: '/changecard',
                query: {
                  isChangeCard: this.isChangeCard,
                  workOrderID: this.workOrderID,
                  payFlag: this.payFlag,
                  price: this.oprice,
                  payMode: this.payMode,
                  changeCardData: this.changeCardData,
                  cdif: this.cdif,
                  etcUserId: this.etcUserId,
                  newVehicleNumber: this.newVehicleNumber,
                  newVehicleColor: this.newVehicleColor,
                },
              });
            })
            .catch(() => {
              // 继续操作
              this.newCardForm.obuSysID = '';
              this.newCardForm.txType = '';
              this.newCardForm.issueVersion = '';
              this.disabledReadNew = false;
              this.due = '0.00';
              this.receive = '0.00';
            });
        } else {
          // 旧卡是否已核销
          if (this.changeCardData.oldCardInfo.status === '2') {
            this.disabledDistroyOld = true;
            this.disabledChangeNew = false;
          } else {
            this.disabledDistroyOld = false;
            this.disabledChangeNew = true;
          }
        }
        // 旧卡是否已核销
        // if (this.changeCardData.oldCardInfo.status === '2') {
        //   this.disabledDistroyOld = true;
        //   this.disabledChangeNew = false;
        // } else {
        //   this.disabledDistroyOld = false;
        //   this.disabledChangeNew = true;
        // }
      }
    },
  },
  async mounted() {
    console.log('userInfouserInfouserInfo2', this.userInfo.userName);
    // if (this.isEmptyObj(this.userInfo)) {
    //   this.$message.error('无法获取用户信息');
    // } else {
    // }
    if (!this.$route.query.workOrderID) {
      this.$message.error('不存在该工单号');
    } else {
      this.workOrderID = this.$route.query.workOrderID;
    }
    this.hasSpecialFreeAuth = this.$route.query.specialfree; // 特许免费是否有权限
    console.log('hasSpecialFreeAuth', this.hasSpecialFreeAuth);
    // 继续办理换卡初始化
    this.changeCardData = this.$route.query.changeCardData;
    this.payFlag = this.$route.query.payFlag;
    this.payMode = this.$route.query.payMode;
    this.payMode = '1';
    this.oprice = this.$route.query.price;
    this.cdif = this.$route.query.cdif;
    this.isChangeCard = this.$route.query.isChangeCard;
    this.etcUserId = this.$route.query.etcUserId;
    this.newVehicleNumber = this.$route.query.newVehicleNumber;
    this.newVehicleColor = this.$route.query.newVehicleColor;
  },
  destroyed() {
    clearTimeout(this.timer);
  },
};
</script>