<!-- 首页 -->
<template>
  <div class="offline-accountwriteoff">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-accountwriteoff_title">账户注销</h4>
        </h4>
      </div>
    </div>
    <div class="o-flex offline-accountwriteoff_block-wrap">
      <div class="offline-accountwriteoff_block">
        <div class="offline-accountwriteoff_title-wrap">
          <span class="offline-accountwriteoff_title-desc">账户信息</span>
        </div>
        <div class="o-flex-column offline-accountwriteoff_content-wrap">
          <div class="offline-accountwriteoff_content-top">
            <el-row :gutter="0" class="offline-accountwriteoff_content-row">
              <el-col :xl="4" :lg="4" :md="6">用户名称</el-col>
              <!-- <el-col :xl="20" :lg="20" :md="18" class="offline-accountwriteoff_content-row-detailcontent">啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥啥</el-col> -->
              <el-col :xl="20" :lg="20" :md="18">{{
                account.userName
                }}</el-col>
            </el-row>
          </div>
          <div class="offline-accountwriteoff_content-bottom">
            <div class="offline-accountwriteoff_content offline-accountwriteoff_content-left">
              <el-row :gutter="0" class="offline-accountwriteoff_content-row">
                <el-col :xl="8" :lg="12" :md="12">账户类型</el-col>
                <el-col :xl="16" :lg="12" :md="12">{{
                  account.useracctTypeDesc
                  }}</el-col>
              </el-row>
              <el-row :gutter="0" class="offline-accountwriteoff_content-row">
                <el-col :xl="8" :lg="12" :md="12">签约银行</el-col>
                <el-col :xl="16" :lg="12" :md="12">{{
                  account.paychannelName
                  }}</el-col>
              </el-row>
              <el-row :gutter="0" class="offline-accountwriteoff_content-row">
                <el-col :xl="8" :lg="12" :md="12">挂账金额</el-col>
                <el-col :xl="16" :lg="12" :md="12" class="offline-accountwriteoff_content-row-amount">{{
                  account.creditfee | amount
                  }}</el-col>
              </el-row>
              <el-row :gutter="0" class="offline-accountwriteoff_content-row">
                <el-col :xl="8" :lg="12" :md="12">消费限额</el-col>
                <el-col :xl="16" :lg="12" :md="12" class="offline-accountwriteoff_content-row-amount">{{
                  account.overLimit | amount
                  }}</el-col>
              </el-row>
              <!-- <el-row :gutter="0" class="offline-accountwriteoff_content-row">
              <el-col :xl="8" :lg="12" :md="12">累计欠费金额</el-col>
              <el-col :xl="16" :lg="12" :md="12" class="offline-accountwriteoff_content-row-amount">{{
                account.overdraftTotal | amount
              }}</el-col>
            </el-row> -->
              <el-row :gutter="0" class="offline-accountwriteoff_content-row">
                <el-col :xl="8" :lg="12" :md="12">可疑未清算金额</el-col>
                <el-col :xl="16" :lg="12" :md="12" class="offline-accountwriteoff_content-row-amount">{{
                  account.susTxnfee | amount
                  }}</el-col>
              </el-row>
              <el-row :gutter="0" class="offline-accountwriteoff_content-row">
                <el-col :xl="8" :lg="12" :md="12">账户下开通设备数</el-col>
                <el-col :xl="16" :lg="12" :md="12">{{
                  account.issueNum
                  }}</el-col>
              </el-row>
            </div>
            <div class="offline-accountwriteoff_content offline-accountwriteoff_content-right">
              <el-row :gutter="0" class="offline-accountwriteoff_content-row">
                <el-col :xl="8" :lg="12" :md="12">账户编号</el-col>
                <el-col :xl="16" :lg="12" :md="12">{{
                  account.userAcctid
                  }}</el-col>
              </el-row>
              <!-- <el-row :gutter="0" class="offline-accountwriteoff_content-row">
              <el-col :xl="8" :lg="12" :md="12">账户名称</el-col>
              <el-col :xl="16" :lg="12" :md="12">{{
                account.accountAlias
              }}</el-col>
            </el-row> -->
              <el-row :gutter="0" class="offline-accountwriteoff_content-row">
                <el-col :xl="8" :lg="12" :md="12">账户状态</el-col>
                <el-col :xl="16" :lg="12" :md="12">{{
                  account.useracctStatus
                  }}</el-col>
              </el-row>
              <el-row :gutter="0" class="offline-accountwriteoff_content-row">
                <el-col :xl="8" :lg="12" :md="12">账户余额</el-col>
                <el-col :xl="16" :lg="12" :md="12" class="offline-accountwriteoff_content-row-amount">{{
                  account.balance | amount
                  }}</el-col>
              </el-row>
              <el-row :gutter="0" class="offline-accountwriteoff_content-row">
                <el-col :xl="8" :lg="12" :md="12">圈存金额</el-col>
                <el-col :xl="16" :lg="12" :md="12" class="offline-accountwriteoff_content-row-amount">{{
                  account.consumeLimit | amount
                  }}</el-col>
              </el-row>
              <el-row :gutter="0" class="offline-accountwriteoff_content-row">
                <el-col :xl="8" :lg="12" :md="12">警告限额</el-col>
                <el-col :xl="16" :lg="12" :md="12" class="offline-accountwriteoff_content-row-amount">{{
                  account.noticeLimit | amount
                  }}</el-col>
              </el-row>

            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="offline-accountwriteoff_bottom-wrap">
      <el-button class="offline-accountwriteoff_bottom-button" size="large" type="danger" @click="toSettle"
        :loading="loading" round>
        账户注销
      </el-button>
      <!-- <el-button
        class="offline-accountwriteoff_bottom-button"
        size="large"
        type="danger"
        @click="childMethod" 
        round
      >
     test
      </el-button> -->
      <!-- <el-button type="primary"  @click="voucherVisiable = true" >111</el-button> -->
    </div>
    <el-dialog :title="dialogSettleTitle" class="offline-dialog offline-accountwriteoff_dialogSettle"
      :visible.sync="dialogSettleVisible" :append-to-body="true" :close-on-click-modal="false" @open="clearFormSettle"
      @closed="closedSettle">
      <!-- @opened="initFormSettleEnd" -->
      <div class="o-flex offline-accountwriteoff_dialogSettle-content-wrap">
        <el-form ref="form" :model="form" :rules="rules" :validate-on-rule-change="false"
          class="offline-accountwriteoff_dialogSettle-content-form">
          <div class="offline-accountwriteoff_dialogSettle-content-upper">
            <el-row :gutter="55">
              <el-col :md="12" :lg="12">
                <el-form-item label="预约结清日期" prop="settleDate">
                  <el-date-picker v-model="form.settleDate" type="date" placeholder="选择日期" format="yyyy 年 MM 月 dd 日"
                    :picker-options="expireTimeOption" readonly>
                  </el-date-picker>
                </el-form-item>
              </el-col>
              <!-- <el-col :md="5" :lg="5" prop="invoice" class="offline-accountwriteoff_dialogSettle-content-upper-checkbox">
          <el-form-item>
              <el-checkbox label="发票登记" v-model="form.invoice"></el-checkbox>
          </el-form-item>
          </el-col> -->
              <el-col :md="4" :lg="4" prop="refund" class="offline-accountwriteoff_dialogSettle-content-upper-checkbox">
                <el-form-item>
                  <el-checkbox label="放弃退款" v-model="form.refund" @change="refundChange"></el-checkbox>
                </el-form-item>
              </el-col>
            </el-row>
          </div>
          <div class="offline-accountwriteoff_dialogSettle-content-lower">
            <div class="offline-accountwriteoff_dialogSettle-content-lower-title">
              <span>退款接收账户</span>
            </div>
            <div class="mb20">请上传银行卡</div>
            <div class="o-flex mb20">
              <photograph-block type="bankCardType" is-button width="104" height="104" label="本地上传" default-type="6011"
                :append-to-body="true" no-select="local" @complete="selectedPic2($event, 'local')" class="ml10 mr20"
                :isButtonDisabled="refundDisabled" :oloading.sync="oloading" ocr />
              <photograph-block type="bankCardType" is-button width="104" height="104" label="拍照上传" default-type="6011"
                :append-to-body="true" no-select="gpy" @complete="selectedPic2($event, 'gpy')"
                :isButtonDisabled="refundDisabled" :oloading.sync="oloading" ocr />
            </div>
            <div class="offline-home_dialog-content_pics o-flex o-flex-wrap">
              <photograph-block only-pics :default-pics="selectedPics2" @complete="selectedPic2($event, 'change')" />
            </div>
            <el-row :gutter="20">
              <el-col :md="12" :lg="12">
                <el-form-item label="所属省" prop="province">
                  <type-select type="province" v-model="form.province" class="o-width-full" :disabled="refundDisabled"
                    @change="provinceChange"></type-select>
                </el-form-item>
              </el-col>
              <el-col :md="12" :lg="12">
                <el-form-item label="所属市" prop="city">
                  <br>
                  <regex-input type="city" v-model="form.city" placeholder="请输入所属市" :disabled="refundDisabled">
                  </regex-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :md="12" :lg="12">
                <el-form-item label="银行名称" prop="bankName">
                  <el-input v-model="form.bankName" placeholder="请输入银行名称" :disabled="refundDisabled"></el-input>
                  <!-- <type-select
                      type="bankName"
                      v-model="form.bankName"
                      class="o-width-full"
                      :disabled="refundDisabled"
                    ></type-select> -->
                </el-form-item>
              </el-col>
              <el-col :md="12" :lg="12">
                <el-form-item label="账户名称" prop="bankAccountName">
                  <el-input v-model="form.bankAccountName" placeholder="请输入账户名称" :disabled="refundDisabled"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :md="12" :lg="12">
                <el-form-item label="账户号" prop="bankAccountID">
                  <br>
                  <!-- <el-input v-model="form.bankAccountID"  placeholder="请输入账户号" :disabled="refundDisabled"></el-input> -->
                  <regex-input type="bankId" v-model="form.bankAccountID" placeholder="请输入账户号"
                    :disabled="refundDisabled"></regex-input>
                </el-form-item>
              </el-col>
              <el-col :md="12" :lg="12">
                <el-form-item label="联系手机" prop="mobile">
                  <regex-input type="mobile" v-model="form.mobile" placeholder="请输入联系手机" :disabled="refundDisabled">
                  </regex-input>
                </el-form-item>
              </el-col>
            </el-row>
          </div>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogSettleVisible = false">取 消</el-button>
        <el-button type="primary" @click="settleConfirm">确 定</el-button>
      </span>
    </el-dialog>

    <el-dialog :title="dialogInvoiceTitle" class="offline-dialog offline-dialog-small"
      :visible.sync="dialogInvoiceVisible" :append-to-body="true" @open="clearFormInvoice">
      <div class="o-flex offline-accountwriteoff_dialogInvoice-content-wrap">
        <el-form ref="formInvoice" :model="formInvoice" :rules="rulesInvoice"
          class="offline-accountwriteoff_dialogInvoice-content-form">
          <el-row :gutter="20">
            <el-col :md="24" :lg="24">
              <el-form-item label="发票号码" prop="invoiceCode" required>
                <el-input v-model="formInvoice.invoiceCode"></el-input>
              </el-form-item>
            </el-col>
            <el-col :md="24" :lg="24">
              <el-form-item label="发票金额" prop="invoiceMoney" required>
                <el-input v-model="formInvoice.invoiceMoney"></el-input>
              </el-form-item>
            </el-col>
            <el-col :md="24" :lg="24">
              <el-form-item label="备注" prop="note" required>
                <el-input type="textarea" :rows="4" v-model="formInvoice.note"></el-input>
              </el-form-item>
            </el-col>
            <el-col :md="24" :lg="24" class="offline-accountwriteoff_dialogInvoice-content-radiogroup">
              <el-form-item>
                <el-radio-group v-model="formInvoice.invoiceType">
                  <el-radio label="客户提供发票"></el-radio>
                  <el-radio label="差额发票"></el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogInvoiceVisible = false">取 消</el-button>
        <el-button type="primary" @click="InvoiceConfirm">登 记</el-button>
      </span>
    </el-dialog>

    <voucher-layer-confirm ref="mychild1" :column="2" :info="voucherConfirmData" :keys="voucherConfirmKeys"
      :visible.sync="voucherConfirmVisiable" @closed="voucherConfirmClosed" @complete="writeoff">
    </voucher-layer-confirm>
    <voucher-layer ref="mychild2" :column="2" :info="voucherData" :footer="voucherFooter" :keys="voucherKeys"
      :visible.sync="voucherVisiable" :cancel-show="false" @complete="receiptComplete"></voucher-layer>
    <!-- <loading-button @click="btnRequest">111</loading-button> -->
  </div>
</template>

<script>
  import VoucherLayer from '@/components/VoucherLayer';
  import LoadingButton from '@/components/LoadingButton';
  import VoucherLayerConfirm from '@/components/VoucherLayerConfirm';
  import { accountOutHandle, queryAcctLogout } from '@/api/writeoff';
  import {
    createOrder,
    updateWorkOrder,
    systemParameterQuery,
    systemTime,
  } from '@/api/common';
  import { etcAccountQuery } from '@/api/user';
  import PhotographBlock from '@/components/PhotographBlock';
  import RegexInput from '@/components/RegexInput';
  import { validatePhone, validateCity, validateAmount } from '@/utils/validate';
  import { formatDate } from '@/utils/format';
  import { globalBus } from '@/utils/globalBus';
  import {
    dicKeys,
    getAllDics,
    getDicDesByCode,
    getDicCodeByDes,
    getDicCodeByAll,
    getDicDesByAll,
  } from '@/methods/dics';
  export default {
    data() {
      return {
        expireTimeOption: {
          disabledDate(date) {
            return date.getTime() <= Date.now();
          },
        },
        selectedPics2: [],
        defaultPic: [],
        account: {},
        workOrderID: '', // 工单号
        dialogSettleTitle: '账户结清登记',
        dialogInvoiceTitle: '发票登记',
        dialogSettleVisible: false,
        dialogInvoiceVisible: false,
        bankCardImageList: [], // 核验证件图片信息
        workOrderIDConfirm: '', // 确认凭证工单号
        workOrderIDReceipt: '', // 回执凭证工单号
        imgFrontIDConfirm: '', // 确认凭证前置图片id
        imgFrontIDReceipt: '', // 回执凭证前置图片id
        note0: '用户选择放弃账户余额', // 备注0
        note1: '若账户结清后有余额，将在28个自然日内退至您的银行账户', // 备注1
        // note2: '用户已放弃退款',// 备注2
        form: {
          settleDate: '',
          province: '',
          city: '',
          bankName: '',
          bankAccountName: '',
          bankAccountID: '',
          mobile: '',
          invoice: '',
          refund: '',
          // init:true,
        },
        loading: false,
        oloading: false,
        settleConfirmFlag: false,
        refundRequired: true,
        // dateRequired:true,
        refundDisabled: true,
        formInvoice: {
          invoiceCode: '',
          invoiceMoney: '',
          note: '',
          invoiceType: '客户提供发票',
        },
        rulesInvoice: {
          invoiceCode: [
            { required: true, message: '请输入发票号码', trigger: 'blur' },
            { max: 64, message: '长度不能超过64个字符', trigger: 'blur' },
          ],
          invoiceMoney: [
            { required: true, message: '请输入发票金额', trigger: 'blur' },
            { max: 8, message: '长度不能超过8个字符', trigger: 'blur' },
            { validator: validateAmount, trigger: 'blur' },
          ],
          note: [
            { required: true, message: '请输入备注', trigger: 'blur' },
            { max: 500, message: '长度不能超过500个字符', trigger: 'blur' },
          ],
        },
        voucherConfirmData: {},
        // voucherConfirmFooter:{},
        voucherConfirmKeys: [
          [{ key: 'businessType', label: '业务类型' }],
          // [{ key: 'etcUserId', label: 'ETC用户ID' }],
          [
            { key: 'userName', label: '用户名称', span: 2 },
            { key: 'userCertType', label: '证件类型' },
            { key: 'userCode', label: '证件号码' },
          ],
          [
            { key: 'useracctType', label: '账户类型' },
            { key: 'province', label: '所属省' },
            { key: 'city', label: '所属市' },
            {
              key: 'bankName',
              label: '银行名称',
              color: 'blue',
              fontWeight: 'bold',
            },
            {
              key: 'bankAccountName',
              label: '账户名称',
              color: 'blue',
              fontWeight: 'bold',
            },
            {
              key: 'bankAccountID',
              label: '银行卡号',
              color: 'blue',
              fontWeight: 'bold',
            },
            {
              key: 'mobile',
              label: '联系手机',
              color: 'blue',
              fontWeight: 'bold',
            },
          ],
          [
            {
              key: 'note1',
              label: '备注',
              span: 2,
              color: 'red',
              fontSize: '20px',
              fontWeight: '600',
            },
            // { key: 'note2', label: '备注2' },
          ],
        ],
        // voucherDataCompleted: {}, // 回执凭证点击确认后备份的voucherData
        voucherData: {},
        voucherFooter: {},
        voucherKeys: [
          [{ key: 'businessType', label: '业务类型' }],
          // [{ key: 'etcUserId', label: 'ETC用户ID' }],
          [
            { key: 'userName', label: '用户名称', span: 2 },
            { key: 'userCertType', label: '证件类型' },
            { key: 'userCode', label: '证件号码' },
          ],
          [
            { key: 'useracctType', label: '账户类型' },
            { key: 'province', label: '所属省' },
            { key: 'city', label: '所属市' },
            { key: 'bankName', label: '银行名称' },
            { key: 'bankAccountName', label: '账户名称' },
            { key: 'bankAccountID', label: '银行卡号' },
            { key: 'mobile', label: '联系手机' },
          ],
          [
            {
              key: 'note1',
              label: '备注',
              span: 2,
              color: 'red',
              fontSize: '20px',
              fontWeight: '600',
            },
            // { key: 'note2', label: '备注2' },
          ],
        ],
        voucherConfirmVisiable: false,
        voucherVisiable: false,
        voucherConfirmConfirmFlag: false,
        userAccountId: '',
        voucherConfirmFlag: false, // 确认凭证标志（已确认true,未确认false）
        voucherFlag: false, // 回执凭证标志（已确认true,未确认false）
        timer1: false, //
      };
    },
    components: {
      VoucherLayer,
      VoucherLayerConfirm,
      PhotographBlock,
      RegexInput,
      LoadingButton,
    },
    computed: {
      // vehicleInfo() {
      //   return this.$store.getters.searchCarInfo;
      // },
      // obuInfo() {
      //   return this.$store.getters.searchObuInfo;
      // },
      // cardInfo() {
      //   return this.$store.getters.searchCardInfo;
      // },
      userInfo() {
        return this.$store.getters.searchUserInfo;
      },
      rules() {
        return {
          // settleDate: [
          //   { required: this.dateRequired, message: '请输入预约结清日期', trigger: 'blur' },
          // ],
          province: [
            {
              required: this.refundRequired,
              message: '请选择所属省',
              trigger: 'change',
            },
          ],
          city: [
            {
              required: this.refundRequired,
              message: '请输入所属市',
              trigger: 'blur',
            },
            { max: 32, message: '长度不能超过32个字符', trigger: 'blur' },
            // { validator: validateCity, trigger: 'blur' },
          ],
          bankName: [
            {
              required: this.refundRequired,
              message: '请输入银行名称',
              trigger: 'blur',
            },
            { max: 64, message: '长度不能超过64个字符', trigger: 'blur' },
          ],
          bankAccountName: [
            {
              required: this.refundRequired,
              message: '请输入账户名称',
              trigger: 'blur',
            },
            { max: 64, message: '长度不能超过64个字符', trigger: 'blur' },
          ],
          bankAccountID: [
            {
              required: this.refundRequired,
              message: '请输入账户号',
              trigger: 'blur',
            },
            { max: 32, message: '长度不能超过32个字符', trigger: 'blur' },
          ],
          mobile: [
            {
              required: this.refundRequired,
              message: '请输入联系手机',
              trigger: 'blur',
            },
            { max: 13, message: '长度不能超过13个字符', trigger: 'blur' },
            { validator: validatePhone, trigger: 'blur' },
          ],
        };
      },
    },
    watch: {
      userInfo: function (val, oldVal) {
        this.getAccount();
      },
    },
    methods: {
      // btnRequest() {
      //   systemTime();
      //   systemTime();
      //   systemTime();
      //   systemTime();
      // },
      childMethod() {
        globalBus.$emit('clickToSearch');
      },
      selectedPic2(pics, type) {
        if (type === 'change') {
          this.selectedPics2 = [...pics];
        } else {
          this.selectedPics2 = [...pics];
          const self = this;
          // self.$set(self.form, 'bankAccountID','2222');
          // 获取识别结果，赋值显示
          const currentPic = pics[pics.length - 1];
          const ocr = pics[pics.length - 1].ocr;
          if (ocr) {
            if (ocr && currentPic.type === '601-1') {
              // 银行类型ocr识别
              self.$set(self.form, 'bankAccountID', ocr.bankCardNo);
              // self.$set(self.form, 'bankName', ocr.bankInfo);
            }
          }
        }
        this.$store.dispatch('GetBankCardImg', this.selectedPics2);
      },
      radioChange(label) { },
      // 放弃退款checkbox更新事件
      refundChange(checked) {
        this.$refs.form.clearValidate();
        if (checked) {
          this.form.province = '';
          this.form.city = '';
          this.form.bankName = '';
          this.form.bankAccountName = '';
          this.form.bankAccountID = '';
          this.form.mobile = '';
          this.refundRequired = false;
          // this.dateRequired = true;
          this.refundDisabled = true;
        } else {
          this.refundRequired = true;
          // this.dateRequired = true;
          this.refundDisabled = false;
        }
      },
      voucherConfirmClosed() {
        if (this.voucherConfirmConfirmFlag) {
          this.loading = true;
        } else {
          this.loading = false;
        }
      },
      // // 点击回执凭证抽屉完成按钮
      // toAccountWriteoff() {
      //   this.$router.push({
      //     path: '/accountWriteoff',
      //   });
      // },
      // 弹出确认凭证抽屉
      async toConfirm() {
        this.voucherConfirmConfirmFlag = false;
        this.loading = true;
        this.timer1 = setTimeout(async () => {
          if (!this.voucherConfirmFlag) {
            // 未确认
            // const bizCode = await getDicCodeByDes(
            //   dicKeys.bizCode,
            //   '账户注销工单'
            // );
            let res0;
            let userCertType = await getDicDesByCode(
              dicKeys.userCertType,
              this.userInfo.userCertType
            );
            let useracctType = await getDicDesByCode(
              dicKeys.useracctType,
              this.account.useracctType
            );
            // console.log('useracctType:'+useracctType)
            if (!this.form.refund) {
              // 用户不放弃退款，备注不需要加红加大加粗样式
              for (let i = 0; i < this.voucherConfirmKeys.length; i++) {
                for (let j = 0; j < this.voucherConfirmKeys[i].length; j++) {
                  if (this.voucherConfirmKeys[i][j].key === 'note1') {
                    this.voucherConfirmKeys[i][j].color = '';
                    this.voucherConfirmKeys[i][j].fontSize = '';
                    this.voucherConfirmKeys[i][j].fontWeight = '';
                  }
                }
              }
            }
            this.voucherConfirmData = {
              businessType: '账户注销',
              userName: this.userInfo.userName,
              userCertType,
              userCode: this.userInfo.userCode,
              useracctType,
              province: this.form.province,
              city: this.form.city,
              bankName: this.form.bankName,
              bankAccountName: this.form.bankAccountName,
              bankAccountID: this.$trim(this.form.bankAccountID),
              mobile: this.$trim(this.form.mobile),
              note1: this.form.refund ? this.note0 : this.note1,
              // note2: this.form.refund?this.note2:'',
            };
            this.dialogInvoiceVisible = false;
            this.voucherConfirmVisiable = true;
            this.$nextTick(() => {
              //执行调用手写板
              this.$refs.mychild1.sendpad();
            });
          } else {
            // 已确认
            this.writeoff();
          }
        }, 1);
      },
      // 点击注销按钮，弹出结清登记窗口
      async toSettle() {
        this.settleConfirmFlag = false; // 结清登记窗口未确认
        if (!this.userInfo.userID) {
          this.$message.info('无法获取当前用户信息,请查询！');
          return;
        }
        if (!this.account.userAcctid) {
          this.$message.warning('无法获取当前账户信息');
          return;
        }
        if (this.account.issueNum > 0) {
          this.$alert('当前账户下开通设备数大于0，无法注销', '提示', {
            confirmButtonText: '确定',
            type: 'warning',
          });
          return;
        }
        if (this.account.balance < 0) {
          this.$alert('当前账户欠费，无法注销', '提示', {
            confirmButtonText: '确定',
            type: 'warning',
          });
          return;
        }
        this.loading = true;

        const res = await this.setDate();
        try {
          if (res) {
            if (!this.voucherConfirmFlag) {
              // 确认凭证未确认
              this.dialogSettleVisible = true;
            } else {
              // 确认凭证已点击确认
              await this.settleConfirm();
            }
          } else {
            this.loading = false;
          }
        } catch (e) {
          this.loading = false;
        }
      },
      // 重置结清登记表单
      clearFormSettle() {
        if (this.$refs.form) {
          this.$refs.form.clearValidate();
        }
        // console.log('clearFormSettle')

        // this.form.settleDate = ''
        this.form.province = '';
        this.form.city = '';
        this.form.bankName = '';
        this.form.bankAccountName = '';
        this.form.bankAccountID = '';
        this.form.mobile = '';
        this.form.invoice = false;
        this.form.refund = false;
        this.refundDisabled = false;
        this.refundRequired = true;
        // this.dateRequired = true;
      },
      // initFormSettleEnd(){
      //   this.form.init = true;
      // },
      closedSettle() {
        if (this.settleConfirmFlag) {
          this.loading = true;
        } else {
          this.loading = false;
        }
      },
      // 重置发票表单
      clearFormInvoice() {
        if (this.$refs.formInvoice) {
          this.$refs.formInvoice.resetFields();
        }
      },
      // 结清登记表单确认
      async settleConfirm() {
        let self = this;
        self.settleConfirmFlag = true;
        this.loading = true;
        let promise = self.$refs.form.validate();
        promise
          .then(function () {
            // console.log('self.form.invoice:'+self.form.invoice);
            // console.log('self.form.refund:'+self.form.refund);
            if (self.form.refund) {
              // 勾选放弃退款
              self.$refs.form.clearValidate();
              self.$refs.form.validateField('settleDate');
            }
            if (self.form.invoice) {
              // 勾选发票登记
              self.dialogInvoiceVisible = true;
            } else {
              self.toConfirm();
            }
            self.dialogSettleVisible = false;
          })
          .catch(function (error) {
            self.loading = false;
            console.log('发生错误！', error);
          });
      },
      // 发票表单登记
      InvoiceConfirm() {
        let self = this;
        let promise = self.$refs.formInvoice.validate();
        promise
          .then(function () {
            self.toConfirm();
          })
          .catch(function (error) {
            console.log('发生错误！', error);
          });
      },
      //注销
      async writeoff(resUploadLayerPic) {
        this.voucherConfirmConfirmFlag = true;
        this.loading = true;
        // 保存凭证图片
        if (resUploadLayerPic) {
          this.imgFrontIDConfirm = resUploadLayerPic.frontImgid;
        }
        this.voucherConfirmVisiable = false;
        this.voucherConfirmFlag = true;
        try {
          // 调13.17.查询注销资格
          const res9 = await etcAccountQuery({
            userAccountId: this.userAccountId,
            etcUserId: this.userInfo.etcUserId,
          });
          let vm = this;
          if (res9 && res9.useracctStatus === '2') {
            // 账户已注销
            //（账户已注销，界面和签名版上没有取消）
            this.$alert('账户已注销', '提示', {
              confirmButtonText: '确定',
              type: 'info',
              showClose: false,
            }).then(() => {
              if (vm.voucherFlag) {
                //回执凭证已点击确认，但确认过程中断
                vm.receiptComplete();
              }
              vm.loading = false;
            });
            return;
          }
          if (!res9) {
            this.loading = false;
          }
          let self = this;
          self.form.mobile = this.$trim(self.form.mobile);
          self.form.settleDate = formatDate(
            'YYYYMMDD',
            new Date(self.form.settleDate.toDateString())
          );
          self.form.refund
            ? (self.form.noRefundFlag = '1')
            : (self.form.noRefundFlag = '0');
          // console.dir({...self.form,...self.formInvoice});
          self.formInvoice.invoiceType === '客户提供发票'
            ? (self.formInvoice.invoiceType = '0')
            : (self.formInvoice.invoiceType = '1');
          self.account.oldUserAcctID = self.account.userAcctid;
          self.account.userAcctID = self.account.userAcctid;
          // self.account.oldUserAcctID = "112233";
          console.log('self.account.oldUserAcctID:' + self.account.oldUserAcctID);
          const res0 = await accountOutHandle({
            ...self.account,
            ...self.form,
            ...self.formInvoice,
            etcUserId: this.userInfo.etcUserId,
          });
          // const res0 = {workOrderID:'332211'};
          if (res0) {
            let userCertType = await getDicDesByCode(
              dicKeys.userCertType,
              res0.userCertType
            );
            let useracctType = await getDicDesByCode(
              dicKeys.useracctType,
              res0.useracctType
            );
            let completeTime = await systemTime();
            if (!this.form.refund) {
              // 用户不放弃退款，备注不需要加红加大加粗样式
              for (let i = 0; i < this.voucherKeys.length; i++) {
                for (let j = 0; j < this.voucherKeys[i].length; j++) {
                  if (this.voucherKeys[i][j].key === 'note1') {
                    this.voucherKeys[i][j].color = '';
                    this.voucherKeys[i][j].fontSize = '';
                    this.voucherKeys[i][j].fontWeight = '';
                  }
                }
              }
            }
            if (completeTime) {
              self.voucherData = {
                businessType: '账户注销',
                userName: res0.userName,
                userCertType,
                userCode: res0.userCode,
                useracctType,
                province: res0.province,
                city: res0.city,
                bankName: res0.bankName,
                bankAccountName: res0.bankAccountName,
                bankAccountID: res0.bankAccountID,
                mobile: res0.mobile,
                note1: this.form.refund ? this.note0 : this.note1,
                // note2: this.form.refund?this.note2:'',
              };
              self.voucherFooter = {
                date: completeTime.systemTime,
                outletId: res0.netID,
                operator: res0.oprtID,
              };
              self.workOrderIDReceipt = res0.workOrderID;
              self.workOrderIDConfirm = res0.workOrderID;
              //判断是否需要重新弹出回执凭证
              // let voucherDataStr = JSON.stringify(self.voucherData);
              // let voucherDataCompletedStr = JSON.stringify(
              //   self.voucherDataCompleted
              // );
              // if (!self.voucherFlag) {
              //  // 回执未确认
              self.voucherVisiable = true;
              self.$nextTick(() => {
                //执行调用手写板
                self.$refs.mychild2.sendpad();
              });
              // } else {
              //   // 回执已确认
              //   await self.receiptComplete();
              // }
            }
          } else {
            self.loading = false;
          }
        } catch (e) {
          console.log(e);
          this.loading = false;
        }
      },
      // 点击回执凭证抽屉完成按钮
      async receiptComplete(resUploadLayerPic) {
        this.voucherFlag = true; // 回执凭证已经点击确认
        if (resUploadLayerPic) {
          // this.voucherDataCompleted = this.voucherData;
          this.imgFrontIDReceipt = resUploadLayerPic.frontImgid;
        }
        try {
          // 银行卡信息上传
          let self = this;
          const bankCardMediaType = await getDicCodeByDes(
            dicKeys.mediaType,
            '银行卡'
          );
          const bankCardImgType = await getDicCodeByDes(
            dicKeys.imgType,
            '银行卡'
          );
          if (
            bankCardMediaType &&
            self.selectedPics2.length !== 0 &&
            !this.form.refund
          ) {
            self.$store.getters.bankCardImg.forEach((pic) => {
              self.bankCardImageList.push({
                imgFrontID: pic.frontImgid,
                imgType: bankCardImgType,
                mediaType: bankCardMediaType,
              });
            });
            const res2 = await updateWorkOrder({
              workOrderID: self.workOrderIDReceipt,
              modifyInfo: { imagelist: self.bankCardImageList },
            });
            if (!res2) {
              this.loading = false;
            }
          }
          // 保存凭证图片
          const mediaType = await getDicCodeByDes(dicKeys.mediaType, '业务凭证');
          const imgType = await getDicCodeByDes(dicKeys.imgType, '业务凭证');
          if (mediaType) {
            // const modifyInfoConfirm=[];
            const ImageInfoConfirm = {
              mediaType,
              imgType,
              imgFrontID: this.imgFrontIDConfirm,
            };
            const ImageInfoReceipt = {
              mediaType,
              imgType,
              imgFrontID: this.imgFrontIDReceipt,
            };
            const res0 = await updateWorkOrder({
              workOrderID: this.workOrderIDConfirm,
              // workOrderID:"1111",
              modifyInfo: { imagelist: [ImageInfoConfirm] },
            });
            if (!res0) {
              this.loading = false;
            }
            // console.log('res0:'+res0.msg)
            const res1 = await updateWorkOrder({
              workOrderID: this.workOrderIDReceipt,
              // workOrderID:"2222",
              modifyInfo: { imagelist: [ImageInfoReceipt] },
            });
            if (!res1) {
              this.loading = false;
            }
          }
          if (resUploadLayerPic) {
            // 正常流程执行，如果中断后重复执行receiptComplete，不需要执行
            this.$alert('注销成功', '提示', {
              confirmButtonText: '确定',
              type: 'success',
              showClose: false,
            }).then(() => {
              this.loading = false;
              this.$router.push({
                path: '/menu',
              });
            });
          }
        } catch (e) {
          console.log(e);
          this.loading = false;
        }
      },
      complete() { },
      async getAccount() {
        const res = await etcAccountQuery({
          userAccountId: this.userAccountId,
          etcUserId: this.$store.getters.searchUserInfo.etcUserId,
        });
        if (res) {
          this.account = res;
          this.account.paychannelName = this.account.subpaychannelName
            ? this.account.subpaychannelName
            : this.account.paychannelName; //签约银行
          this.account.useracctTypeDesc = await getDicDesByCode(
            dicKeys.useracctType,
            res.useracctType
          );
          this.account.useracctStatus = await getDicDesByCode(
            dicKeys.useracctStatus,
            res.useracctStatus
          );
        }
      },
      async setDate() {
        //用后台接口返回的时间
        const res = await systemParameterQuery({ requestType: '00' });
        if (res && res.value) {
          let dateString =
            res.value.substring(0, 4) +
            '-' +
            res.value.substring(4, 6) +
            '-' +
            res.value.substring(6, 8);
          // console.log(dateString);
          let date1 = new Date(
            new Date(dateString).setDate(new Date(dateString).getDate() + 14)
          ); //在系统时间上增加14天
          this.form.settleDate = date1;
          // console.log(this.form.settleDate);
          return true;
        }
      },
      provinceChange(val) {
        // console.log('provinceChange:'+val)
        this.form.city = '';
        if (
          val === '上海' ||
          val === '北京' ||
          val === '重庆' ||
          val === '天津'
        ) {
          this.form.city = val;
        }
      },
    },
    mounted() {
      this.userAccountId = this.$route.query.userAccountId;
      console.log('this.userAccountId:' + this.userAccountId);
      this.getAccount();
    },
    destroyed() {
      clearTimeout(this.timer1);
    },
  };
</script>