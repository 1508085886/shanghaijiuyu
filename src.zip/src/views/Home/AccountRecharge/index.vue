<!-- 首页 -->
<template>
  <div class="offline-accountrecharge">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-accountrecharge_title">账户充值</h4>
      </div>
    </div>
    <div class="offline-accountrecharge_block">
      <el-form
        ref="rechargeForm1"
        :model="rechargeForm"
        class="offline-accountrecharge_block-form"
      >
        <div class="offline-accountrecharge_block-readcard-centent">
          <el-col :xl="8" :lg="8" :md="8">
            <el-row>
              <el-form-item prop="userAcctId" ref="userAcctId">
                <el-col :xl="9" :lg="9" :md="9">账户编号：</el-col>
                <el-col :xl="15" :lg="15" :md="15">{{
                  rechargeForm.userAcctId
                }}</el-col>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="accountType" ref="accountType">
                <el-col :xl="9" :lg="9" :md="9">账户类型：</el-col>
                <el-col :xl="15" :lg="15" :md="15">{{
                  rechargeForm.accountType
                }}</el-col>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item
                prop="balance"
                ref="balance"
                class="offline-accountrecharge_balance"
              >
                <el-col :xl="9" :lg="9" :md="9">账户余额：</el-col>
                <el-col :xl="15" :lg="15" :md="15">
                  {{ rechargeForm.balance }}</el-col
                >
              </el-form-item>
            </el-row>
          </el-col>
          <el-col :xl="8" :lg="8" :md="8">
            <el-row>
              <el-form-item prop="ratedBalance" ref="ratedBalance">
                <el-col :xl="10" :lg="10" :md="10">可用余额：</el-col>
                <el-col :xl="14" :lg="14" :md="14">
                  {{ rechargeForm.ratedBalance }}</el-col
                >
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="susTxnfee" ref="susTxnfee">
                <el-col :xl="10" :lg="10" :md="10">待确认金额：</el-col>
                <el-col :xl="14" :lg="14" :md="14">
                  {{ rechargeForm.susTxnfee }}</el-col
                >
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="overLimit" ref="overLimit">
                <el-col :xl="10" :lg="10" :md="10">消费限额：</el-col>
                <el-col :xl="14" :lg="14" :md="14">
                  {{ rechargeForm.overLimit }}</el-col
                >
              </el-form-item>
            </el-row>
          </el-col>
          <el-col :xl="8" :lg="8" :md="8">
            <el-row>
              <el-form-item prop="noticeLimit" ref="noticeLimit">
                <el-col :xl="10" :lg="10" :md="10">警告限额：</el-col>
                <el-col :xl="14" :lg="14" :md="14">
                  {{ rechargeForm.noticeLimit }}</el-col
                >
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="accountType" ref="accountType">
                <el-col :xl="10" :lg="10" :md="10">最低充值额：</el-col>
                <el-col :xl="14" :lg="14" :md="14"> {{ lowestAmount }}</el-col>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="isInvoice" ref="isInvoice">
                <el-checkbox
                  v-model="rechargeForm.isInvoice"
                  class="offline-accountrecharge_block-readcard-checkbox"
                  >部平台开票</el-checkbox
                >
              </el-form-item>
            </el-row>
          </el-col>
        </div>
      </el-form>
    </div>
    <!-- 充值金额选择块 -->
    <div class="offline-accountrecharge_amountblock_wrap">
      <div class="offline-accountrecharge_amountblock_title">
        选择充值金额（元）
      </div>
      <el-row :gutter="8" class="offline-accountrecharge_amountblock_row0">
        <el-col :md="3" v-for="(item, index) in amountBlockArr" :key="item">
          <div
            class="amountblock"
            :class="{ active: index === idx }"
            @click="idx = index"
          >
            {{ item }}
          </div>
        </el-col>
      </el-row>
    </div>
    <!-- 一键充值表单 -->
    <div class="offline-accountrecharge_recharge-block">
      <el-form
        ref="rechargeForm2"
        :model="rechargeForm"
        :rules="rechargeFormRules"
        :inline="true"
      >
        <!-- label-width="76px" -->
        <el-row>
          <el-form-item label="充值金额：" prop="txAmount">
            <el-input
              ref="txAmountInput"
              v-model="rechargeForm.txAmount"
            ></el-input>
          </el-form-item>
          <el-form-item label="支付方式：" prop="payMode">
            <type-select
              type="payMode0"
              v-model="rechargeForm.payMode"
              placeholder="请选择"
              class="offline-accountrecharge_recharge-paymode-select"
            />
          </el-form-item>
          <el-form-item label="凭证号：" prop="num">
            <el-input v-model="rechargeForm.num"></el-input>
          </el-form-item>
        </el-row>
      </el-form>
      <el-button
        type="primary"
        @click="recharge"
        ref="rechargeBtn"
        :loading="btnLoading"
        :disabled="mainBusinessDisabled"
        >充值
      </el-button>
    </div>
    <div class="offline-accountrecharge_recharge-tip">
      最低充值额为{{ lowestAmount }}元
    </div>
    <voucher-layer-confirm
      ref="mychild1"
      :column="2"
      :info="voucherConfirmData"
      :keys="voucherConfirmKeys"
      :visible.sync="voucherConfirmVisiable"
      @complete="newBusiness"
    ></voucher-layer-confirm>
    <!-- <voucher-layer-confirm
      ref="mychildsa"
      :column="2"
      :info="voucherConfirmSubAcctData"
      :keys="voucherConfirmSubAcctKeys"
      :visible.sync="voucherConfirmSubAcctVisiable"
      @complete="newBusiness('subAcct')"
    ></voucher-layer-confirm> -->
    <voucher-layer
      ref="mychild2"
      :column="2"
      :info="voucherData"
      :footer="voucherFooter"
      :keys="voucherKeys"
      :visible.sync="voucherVisiable"
      :cancel-show="false"
      @complete="receiptComplete"
    ></voucher-layer>
    <voucher-layer-format
      ref="mychildf"
      :column="2"
      :info="voucherData"
      :footer="voucherFooter"
      :keys="voucherKeys"
      voucherType="invoice"
      :visible.sync="voucherFormatVisiable"
      :cancel-show="false"
      @complete="receiptComplete"
    ></voucher-layer-format>
    <!-- <voucher-layer
      ref="mychildsaS"
      :column="2"
      :info="voucherSubAcctData"
      :footer="voucherSubAcctFooter"
      :keys="voucherSubAcctKeys"
      :visible.sync="voucherSubAcctVisiable"
      :cancel-show="false"
      @complete="receiptSubAcctComplete"
    ></voucher-layer>
    <voucher-layer-format
      ref="mychildfS"
      :column="2"
      :info="voucherSubAcctData"
      :footer="voucherSubAcctFooter"
      :keys="voucherSubAcctKeys"
      voucherType="invoice"
      :visible.sync="voucherFormatSubAcctVisiable"
      :cancel-show="false"
      @complete="receiptSubAcctComplete"
    ></voucher-layer-format> -->
    <!-- <complex-table3
      title="工单"
      confirmBtnText="继续"
      :tip="tip"
      :visible.sync="oldWorkOrderVisible"
      :columns="tables"
      requestListUrl="/queryPayList"
      :requestListParam="{
        pageNo: 1,
        pageSize: 10,
      }"
      @confirm="toContinue"
      :responseListFormat="responseListFormat"
      :append-to-body="true"
      :need-cancel-btn="false"
      :defaultValue="[]"
    /> -->
  </div>
</template>

<script>
import LoadingButton from '@/components/LoadingButton';
import VoucherLayer from '@/components/VoucherLayer';
import VoucherLayerFormat from '@/components/VoucherLayerFormat';
import VoucherLayerConfirm from '@/components/VoucherLayerConfirm';
import { readCardAndGetAmount, recharge, get50Records } from '@/utils/dynamic';
import { getFormatAmount, getFormatAmountYuan2Fen } from '@/utils/utils';
import { formatDate } from '@/utils/format';
import ComplexTable3 from '@/components/ComplexTable3';
import {
  createOrderv,
  updateWorkOrder,
  startTblWork,
  systemParameterQuery,
  systemTime,
} from '@/api/common';
import { accountRechargeApply } from '@/api/recharge';
import { accountOutHandle, queryAcctLogout } from '@/api/writeoff';
import { queryEtcAcct } from '@/api/user';
import RegexInput from '@/components/RegexInput';
// import { validateAmount } from '@/utils/validate';
import { globalBus } from '@/utils/globalBus';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';
import { mapGetters } from 'vuex';
export default {
  data() {
    return {
      amountBlockArr: [
        '100',
        '200',
        '300',
        '400',
        '500',
        '600',
        '700',
        '800',
        '900',
        '1000',
        '1500',
        '2000',
        '3000',
        '4000',
        '5000',
        '自定义',
      ],
      idx: null,
      readAgainTimes: 0,
      atfAmount: 0,
      tip: '',
      tac: '',
      cardTxSeq: '',
      cardIdNotSameMsg: '',
      cardIdNotSameCancelMsg: '',
      accountRechargeWorkOrderId: '', // 账户充值工单号
      loadingBackground: 'rgba(0, 0, 0, 0.48)',
      loadingClass: 'offline-accountrecharge_wholeLoading',
      mainBusinessDisabled: true,
      btnLoading: false,
      wLoading: null,
      timer1: null,
      oldWorkOrderVisible: false,
      rechargeForm: {
        userAcctId: '',
        accountType: '',
        balance: '',
        ratedBalance: '',
        susTxnfee: '',
        overLimit: '',
        noticeLimit: '',
        isInvoice: false,
        txAmount: '',
        payMode: '',
        num: '',
      },
      rechargeFormRules: {
        txAmount: [
          {
            required: true,
            message: '请输入充值金额',
            trigger: 'blur',
          },
          // { validator: this.validateAmount, trigger: 'blur' },
        ],
        payMode: [
          {
            required: true,
            message: '请选择支付方式',
            trigger: 'change',
          },
        ],
        // num: [
        //   { required: true, message: '请输入凭证号', trigger: 'blur' },
        //   // { max: 20, message: '长度不能超过20个字符', trigger: 'blur' },
        // ],
      },
      voucherConfirmData: {},
      // voucherConfirmFooter:{},
      voucherConfirmKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '客户名称', span: 2 },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'userAcctId', label: '账户编号' },
          { key: 'userAcctType', label: '账户类型' },
          { key: 'userAcctStatus', label: '账户状态' },
        ],
        [
          {
            key: 'txAmountAft',
            label: '账户余额',
            color: '#027AFF',
            // fontWeight: 'bold',
          },
          {
            key: 'txAmount',
            label: '充值金额',
            color: '#027AFF',
            // fontWeight: 'bold',
          },
        ],
      ],
      createOrderObj: {},
      voucherData: {},
      voucherFooter: {},
      voucherKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '客户名称', span: 2 },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'userAcctId', label: '账户编号' },
          { key: 'userAcctType', label: '账户类型' },
          { key: 'userAcctStatus', label: '账户状态' },
          { key: 'overLimit', label: '消费限额' },
          { key: 'noticeLimit', label: '警告限额' },
        ],
        [
          {
            key: 'txAmountBef',
            label: '交易前账户余额',
            labelWidth: '150px',
            color: '#027AFF',
          },
          { key: 'txAmount', label: '充值金额', color: '#027AFF' },
          {
            key: 'txAmountAft',
            label: '交易后账户余额',
            labelWidth: '150px',
            color: '#027AFF',
          },
          { key: 'payMode', label: '支付方式', color: '#027AFF' },
        ],
      ],
      voucherConfirmVisiable: false,
      voucherVisiable: false,
      voucherFormatVisiable: false,
      txAmountBef: '', // 交易前账户余额
      balance: '', // 账户余额原始值（分）
      overLimit: '', // 消费限额原始值（分）
      susTxnfee: '', // 待确认金额原始值（分）
    };
  },
  components: {
    VoucherLayer,
    VoucherLayerConfirm,
    VoucherLayerFormat,
    RegexInput,
    LoadingButton,
    ComplexTable3,
  },
  computed: {
    lowestAmount() {
      return getFormatAmount(this.balance - this.susTxnfee - this.overLimit);
    },
    vehicleInfo() {
      return this.$store.getters.searchCarInfo;
    },
    obuInfo() {
      return this.$store.getters.searchObuInfo;
    },
    cardInfo() {
      return this.$store.getters.searchCardInfo;
    },
    userInfo() {
      return this.$store.getters.searchUserInfo;
    },
    accountInfo() {
      return this.$store.getters.searchAccountInfo;
    },
    departmentInfo() {
      return this.$store.getters.searchDepartmentInfo;
    },
    ...mapGetters(['netLevel', 'oprtId', 'netid']),
  },
  watch: {
    idx(val) {
      if (this.amountBlockArr[val] != '自定义') {
        this.rechargeForm.txAmount = this.amountBlockArr[val] + '.00';
      } else {
        this.rechargeForm.txAmount = '';
        this.$refs.txAmountInput.focus();
      }
    },
  },
  methods: {
    async newBusiness() {
      // 用户确认后，
      this.$writeLog('用户确认后');
      if (!this.accountRechargeWorkOrderId) {
        // 如果充值页面没有工单号
        // 调后台创建工单接口，创建账户充值工单
        this.$writeLog('充值页面没有工单号');
        this.$writeLog('调后台创建工单接口，创建账户充值工单');
        const bizCode0 = await getDicCodeByDes(dicKeys.bizCode, '账户充值');
        this.createOrderObj = {
          oldUserId: this.userInfo.userID,
          oldUserAcctId: this.accountInfo.userAcctId,
          oldDepartmentName: this.departmentInfo.department,
          oldBuyId: this.accountInfo.signOrderNo,
          oldVehicleId: this.vehicleInfo.vehicleId,
          oldVehicleNumber: this.vehicleInfo.vehicleNumber,
          oldVehicleColor: this.vehicleInfo.vehicleColor,
          oldCardId: this.cardInfo.cardID,
          oldObuysId: this.obuInfo.printID,
          oldObuId: this.obuInfo.obuID,
          oldEtcUserId: this.userInfo.etcUserId,
          oldUsername: this.userInfo.userName,
          oldPayChannelName: this.accountInfo.paychannelName,
          oldSubPayChannelName: this.accountInfo.subPaychannelName,
        };
        try {
          const resCo = await createOrderv({
            bizCode0,
            ...this.createOrderObj,
          });
          if (resCo) {
            this.$writeLog('调后台创建工单接口成功');
            this.accountRecharge();
          } else {
            this.btnLoading = false;
            this.$writeLog('调后台创建工单接口报错');
          }
        } catch (error) {
          this.btnLoading = false;
          this.$writeLog('创建工单接口超时等异常：' + JSON.stringify(error));
        }
      } else {
        // 如果充值页面已有工单号，则无需创建工单。
        this.$writeLog('充值页面已有工单号，则无需创建工单');
        this.accountRecharge();
      }
    },
    // 账户充值
    async accountRecharge() {
      // 前端调前置接口进行账户充值申请
      try {
        this.$writeLog('调系统时间查询接口');
        const resTime = await systemTime();
        if (resTime) {
          const chargeTime = formatDate(
            'yyyyMMddHHmmss',
            new Date(resTime.systemTime)
          );
          this.$writeLog('前端调前置接口进行账户充值申请');
          const resAr = accountRechargeApply({
            workOrderId: this.acctRechargeWorkOrderId,
            etcUserId: this.userInfo.etcUserId,
            chargeTime,
          });
          if (resAr) {
            if (!resAr.exCode) {
              this.$writeLog('调账户充值申请接口成功');
              // 充值完成后，重新查询刷新数据，
              this.$writeLog('充值完成后，重新查询刷新数据');
              this.txAmountBef = this.rechargeForm.txAmount;
              await this.getAccountInfo();
              // 并弹出用户签名回执凭证
              this.toReceipt();
            } else {
              if (resAr.exCode === '138') {
                // 返回错误码138，“账户充值异常，请确认账户余额并采取后续操作”
                this.$writeLog(
                  '返回错误码138，提示-“账户充值异常，请确认账户余额并采取后续操作”'
                );
                this.$alert(
                  '账户充值异常，请确认账户余额并采取后续操作',
                  '提示',
                  {
                    confirmButtonText: '确定',
                    closeOnClickModal: false,
                    closeOnPressEscape: false,
                    showClose: false,
                    type: 'error',
                  }
                ).then(() => {
                  this.btnLoading = false;
                  this.$writeLog(
                    '提示-“账户充值异常，请确认账户余额并采取后续操作”点击确定'
                  );
                  // 操作员可以重新点击账户充值按钮，或在工单管理页面进行退单或完成工单操作。
                });
              } else {
                this.btnLoading = false;
                this.$writeLog('账户充值申请接口其他异常');
              }
            }
          } else {
            this.btnLoading = false;
            this.$writeLog('调账户充值申请接口报错');
          }
        } else {
          this.btnLoading = false;
          this.$writeLog('调系统时间查询接口报错');
        }
      } catch (error) {
        this.btnLoading = false;
        this.$writeLog('接口超时等异常：' + JSON.stringify(error));
      }
    },
    // 点击充值按钮
    async recharge() {
      this.$writeLog('点击充值按钮');
      this.$refs.rechargeForm2.validate(async (valid) => {
        if (valid) {
          this.btnLoading = true;
          if (this.rechargeForm.txAmount < this.lowestAmount) {
            // 若充值金额<最低充值额，提示“最低充值额为X元”，仅提示，不拦截业务。
            this.$writeLog(
              '若充值金额<最低充值额，提示“最低充值额为X元”，仅提示，不拦截业务'
            );
            this.$alert('最低充值额为' + this.lowestAmount + '元', '提示', {
              confirmButtonText: '确定',
              closeOnClickModal: false,
              closeOnPressEscape: false,
              showClose: false,
              type: 'warning',
            }).then(() => {
              this.toConfirm();
            });
          } else {
            this.toConfirm();
          }
        }
      });
    },

    async toContinue(selection) {
      this.$writeLog('继续未完成的充值交易');
      console.log('selection', selection);
      if (selection.length === 0) {
        this.$writeLog('没有选中的业务');
        this.$alert('请选中要继续的业务', '提示', {
          confirmButtonText: '确定',
          closeOnClickModal: false,
          closeOnPressEscape: false,
          showClose: false,
          type: 'warning',
        });
      } else {
        this.oldWorkOrderVisible = false;
        if (selection[0].tradeType === '2') {
          // 5.继续办理圈存账户充值交易
          this.$writeLog('继续办理圈存账户充值交易');
          this.wLoading = this.$loading(
            '卡片办理圈存账户充值中，请稍候',
            this.loadingBackground,
            this.loadingClass
          );
          if (
            this.rechargeForm.transType ===
            (await getDicCodeByDes(dicKeys.rechargeWay, '电子钱包'))
          ) {
            // 如果当前场景为选择'电子钱包' - 继续办理圈存账户充值交易
            this.$writeLog('当前场景为选择电子钱包');
            this.acctRecharge();
          } else if (
            this.rechargeForm.transType ===
            (await getDicCodeByDes(dicKeys.rechargeWay, '圈存账户'))
          ) {
            // 如果当前场景为选择'圈存账户' - 继续办理圈存账户充值交易
            this.$writeLog('当前场景为选择圈存账户');
            this.toSubAcctConfirm();
          }
        } else if (selection[0].tradeType === '3') {
          this.$writeLog('继续办理卡片圈存充值交易');
          console.log('继续-卡片圈存中');
          // 6.	如果当前场景为继续办理储值卡圈存。
          // （1）	前端显示loading页面，话术“卡片圈存中，请稍候”。
          this.wLoading = this.$loading(
            '卡片圈存中，请稍候',
            this.loadingBackground,
            this.loadingClass
          );
          // （2）	首先进行验卡流程。如果验卡结果为1:完成写卡确认，参考4（10）。
          this.checkCard('continue');
          // （3）	如果验卡结果为“2:未完成写卡确认，正确返回至圈存账户”，参考4（8）-4（10）。
          // 代码包含在this.checkCard('continue');中
        }
      }
    },

    // 确认凭证
    async toConfirm() {
      this.$writeLog('账户充值确认凭证方法进入');
      let userCertType = await getDicDesByCode(
        dicKeys.userCertType,
        this.userInfo.userCertType
      );
      let userAcctType = await getDicDesByCode(
        dicKeys.useracctType,
        this.accountInfo.userAcctType
      );
      let userAcctStatus = await getDicDesByCode(
        dicKeys.useracctType,
        this.accountInfo.userAcctStatus
      );
      this.voucherConfirmData = {
        businessType: '账户充值',
        userName: this.userInfo.userName,
        userCertType,
        userCode: this.userInfo.userCode,
        userAcctId: this.accountInfo.userAcctId,
        userAcctType,
        userAcctStatus,
        txAmountAft: this.rechargeForm.balance + '元',
        txAmount:
          this.rechargeForm.txAmount.indexOf('.') < 0
            ? this.rechargeForm.txAmount + '.00'
            : this.rechargeForm.txAmount + '元',
      };
      this.$writeLog('账户充值确认凭证显示');
      this.voucherConfirmVisiable = true;
      this.$nextTick(() => {
        //执行调用手写板
        this.$writeLog('执行调用手写板');
        this.$refs.mychild1.sendpad();
      });
    },
    // 回执凭证
    async toReceipt() {
      // 点击回执签名按钮，调后台接口，获取回执内容
      this.$writeLog('账户充值回执凭证方法进入');
      try {
        this.$writeLog('调系统查询时间接口');
        let completeTime = await systemTime();
        let userCertType = await getDicDesByCode(
          dicKeys.userCertType,
          this.userInfo.userCertType
        );
        let userAcctType = await getDicDesByCode(
          dicKeys.useracctType,
          this.accountInfo.userAcctType
        );
        let userAcctStatus = await getDicDesByCode(
          dicKeys.useracctType,
          this.accountInfo.userAcctStatus
        );
        let payMode = await getDicDesByCode(
          dicKeys.payMode0,
          this.rechargeForm.payMode
        );
        if (completeTime) {
          this.voucherData = {
            businessType: '账户充值',
            userName: this.userInfo.userName,
            userCertType,
            userCode: this.userInfo.userCode,
            userAcctId: this.accountInfo.userAcctId,
            userAcctType,
            userAcctStatus,
            txAmountBef: this.txAmountBef + '元',
            txAmount:
              this.rechargeForm.txAmount.indexOf('.') < 0
                ? this.rechargeForm.txAmount + '.00'
                : this.rechargeForm.txAmount + '元',
            txAmountAft: this.rechargeForm.txAmount + '元',
            payMode,
          };
          this.voucherFooter = {
            date: completeTime.systemTime,
            outletId: this.$store.getters.netid,
            operator: this.$store.getters.userName,
          };
          this.$writeLog('账户充值回执凭证显示');
          this.rechargeForm.isInvoice
            ? (this.voucherFormatVisiable = true)
            : (this.voucherVisiable = true);
          this.$nextTick(() => {
            //执行调用手写板
            this.$writeLog('执行调用手写板');
            this.rechargeForm.isInvoice
              ? this.$refs.mychildf.sendpad()
              : this.$refs.mychild2.sendpad();
          });
        } else {
          this.btnLoading = false;
          this.$writeLog('调系统查询时间接口报错');
        }
      } catch (error) {
        this.btnLoading = false;
        this.$writeLog('接口超时等异常：' + JSON.stringify(error));
      }
    },

    // 回执确认
    receiptComplete() {
      this.$writeLog(' 回执签名后弹框提示-充值成功');
      // 用户签名确认，账户充值完成，返回主页
      this.$alert('充值成功', '提示', {
        confirmButtonText: '确定',
        closeOnClickModal: false,
        closeOnPressEscape: false,
        showClose: false,
        type: 'success',
      }).then(() => {
        this.btnLoading = false;
        // 返回主页
        this.$writeLog('返回主页');
        this.$router.push({
          path: '/menu',
        });
      });
    },
    validateAmount(rule, value, callback) {
      if (value == '' || value == undefined || value == null) {
        callback();
      } else {
        if (getFormatAmountYuan2Fen(value) >= 1000000) {
          callback(new Error('充值金额须小于10000.00元'));
        } else {
          callback();
        }
      }
    },
    async getAccountInfo() {
      try {
        this.$writeLog('调用6.1.	ETC账户查询接口');
        const resAcct = await queryEtcAcct({
          etcUserId: this.userInfo.etcUserId,
          userAccountId: this.accountInfo.userAcctId,
          vehicleNumber: this.vehicleInfo.vehicleNumber,
          vehicleColor: this.vehicleInfo.vehicleColor,
        });
        if (resAcct) {
          this.$writeLog('调用6.1.	ETC账户查询接口成功');
          this.balance = resAcct.balance;
          this.susTxnfee = resAcct.susTxnfee;
          this.overLimit = resAcct.overLimit;
          this.rechargeForm.balance = getFormatAmount(resAcct.balance);
          this.rechargeForm.susTxnfee = getFormatAmount(resAcct.susTxnfee);
          this.rechargeForm.overLimit = getFormatAmount(resAcct.overLimit);
          this.rechargeForm.ratedBalance = getFormatAmount(
            resAcct.ratedBalance
          );
          this.rechargeForm.noticeLimit = getFormatAmount(resAcct.noticeLimit);
          return true;
        } else {
          this.$writeLog('6.1.	ETC账户查询接口报错');
          return;
        }
      } catch (error) {
        this.$writeLog('6.1.	ETC账户查询接口超时等异常' + JSON.stringify(error));
        return;
      }
    },
  },
  async mounted() {
    this.$writeLog('储值卡充值业务进入');
    // 账户信息从综合查询获取
    if (this.isEmptyObj(this.accountInfo)) {
      this.$writeLog('缓存中没有账户信息');
      this.$alert('无法获取账户信息', '提示', {
        confirmButtonText: '确定',
        closeOnClickModal: false,
        closeOnPressEscape: false,
        type: 'warning',
      });
      return;
    }
    this.$writeLog('从综合查询获取账户信息');
    this.rechargeForm.userAcctId = this.accountInfo.userAcctId;
    this.rechargeForm.accountType = await getDicDesByCode(
      dicKeys.useracctType,
      this.accountInfo.userAcctType
    );
    // this.rechargeForm.accountStatus = await getDicDesByCode(
    //   dicKeys.useracctStatus,
    //   this.accountInfo.userAcctStatus
    // );
    // 账户其他信息从6.1.	ETC账户查询接口获取
    this.$writeLog('账户其他信息从6.1.	ETC账户查询接口获取');
    const resAi = await this.getAccountInfo();
    if (resAi) {
      this.mainBusinessDisabled = false; // 可以进行主业务
    }
  },
  destroyed() {
    // clearTimeout(this.timer1);
  },
};
</script>