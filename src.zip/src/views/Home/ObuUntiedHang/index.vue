<!-- 换卡 -->
<template>
  <div class="offline-obuuntiedhangindex">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-obuuntiedhangindex_title">标签解挂</h4>
      </div>
    </div>
    <drawer
      :order="1"
      title="证件上传"
      note="需要上传的证件：用户证件、经办人证件、其他证件资料"
      :btnState="btnState1"
      :btnDesc="btnDescDocupload"
      @btnClick="to('/obuuntiedhang/docupload')"
    >
    </drawer>
    <drawer
      :order="2"
      title="标签解挂"
      note="标签解挂"
      :btnState="btnState2"
      btnDesc="标签解挂"
      @btnClick="confirmFlagc ? obuUntiedHang() : toConfirm()"
    >
    </drawer>
    <drawer
      :order="3"
      title="回执签名"
      note="回执签名"
      :btnState="btnState3"
      btnDesc="回执签名"
      @btnClick="toReceipt"
    >
    </drawer>
    <!-- <drawer
      :order="4"
      title="开具发票"
      note="开具发票"
      :btnDesc="btnDescInvoice"
      :btnState="btnState4"
      @btnClick="toInvoice"
    >
    </drawer> -->
    <el-button
      type="primary"
      :disabled="rtnDisabled"
      icon="el-icon-refresh-left"
      class="offline-obuuntiedhangindex_rtn-button"
      @click="backHome"
      >返回主页
    </el-button>
    <!-- :tip="confirmTip" -->
    <voucher-layer-confirm
      ref="mychild1"
      :column="2"
      :info="voucherConfirmData"
      :keys="voucherConfirmKeys"
      :visible.sync="voucherConfirmVisiable"
      :confirmFlag.sync="confirmFlagc"
      @complete="obuUntiedHang"
    ></voucher-layer-confirm>
    <voucher-layer
      ref="mychild2"
      :column="2"
      :info="voucherData"
      :footer="voucherFooter"
      :keys="voucherKeys"
      :visible.sync="voucherVisiable"
      :confirmFlag.sync="confirmFlag"
      :cancel-show="false"
      @complete="receiptComplete"
    ></voucher-layer>
  </div>
</template>
<script>
import VoucherLayerConfirm from '@/components/VoucherLayerConfirm';
import VoucherLayer from '@/components/VoucherLayer';
import Drawer from '@/components/Drawer';
import { updateWorkOrder, systemTime, addBranch } from '@/api/common';
import showQrcode from '@/utils/qrcode';
import { globalBus } from '@/utils/globalBus';
import {
  strPadEnd,
  getFormatAmount,
  getQueryStringByName,
  getFormatCardIdw,
} from '@/utils/utils';
import {
  UncouplingObu,
  queryReceiptUncouplingObu,
  queryUncouplingObu,
  // UncouplingCard,
  // queryReceiptUncouplingCard,
  // queryUncouplingCard,
} from '@/api/equipment';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';
import { tblStatusQuery } from '@/api/order';
export default {
  data() {
    return {
      cardId: '',
      newCard: {},
      note2: '',
      btnDescDocupload: '证件上传',
      // btnDescInvoice: '开具发票',
      btnState1: 'usable',
      btnState2: 'disable',
      btnState3: 'disable',
      // btnState4: 'disable',
      rtnDisabled: true,
      workOrderID: '', // 工单号
      voucherConfirmData: {},
      voucherConfirmKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '用户名称' },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'vehicleNumber', label: '车牌号码' },
          { key: 'vehicleColor', label: '车牌颜色' },
        ],
        [
          { key: 'obuId', label: '标签ID' },
          { key: 'printId', label: '标签表面号' },
          { key: 'obuStatus', label: '标签当前状态' },
        ],
        [{ key: 'amount', label: '收费' }],
      ],
      voucherConfirmVisiable: false,
      confirmFlagc: false, // 确认凭证是否被确认
      voucherData: {},
      voucherFooter: {},
      voucherKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '用户名称' },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'vehicleNumber', label: '车牌号码' },
          { key: 'vehicleColor', label: '车牌颜色' },
        ],
        [
          { key: 'obuId', label: '标签ID' },
          { key: 'printId', label: '标签表面号' },
          { key: 'obuStatus', label: '标签当前状态' },
        ],
        [{ key: 'amount', label: '收费' }],
      ],
      voucherVisiable: false,
      confirmFlag: false,
      invoiceUrl: '',
      invoiceOpened: false,
      step: '',
      continueData: {},
      payFlag: '',
      price: '',
      payMode: '',
      cdif: '',
      isContinue: '', // 继续办理标志
      etcUserId: '',
      newVehicleNumber: '',
      newVehicleColor: '',
    };
  },
  components: {
    Drawer,
    VoucherLayer,
    VoucherLayerConfirm,
  },
  computed: {
    vehicleInfo() {
      return this.$store.getters.searchCarInfo;
    },
    obuInfo() {
      return this.$store.getters.searchObuInfo;
    },
    cardInfo() {
      return this.$store.getters.searchCardInfo;
    },
    userInfo() {
      return this.$store.getters.searchUserInfo;
    },
  },
  methods: {
    backHome() {
      let form = {
        obuID: this.obuInfo.obuID,
        // cardId: '0131002714297278',
      };
      globalBus.$emit('clickToSearch', form);
      this.$router.push('/menu');
      // 跳转到工单管理
      if (this.continueData) {
        console.log('跳转工单:' + this.cdif);
        let rtn = etcdev.predisplay(
          this.cdif,
          'vueEmit(\'{"type":"refreshTable1","param":{}}\')'
        );
      }
    },
    async to(path) {
      let canAccess = false;
      if (this.workOrderID) {
        const res = await tblStatusQuery({ tblWorkOrderId: this.workOrderID });
        if (res) {
          if (res.status == '1') {
            canAccess = true;
          } else {
            // 工单已完成/已关闭，不能操作
            canAccess = false;
            this.$alert('工单已完成/已关闭', '提示', {
              confirmButtonText: '确定',
              type: 'success',
            });
            return;
          }
        }
      } else {
        canAccess = true;
      }
      if (canAccess) {
        let view = '';
        if (path === '/obuuntiedhang/docupload') {
          if (this.btnState1 === 'complete2use') {
            // 查看
            view = true;
          }
        }
        this.$router.push({
          path,
          query: {
            view,
            step: this.step,
            cardId: this.cardId,
            workOrderID: this.workOrderID,
            continueData: this.continueData,
            payFlag: this.payFlag,
            price: this.price,
            payMode: this.payMode,
            cdif: this.cdif,
            isContinue: this.isContinue,
            etcUserId: this.etcUserId,
            newVehicleNumber: this.newVehicleNumber,
            newVehicleColor: this.newVehicleColor,
          },
        });
      }
    },
    // 确认凭证
    async toConfirm() {
      // // 14.25.	卡挂失计费
      // const resCal = await calculateLostCard({
      //   etcUserId: this.userInfo.etcUserId,
      // });
      let userCertType = await getDicDesByCode(
        dicKeys.userCertType,
        this.userInfo.userCertType
      );
      let vehicleColor = await getDicDesByCode(
        dicKeys.vehicleColor,
        this.vehicleInfo.vehicleColor
      );
      let obuStatus = await getDicDesByCode(
        dicKeys.obuStatus,
        this.obuInfo.obuStatus
      );
      this.voucherConfirmData = {
        businessType: '标签解挂',
        userName: this.userInfo.userName,
        userCertType,
        userCode: this.userInfo.userCode,
        vehicleNumber: this.vehicleInfo.vehicleNumber,
        vehicleColor,
        printId: this.obuInfo.printID,
        obuId: this.obuInfo.obuID,
        obuStatus,
        amount: '0' + '元',
      };
      this.voucherConfirmVisiable = true;
      this.$nextTick(() => {
        //执行调用手写板
        this.$refs.mychild1.sendpad();
      });
    },
    // 挂失
    async obuUntiedHang(resUploadLayerPic) {
      // 调后台12.9.修改工单接口上传确认凭证
      if (resUploadLayerPic) {
        let imgFrontIDConfirm = resUploadLayerPic.frontImgid;
        // 保存凭证图片
        const mediaType = await getDicCodeByDes(dicKeys.mediaType, '业务凭证');
        const imgType = await getDicCodeByDes(dicKeys.imgType, '业务凭证');
        const ImageInfoConfirm = {
          mediaType,
          imgType,
          imgFrontID: imgFrontIDConfirm,
        };
        const res0 = await updateWorkOrder({
          workOrderID: this.workOrderID,
          modifyInfo: { imagelist: [ImageInfoConfirm] },
        });
      }
      // 前端继续调后台挂失接口，14.30.	卡解挂失业务申请
      const res = await UncouplingObu({
        etcUserId: this.userInfo.etcUserId,
        workOrderId: this.workOrderID,
        obuId: this.obuInfo.obuID,
        vehicleId: this.vehicleInfo.vehicleId,
      });
      if (res) {
        // this.$alert('解挂成功', '提示', {
        //   confirmButtonText: '确定',
        //   type: 'success',
        // });
        // 设置按钮状态
        this.btnState1 = 'complete2use';
        this.btnState2 = 'complete';
        this.btnState3 = 'usable';
        this.btnDescDocupload = '已完成';
        this.rtnDisabled = true;
        this.step = 'main';
      }
    },
    // 回执签名
    async toReceipt() {
      // 点击回执签名按钮，调后台接口，获取回执内容 14.31.	卡解挂失业务回执查询
      const resQuery = await queryReceiptUncouplingObu({
        etcUserId: this.userInfo.etcUserId,
        workOrderId: this.workOrderID,
      });
      console.log('resQuery', resQuery);
      if (resQuery) {
        let completeTime = await systemTime();
        let userCertType = await getDicDesByCode(
          dicKeys.userCertType,
          resQuery.userInfo.userCertType
        );
        let vehicleColor = await getDicDesByCode(
          dicKeys.vehicleColor,
          resQuery.vehicleInfo.vehicleColor
        );
        let obuStatus = await getDicDesByCode(
          dicKeys.obuStatus,
          resQuery.uncouplingInfo.status
        );
        if (completeTime) {
          this.voucherData = {
            businessType: '标签解挂',
            userName: resQuery.userInfo.userName,
            userCertType,
            userCode: resQuery.userInfo.userCode,
            vehicleNumber: resQuery.vehicleInfo.vehicleNumber,
            vehicleColor,
            printId: resQuery.uncouplingInfo.obuPrintId,
            obuId: resQuery.uncouplingInfo.obuId,
            obuStatus,
            // amount: getFormatAmount(resQuery.chargeInfo.price) + '元',
            amount: '0' + '元',
          };
          this.voucherFooter = {
            date: completeTime.systemTime,
            outletId: this.$store.getters.netid,
            operator: this.$store.getters.userName,
          };
          this.voucherVisiable = true;
          this.$nextTick(() => {
            //执行调用手写板
            this.$refs.mychild2.sendpad();
          });
        }
      }
    },
    // 回执签名确认
    async receiptComplete(resUploadLayerPic) {
      // 回执签名完成后，调用后台12.9.修改工单接口，上传签名图片
      let imgFrontIDConfirm = resUploadLayerPic.frontImgid;
      // 保存凭证图片
      const mediaType = await getDicCodeByDes(dicKeys.mediaType, '回执凭证');
      const imgType = await getDicCodeByDes(dicKeys.imgType, '回执凭证');
      const ImageInfoConfirm = {
        mediaType,
        imgType,
        imgFrontID: imgFrontIDConfirm,
      };
      const res0 = await updateWorkOrder({
        workOrderID: this.workOrderID,
        modifyInfo: { imagelist: [ImageInfoConfirm] },
      });
      // 设置按钮状态
      this.btnState1 = 'complete2use';
      this.btnState2 = 'complete';
      this.btnState3 = 'complete';
      this.btnDescDocupload = '已完成';
      this.rtnDisabled = false;
      this.step = 'receipt';
    },
    async initContinue() {
      // 初始化继续办理-标签解挂数据
      // 调用标签解挂查询接口 14.32.	卡解挂失业务查询
      const res = await queryUncouplingObu({
        etcUserId: this.etcUserId,
        workOrderId: this.workOrderID,
        vehicleNumber: this.newVehicleNumber,
        vehicleColor: this.newVehicleColor,
      });
      this.continueData = res;
      if (res) {
        // 是否证件上传
        if (res.workOrderInfo.isUploadCert === '1') {
          this.step = 'docupload';
        }
        // 是否完成主业务
        if (res.workOrderInfo.isBusinessCompleted === '1') {
          this.step = 'main';
        }
        // 是否回执上传
        if (res.workOrderInfo.isUploadReceipt === '1') {
          this.step = 'receipt';
        }
        // 是否开票
        // if(res.workOrderInfo.isInvoice === '1') {
        //  this.step = 'invoice';
        // }

        // 更新userinfo 等信息
        let form = {
          // cardId: this.cardId,
          vehicleNumber: this.newVehicleNumber,
          vehicleColor: this.newVehicleColor,
        };
        await globalBus.$emit('clickToSearch', form);
      } else {
        this.$message.error(res.message || '查询失败!');
      }
    },
  },
  async mounted() {
    this.workOrderID = this.$route.query.workOrderID;
    this.isContinue = this.$route.query.isContinue;
    this.cdif = this.$route.query.cdif;
    // console.log('cdif:' + this.cdif);
    const cstep = this.$route.query.step;
    // console.log('cstep:', cstep);
    this.etcUserId = this.$route.query.etcUserId;
    this.newVehicleNumber = this.$route.query.newVehicleNumber;
    this.newVehicleColor = this.$route.query.newVehicleColor;
    // console.log('newVehicleColor:', this.newVehicleColor);
    // 继续办理换卡处理
    if (this.isContinue) {
      console.log('继续办理');
      await this.initContinue();
      if (this.step === 'docupload') {
        this.btnState1 = 'complete2use';
        this.btnState2 = 'usable';
        this.btnDescDocupload = '已完成';
        this.rtnDisabled = true;
      } else if (this.step === 'main') {
        this.btnState1 = 'complete2use';
        this.btnState2 = 'complete';
        this.btnState3 = 'usable';
        this.btnDescDocupload = '已完成';
        this.rtnDisabled = true;
        // this.note2 += `，新卡号：${strPadEnd(this.cardId, 2)}`;
      } else if (this.step === 'receipt') {
        this.btnState1 = 'complete2use';
        this.btnState2 = 'complete';
        this.btnState3 = 'complete';
        this.btnDescDocupload = '已完成';
        this.rtnDisabled = false;
      }
    } else {
      if (this.isEmptyObj(this.userInfo)) {
        this.$message.error('无法获取用户信息');
        this.btnState1 = 'disable';
        this.btnState2 = 'disable';
        this.btnState3 = 'disable';
        this.btnState4 = 'disable';
        this.rtnDisabled = true;
      } else {
        // 按钮初始化
        this.btnState1 = 'usable';
        this.btnState2 = 'disable';
        this.btnState3 = 'disable';
        this.btnState4 = 'disable';
        this.rtnDisabled = true;
        // this.rtnDisabled = false;
        this.step = this.$route.query.step;
        this.cardId = this.$route.query.cardId;
        this.workOrderID = this.$route.query.workOrderID;
        this.note2 = `旧卡卡号：${getFormatCardIdw(
          strPadEnd(this.cardInfo.cardID, 2)
        )}`;
        // 按钮状态切换
        if (this.$route.query.rtn === 'docupload') {
          this.btnState1 = 'complete2use';
          this.btnState2 = 'usable';
          this.btnDescDocupload = '已完成';
        }
        // 由步骤决定抽屉按钮最终状态
        if (this.step === 'docupload') {
          this.btnState1 = 'complete2use';
          this.btnState2 = 'usable';
          this.btnDescDocupload = '已完成';
        } else if (this.step === 'main') {
          this.btnState1 = 'complete2use';
          this.btnState2 = 'complete';
          this.btnState3 = 'usable';
          this.btnDescDocupload = '已完成';
        } else if (this.step === 'receipt') {
          this.btnState1 = 'complete2use';
          this.btnState2 = 'complete';
          this.btnState3 = 'complete';
          this.btnDescDocupload = '已完成';
          this.rtnDisabled = false;
        }
        // else if (this.step === 'invoice') {
        //   this.btnState1 = 'complete2use';
        //   this.btnState2 = 'complete';
        //   this.btnState3 = 'complete';
        //   this.btnState4 = 'complete2use';
        //   this.btnDescInvoice = '查看发票';
        //   this.rtnDisabled = false;
        // }
        if (this.step) {
          // // changecardmain已完成
          // this.note2 += `<br>新卡卡号：${getFormatCardIdw(
          //   strPadEnd(this.cardId, 2)
          // )}`;
        }
      }
    }
  },
};
</script>