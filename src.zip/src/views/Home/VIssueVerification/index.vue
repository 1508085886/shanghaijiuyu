<!-- 首页 -->
<template>
    <div class="offline-VIssueVerification">
        <div class="clearfix">
            <div class="fl">
                <h4 class="offline-VIssueVerification_title">车牌发行资格校验</h4>
            </div>
        </div>
        <div v-if="this.$store.getters.searchUserInfo.userProperty || this.$route.query.userProperty">
            <div v-if="this.$store.getters.searchUserInfo.userProperty==='1' || this.$route.query.userProperty==='1'">
                <div class="offline-VIssueVerification_block" style="height: 392px;">
                    <el-form :model="pform" class="offline-VIssueVerification_block-form" ref="form" :rules="rules">
                        <div class="offline-VIssueVerification_block-readcard-centent">
                            <el-row :gutter="20">
                                <el-row :gutter="20" style="margin-bottom: 6px;">
                                    <el-col :span='16' class="o-font-family form-text">用户名称：</el-col>
                                    <el-col :span='8' class="o-font-family form-text" style="padding: 0px 0px;">证件类型：
                                    </el-col>
                                </el-row>
                                <el-row style="margin-bottom: 16px;">
                                    <el-col :span='16' class="o-font-family form-text">
                                        <el-input v-model="pform.userName" style="width: 714px;">
                                        </el-input>
                                    </el-col>
                                    <el-col :span='8'>
                                        <type-select class="offline-VIssueVerification-type-select" type="userCertTypeP"
                                            v-model="pform.userCertType">
                                        </type-select>
                                    </el-col>
                                </el-row>
                                <el-row :gutter="20" style="margin-bottom: 6px;">
                                    <el-col :span='8' class="o-font-family form-text">证件号码：</el-col>
                                    <el-col :span='8' class="o-font-family form-text" style="padding: 0px 0px;">车牌号码：
                                    </el-col>
                                    <el-col :span='8' class="o-font-family form-text" style="padding: 0px 0px;">车牌颜色：
                                    </el-col>
                                </el-row>
                                <el-row style="margin-bottom: 16px;">
                                    <el-col :span='8' class="o-font-family form-text">
                                        <el-input v-model="pform.userCode" style="width:300px"></el-input>
                                    </el-col>
                                    <el-col :span='8' class="o-font-family form-text">
                                        <el-form-item label="" prop="vehicleNumber">
                                            <el-input v-model="pform.vehicleNumber" style="width:300px"></el-input>
                                        </el-form-item>
                                    </el-col>
                                    <el-col :span='8'>
                                        <el-form-item label="" prop="vehicleColor">
                                            <type-select type="vehicleColor" v-model="pform.vehicleColor">
                                            </type-select>
                                        </el-form-item>
                                    </el-col>
                                </el-row>

                                <el-row style="margin-bottom: 20px;">
                                    <el-col :span='24' class="o-font-family form-text">
                                        选择签约银行：
                                    </el-col>
                                </el-row>
                                <el-row>
                                    <el-col v-for=" channel in channelList" :key="channel.channelId" :xl="xl" :lg="lg"
                                        style="width: auto;" :md="8" :sm="8" class="mb52">
                                        <div ref="channelId"
                                            class="offline-bank-sign_bank-smallitem o-flex o-flex-align-center o-flex-justify-center"
                                            :class="[
                                      { 'is-active': selectedChannel.name === channel.remarks },
                                    ]" @click="selectChannel(channel)">
                                            <!-- <img src="../../../assets/images/bank/建设银行.png" alt=""> -->
                                            <img :src="
                                        require('../../../assets/images/bank/' +
                                          channel.channelId +
                                          '_MINI.png')
                                      " />
                                        </div>
                                    </el-col>
                                </el-row>
                            </el-row>
                        </div>
                    </el-form>
                </div>
                <el-row style="padding-top: 160px; text-align: center">
                    <el-col>
                        <el-button @click="vVerification" type="primary" size="medium" round
                            class="offline-VIssueVerification_Button">
                            发行校验
                        </el-button>
                    </el-col>
                </el-row>
            </div>
        </div>
        <div v-if="this.$store.getters.searchUserInfo.userProperty || this.$route.query.userProperty">
            <div v-if="this.$store.getters.searchUserInfo.userProperty==='2' || this.$route.query.userProperty==='2'">
                <div class="offline-VIssueVerification_block" style="height: 544px;">
                    <el-form :model="publicform" class="offline-VIssueVerification_block-form" ref="form"
                        :rules="rules">
                        <div class="offline-VIssueVerification_block-readcard-centent">
                            <el-row :gutter="20">
                                <el-row :gutter="20" style="margin-bottom: 6px;">
                                    <el-col :span='16' class="o-font-family form-text">用户名称：</el-col>
                                    <el-col :span='8' class="o-font-family form-text" style="padding: 0px 0px;">证件类型：
                                    </el-col>
                                </el-row>
                                <el-row style="margin-bottom: 16px;">
                                    <el-col :span='16' class="o-font-family form-text">

                                        <el-input v-model="publicform.userName" style="width: 714px;"></el-input>

                                    </el-col>
                                    <el-col :span='8'>

                                        <type-select type="userCertTypeC" v-model="publicform.userCertType">
                                        </type-select>

                                    </el-col>
                                </el-row>
                                <el-row :gutter="20" style="margin-bottom: 6px;">
                                    <el-col :span='8' class="o-font-family form-text">证件号码：</el-col>
                                    <el-col :span='8' class="o-font-family form-text" style="padding: 0px 0px;">分支机构：
                                    </el-col>
                                    <el-col :span='8' class="o-font-family form-text" style="padding: 0px 0px;">代理人姓名：
                                    </el-col>
                                </el-row>
                                <el-row style="margin-bottom: 16px;">
                                    <el-col :span='8' class="o-font-family form-text">

                                        <el-input v-model="publicform.userCode" style="width:300px"></el-input>

                                    </el-col>
                                    <el-col :span='8' class="o-font-family form-text">

                                        <el-input v-model="publicform.department" style="width:300px"></el-input>

                                    </el-col>
                                    <el-col :span='8' class="o-font-family form-text">

                                        <el-input v-model="publicform.agentName" style="width:300px"></el-input>

                                    </el-col>
                                </el-row>
                                <el-row :gutter="20" style="margin-bottom: 6px;">
                                    <el-col :span='8' class="o-font-family form-text">代理人证件类型：</el-col>
                                    <el-col :span='8' class="o-font-family form-text" style="padding: 0px 0px;">代理人证件号码：
                                    </el-col>
                                    <el-col :span='8' class="o-font-family form-text" style="padding: 0px 0px;">代理人手机号码：
                                    </el-col>
                                </el-row>
                                <el-row style="margin-bottom: 16px;">
                                    <el-col :span='8' class="o-font-family form-text">

                                        <type-select type="agentIdType" v-model="publicform.agentIdType">
                                        </type-select>

                                    </el-col>
                                    <el-col :span='8' class="o-font-family form-text">

                                        <el-input v-model="publicform.agentIdNum" style="width:300px"></el-input>

                                    </el-col>
                                    <el-col :span='8' class="o-font-family form-text">

                                        <el-input v-model="publicform.agentPhoneNum" style="width:300px"></el-input>

                                    </el-col>
                                </el-row>
                                <el-row :gutter="20" style="margin-bottom: 6px;">
                                    <el-col :span='8' class="o-font-family form-text">车牌号码：
                                    </el-col>
                                    <el-col :span='8' class="o-font-family form-text" style="padding: 0px 0px;">车牌颜色：
                                    </el-col>
                                </el-row>
                                <el-row style="margin-bottom: 20px;">
                                    <el-col :span='8' class="o-font-family form-text">
                                        <el-form-item label="" prop="vehicleNumber">
                                            <el-input v-model="publicform.vehicleNumber" style="width:300px"></el-input>
                                        </el-form-item>
                                    </el-col>
                                    <el-col :span='8' class="o-font-family form-text">
                                        <el-form-item label="" prop="vehicleColor">
                                            <type-select type="vehicleColor" v-model="publicform.vehicleColor">
                                            </type-select>
                                        </el-form-item>
                                    </el-col>
                                </el-row>
                                <el-row style="margin-bottom: 20px;">
                                    <el-col :span='24' class="o-font-family form-text">
                                        选择签约银行：
                                    </el-col>
                                </el-row>
                                <el-row>
                                    <el-col v-for=" channel in channelList" :key="channel.channelId" :xl="xl" :lg="lg"
                                        style="width: auto;margin-bottom: 24px;" :md="8" :sm="8" class="mb24">
                                        <div ref="channelId"
                                            class="offline-bank-sign_bank-smallitem o-flex o-flex-align-center o-flex-justify-center"
                                            :class="[
                                      { 'is-active': selectedChannel.name === channel.remarks },
                                    ]" @click="selectChannel(channel)">
                                            <!-- <img src="../../../assets/images/bank/建设银行.png" alt=""> -->
                                            <img :src="
                                        require('../../../assets/images/bank/' +
                                          channel.channelId +
                                          '_MINI.png')
                                      " />
                                        </div>
                                    </el-col>
                                </el-row>
                            </el-row>
                        </div>
                    </el-form>
                </div>
                <el-row style="padding-top: 15px; text-align: center">
                    <el-col>
                        <el-button @click="vVerification" type="primary" size="medium" round
                            class="offline-VIssueVerification_Button">发行校验
                        </el-button>
                    </el-col>
                </el-row>
            </div>
        </div>
    </div>

</template>
<script>

    import TypeSelect from '@/components/TypeSelect';
    import { getChannelList } from '@/api/newPublish';
    import { vehicleVerification } from '@/api/vehicle';
    export default {
        data() {
            return {

                isSelect: false,
                channelList: [],
                selectedChannel: {
                    subPayChannelId: '',
                    channelId: '',
                    name: '',
                    code: '',
                },
                pform: {
                    userName: '',
                    userCertType: '',
                    userCode: '',
                    vehicleNumber: '',
                    vehicleColor: '',
                },
                publicform: {
                    userName: '',
                    userCertType: '',
                    userCode: '',
                    department: '',
                    agentName: '',
                    agentIdType: '',
                    agentIdNum: '',
                    agentPhoneNum: '',
                    vehicleNumber: '',
                    vehicleColor: '',
                },
                rules: {
                    vehicleNumber: [
                        { required: true, message: '请输入车牌号码', trigger: 'blur' },
                        { max: 12, message: '长度不能超过12个字符', trigger: 'blur' },
                    ],
                    vehicleColor: [
                        { required: true, message: '请选择车牌颜色', trigger: 'blur' },
                    ],
                }
            };

        },
        props: {

            xl: {
                type: Number,
                default: 8,
            },
            lg: {
                type: Number,
                default: 8,
            },
        },
        components: {

        },
        computed: {

            vehicleInfo() {
                return this.$store.getters.searchCarInfo;
            },
            obuInfo() {
                return this.$store.getters.searchObuInfo;
            },
            cardInfo() {
                return this.$store.getters.searchCardInfo;
            },
            userInfo() {
                return this.$store.getters.searchUserInfo;
            },
            accountInfo() {
                return this.$store.getters.searchAccountInfo;
            },
            departmentInfo() {
                return this.$store.getters.searchDepartmentInfo;
            },
        },
        watch: {

        },
        methods: {
            async getChannelList() {
                const self = this;
                const userType = this.$store.getters.registerUser.userProperty;
                const res = await getChannelList(userType);
                if (res) {
                    self.channelList = res.channelList;
                }
                // if (this.$store.getters.searchUserInfo.userProperty || this.$route.query.userProperty) {
                //     this.$nextTick(() => {
                //         this.clickchannel()
                //     })
                // }
            },
            // clickchannel() {
            //     if (this.channelList.length > 0) {

            //         for (let i = 0; i < this.channelList.length; i++) {
            //             console.log("this.refs:", this.$refs)
            //             setTimeout(() => {
            //                 if (this.channelList[i].channelId == 'ETC_UNIONPAY') {
            //                     console.log("1:", this.$refs)
            //                     console.log(this.$refs.channelId[i])
            //                     this.$refs.channelId[i].click()
            //                 }
            //             }, 200);
            //         }
            //     }

            // },
            // 选择渠道
            async selectChannel(channel) {
                const self = this;
                console.log('channnel:', channel)
                self.selectedChannel.name = channel.remarks
                self.selectedChannel.channelId = channel.channelId
                self.selectedChannel.subPayChannelId = channel.subChannelId
            },
            //发行资格校验
            async vVerification() {
                const self = this
                self.$refs.form.validate(async (valid) => {
                    if (valid) {
                        if (this.$store.getters.searchUserInfo.userProperty || this.$route.query.userProperty) {
                            if (!this.selectedChannel.channelId) {
                                this.$message.error(
                                    '请选择签约银行'
                                );
                                return
                            }
                            const res = await vehicleVerification({
                                etcUserId: this.$store.getters.registerUser.etcUserId || this.$store.getters.searchUserInfo.etcUserId,
                                vehicleNumber: this.pform.vehicleNumber || this.publicform.vehicleNumber,
                                vehicleColor: this.pform.vehicleColor || this.publicform.vehicleColor,
                                payChannel: this.selectedChannel.channelId,
                                subPayChannelId: this.selectedChannel.subPayChannelId,
                            });
                            if (res) {
                                this.$alert('可发行', '提示', {
                                    confirmButtonText: '确定',
                                    showClose: false,
                                    type: 'success',
                                }).then(() => {
                                    //新办发行流程中，若校验通过，进入车辆注册页面。
                                    if (this.$route.query.userProperty) {
                                        this.$store.dispatch('GetRegisterUser', {
                                            // 保存车牌校验中选择的支付渠道
                                            ...this.$store.getters.registerUser,
                                            channelId: this.selectedChannel.channelId,
                                        });
                                        console.log('$route.query.pathh:', this.$route.query.pathh)
                                        this.$router.push({
                                            // path: '/newpublish/carregisterinput',
                                            path: this.$route.query.pathh,
                                            query: {
                                                userProperty: this.$route.query.userProperty,
                                                uct: this.$route.query.uct,
                                                uc: this.$route.query.uc,
                                                euid: this.$route.query.euid,
                                                woid: this.$route.query.woid,
                                                department: this.$route.query.department,
                                            },
                                        });
                                    }
                                });
                            }
                        }
                    } else {
                        return false;
                    }
                });

            }
        },
        mounted() {

            if (this.$route.query.userProperty) {
                console.log('$route.userProperty:', this.$route.query.userProperty)
                //对公
                if (this.$route.query.userProperty === '2') {
                    this.publicform.userName = this.$store.getters.registerUser.userName
                    this.publicform.userCertType = this.$store.getters.registerUser.userCertType
                    this.publicform.userCode = this.$store.getters.registerUser.userCode
                    this.publicform.department = this.$store.getters.registerUser.department
                    this.publicform.agentName = this.$store.getters.registerUser.agentName
                    this.publicform.agentIdNum = this.$store.getters.registerUser.agentIdNum
                    this.publicform.agentPhoneNum = this.$store.getters.registerUser.agentPhoneNum
                    this.publicform.agentIdType = this.$store.getters.registerUser.agentIdType
                } else {
                    this.pform.userName = this.$store.getters.registerUser.userName
                    this.pform.userCertType = this.$store.getters.registerUser.userCertType
                    this.pform.userCode = this.$store.getters.registerUser.userCode
                }
            }
            this.getChannelList();
        },
        updated() {
        },
        destroyed() {

        },
    };
</script>