<!--50条记录查询-->
<template>
  <div class="offline-equipmentissuance">
    <el-form class="offline_layout-aside_search-form">
      <div class="clearfix">
        <div class="fl">
          <h4 class="offline-devicewriteoff_title">分支机构管理</h4>
        </div>
      </div>
      <div class="mt30 offline-systemInfoChecked">
        <el-input
          class="input"
          v-model="form.department"
          placeholder="分支机构名称"
        ></el-input>
        <el-input
          class="input"
          v-model="form.agentName"
          placeholder="代理人名称"
        ></el-input>
        <el-form-item>
          <type-select-input
            :app.sync="form.agentIdNum"
            :pre.sync="form.agentIdType"
            inputnochinese="true"
            type="agentIdType"
            label="代理人证件类型"
            placeholder="代理人证件号码"
            spellcheck="false"
            :len="64"
          />
        </el-form-item>
        <div class="btn">
          <el-button
            class="btn1"
            type="primary"
            @click="searchTalbe"
            icon="el-icon-search"
            size="small"
            round
            >搜索</el-button
          >
        </div>
      </div>
    </el-form>
    <div style="margin-top: 16px">
      <el-table
        :data="tableData"
        :header-cell-style="{
          width: '1074px',
          height: '41px',
          background: '#D3D6DF',
          opacity: '1',
          'border-radius': '4px 4px 0px 0px',
        }"
        :row-style="{
          width: '1074px',
          height: '38px',
          background: '#E5E5EA',
          border: '1px solid #C0C4C9',
          opacity: '1',
        }"
      >
        <el-table-column type="selection" width="42"> </el-table-column>
        <el-table-column
          label="是否有效"
          prop="notFitrule"
          :formatter="fmIsValid"
        >
        </el-table-column>
        <el-table-column
          label="是否默认"
          prop="defaultFlag"
          :formatter="fmIsDefault"
        >
        </el-table-column>
        <el-table-column label="分支机构名称" prop="department" width="100">
        </el-table-column>
        <el-table-column label="代理人名称" prop="agentName" width="100">
        </el-table-column>
        <el-table-column
          label="代理人证件类型"
          prop="agentIdTypeDesc"
          width="150"
        >
        </el-table-column>
        <el-table-column label="代理人证件号码" prop="agentIdNum" width="180">
        </el-table-column>
        <el-table-column
          label="代理人手机号码"
          prop="agentPhoneNum"
          width="120"
        >
        </el-table-column>
        <el-table-column label="代理人证件类型" prop="agentIdType" v-if="show">
        </el-table-column>
        <el-table-column label="操作" width="150">
          <template slot-scope="scope">
            <el-button
              plain
              size="mini"
              type="primary"
              :disabled="scope.row.invalidBtnDisabled"
              @click="changeBranch(scope.$index, scope.row, 'invalid')"
              >无效</el-button
            >
            <el-button
              size="mini"
              type="primary"
              :disabled="scope.row.defaultFlagBtnDisabled"
              @click="changeBranch(scope.$index, scope.row, 'default')"
              >默认</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>

    <div
      class="fl offline-workordermanagement_tableblock-pagination-desc"
      v-if="total != 0"
    >
      第{{ startRecords }}到{{ currentSize }}条，
    </div>
    <el-pagination
      background
      @current-change="handleCurrentChange"
      :current-page.sync="currentPage"
      :page-size="pageSize"
      layout="total,->,prev, pager, next,slot"
      :total="total"
    >
    </el-pagination>
  </div>
</template>

<script>
import { getCpuId } from '@/utils/dynamic';
import TypeSelectInputReg from '@/components/TypeSelectInput/indexReg.vue';
import { branchQuery } from '@/api/branch';
import { dicKeys, getDicDesByCode, getDicCodeByDes } from '@/methods/dics';
export default {
  data() {
    return {
      startRecords: 1,
      currentSize: '',
      currentPage: 1,
      tableData: [],
      total: 0,
      page: 1,
      pageSize: 20,
      form: {
        departmentName: '',
        agentName: '',
        agentIdType: '',
        agentIdNum: '',
      },
      invalidBtnDisabled: false,
      defaultBtnDisabled: false,
      show: false,
    };
  },
  watch: {},
  components: {},
  computed: {},

  methods: {
    handleSizeChange(val) {
      this.pageSize = val;
      this.getTabelInfo();
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      // 当前为第几页时调用getTabelInfo()显示第几页数据
      this.page = val;
      this.currentPage = val;
      this.getTabelInfo();
      console.log(`当前页: ${val}`);
    },
    async searchTalbe() {
      this.getTabelInfo();
    },
    async getTabelInfo() {
      const res = await branchQuery({
        ectUserId: '',
        departmentName: this.form.departmentName,
        workOrderId: '',
        pageNo: this.startRecords,
        pageSize: this.pageSize,
      });
      if (res) {
        let recordListArr = res.departmentInfo;
        for (let i = 0; i < recordListArr.length; i++) {
          // 是否默认
          if (recordListArr[i].defaultFlag === '0') {
            res.departmentInfo[i].defaultFlagBtnDisabled = true;
          } else {
            res.departmentInfo[i].defaultFlagBtnDisabled = false;
          }
          // 是否无效
          if (recordListArr[i].notFitrule === '合规') {
            res.departmentInfo[i].invalidBtnDisabled = false;
          } else {
            res.departmentInfo[i].invalidBtnDisabled = true;
          }
          recordListArr[i].agentIdTypeDesc = await getDicDesByCode(
            dicKeys.agentIdType,
            recordListArr[i].agentIdType
          );
        }
        this.tableData = recordListArr;
        this.total = res.recnum;
        this.currentSize =
          this.pageSize * this.page >= this.total
            ? this.total
            : this.page * this.pageSize;
        console.log(`this.total: ${this.total}`);
      }
    },
    changeBranch(index, row, disStr) {
      if (disStr == 'default') {
        console.log('修改分支机构默认');
      } else if (disStr == 'invalid') {
        console.log('修改分支机构无效');
      }
    },
    fmIsValid(row, column) {
      return row.notFitrule === '合规' ? (
        <div style="color: #67C33A">
          <i class="el-icon-success"></i>
        </div>
      ) : (
        <div style="color: #F56C6C">
          <i class="el-icon-error"></i>
        </div>
      );
    },
    fmIsDefault(row, column) {
      return row.defaultFlag === '0' ? (
        <div style="color: #67C33A">
          <i class="el-icon-success"></i>
        </div>
      ) : (
        <div style="color: #F56C6C">
          <i class="el-icon-error"></i>
        </div>
      );
    },
    async fmAgentIdType(row, column) {
      console.log('type:', row.agentIdType);
      console.log('dicKeys:', dicKeys.agentIdType);
      console.log(
        'dicKeys11:',
        getDicDesByCode(dicKeys.agentIdType, row.agentIdType)
      );

      const desc = await getDicDesByCode(dicKeys.agentIdType, row.agentIdType);
      // desc = '1234';
      console.log('1231:', desc);
      return desc;
    },
  },
  mounted() {
    this.getTabelInfo();
  },
};
</script>
<style scoped>
.input {
  width: 240px;
  height: 32px;
  background: #ffffff;
  border: 1px solid #c0c4c9;
  opacity: 1;
  border-radius: 3px;
  margin-right: 20px;
}
.btn {
  width: 150px;
  height: 34px;
  opacity: 1;
}
.btn1 {
  margin-left: 30px;
  margin-top: 2px;
}
</style>
