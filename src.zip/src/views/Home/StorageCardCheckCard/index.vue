<!-- 首页 -->
<template>
  <div class="offline-storagecardcheckcard">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-storagecardcheckcard_title">储值卡验卡</h4>
      </div>
    </div>
    <div class="offline-storagecardcheckcard_block">
      <el-form
        ref="repaymentForm1"
        :model="checkCardForm"
        class="offline-storagecardcheckcard_block-form"
      >
        <div class="offline-storagecardcheckcard_block-readcard-centent">
          <el-col :xl="8" :lg="8" :md="8">
            <el-row>
              <el-form-item prop="userAcctId" ref="userAcctId">
                <el-col :xl="10" :lg="10" :md="10">账户编号：</el-col>
                <el-col :xl="14" :lg="14" :md="14">{{
                  checkCardForm.userAcctId
                }}</el-col>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="acctBalance" ref="acctBalance">
                <el-col :xl="10" :lg="10" :md="10">账户余额：</el-col>
                <el-col :xl="14" :lg="14" :md="14">{{
                  checkCardForm.acctBalance
                }}</el-col>
              </el-form-item>
            </el-row>
          </el-col>
          <el-col :xl="8" :lg="8" :md="8">
            <el-row>
              <el-form-item prop="accountType" ref="accountType">
                <el-col :xl="11" :lg="11" :md="11">账户类型：</el-col>
                <el-col :xl="13" :lg="13" :md="13">{{
                  checkCardForm.accountType
                }}</el-col>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="subAcctBalance" ref="subAcctBalance">
                <el-col :xl="11" :lg="11" :md="11">圈存账户余额：</el-col>
                <el-col :xl="13" :lg="13" :md="13">{{
                  checkCardForm.subAcctBalance
                }}</el-col>
              </el-form-item>
            </el-row>
          </el-col>
          <el-col :xl="8" :lg="8" :md="8">
            <el-row>
              <el-form-item prop="accountStatus" ref="accountStatus">
                <el-col :xl="10" :lg="10" :md="10">账户状态：</el-col>
                <el-col :xl="14" :lg="14" :md="14"></el-col>
                {{ checkCardForm.accountStatus }}
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="creditfee" ref="creditfee">
                <el-col :xl="10" :lg="10" :md="10">卡面余额：</el-col>
                <el-col :xl="14" :lg="14" :md="14">{{
                  checkCardForm.epBalance
                }}</el-col>
              </el-form-item>
            </el-row>
          </el-col>
        </div>
      </el-form>
    </div>
    <div class="offline-storagecardcheckcard_detail">
      <h4 class="offline-storagecardcheckcard_title2">交易记录</h4>
    </div>
    <div class="offline-storagecardcheckcard_form">
      <el-table
        :data="tables"
        tooltip-effect="dark"
        :height="300"
        :header-cell-style="{ 'background-color': '#D3D6DF' }"
      >
        <el-table-column label="工单号" prop="workOrderId"> </el-table-column>
        <el-table-column label="交易类型" prop="tradeType"> </el-table-column>
        <el-table-column label="交易日期" prop="tradeTime"> </el-table-column>
        <el-table-column label="交易时间" prop="tradeTime"> </el-table-column>
        <el-table-column label="交易前余额" prop="txAmountBef">
        </el-table-column>
        <el-table-column label="交易金额" prop="txAmount"> </el-table-column>
        <el-table-column label="交易后余额" prop="txAmountAft">
        </el-table-column>
        <el-table-column label="支付方式" prop="payMode">
          <!-- :formatter="payModeFormatter" -->
        </el-table-column>
        <el-table-column label="操作员" prop="operatorid"> </el-table-column>
        <el-table-column label="网点" prop="netid"> </el-table-column>
      </el-table>
      <!-- <div
        style="background: #d3d6df; height: 50px"
        class="clearfix offline-storagecardcheckcard_pagination"
      >
        <div
          class="fl offline-workordermanagement_tableblock-pagination-desc"
          v-if="total"
        >
          第{{ startRecords }}到{{ currentSize }}条，
        </div>
        <el-pagination
          background
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="currentPage"
          :page-size="pageSize"
          layout="total,->,prev, pager, next,slot"
          :total="total"
        >
        </el-pagination>
      </div> -->
    </div>
    <el-button
      class="offline-storagecardcheckcard_btn"
      type="primary"
      :loading="btnLoading"
      :disabled="mainBusinessDisabled"
      @click="toCheckCard"
      >验卡
    </el-button>
    <voucher-layer
      ref="mychild2"
      :column="2"
      :info="voucherData"
      :hasFooter="false"
      :keys="voucherKeys"
      :visible.sync="voucherVisiable"
      @complete="receiptComplete"
    ></voucher-layer>
    <voucher-layer
      ref="mychilds"
      :column="2"
      :info="voucherSuccessData"
      :hasFooter="false"
      :keys="voucherSuccessKeys"
      :visible.sync="voucherSuccessVisiable"
      @complete="receiptComplete"
    ></voucher-layer>
  </div>
</template>
<script>
import VoucherLayer from '@/components/VoucherLayer';
import { getFormatAmount, getFormatAmountYuan2Fen } from '@/utils/utils';
import VoucherLayerConfirm from '@/components/VoucherLayerConfirm';
import VoucherLayerOldWorkOrder from '@/components/VoucherLayerOldWorkOrder';
import TypeSelect from '@/components/TypeSelect';
import {
  createOrder,
  systemTime,
  updateWorkOrder,
  systemParameterQuery,
} from '@/api/common';
import { queryPayList, checkCardServe } from '@/api/recharge';
import { readCardAndGetAmount, recharge, get50Records } from '@/utils/dynamic';
import {
  queryCreditRepaymentList,
  creditRepayment,
  queryCreditRepayment,
  creditRepaymentQuery,
} from '@/api/repayment';
import { etcAccountQuery } from '@/api/user';
import BDialog from '@/components/DialogBlueTitle';
import { orderQuery } from '@/api/order';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';
export default {
  data() {
    return {
      continueTip: '该储值卡有未完成的挂账还款交易，请继续',
      mainBusinessDisabled: true,
      voucherVisiable: false,
      voucherSuccessVisiable: false,
      confirmFlag: false,
      btnLoading: false,
      total: 0, //总条数
      currentPage: 1,
      page: 1, //初始显示第几页
      pageSize: 5, //每页显示多少数据
      currentSize: 0, // 当前页条数

      cvisible: false,
      title: '其他还款渠道锁定挂账明细',
      appendToBody: false,
      showclose: true,
      oldRes: '',
      checkCardForm: {
        userAcctId: '',
        accountType: '',
        accountStatus: '',
        subAcctBalance: '',
        acctBalance: '',
        epBalance: '',
      },
      tables: [],
      voucherData: {},
      voucherFooter: {},
      voucherKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        // [{ key: 'etcUserId', label: 'ETC用户ID' }],
        [
          { key: 'userName', label: '客户名称' },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'cardId', label: '卡号' },
          { key: 'userAcctId', label: '账户编号' },
          { key: 'useracctType', label: '账户类型' },
          { key: 'accountStatus', label: '账户状态' },
        ],
        [
          {
            key: 'txAmount',
            label: '圈存金额',
            color: '#027AFF',
            labelWidth: '180px',
          },
          {
            key: 'txAmountBef',
            label: '圈存账户交易前余额',
            color: '#027AFF',
            labelWidth: '180px',
          },
          {
            key: 'txAmountAft',
            label: '圈存账户交易后余额',
            color: '#027AFF',
            labelWidth: '180px',
          },
        ],
      ],
      voucherSuccessData: {},
      voucherSuccessFooter: {},
      voucherSuccessKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        // [{ key: 'etcUserId', label: 'ETC用户ID' }],
        [
          { key: 'userName', label: '客户名称' },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'cardId', label: '卡号' },
          { key: 'userAcctId', label: '账户编号' },
          { key: 'useracctType', label: '账户类型' },
          { key: 'accountStatus', label: '账户状态' },
        ],
        [
          {
            key: 'txAmount',
            label: '圈存金额',
            color: '#027AFF',
            labelWidth: '180px',
          },
          {
            key: 'txAmountBef',
            label: '圈存账户交易前余额',
            color: '#027AFF',
            labelWidth: '180px',
          },
          {
            key: 'txAmountAft',
            label: '圈存账户交易后余额',
            color: '#027AFF',
            labelWidth: '180px',
          },
          {
            key: 'epBalanceBef',
            label: '卡面交易前余额',
            color: '#027AFF',
            labelWidth: '180px',
          },
          {
            key: 'epBalanceAft',
            label: '卡面交易后余额',
            color: '#027AFF',
            labelWidth: '180px',
          },
        ],
      ],
    };
  },
  components: {
    BDialog,
    VoucherLayerConfirm,
    TypeSelect,
    VoucherLayer,
    VoucherLayerOldWorkOrder,
  },
  computed: {
    //起始记录
    startRecords() {
      return (this.page - 1) * this.pageSize + 1;
    },
    vehicleInfo() {
      return this.$store.getters.searchCarInfo;
    },
    obuInfo() {
      return this.$store.getters.searchObuInfo;
    },
    cardInfo() {
      return this.$store.getters.searchCardInfo;
    },
    userInfo() {
      return this.$store.getters.searchUserInfo;
    },
    accountInfo() {
      console.log(this.$store.getters.searchAccountInfo);
      return this.$store.getters.searchAccountInfo;
    },
    departmentInfo() {
      return this.$store.getters.searchDepartmentInfo;
    },
  },
  watch: {},
  methods: {
    async toReadCard(needWholeLoading, notNeedCardInfo) {
      this.cardIdNotSameMsg =
        '当前卡号和主页查询的卡号不一致，请清除后重新查询';
      // this.cardIdNotSameCancelMsg =
      //   '圈存账户充值成功，卡片圈存交易异常，请将充值卡片放置于桌面天线上进行验卡';
      let failObj = {
        showMsg: false,
      };
      let successObj = {
        notNeedCardInfo,
        cardInfo: this.cardInfo,
        cardIdNotSameMsg: this.cardIdNotSameMsg,
        cardIdNotSameCancelMsg: this.cardIdNotSameCancelMsg,
        cardIdNotSameCancelFunc: this.checkCard,
        successFunc: (successRes) => {
          // 自动读卡，显示卡面余额
          this.checkCardForm.epBalance = getFormatAmount(successRes.price);
        },
      };
      this.$writeLog('开始读卡');
      const res = await readCardAndGetAmount(
        needWholeLoading,
        failObj,
        successObj
      );
      return res;
    },
    // tradeTypeFormatter(row, column, cellValue, index) {
    //   getDicDesByCode(dicKeys.tradeType, cellValue).then((value) => {
    //     console.log('value', value);
    //     return value;
    //   });
    //   // return await getDicDesByCode(dicKeys.tradeType, cellValue);
    // },
    // async payModeFormatter(row, column, cellValue, index) {
    //   console.log('cellValue', cellValue);
    //   return await getDicDesByCode(dicKeys.payMode0, cellValue);
    // },
    async toCheckCard() {
      // 点击验卡按钮
      this.$writeLog('开始验卡');
      this.btnLoading = true;
      try {
        // 前端页面通过框架调动态库的50条交易
        this.$writeLog('前端页面通过框架调动态库的50条交易');
        const res50 = await get50Records();
        // 前端页面调前置的10.12验卡接口。
        if (res50.code === '0') {
          this.$writeLog('前端页面调前置的10.12验卡接口');
          const resCc = await checkCardServe({
            workOrderId: this.circleRechargeWorkOrderId,
            etcUserId: this.userInfo.etcUserId,
            curTxSeq: this.cardTxSeq,
            curBeforeAmt: this.checkCardForm.epBalance, //TODO 交易前金额 = 卡面余额？
            cardTxDetail: res50.info,
          });
          if (resCc) {
            if (resCc.loadResult === 1) {
              //前置10.12完成原圈存工单，返回成功
              this.$writeLog('前置10.12完成原圈存工单，返回成功');
              // 前端提示“确认圈存交易成功”
              this.$alert('确认圈存交易成功', '提示', {
                confirmButtonText: '确定',
                closeOnClickModal: false,
                closeOnPressEscape: false,
                showClose: false,
                type: 'success',
              }).then(() => {
                this.toSuccessReceipt();
              });
            } else if (resCc.loadResult === 2) {
              this.$writeLog('6.18返回2：确认失败');
              // 6.18返回2：确认失败
              // 前端提示“确认圈存交易失败，圈存金额已返回圈存账户”
              this.$alert('确认圈存交易失败，圈存金额已返回圈存账户', '提示', {
                confirmButtonText: '确定',
                closeOnClickModal: false,
                closeOnPressEscape: false,
                showClose: false,
                type: 'warning',
              }).then(() => {
                this.toFailReceipt();
              });
            }
          } else {
            this.btnLoading = false;
            this.$writeLog('10.12验卡接口接口异常:' + res50.msg);
          }
        } else {
          this.btnLoading = false;
          this.$writeLog('动态库的50条交易接口接口异常');
        }
      } catch (error) {
        this.btnLoading = false;
        this.$writeLog('接口超时等异常：' + JSON.stringify(error));
      }
    },
    handleSizeChange(val) {
      this.pageSize = val;
      this.repaymentSearch();
      console.log(`每页 ${val} 条`);
    },
    async handleCurrentChange(val) {
      this.page = val;
      this.currentPage = val;
      this.repaymentSearch();
      console.log(`当前页: ${val}`);
    },
    // 验卡失败回执凭证
    async toFailReceipt() {
      // 点击回执签名按钮，调后台接口，获取回执内容
      this.$writeLog('验卡失败回执凭证方法进入');
      try {
        this.$writeLog('调系统查询时间接口');
        let completeTime = await systemTime();
        let userCertType = await getDicDesByCode(
          dicKeys.userCertType,
          this.userInfo.userCertType
        );
        let userAcctType = await getDicDesByCode(
          dicKeys.useracctType,
          this.accountInfo.userAcctType
        );
        let userAcctStatus = await getDicDesByCode(
          dicKeys.useracctType,
          this.accountInfo.userAcctStatus
        );
        if (completeTime) {
          this.voucherData = {
            businessType: '账户充值',
            userName: this.userInfo.userName,
            userCertType,
            userCode: this.userInfo.userCode,
            cardId: this.cardInfo.cardID,
            userAcctId: this.accountInfo.userAcctId,
            userAcctType,
            userAcctStatus,
            txAmountBef: this.checkCardForm.subAcctBalance + '元',
            // txAmount:
            //   this.checkCardForm.txAmount.indexOf('.') < 0
            //     ? this.checkCardForm.txAmount + '.00'
            //     : this.checkCardForm.txAmount + '元',
            // txAmountAft: this.checkCardForm.txAmount + '元',
            txAmount: '100元',
            txAmountAft: '200元',
          };
          this.voucherFooter = {
            date: completeTime.systemTime,
            outletId: this.$store.getters.netid,
            operator: this.$store.getters.userName,
          };
          this.$writeLog('验卡失败回执凭证显示');
          this.voucherVisiable = true;
          this.$nextTick(() => {
            //执行调用手写板
            this.$writeLog('执行调用手写板');
            this.$refs.mychild2.sendpad();
          });
        } else {
          this.btnLoading = false;
          this.$writeLog('调系统查询时间接口报错');
        }
      } catch (error) {
        this.btnLoading = false;
        this.$writeLog('接口超时等异常：' + JSON.stringify(error));
      }
    },
    // 验卡成功回执凭证
    async toSuccessReceipt() {
      // 点击回执签名按钮，调后台接口，获取回执内容
      this.$writeLog('验卡成功回执凭证方法进入');
      try {
        this.$writeLog('调系统查询时间接口');
        let completeTime = await systemTime();
        let userCertType = await getDicDesByCode(
          dicKeys.userCertType,
          this.userInfo.userCertType
        );
        let userAcctType = await getDicDesByCode(
          dicKeys.useracctType,
          this.accountInfo.userAcctType
        );
        let userAcctStatus = await getDicDesByCode(
          dicKeys.useracctType,
          this.accountInfo.userAcctStatus
        );
        if (completeTime) {
          this.voucherSuccessData = {
            businessType: '账户充值',
            userName: this.userInfo.userName,
            userCertType,
            userCode: this.userInfo.userCode,
            cardId: this.cardInfo.cardID,
            userAcctId: this.accountInfo.userAcctId,
            userAcctType,
            userAcctStatus,
            txAmountBef: this.checkCardForm.subAcctBalance + '元',
            // txAmount:
            //   this.checkCardForm.txAmount.indexOf('.') < 0
            //     ? this.checkCardForm.txAmount + '.00'
            //     : this.checkCardForm.txAmount + '元',
            // txAmountAft: this.checkCardForm.txAmount + '元',
            txAmount: '100元',
            txAmountAft: '200元',
            epBalanceBef: this.checkCardForm.epBalance + '元',
            epBalanceAft: '200元',
          };
          this.voucherSuccessFooter = {
            date: completeTime.systemTime,
            outletId: this.$store.getters.netid,
            operator: this.$store.getters.userName,
          };
          this.$writeLog('验卡成功回执凭证显示');
          this.voucherSuccessVisiable = true;
          this.$nextTick(() => {
            //执行调用手写板
            this.$writeLog('执行调用手写板');
            this.$refs.mychilds.sendpad();
          });
        } else {
          this.btnLoading = false;
          this.$writeLog('调系统查询时间接口报错');
        }
      } catch (error) {
        this.btnLoading = false;
        this.$writeLog('接口超时等异常：' + JSON.stringify(error));
      }
    },
    async receiptComplete() {
      this.$writeLog('回执签名后');
      this.$writeLog('返回主页');
      this.btnLoading = false;
      this.$router.push({
        path: '/menu',
      });
    },
    async recordSearch() {
      try {
        // 调前置10.9接口，查询进行中的圈存工单
        // 查询条件限定：当天、本操作员、该储值卡对应的账户编号
        // TODO 10.9接口缺少url，返回参数部分缺少
        this.$writeLog('调查询系统时间接口');
        const resSpq = await systemParameterQuery({ requestType: '00' });
        if (resSpq) {
          this.$writeLog('调前置10.9接口，查询进行中的充值工单');
          const resRrs = await queryPayList({
            etcUserId: this.userInfo.etcUserId,
            useracctId: this.accountInfo.userAcctId,
            oprtId: this.oprtId,
            netId: this.netid,
            startDate: resSpq.value,
            expireDate: resSpq.value,
          });
          if (resRrs) {
            this.$writeLog('调前置10.9接口成功');
            if (resRrs.chargeList && resRrs.chargeList.length > 0) {
              this.$writeLog('该储值卡有进行中的圈存工单');
              let chargeArr = resRrs.chargeList;
              chargeArr.forEach(async (element) => {
                element.tradeType = await getDicDesByCode(
                  dicKeys.tradeType,
                  element.tradeType
                );
                element.payMode = await getDicDesByCode(
                  dicKeys.payMode0,
                  element.payMode
                );
              });
              this.tables = chargeArr;
              return true;
            } else {
              this.$writeLog('该储值卡没有进行中的圈存工单');
              this.$alert('该储值卡没有进行中的圈存工单', '提示', {
                confirmButtonText: '确定',
                closeOnClickModal: false,
                closeOnPressEscape: false,
                type: 'warning',
              });
              return;
            }
          } else {
            this.$writeLog('10.9接口异常报错');
            return;
          }
        } else {
          this.$writeLog('systemParameterQuery查询系统时间接口异常');
          return;
        }
      } catch (error) {
        this.$writeLog('接口超时等异常：' + JSON.stringify(error));
        return;
      }
    },
  },
  async mounted() {
    this.$writeLog('储值卡验卡业务进入');
    // 账户信息从综合查询获取
    if (this.isEmptyObj(this.accountInfo)) {
      this.$writeLog('缓存中没有账户信息');
      this.$alert('无法获取账户信息', '提示', {
        confirmButtonText: '确定',
        closeOnClickModal: false,
        closeOnPressEscape: false,
        type: 'warning',
      });
      return;
    }
    this.$writeLog('从综合查询获取账户信息');
    this.checkCardForm.userAcctId = this.accountInfo.userAcctId;
    this.checkCardForm.accountType = await getDicDesByCode(
      dicKeys.useracctType,
      this.accountInfo.userAcctType
    );
    this.checkCardForm.accountStatus = await getDicDesByCode(
      dicKeys.useracctStatus,
      this.accountInfo.userAcctStatus
    );
    // 账户余额和圈存账户余额从主页面的综合查询里获得
    this.checkCardForm.acctBalance = getFormatAmount(this.accountInfo.balance);
    this.checkCardForm.subAcctBalance = getFormatAmount(
      this.accountInfo.consumeLimit
    );
    // 调框架接口读取卡号和余额，首先进行卡号验证。卡号验证通过后，显示卡面余额。
    this.$writeLog(
      '调框架接口读取卡号和余额，首先进行卡号验证。卡号验证通过后，显示卡面余额'
    );
    const resRc = await this.toReadCard();
    if (resRc && resRc.code === '0') {
      // 再调前置的充值查询接口
      this.$writeLog('读卡成功，开始充值列表查询');
      const resRs = await this.recordSearch();
      if (resRs) {
        this.mainBusinessDisabled = false; // 可以进行主业务
      }
    }
  },
};
</script>