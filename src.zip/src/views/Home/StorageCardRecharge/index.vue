<!-- 首页 -->
<template>
  <div class="offline-storagecardrecharge">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-storagecardrecharge_title">储值卡充值</h4>
      </div>
    </div>
    <div class="offline-storagecardrecharge_block">
      <el-form
        ref="rechargeForm1"
        :model="rechargeForm"
        class="offline-storagecardrecharge_block-form"
      >
        <div class="offline-storagecardrecharge_block-readcard-centent">
          <el-col :xl="12" :lg="12" :md="12">
            <el-row>
              <el-form-item prop="userAcctId" ref="userAcctId">
                <el-col :xl="7" :lg="7" :md="7">账户编号：</el-col>
                <el-col :xl="17" :lg="17" :md="17">{{
                  rechargeForm.userAcctId
                }}</el-col>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="accountType" ref="accountType">
                <el-col :xl="7" :lg="7" :md="7">账户类型：</el-col>
                <el-col :xl="17" :lg="17" :md="17">{{
                  rechargeForm.accountType
                }}</el-col>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="accountStatus" ref="accountStatus">
                <el-col :xl="7" :lg="7" :md="7">账户状态：</el-col>
                <el-col :xl="17" :lg="17" :md="17"></el-col>
                {{ rechargeForm.accountStatus }}
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="isInvoice" ref="isInvoice">
                <el-checkbox
                  v-model="rechargeForm.isInvoice"
                  class="offline-storagecardrecharge_block-readcard-checkbox"
                  >部平台开票</el-checkbox
                >
              </el-form-item>
            </el-row>
          </el-col>
          <el-col :xl="12" :lg="12" :md="12">
            <el-row>
              <el-form-item prop="subAcctBalance" ref="subAcctBalance">
                <el-col :xl="8" :lg="8" :md="8">圈存账户余额：</el-col>
                <el-col :xl="16" :lg="16" :md="16">{{
                  rechargeForm.subAcctBalance
                }}</el-col>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="acctBalance" ref="acctBalance">
                <el-col :xl="8" :lg="8" :md="8">账户余额：</el-col>
                <el-col :xl="16" :lg="16" :md="16">{{
                  rechargeForm.acctBalance
                }}</el-col>
              </el-form-item>
            </el-row>
            <el-row>
              <el-form-item prop="epBalance" ref="epBalance">
                <el-col :xl="8" :lg="8" :md="8">卡面余额：</el-col>
                <el-col :xl="16" :lg="16" :md="16">{{
                  rechargeForm.epBalance
                }}</el-col>
              </el-form-item>
            </el-row>
          </el-col>
        </div>
      </el-form>
    </div>
    <!-- 充值金额选择块 -->
    <div class="offline-storagecardrecharge_amountblock_wrap">
      <div class="offline-storagecardrecharge_amountblock_title">
        选择充值金额（元）
      </div>
      <el-row :gutter="8" class="offline-storagecardrecharge_amountblock_row0">
        <el-col :md="3" v-for="(item, index) in amountBlockArr" :key="item">
          <div
            class="amountblock"
            :class="{ active: index === idx }"
            @click="idx = index"
          >
            {{ item }}
          </div>
        </el-col>
      </el-row>
    </div>
    <!-- 一键充值表单 -->
    <div class="offline-storagecardrecharge_recharge-block">
      <el-form
        ref="rechargeForm2"
        :model="rechargeForm"
        :rules="rechargeFormRules"
        :inline="true"
      >
        <!-- label-width="76px" -->
        <el-row>
          <el-form-item label="充值金额：" prop="txAmount">
            <el-input
              ref="txAmountInput"
              v-model="rechargeForm.txAmount"
            ></el-input>
          </el-form-item>
          <el-form-item label="支付方式：" prop="payMode">
            <type-select
              type="payMode0"
              v-model="rechargeForm.payMode"
              placeholder="请选择"
              class="offline-storagecardrecharge_recharge-paymode-select"
            />
          </el-form-item>
          <el-form-item label="凭证号：" prop="num">
            <el-input v-model="rechargeForm.num"></el-input>
          </el-form-item>
        </el-row>
        <el-row class="offline-storagecardrecharge_recharge-block-way">
          <el-form-item>
            <el-radio-group v-model="rechargeForm.transType">
              <el-radio label="0">电子钱包</el-radio>
              <el-radio label="1">圈存账户</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-row>
      </el-form>
      <loading-button
        type="primary"
        @click="recharge"
        ref="rechargeBtn"
        :loading="btnLoading"
        :disabled="mainBusinessDisabled"
        >充值
      </loading-button>
      <!-- <el-button @click="aaa">test</el-button> -->
    </div>
    <!-- 圈存表单 -->
    <!-- <div class="offline-storagecardrecharge_circlemoney-block">
      <el-form
        ref="circlemoneyForm"
        :model="circlemoneyForm"
        :inline="true"
        label-width="76px"
      >
        <el-form-item label="圈存金额：">
          <el-input v-model="circlemoneyForm.txAmount"></el-input>
        </el-form-item>
        <el-form-item prop="destroy" ref="destroy">
          <el-checkbox v-model="circlemoneyForm.cq">全额圈存</el-checkbox>
        </el-form-item>
      </el-form>
      <loading-button type="primary">圈存 </loading-button>
    </div> -->

    <voucher-layer-confirm
      ref="mychild1"
      :column="2"
      :info="voucherConfirmData"
      :keys="voucherConfirmKeys"
      :visible.sync="voucherConfirmVisiable"
      @complete="newBusiness"
    ></voucher-layer-confirm>
    <voucher-layer-confirm
      ref="mychildsa"
      :column="2"
      :info="voucherConfirmSubAcctData"
      :keys="voucherConfirmSubAcctKeys"
      :visible.sync="voucherConfirmSubAcctVisiable"
      @complete="newBusiness('subAcct')"
    ></voucher-layer-confirm>
    <!-- @closed="voucherConfirmClosed" -->
    <voucher-layer
      ref="mychild2"
      :column="2"
      :info="voucherData"
      :footer="voucherFooter"
      :keys="voucherKeys"
      :visible.sync="voucherVisiable"
      :cancel-show="false"
      @complete="receiptComplete"
    ></voucher-layer>
    <voucher-layer-format
      ref="mychildf"
      :column="2"
      :info="voucherData"
      :footer="voucherFooter"
      :keys="voucherKeys"
      voucherType="invoice"
      :visible.sync="voucherFormatVisiable"
      :cancel-show="false"
      @complete="receiptComplete"
    ></voucher-layer-format>
    <voucher-layer
      ref="mychildsaS"
      :column="2"
      :info="voucherSubAcctData"
      :footer="voucherSubAcctFooter"
      :keys="voucherSubAcctKeys"
      :visible.sync="voucherSubAcctVisiable"
      :cancel-show="false"
      @complete="receiptSubAcctComplete"
    ></voucher-layer>
    <voucher-layer-format
      ref="mychildfS"
      :column="2"
      :info="voucherSubAcctData"
      :footer="voucherSubAcctFooter"
      :keys="voucherSubAcctKeys"
      voucherType="invoice"
      :visible.sync="voucherFormatSubAcctVisiable"
      :cancel-show="false"
      @complete="receiptSubAcctComplete"
    ></voucher-layer-format>
    <complex-table3
      title="未完成的充值交易"
      confirmBtnText="继续"
      :tip="tip"
      :visible.sync="oldWorkOrderVisible"
      :columns="tables"
      requestListUrl="/queryPayList"
      :requestListParam="{
        pageNo: 1,
        pageSize: 10,
      }"
      @confirm="toContinue"
      :responseListFormat="responseListFormat"
      :append-to-body="true"
      :need-cancel-btn="false"
      :table-height="110"
      :defaultValue="[]"
    />
    <!-- @cancel="" -->
  </div>
</template>

<script>
import LoadingButton from '@/components/LoadingButton';
import VoucherLayer from '@/components/VoucherLayer';
import VoucherLayerFormat from '@/components/VoucherLayerFormat';
import VoucherLayerConfirm from '@/components/VoucherLayerConfirm';
import { readCardAndGetAmount, recharge, get50Records } from '@/utils/dynamic';
import { getFormatAmount, getFormatAmountYuan2Fen } from '@/utils/utils';
import ComplexTable3 from '@/components/ComplexTable3';
import {
  createOrderv,
  updateWorkOrder,
  startTblWork,
  systemParameterQuery,
  systemTime,
} from '@/api/common';
import {
  queryPayList,
  acctCircleRecharge,
  cardCircleRechargeConfirm,
  checkCardServe,
} from '@/api/recharge';
import { accountOutHandle, queryAcctLogout } from '@/api/writeoff';
import { etcAccountQuery } from '@/api/user';
import RegexInput from '@/components/RegexInput';
// import { validateAmount } from '@/utils/validate';
import { formatDate } from '@/utils/format';
import { globalBus } from '@/utils/globalBus';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';
import { mapGetters } from 'vuex';
export default {
  data() {
    return {
      amountBlockArr: [
        '100',
        '200',
        '300',
        '400',
        '500',
        '600',
        '700',
        '800',
        '900',
        '1000',
        '1500',
        '2000',
        '3000',
        '4000',
        '5000',
        '自定义',
      ],
      idx: null,
      readAgainTimes: 0,
      atfAmount: 0,
      tip: '',
      tac: '',
      cardTxSeq: '',
      cardIdNotSameMsg: '',
      cardIdNotSameCancelMsg: '',
      acctRechargeWorkOrderId: '', // 圈存账户充值工单号
      circleRechargeWorkOrderId: '', // 圈存充值工单号
      loadingBackground: 'rgba(0, 0, 0, 0.48)',
      loadingClass: 'offline-storagecardrecharge_wholeLoading',
      mainBusinessDisabled: true,
      btnLoading: false,
      wLoading: null,
      timer1: null,
      oldWorkOrderVisible: false,
      rechargeForm: {
        userAcctId: '',
        accountType: '',
        accountStatus: '',
        subAcctBalance: '',
        acctBalance: '',
        epBalance: '',
        isInvoice: false,
        txAmount: '',
        payMode: '',
        num: '',
        transType: '0',
      },
      rechargeFormRules: {
        txAmount: [
          {
            required: true,
            message: '请输入充值金额',
            trigger: 'blur',
          },
          { validator: this.validateAmount, trigger: 'blur' },
        ],
        payMode: [
          {
            required: true,
            message: '请选择支付方式',
            trigger: 'change',
          },
        ],
        // num: [
        //   { required: true, message: '请输入凭证号', trigger: 'blur' },
        //   // { max: 500, message: '长度不能超过500个字符', trigger: 'blur' },
        // ],
      },
      voucherConfirmData: {},
      // voucherConfirmFooter:{},
      voucherConfirmKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '客户名称', span: 2 },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'cardId', label: '卡号' },
          { key: 'userAcctId', label: '账户编号' },
          { key: 'userAcctType', label: '账户类型' },
        ],
        [
          { key: 'txAmountAft', label: '卡面余额' },
          {
            key: 'txAmount',
            label: '充值金额',
            color: '#027AFF',
            // fontWeight: 'bold',
          },
        ],
      ],
      voucherConfirmSubAcctVisiable: false,
      voucherConfirmSubAcctData: {},
      // voucherConfirmFooter:{},
      voucherConfirmSubAcctKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '客户名称', span: 2 },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'cardId', label: '卡号' },
          { key: 'userAcctId', label: '账户编号' },
          { key: 'userAcctType', label: '账户类型' },
        ],
        [
          { key: 'txAmountAft', label: '圈存账户余额' },
          {
            key: 'txAmount',
            label: '充值金额',
            color: '#027AFF',
            // fontWeight: 'bold',
          },
        ],
      ],
      createOrderObj: {},
      voucherData: {},
      voucherFooter: {},
      voucherKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '客户名称', span: 2 },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'cardId', label: '卡号' },
          { key: 'userAcctId', label: '账户编号' },
          { key: 'userAcctType', label: '账户类型' },
          { key: 'userAcctStatus', label: '账户状态' },
        ],
        [
          { key: 'txAmountBef', label: '交易前卡面余额', labelWidth: '150px' },
          { key: 'txAmount', label: '充值金额' },
          { key: 'txAmountAft', label: '交易后卡面余额', labelWidth: '150px' },
          { key: 'payMode', label: '支付方式' },
        ],
      ],
      voucherFormatSubAcctVisiable: false,
      voucherSubAcctVisiable: false,
      voucherSubAcctData: {},
      voucherSubAcctFooter: {},
      voucherSubAcctKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '客户名称', span: 2 },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'cardId', label: '卡号' },
          { key: 'userAcctId', label: '账户编号' },
          { key: 'userAcctType', label: '账户类型' },
          { key: 'userAcctStatus', label: '账户状态' },
        ],
        [
          {
            key: 'txAmountBef',
            label: '交易前圈存账户余额',
            labelWidth: '210px',
          },
          { key: 'txAmount', label: '充值金额' },
          {
            key: 'txAmountAft',
            label: '交易后圈存账户卡面余额',
            labelWidth: '210px',
          },
          { key: 'payMode', label: '支付方式' },
        ],
      ],
      voucherConfirmVisiable: false,
      voucherVisiable: false,
      voucherFormatVisiable: false,
      tables: [
        {
          name: '工单号',
          filed: 'workOrderId',
          edit: true,
        },
        {
          name: '卡号',
          filed: 'cardId',
          edit: true,
        },
        {
          name: '账户编号',
          filed: 'userAcctId',
          edit: true,
        },
        {
          name: '工单类型',
          filed: 'bizCode',
          edit: true,
        },
        {
          name: '交易日期',
          filed: 'tradeDate',
          edit: true,
        },
        {
          name: '交易时间',
          filed: 'tradeTime',
          edit: true,
        },
        {
          name: '交易前余额',
          filed: 'txAmountBef',
          edit: true,
        },
        {
          name: '交易金额',
          filed: 'txAmount',
          edit: true,
        },
        {
          name: '交易后余额',
          filed: 'txAmountAft',
          edit: true,
        },
        {
          name: '支付方式',
          filed: 'payModeFormat',
          edit: true,
        },
        {
          name: '操作员',
          filed: 'operatorid',
          edit: true,
        },
        {
          name: '网点',
          filed: 'netid',
          edit: true,
        },
        {
          name: '工单状态',
          filed: 'workrderStatusFormat',
          edit: true,
        },
        // {
        //   name: '代理人证件类型',
        //   filed: 'agentIdType',
        //   format: (val) => {
        //     return getDicDesByAll(this.vehicleUserTypes, val);
        //   },
        //   edit: true,
        // },
        // {
        //   name: '是否需要修改',
        //   filed: 'notFitrule',
        //   format: (val) => {
        //     val;
        //     if (val) {
        //       return (val = '是');
        //     } else {
        //       return (val = '否');
        //     }
        //   },
        //   edit: true,
        // },
      ],
    };
  },
  components: {
    VoucherLayer,
    VoucherLayerConfirm,
    VoucherLayerFormat,
    RegexInput,
    LoadingButton,
    ComplexTable3,
  },
  computed: {
    vehicleInfo() {
      return this.$store.getters.searchCarInfo;
    },
    obuInfo() {
      return this.$store.getters.searchObuInfo;
    },
    cardInfo() {
      return this.$store.getters.searchCardInfo;
    },
    userInfo() {
      return this.$store.getters.searchUserInfo;
    },
    accountInfo() {
      return this.$store.getters.searchAccountInfo;
    },
    departmentInfo() {
      return this.$store.getters.searchDepartmentInfo;
    },
    ...mapGetters(['netLevel', 'oprtId', 'netid']),
  },
  watch: {
    idx(val) {
      if (this.amountBlockArr[val] != '自定义') {
        this.rechargeForm.txAmount = this.amountBlockArr[val] + '.00';
      } else {
        this.rechargeForm.txAmount = '';
        this.$refs.txAmountInput.focus();
      }
    },
  },
  methods: {
    async toReadCard(needWholeLoading, readAgain, notNeedCardInfo) {
      this.cardIdNotSameMsg =
        '当前卡号和主页查询的卡号不一致，请清除后重新查询';
      // this.cardIdNotSameCancelMsg =
      //   '圈存账户充值成功，卡片圈存交易异常，请将充值卡片放置于桌面天线上进行验卡';
      let failObj = {
        showMsg: false,
      };
      let successObj = {
        notNeedCardInfo,
        cardInfo: this.cardInfo,
        cardIdNotSameMsg: this.cardIdNotSameMsg,
        cardIdNotSameCancelMsg: this.cardIdNotSameCancelMsg,
        cardIdNotSameCancelFunc: this.checkCard,
        successFunc: (successRes) => {
          // 自动读卡，显示卡面余额
          this.rechargeForm.epBalance = getFormatAmount(successRes.price);
        },
      };
      this.$writeLog('开始读卡');
      const res = await readCardAndGetAmount(
        needWholeLoading,
        failObj,
        successObj
      );
      this.readAgainTimes++;
      if (readAgain) {
        // 若是前端自行回读的，需判断回读的卡号，卡号不一致，提示“回读的卡号和充值卡号不一致，请将充值卡片放置于桌面天线上，重新回读”。
        this.cardIdNotSameMsg =
          '回读的卡号和充值卡号不一致，请将充值卡片放置于桌面天线上，重新回读';
        // 若回读余额失败，自动重试回读，最多回读3次
        if (res && this.readAgainTimes <= 3) {
          this.$writeLog('回读成功：' + JSON.stringify(res));
          return res;
        } else if (!res && this.readAgainTimes >= 3) {
          // 第3次失败后，提示“回读余额失败，请调整卡片位置，重试”
          this.$writeLog('回读余额失败，回读次数>=3：' + JSON.stringify(res));
          this.$confirm('回读余额失败，请调整卡片位置，重试', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            closeOnClickModal: false,
            closeOnPressEscape: false,
            type: 'warning',
          })
            .then(() => {
              //若点击确定则再次回读
              this.toReadCard(false, true);
            })
            .catch(() => {
              // 若点击取消，弹出提示“圈存账户充值成功，卡片圈存交易异常，请将充值卡片放置于桌面天线上进行验卡”
              this.$alert(this.cardIdNotSameCancelMsg, '提示', {
                confirmButtonText: '确定',
                closeOnClickModal: false,
                closeOnPressEscape: false,
                showClose: false,
                type: 'warning',
              }).then(() => {
                //只提供确定按钮，点击确定后自动执行验卡。
                this.checkCard();
              });
            });
        } else if (this.readAgainTimes < 3) {
          this.$writeLog('回读余额失败，回读次数<3，继续回读');
          this.toReadCard(false, true);
        }
      } else {
        this.$writeLog('不回读：' + JSON.stringify(res));
        return res;
      }
    },
    // 点击充值按钮
    async recharge() {
      this.$writeLog('点击充值按钮');
      this.$refs.rechargeForm2.validate(async (valid) => {
        if (valid) {
          if (
            this.rechargeForm.transType ===
            (await getDicCodeByDes(dicKeys.rechargeWay, '电子钱包'))
          ) {
            this.oneClickRecharge(); // 一键充值
          } else if (
            this.rechargeForm.transType ===
            (await getDicCodeByDes(dicKeys.rechargeWay, '圈存账户'))
          ) {
            this.subAcctRecharge(); // 圈存账户充值
          }
        }
      });
    },
    // 圈存账户充值
    async subAcctRecharge() {
      this.$writeLog('圈存账户充值进入');
      // 点击充值按钮，调框架接口读取卡号
      const resRc = await this.toReadCard(true, false, true);
      if (!resRc) {
        // 若读卡失败
        this.$writeLog('读卡失败');
        if (
          this.netLevel ===
          (await getDicCodeByDes(dicKeys.netLevel, '管理网点'))
        ) {
          // 根据根据登录时3.1.PC端操作员登录接口返回的网点级别，如果是管理网点，忽略；
          this.$writeLog('是管理网点');
          // 继续流程
        } else {
          // 如果是非管理网点，弹出提示（提示话术参考其他读卡失败），流程中止
          this.$writeLog('是非管理网点');
          this.$alert(resRc.msg + ' < br > ' + '读卡失败', '提示', {
            confirmButtonText: '确定',
            closeOnClickModal: false,
            closeOnPressEscape: false,
            showClose: false,
            type: 'warning',
          });
          return;
        }
      } else {
        // 如果读卡成功，但卡号不一致，提示“当前卡号和主页查询的卡号不一致，请清除后重新查询”，流程中止。
        if (resRc.cardId !== this.cardInfo.cardID) {
          this.$writeLog('如果读卡成功，但卡号不一致');
          this.$alert(
            ' 当前卡号和主页查询的卡号不一致，请清除后重新查询',
            '提示',
            {
              confirmButtonText: '确定',
              closeOnClickModal: false,
              closeOnPressEscape: false,
              showClose: false,
              type: 'warning',
            }
          );
          return;
        }
      }
      try {
        // 调前置接口，查询该储值卡是否有进行中的圈存账户充值工单
        // 查询条件限定当天、本操作员、该储值卡对应的账户编号
        this.$writeLog('调查询系统时间接口');
        const resSpq = await systemParameterQuery({ requestType: '00' });
        if (resSpq) {
          this.$writeLog(
            '调前置10.9接口，查询该储值卡是否有进行中的圈存账户充值工单'
          );
          const resRrs1 = await queryPayList({
            etcUserId: this.userInfo.etcUserId,
            useracctId: this.accountInfo.userAcctId,
            oprtId: this.oprtId,
            netId: this.netid,
            startDate: resSpq.value,
            expireDate: resSpq.value,
          });
          if (resRrs1.chargeList && resRrs1.chargeList.length > 0) {
            this.$writeLog('该储值卡有未完成的充值交易');
            // if (false) {
            // 如果有，弹出窗口显示原工单内容
            this.tip = '该储值卡有未完成的充值交易，请继续';
            this.oldWorkOrderVisible = true;
          } else {
            this.$writeLog('该储值卡没有未完成的充值交易，开始新充值');
            this.toSubAcctConfirm();
          }
        } else {
          this.$writeLog('systemParameterQuery查询系统时间接口异常');
        }
      } catch (error) {
        this.$writeLog('接口超时等异常：' + JSON.stringify(error));
      }
    },
    // 圈存账户确认凭证
    async toSubAcctConfirm() {
      this.$writeLog('调起圈存账户充值确认凭证');
      let userCertType = await getDicDesByCode(
        dicKeys.userCertType,
        this.userInfo.userCertType
      );
      let userAcctType = await getDicDesByCode(
        dicKeys.useracctType,
        this.accountInfo.userAcctType
      );
      // this.voucherConfirmKeys.forEach((arr) => {
      //   arr.forEach((element) => {
      //     if (element.key === 'txAmountAft') {
      //       element.label = '圈存账户余额';
      //     }
      //   });
      // });
      this.voucherConfirmSubAcctData = {
        businessType: '圈存账户充值',
        userName: this.userInfo.userName,
        userCertType,
        userCode: this.userInfo.userCode,
        cardId: this.cardInfo.cardID,
        userAcctId: this.accountInfo.userAcctId,
        userAcctType,
        txAmountAft: this.rechargeForm.subAcctBalance + '元',
        txAmount:
          this.rechargeForm.txAmount.indexOf('.') < 0
            ? this.rechargeForm.txAmount + '.00'
            : this.rechargeForm.txAmount + '元',
      };
      this.voucherConfirmSubAcctVisiable = true;
      this.$nextTick(() => {
        //执行调用手写板
        this.$writeLog('执行调用手写板');
        this.$refs.mychildsa.sendpad();
      });
    },
    // // 新圈存账户充值
    // newSubAcctBusiness() {},
    // 一键充值
    async oneClickRecharge() {
      this.$writeLog('电子钱包充值进入');
      // 点击充值按钮，首先调框架的2.14获取卡余额及卡号接口
      const resRc = await this.toReadCard(false);
      if (!resRc) return;
      this.createOrderObj = {
        oldUserId: this.userInfo.userID,
        oldUserAcctId: this.accountInfo.userAcctId,
        oldDepartmentName: this.departmentInfo.department,
        oldBuyId: this.accountInfo.signOrderNo,
        oldVehicleId: this.vehicleInfo.vehicleId,
        oldVehicleNumber: this.vehicleInfo.vehicleNumber,
        oldVehicleColor: this.vehicleInfo.vehicleColor,
        oldCardId: this.cardInfo.cardID,
        oldObuysId: this.obuInfo.printID,
        oldObuId: this.obuInfo.obuID,
        oldEtcUserId: this.userInfo.etcUserId,
        oldUsername: this.userInfo.userName,
        oldPayChannelName: this.accountInfo.paychannelName,
        oldSubPayChannelName: this.accountInfo.subPaychannelName,
      };
      try {
        // 调前置10.9接口，查询进行中的充值工单（圈存账户或圈存工单）
        // 查询条件限定当天、本操作员、该储值卡对应的账户编号
        // TODO 10.9接口缺少url，返回参数部分缺少
        this.$writeLog('调查询系统时间接口');
        const resSpq = await systemParameterQuery({ requestType: '00' });
        if (resSpq) {
          this.$writeLog('调前置10.9接口，查询进行中的充值工单');
          const resRrs = await queryPayList({
            etcUserId: this.userInfo.etcUserId,
            useracctId: this.accountInfo.userAcctId,
            oprtId: this.oprtId,
            netId: this.netid,
            startDate: resSpq.value,
            expireDate: resSpq.value,
          });
          if (resRrs) {
            if (resRrs.chargeList && resRrs.chargeList.length > 0) {
              // if (false) {
              // 如果有，弹出窗口显示原工单内容
              this.$writeLog('该储值卡有未完成的充值交易');
              this.tip = '该储值卡有未完成的充值交易，请继续';
              this.oldWorkOrderVisible = true;
            } else {
              this.$writeLog('该储值卡没有未完成的充值交易，开始新充值');
              this.toConfirm();
            }
          } else {
            this.$writeLog('10.9接口异常报错');
          }
        } else {
          this.$writeLog('systemParameterQuery查询系统时间接口异常');
        }
      } catch (error) {
        this.$writeLog('接口超时等异常：' + JSON.stringify(error));
      }
    },
    async toContinue(selection) {
      this.$writeLog('继续未完成的充值交易');
      console.log('selection', selection);
      if (selection.length === 0) {
        this.$writeLog('没有选中的业务');
        this.$alert('请选中要继续的业务', '提示', {
          confirmButtonText: '确定',
          closeOnClickModal: false,
          closeOnPressEscape: false,
          showClose: false,
          type: 'warning',
        });
      } else {
        this.oldWorkOrderVisible = false;
        // console.log(
        //   'selection[0].tradeType',
        //   selection,
        //   selection[0].tradeType
        // );
        if (selection[0].tradeType === '2') {
          // 5.继续办理圈存账户充值交易
          this.$writeLog('继续办理圈存账户充值交易');
          this.wLoading = this.$loading(
            '卡片办理圈存账户充值中，请稍候',
            this.loadingBackground,
            this.loadingClass
          );
          if (
            this.rechargeForm.transType ===
            (await getDicCodeByDes(dicKeys.rechargeWay, '电子钱包'))
          ) {
            // 如果当前场景为选择'电子钱包' - 继续办理圈存账户充值交易
            this.$writeLog('当前场景为选择电子钱包');
            this.acctRecharge();
          } else if (
            this.rechargeForm.transType ===
            (await getDicCodeByDes(dicKeys.rechargeWay, '圈存账户'))
          ) {
            // 如果当前场景为选择'圈存账户' - 继续办理圈存账户充值交易
            this.$writeLog('当前场景为选择圈存账户');
            this.toSubAcctConfirm();
          }
        } else if (selection[0].tradeType === '3') {
          this.$writeLog('继续办理卡片圈存充值交易');
          console.log('继续-卡片圈存中');
          // 6.	如果当前场景为继续办理储值卡圈存。
          // （1）	前端显示loading页面，话术“卡片圈存中，请稍候”。
          this.wLoading = this.$loading(
            '卡片圈存中，请稍候',
            this.loadingBackground,
            this.loadingClass
          );
          // （2）	首先进行验卡流程。如果验卡结果为1:完成写卡确认，参考4（10）。
          this.checkCard('continue');
          // （3）	如果验卡结果为“2:未完成写卡确认，正确返回至圈存账户”，参考4（8）-4（10）。
          // 代码包含在this.checkCard('continue');中
        }
      }
    },
    // 新业务
    async newBusiness(type) {
      try {
        // 用户确认后，开始充值流程
        //（1）	前端显示loading页面，话术“正在进行圈存账户充值”。
        this.$writeLog('储值卡充值确认完毕，正在进行圈存账户充值');
        this.wLoading = this.$loading(
          '正在充值中，请稍候',
          this.loadingBackground,
          this.loadingClass
        );
        //（2）	前端调前置的12.13.创建工单接口，bizCode=27。
        this.$writeLog('调前置的12.13.创建工单接口');
        const bizCode0 = await getDicCodeByDes(dicKeys.bizCode, '储值卡充值');

        const resCo = await createOrderv({
          bizCode0,
          ...this.createOrderObj,
        });
        if (resCo) {
          this.acctRechargeWorkOrderId = resCo.workOrderId;
          this.$writeLog('创建工单成功，调前置的10.8.圈存账户充值申请接口');
          this.acctRecharge(type);
        } else {
          this.wLoading.close();
        }
      } catch (error) {
        this.$writeLog('接口超时等异常：' + JSON.stringify(error));
        this.wLoading.close();
      }
    },
    // 圈存账户充值
    async acctRecharge(type) {
      // （3）	前端调前置的10.8.圈存账户充值申请接口
      let resAcr;
      try {
        this.$writeLog('前端调前置的10.8.圈存账户充值申请接口');
        resAcr = await acctCircleRecharge({
          workOrderId: this.acctRechargeWorkOrderId,
          etcUserId: this.userInfo.etcUserId,
          payMode: this.rechargeForm.payMode,
          txAmount: getFormatAmountYuan2Fen(this.rechargeForm.txAmount),
          describe: '',
        });
      } catch (error) {
        this.$writeLog('接口超时等异常：' + JSON.stringify(error));
        this.wLoading.close();
      }
      if (resAcr) {
        this.$writeLog('圈存账户充值申请成功，圈存账户充值成功');
        // // （5）	若前置的10.8接口返回成功，loading页面追加1行“圈存账户充值成功”。
        // this.wLoading.setText('正在进行圈存账户充值\n圈存账户充值成功');
        // // （6）	loading页面追加1行“正在进行卡片圈存”。
        // this.wLoading.setText(
        //   '正在进行圈存账户充值\n圈存账户充值成功\n正在进行卡片圈存'
        // );
        if (type !== 'subAcct') {
          this.$writeLog('电子钱包模式');
          // 一键充值模式
          // 判余额
          let befAmount = getFormatAmountYuan2Fen(this.rechargeForm.epBalance);
          let txAmount = getFormatAmountYuan2Fen(this.rechargeForm.txAmount);
          // 当前卡余额=交易前卡面余额+充值金额，说明 已圈存 // todo 待确认
          if (this.atfAmount != 0 && befAmount + txAmount === this.atfAmount) {
            // 已圈存
            this.$writeLog('当前卡余额=交易前卡面余额+充值金额，说明已圈存');
            // 前端调前置的10.5.卡片圈存确认接口
            this.circleRechargeConfirm();
          } else {
            // 未圈存，执行圈存操作
            this.$writeLog('正在进行卡片圈存');
            this.circleRecharge(this.createOrderObj);
          }
        } else {
          this.$writeLog('圈存账户充值模式');
          // 圈存账户充值模式
          // loading页面关闭，
          this.wLoading.close();
          // 弹出圈存账户充值回执签名凭证
          this.toSubAcctReceipt();
        }
      } else {
        // （4）	若前置的10.8接口返回失败，前端流程中止
        this.wLoading.close();
      }
    },
    //圈存
    async circleRecharge(createOrderObj) {
      try {
        // （7）	开始卡片圈存操作。页面调前置的12.13.创建工单接口，bizCode=29。
        this.$writeLog('开始卡片圈存操作。页面调前置的12.13.创建工单接口');
        const bizCode1 = await getDicCodeByDes(dicKeys.bizCode, '储值卡圈存');
        const resCo1 = await createOrderv({
          bizCode1,
          ...createOrderObj,
        });
        if (resCo1) {
          this.circleRechargeWorkOrderId = resCo1.workOrderId;
          this.circleRechargeSpecify();
        } else {
          this.$writeLog('12.13.创建工单接口异常');
          this.wLoading.close();
        }
      } catch (error) {
        this.$writeLog('接口超时等异常：' + JSON.stringify(error));
        this.wLoading.close();
      }
    },
    // 卡片圈存具体步骤
    async circleRechargeSpecify() {
      // （8）	前端调框架的2.16储值卡充值接口
      this.$writeLog(
        '12.13.创建工单接口返回成功，前端调框架的2.16储值卡充值接口'
      );
      let resRec;
      try {
        resRec = await recharge({
          strCardID: this.cardInfo.cardID,
          dPrice: getFormatAmountYuan2Fen(this.rechargeForm.txAmount),
          strWorkId: this.circleRechargeWorkOrderId,
          strETCUserId: this.userInfo.etcUserId,
        });
      } catch (error) {
        this.$writeLog('接口超时等异常：' + JSON.stringify(error));
        this.wLoading.close();
      }
      let circleRechargeFailTxt =
        '圈存账户充值成功，卡片圈存交易异常，请将充值卡片放置于桌面天线上进行验卡';
      let circleRechargeAbnormalTxt =
        '圈存账户充值成功，卡片圈存交易异常，请将充值卡片放置于桌面天线上进行验卡';
      let befAmount = getFormatAmountYuan2Fen(this.rechargeForm.epBalance);
      if (resRec) {
        this.$writeLog('2.16储值卡充值接口返回成功');
        //（9）	前端根据交易后卡面余额确认充值成功还是失败。
        let txAmount = getFormatAmountYuan2Fen(this.rechargeForm.txAmount);
        this.atfAmount = resRec.AfterBalance;
        this.cardTxSeq = resRec.EWalletTxid;
        this.tac = resRec.TacData;
        console.log(
          '各种值',
          txAmount,
          this.atfAmount,
          this.cardTxSeq,
          this.tac
        );
        // 框架的储值卡圈存接口返回交易后卡面余额,当前卡余额=交易前卡面余额+充值金额，说明卡片圈存成功
        if (befAmount + txAmount === this.atfAmount) {
          this.$writeLog('当前卡余额=交易前卡面余额+充值金额');
          // 前端调前置的10.5.卡片圈存确认接口
          this.circleRechargeConfirm();
        } else if (befAmount === this.atfAmount) {
          // 若当前卡余额=交易前卡面余额，说明圈存失败
          // 页面提示“圈存账户充值成功，卡片圈存交易异常，请将充值卡片放置于桌面天线上进行验卡”。
          // 只提供确定按钮，点击确定后自动执行验卡。
          this.$writeLog('当前卡余额=交易前卡面余额，说明圈存失败');
          this.$alert(circleRechargeFailTxt, '提示', {
            confirmButtonText: '确定',
            closeOnClickModal: false,
            closeOnPressEscape: false,
            showClose: false,
            type: 'warning',
          }).then(() => {
            //只提供确定按钮，点击确定后自动执行验卡。
            this.checkCard();
          });
        } else if (
          befAmount + txAmount != this.atfAmount &&
          befAmount != this.atfAmount
        ) {
          // 若当前卡余额≠交易前卡面余额+充值金额，且当前卡余额≠交易前卡面余额
          this.$writeLog(
            '当前卡余额≠交易前卡面余额+充值金额，且当前卡余额≠交易前卡面余额'
          );
          this.$alert(circleRechargeAbnormalTxt, '提示', {
            confirmButtonText: '确定',
            closeOnClickModal: false,
            closeOnPressEscape: false,
            showClose: false,
            type: 'warning',
          }).then(() => {
            //只提供确定按钮，点击确定后自动执行验卡。
            this.checkCard();
          });
        } else {
          this.$writeLog('交易金额异常');
        }
      } else {
        this.$writeLog(
          '2.16储值卡充值接口返回失败，前端页面调框架的2.14获取卡余额及卡号接口进行回读余额'
        );
        // 若未收到框架的返回，前端页面调框架的2.14获取卡余额及卡号接口进行回读余额。
        const resRcd = await this.toReadCard(false, true);
        if (resRcd) {
          this.$writeLog('2.14获取卡余额及卡号接口返回成功');
          this.atfAmount = resRcd.price;
          this.cardTxSeq = resRcd.reloadSeq;
          // 当前卡余额=交易前卡面余额+充值金额，说明卡片圈存成功
          if (befAmount + txAmount === this.atfAmount) {
            this.$writeLog('当前卡余额=交易前卡面余额+充值金额');
            // 前端调前置的10.5.卡片圈存确认接口
            this.circleRechargeConfirm();
          } else if (befAmount === this.atfAmount) {
            // 若当前卡余额=交易前卡面余额，说明圈存失败
            // 页面提示“圈存账户充值成功，卡片圈存交易异常，请将充值卡片放置于桌面天线上进行验卡”。
            // 只提供确定按钮，点击确定后自动执行验卡。
            this.$writeLog('当前卡余额=交易前卡面余额，说明圈存失败');
            this.$alert(circleRechargeFailTxt, '提示', {
              confirmButtonText: '确定',
              closeOnClickModal: false,
              closeOnPressEscape: false,
              showClose: false,
              type: 'warning',
            }).then(() => {
              //只提供确定按钮，点击确定后自动执行验卡。
              this.checkCard();
            });
          } else if (
            befAmount + txAmount != this.atfAmount &&
            befAmount != this.atfAmount
          ) {
            // 若当前卡余额≠交易前卡面余额+充值金额，且当前卡余额≠交易前卡面余额
            this.$writeLog(
              '当前卡余额≠交易前卡面余额+充值金额，且当前卡余额≠交易前卡面余额'
            );
            this.$alert(circleRechargeAbnormalTxt, '提示', {
              confirmButtonText: '确定',
              closeOnClickModal: false,
              closeOnPressEscape: false,
              showClose: false,
              type: 'warning',
            }).then(() => {
              //只提供确定按钮，点击确定后自动执行验卡。
              this.checkCard();
            });
          }
        } else {
          console.log('else');
          // 不存在进入这个else的情况，resRcd不为false才会返回
        }
      }
    },
    // 卡片圈存确认
    async circleRechargeConfirm() {
      this.$writeLog('进入circleRechargeConfirm()卡片圈存确认方法');
      let resTime = null;
      try {
        this.$writeLog('调用查询系统时间接口');
        resTime = await systemTime();
      } catch (error) {
        this.$writeLog('接口超时等异常：' + JSON.stringify(error));
        this.wLoading.close();
        return;
      }
      if (resTime) {
        // 前端调前置的10.5.卡片圈存确认接口
        try {
          this.$writeLog('前端调前置的10.5.卡片圈存确认接口');
          const res = await cardCircleRechargeConfirm({
            workOrderId: this.circleRechargeWorkOrderId,
            etcUserId: this.userInfo.etcUserId,
            tradeTime: resTime.systemTime,
            cardBalance: this.atfAmount,
            cardTxSeq: this.cardTxSeq,
            tac: this.tac,
          });
          if (res) {
            // 若接口返回成功，loading页面追加1行“卡片圈存成功”
            this.$writeLog('10.5.卡片圈存确认接口返回成功”');
            // this.wLoading.setText(
            //   '正在进行圈存账户充值\n圈存账户充值成功\n正在进行卡片圈存\n卡片圈存成功'
            // );
            // 随后loading页面关闭，显示回执凭证
            this.$writeLog('随后loading页面关闭，显示回执凭证');
            this.wLoading.close();
            this.toReceipt();
          } else {
            // 若10.5接口超时或返回失败
            // 页面提示“圈存账户充值成功，卡片圈存交易异常，请将充值卡片放置于桌面天线上进行验卡”
            this.$writeLog('10.5.卡片圈存确认接口异常');
            this.$writeLog(
              '页面提示-圈存账户充值成功，卡片圈存交易异常，请将充值卡片放置于桌面天线上进行验卡'
            );
            this.$alert(this.cardIdNotSameCancelMsg, '提示', {
              confirmButtonText: '确定',
              closeOnClickModal: false,
              closeOnPressEscape: false,
              showClose: false,
              type: 'warning',
            }).then(() => {
              this.$writeLog('页面提示点击确定');
              //只提供确定按钮，点击确定后自动执行验卡。
              this.checkCard();
            });
          }
        } catch (error) {
          this.$writeLog('接口超时等异常：' + JSON.stringify(error));
          // 若10.5接口超时或返回失败
          // 页面提示“圈存账户充值成功，卡片圈存交易异常，请将充值卡片放置于桌面天线上进行验卡”
          this.$writeLog(
            '页面提示-圈存账户充值成功，卡片圈存交易异常，请将充值卡片放置于桌面天线上进行验卡'
          );
          this.$alert(this.cardIdNotSameCancelMsg, '提示', {
            confirmButtonText: '确定',
            closeOnClickModal: false,
            closeOnPressEscape: false,
            showClose: false,
            type: 'warning',
          }).then(() => {
            this.$writeLog('页面提示点击确定');
            //只提供确定按钮，点击确定后自动执行验卡。
            this.checkCard();
          });
        }
      } else {
        this.$writeLog('调用查询系统时间接口异常');
        this.wLoading.close();
      }
    },
    // 组织机构返回数据处理
    responseListFormat(data) {
      let chargeArr = data.chargeList;
      chargeArr.forEach(async (element) => {
        element.workrderStatusFormat = await getDicDesByCode(
          dicKeys.status,
          element.workrderStatus
        );
        element.payModeFormat = await getDicDesByCode(
          dicKeys.payMode0,
          element.payMode
        );
        element.tradeTypeFormat = await getDicDesByCode(
          dicKeys.tradeType,
          element.tradeType
        );
      });
      let tables = chargeArr;
      return tables;
    },
    // 确认凭证
    async toConfirm() {
      this.$writeLog('调起储值卡充值确认凭证');
      let userCertType = await getDicDesByCode(
        dicKeys.userCertType,
        this.userInfo.userCertType
      );
      let userAcctType = await getDicDesByCode(
        dicKeys.useracctType,
        this.accountInfo.userAcctType
      );
      this.voucherConfirmData = {
        businessType: '充值',
        userName: this.userInfo.userName,
        userCertType,
        userCode: this.userInfo.userCode,
        cardId: this.cardInfo.cardID,
        userAcctId: this.accountInfo.userAcctId,
        userAcctType,
        txAmountAft: this.rechargeForm.epBalance + '元',
        txAmount:
          this.rechargeForm.txAmount.indexOf('.') < 0
            ? this.rechargeForm.txAmount + '.00'
            : this.rechargeForm.txAmount + '元',
      };
      this.voucherConfirmVisiable = true;
      this.$nextTick(() => {
        //执行调用手写板
        this.$writeLog('执行调用手写板');
        this.$refs.mychild1.sendpad();
      });
    },
    // 回执凭证
    async toReceipt() {
      // 点击回执签名按钮，调后台接口，获取回执内容
      // const resQuery = await queryReceiptLostCard({
      //   etcUserId: this.userInfo.etcUserId,
      //   workOrderId: this.workOrderID,
      // });
      this.$writeLog('电子钱包回执凭证');
      try {
        // const resQuery = {
        //   userInfo: {
        //     userCertType: '203',
        //     userName: 'www',
        //     userCode: '2031111',
        //   },
        // };
        // if (resQuery) {
        let completeTime = await systemTime();
        let userCertType = await getDicDesByCode(
          dicKeys.userCertType,
          this.userInfo.userCertType
        );
        let userAcctType = await getDicDesByCode(
          dicKeys.useracctType,
          this.accountInfo.userAcctType
        );
        let userAcctStatus = await getDicDesByCode(
          dicKeys.useracctType,
          this.accountInfo.userAcctStatus
        );
        let payMode = await getDicDesByCode(
          dicKeys.payMode0,
          this.rechargeForm.payMode
        );
        if (completeTime) {
          this.voucherData = {
            businessType: '充值',
            userName: this.userInfo.userName,
            userCertType,
            userCode: this.userInfo.userCode,
            cardId: this.cardInfo.cardID,
            userAcctId: this.accountInfo.userAcctId,
            userAcctType,
            userAcctStatus,
            txAmountBef: this.rechargeForm.epBalance + '元',
            txAmount:
              this.rechargeForm.txAmount.indexOf('.') < 0
                ? this.rechargeForm.txAmount + '.00'
                : this.rechargeForm.txAmount + '元',
            txAmountAft: getFormatAmount(this.atfAmount) + '.00' + '元',
            payMode,
          };
          this.voucherFooter = {
            date: completeTime.systemTime,
            outletId: this.$store.getters.netid,
            operator: this.$store.getters.userName,
          };
          this.rechargeForm.isInvoice
            ? (this.voucherFormatVisiable = true)
            : (this.voucherVisiable = true);
          this.$nextTick(() => {
            //执行调用手写板
            this.rechargeForm.isInvoice
              ? this.$refs.mychildf.sendpad()
              : this.$refs.mychild2.sendpad();
          });
        }
        // } else {
        //   this.$writeLog('接口异常'); // todo 具体什么接口异常
        // }
      } catch (error) {
        this.$writeLog('接口超时等异常：' + JSON.stringify(error));
      }
    },
    // 圈存账户充值回执凭证
    async toSubAcctReceipt() {
      this.$writeLog(' 圈存账户充值回执凭证');
      // 点击回执签名按钮，调后台接口，获取回执内容
      // const resQuery = await queryReceiptLostCard({
      //   etcUserId: this.userInfo.etcUserId,
      //   workOrderId: this.workOrderID,
      // });
      try {
        // const resQuery = {
        //   userInfo: {
        //     userCertType: '203',
        //     userName: 'www',
        //     userCode: '2031111',
        //   },
        // };
        // if (resQuery) {
        let completeTime = await systemTime();
        let userCertType = await getDicDesByCode(
          dicKeys.userCertType,
          this.userInfo.userCertType
        );
        let userAcctType = await getDicDesByCode(
          dicKeys.useracctType,
          this.accountInfo.userAcctType
        );
        let userAcctStatus = await getDicDesByCode(
          dicKeys.useracctType,
          this.accountInfo.userAcctStatus
        );
        let payMode = await getDicDesByCode(
          dicKeys.payMode0,
          this.rechargeForm.payMode
        );
        if (completeTime) {
          this.voucherSubAcctData = {
            businessType: '圈存账户充值',
            userName: this.userInfo.userName,
            userCertType,
            userCode: this.userInfo.userCode,
            cardId: this.cardInfo.cardID,
            userAcctId: this.accountInfo.userAcctId,
            userAcctType,
            userAcctStatus,
            txAmountBef: this.rechargeForm.subAcctBalance + '元',
            txAmount:
              this.rechargeForm.txAmount.indexOf('.') < 0
                ? this.rechargeForm.txAmount + '.00'
                : this.rechargeForm.txAmount + '元',
            txAmountAft: getFormatAmount(20000) + '元',
            payMode,
          };
          this.voucherSubAcctFooter = {
            date: completeTime.systemTime,
            outletId: this.$store.getters.netid,
            operator: this.$store.getters.userName,
          };
          this.rechargeForm.isInvoice
            ? (this.voucherFormatSubAcctVisiable = true)
            : (this.voucherSubAcctVisiable = true);
          this.$nextTick(() => {
            //执行调用手写板
            this.rechargeForm.isInvoice
              ? this.$refs.mychildfS.sendpad()
              : this.$refs.mychildsaS.sendpad();
          });
        }
        // } else {
        //   this.$writeLog('接口异常'); // todo 具体什么接口异常
        // }
      } catch (error) {
        this.$writeLog('接口超时等异常：' + JSON.stringify(error));
      }
    },
    // 回执确认
    receiptComplete() {
      this.$writeLog(' 回执签名后弹框提示-充值成功');
      // 回执签名后弹框提示“充值成功”。
      this.$alert('充值成功', '提示', {
        confirmButtonText: '确定',
        closeOnClickModal: false,
        closeOnPressEscape: false,
        showClose: false,
        type: 'success',
      }).then(() => {
        this.wLoading = null;
        // 返回主页
        this.$writeLog('返回主页');
        this.$router.push({
          path: '/menu',
        });
      });
    },
    // 圈存账户充值回执确认
    receiptSubAcctComplete() {
      this.$writeLog('圈存账户充值回执确认');
      // 回执签名后弹框提示“充值成功”。
      this.$writeLog('页面提示-圈存账户充值成功，需要对卡片进行圈存吗？');
      this.$confirm('圈存账户充值成功，需要对卡片进行圈存吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        closeOnClickModal: false,
        closeOnPressEscape: false,
        type: 'success',
      })
        .then(() => {
          // 选择是，则跳转到储值卡圈存页面 todo
          this.$writeLog('页面提示点击确定，则跳转到储值卡圈存页面');
          this.$router.push({
            path: '/menu',
          });
        })
        .catch(() => {
          // 选择否，返回主页
          this.$writeLog('页面提示点击取消，返回主页');
          this.$router.push({
            path: '/menu',
          });
        });
      this.wLoading = null;
    },
    // 验卡
    async checkCard(type) {
      this.$writeLog('开始验卡');
      try {
        // 前端页面通过框架调动态库的50条交易
        this.$writeLog('前端页面通过框架调动态库的50条交易');
        const res50 = await get50Records();
        // 前端页面调前置的10.12验卡接口。
        if (res50.code === '0') {
          this.$writeLog('前端页面调前置的10.12验卡接口');
          const resCc = await checkCardServe({
            workOrderId: this.circleRechargeWorkOrderId,
            etcUserId: this.userInfo.etcUserId,
            curTxSeq: this.cardTxSeq,
            curBeforeAmt: this.rechargeForm.epBalance, //TODO 交易前金额 = 卡面余额？
            cardTxDetail: res50.info,
          });
          if (resCc) {
            // loading页面关闭
            this.$writeLog('loading页面关闭');
            this.wLoading.close();
            // 10.12直接完成工单，并返回成功
            if (resCc.loadResult === 1) {
              this.$writeLog('10.12直接完成工单，并返回成功');
              // 完成写卡确认
              // 显示回执凭证
              this.toReceipt();
            } else if (resCc.loadResult === 2) {
              this.$writeLog(
                '未完成写卡确认，正确返回至圈存账户，卡片圈存失败'
              );
              // 未完成写卡确认，正确返回至圈存账户，卡片圈存失败
              if (type === 'continue') {
                this.circleRechargeSpecify();
              } else {
                this.$alert('卡片圈存失败', '提示', {
                  confirmButtonText: '确定',
                  closeOnClickModal: false,
                  closeOnPressEscape: false,
                  showClose: false,
                  type: 'warning',
                }).then(() => {});
              }
            } else if (resCc.loadResult === 3) {
              this.$writeLog('无法验证，需人工校验');
              // 无法验证，需人工校验
              this.$alert(
                '圈存账户充值成功，卡片圈存交易异常，请联系管理员人工确认',
                '提示',
                {
                  confirmButtonText: '确定',
                  closeOnClickModal: false,
                  closeOnPressEscape: false,
                  showClose: false,
                  type: 'warning',
                }
              ).then(() => {
                this.$writeLog(
                  '页面提示-圈存账户充值成功，卡片圈存交易异常，请联系管理员人工-点击确定'
                );
              });
            }
          } else {
            this.$writeLog('10.12验卡接口接口异常:' + res50.msg);
            this.wLoading.close();
          }
        } else {
          this.$writeLog('动态库的50条交易接口接口异常');
          this.wLoading.close();
        }
      } catch (error) {
        this.$writeLog('接口超时等异常：' + JSON.stringify(error));
        this.wLoading.close();
      }
    },
    validateAmount(rule, value, callback) {
      if (value == '' || value == undefined || value == null) {
        callback();
      } else {
        if (getFormatAmountYuan2Fen(value) >= 1000000) {
          console.log('value', value);
          console.log(
            'getFormatAmountYuan2Fen',
            getFormatAmountYuan2Fen(value)
          );
          callback(new Error('充值金额须小于10000.00元'));
        } else {
          callback();
        }
      }
    },
  },
  async mounted() {
    this.$writeLog('储值卡充值业务进入');
    // 账户信息从综合查询获取
    if (this.isEmptyObj(this.accountInfo)) {
      this.$writeLog('缓存中没有账户信息');
      this.$alert('无法获取账户信息', '提示', {
        confirmButtonText: '确定',
        closeOnClickModal: false,
        closeOnPressEscape: false,
        type: 'warning',
      });
      return;
    }
    this.$writeLog('从综合查询获取账户信息');
    this.rechargeForm.userAcctId = this.accountInfo.userAcctId;
    this.rechargeForm.accountType = await getDicDesByCode(
      dicKeys.useracctType,
      this.accountInfo.userAcctType
    );
    this.rechargeForm.accountStatus = await getDicDesByCode(
      dicKeys.useracctStatus,
      this.accountInfo.userAcctStatus
    );
    // 账户余额和圈存账户余额从主页面的综合查询里获得
    this.rechargeForm.acctBalance = getFormatAmount(this.accountInfo.balance);
    this.rechargeForm.subAcctBalance = getFormatAmount(
      this.accountInfo.consumeLimit
    );
    // 读卡获取卡面余额
    const resRc = await this.toReadCard(true);
    if (resRc && resRc.code === '0') {
      this.mainBusinessDisabled = false; // 可以进行主业务
    } else {
      this.$writeLog('读卡失败');
    }
    this.cardIdNotSameCancelMsg =
      '圈存账户充值成功，卡片圈存交易异常，请将充值卡片放置于桌面天线上进行验卡';
  },
  destroyed() {
    // clearTimeout(this.timer1);
  },
};
</script>