<!-- 首页 -->
<template>
  <div class="offline-replacecard">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-replacecard_title">换卡</h4>
      </div>
    </div>
    <div class="o-flex offline-replacecard_step-block-wrap">
      <div class="offline-replacecard_step-block">
        <div class="offline-replacecard_step-title-wrap">
          <span class="offline-replacecard_step-title-no">1</span>
          <span class="offline-replacecard_step-title-desc">旧卡核销</span>
        </div>
        <div class="o-flex-column offline-replacecard_step2-content-wrap">
          <el-form
            ref="form"
            :model="form"
            :rules="rules"
            :validate-on-rule-change="false"
          >
            <el-row :gutter="0" class="offline-replacecard_step-content-select">
              <el-col :xl="8" :lg="8" :md="8">
                <el-radio v-model="radio" label="haveCard" @change="radioChange"
                  >旧卡有卡</el-radio
                ></el-col
              >
              <el-col :xl="12" :lg="12" :md="12">
                <el-radio v-model="radio" label="noCard" @change="radioChange"
                  >旧卡无卡</el-radio
                ></el-col
              >
            </el-row>
            <el-button
              class="offline-replacecard_step-content-btn"
              size="small"
              type="primary"
              :style="{ display: readCardDisplay }"
              @click="readOldCard"
              :loading="loadingReadCard"
              round
            >
              <i class="icon iconfont iconbofang" /> 读卡
            </el-button>
            <div>
              <el-row :gutter="0" class="offline-replacecard_step-content-row">
                <el-col :md="24" :lg="24">
                  <el-form-item label="旧卡卡号" prop="oldCard.cardNumber">
                    <el-input
                      ref="oldCardNumberInput"
                      v-model="form.oldCard.cardNumber"
                      placeholder="请输入卡号"
                      @change="oldCardNumberInputChange"
                    ></el-input>
                  </el-form-item>
                </el-col>
                <!-- <el-col :xl="8" :lg="8" :md="8">旧卡卡号</el-col>
                <el-col :xl="16" :lg="16" :md="16">
                  <el-input
                    v-model="form.oldCard.cardNumber"
                    placeholder="请输入卡号"
                  ></el-input>
                </el-col> -->
              </el-row>
              <!-- <el-row :gutter="0" class="offline-replacecard_step-content-row">
                <el-col :xl="8" :lg="8" :md="8">旧卡类型</el-col>
                <el-col :xl="16" :lg="16" :md="16">{{
                  form.oldCard.cardType
                }}</el-col>
              </el-row> -->
              <!-- <el-row :gutter="0" class="offline-replacecard_step-content-row">
            <el-col :xl="8" :lg="8" :md="8">旧卡状态</el-col>
            <el-col :xl="16" :lg="16" :md="16">挂失</el-col>
          </el-row> -->
              <!-- <el-row :gutter="0" class="offline-replacecard_step-content-row">
                <el-col :xl="8" :lg="8" :md="8">旧卡版本号</el-col>
                <el-col :xl="16" :lg="16" :md="16">{{
                  form.oldCard.cardVersion
                }}</el-col>
              </el-row> -->
            </div>
          </el-form>
        </div>
        <div class="offline-replacecard_step-bottom">
          <el-popconfirm
            icon="el-icon-info"
            iconColor="red"
            title="卡片核销不能回退，确认要核销吗？"
            @onConfirm="confirmFlagc ? writeoff() : toConfirm()"
          >
            <el-button
              slot="reference"
              class="offline-replacecard_step-btn offline-replacecard_step2-btn"
              size="medium "
              type="danger "
              :disabled="jkhxDisabled"
              round
            >
              旧卡核销
            </el-button>
          </el-popconfirm>
        </div>
      </div>
      <div class="offline-replacecard_step-block">
        <div class="offline-replacecard_step-title-wrap">
          <span class="offline-replacecard_step-title-no">2</span>
          <span class="offline-replacecard_step-title-desc">新卡发行</span>
        </div>
        <img
          class="offline-replacecard_step-pic"
          src="../../../assets/images/pic_xkfx.png"
        />
        <div class="o-flex-column offline-replacecard_step3-content-wrap">
          <el-button
            class="offline-replacecard_step-content-btn"
            size="small"
            type="primary"
            @click="readNewCard"
            :loading="loadingReadNewCard"
            round
          >
            <i class="icon iconfont iconbofang" /> 读卡
          </el-button>
          <el-row :gutter="0" class="offline-replacecard_step-content-row">
            <el-col :xl="8" :lg="8" :md="8">新卡卡号</el-col>
            <el-col :xl="16" :lg="16" :md="16">{{ newCardNumber }}</el-col>
          </el-row>
        </div>
        <div class="offline-replacecard_step-bottom">
          <el-button
            class="offline-replacecard_step3-btn"
            size="medium"
            type="primary"
            :disabled="issueCardDisabled"
            @click="confirmFlag ? issueNewCard() : toReceipt()"
            round
          >
            新卡发行
          </el-button>
        </div>
      </div>
    </div>
    <el-button
      class=""
      size="medium "
      type="primary "
      @click="voucherConfirmVisiable = true"
      round
    >
      完成
    </el-button>
    <el-button size="medium" type="primary" round @click="toChange">
      换卡
    </el-button>
    <voucher-layer-confirm
      ref="mychild1"
      :column="2"
      :tip="confirmTip"
      :info="voucherConfirmData"
      :keys="voucherConfirmKeys"
      :visible.sync="voucherConfirmVisiable"
      :confirmFlag.sync="confirmFlagc"
      @complete="writeoff"
    ></voucher-layer-confirm>
    <voucher-layer
      ref="mychild2"
      :column="2"
      :info="voucherData"
      :footer="voucherFooter"
      :keys="voucherKeys"
      :visible.sync="voucherVisiable"
      :confirmFlag.sync="confirmFlag"
      :cancel-show="false"
      @complete="receiptComplete"
    ></voucher-layer>
    <el-button size="medium" type="primary" round @click="type = 1">
      aa1
    </el-button>
    <el-button size="medium" type="primary" round @click="type = 2">
      aa2
    </el-button>
    <el-button size="medium" type="primary" round @click="type = 3">
      aa3
    </el-button>
    <el-button
      size="medium"
      type="primary"
      round
      @click="
        () => {
          this.kk = this.type;
        }
      "
    >
      test
    </el-button>
  </div>
</template>

<script>
// import PhotographBlock from '@/components/PhotographBlock';
import VoucherLayer from '@/components/VoucherLayer';
import VoucherLayerConfirm from '@/components/VoucherLayerConfirm';
import { getCpuIdFF, issueCard, readCard } from '@/utils/dynamic';
import { validateCardId } from '@/utils/validate';
import { createOrder, updateWorkOrder, systemTime } from '@/api/common';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';
export default {
  data() {
    return {
      type: '',
      kk: '',
      form: {
        oldCard: {
          cardNumber: '',
          cardType: '',
          cardVersion: '',
        },
      },
      newCardNumber: '',
      rules: {
        'oldCard.cardNumber': [
          {
            required: true,
            message: '请输入卡号',
            trigger: ['blur', 'change'],
          },
          { validator: validateCardId, trigger: ['blur', 'change'] },
        ],
      },
      radio: 'haveCard',
      readCardDisplay: 'block',
      jkhxDisabled: true,
      issueCardDisabled: false,
      loadingReadCard: false,
      loadingReadNewCard: false,
      confirmFlagc: false, // 确认凭证是否被确认
      confirmTip: '卡片一旦核销，将无法使用，且不能反悔，您确认要核销吗？',
      voucherConfirmData: {
        businessType: '卡片核销',
        userName: '',
        userCertType: '',
        userCode: '',
        vehicleNumber: '沪A502102',
        vehicleColor: '0-蓝色',
        vehicleType: '',
        vehicleClass: '',
        approvedAccount: '',
        viTotalMass: '',
        cardType: '23-ETC联名卡',
        cardId: '063100408667568',
        cardStatus: '1-已开通',
        cardFreeEndDate: '',
      },
      voucherConfirmKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '用户名称' },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'vehicleNumber', label: '车牌号码' },
          { key: 'vehicleColor', label: '车牌颜色' },
          { key: 'vehicleType', label: '车辆用户类型' },
          { key: 'vehicleClass', label: '收费车型' },
          { key: 'approvedAccount', label: '核定载人数' },
          { key: 'viTotalMass', label: '总质量' },
        ],
        [
          { key: 'cardType', label: '卡类型' },
          { key: 'cardId', label: '卡号' },
          { key: 'cardStatus', label: '卡状态' },
          { key: 'cardFreeEndDate', label: '卡片保修期' },
        ],
      ],
      voucherConfirmVisiable: false,
      voucherData: {},
      voucherFooter: {},
      voucherKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '用户名称' },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'vehicleNumber', label: '车牌号码' },
          { key: 'vehicleColor', label: '车牌颜色' },
          { key: 'vehicleType', label: '车辆用户类型' },
          { key: 'vehicleClass', label: '收费车型' },
          { key: 'approvedAccount', label: '核定载人数' },
          { key: 'viTotalMass', label: '总质量' },
        ],
        [
          { key: 'cardType', label: '旧卡卡类型' },
          { key: 'cardId', label: '旧卡号' },
          { key: 'cardStatus', label: '旧卡状态' },
          { key: 'cardFreeEndDate', label: '旧卡保修期' },
        ],
        [
          { key: 'newCardType', label: '新卡卡类型' },
          { key: 'newCardId', label: '新卡号' },
          { key: 'newCardStatus', label: '新卡状态' },
          { key: 'newCardFreeEndDate', label: '新卡保修期' },
          { key: 'newCardDate', label: '新卡有效期' },
        ],
        [
          { key: 'amount', label: '收费金额' },
          {
            key: 'qrCode',
            label: '电子发票二维码',
            html: true,
            display: 'block',
            labelWidth: '130px',
          },
        ],
      ],
      amount: 10,
      voucherVisiable: false,
      confirmFlag: false,
    };
  },
  components: {
    // PhotographBlock,
    VoucherLayer,
    VoucherLayerConfirm,
  },
  computed: {
    vehicleInfo() {
      return this.$store.getters.searchCarInfo;
    },
    // obuInfo() {
    //   return this.$store.getters.searchObuInfo;
    // },
    cardInfo() {
      return this.$store.getters.searchCardInfo;
    },
    userInfo() {
      return this.$store.getters.searchUserInfo;
    },
  },
  watch: {
    kk(val) {
      if (val == 1) {
        this.m1();
      } else if (val == 2) {
        this.m2();
      } else if (val == 3) {
        this.m3();
      }
    },
  },
  methods: {
    m1() {
      console.log('m1');
    },
    m2() {
      console.log('m2');
    },
    m3() {
      console.log('m3');
    },
    //换卡
    toChange() {
      //查询出ETC卡片的发行信息
      if (this.isEmptyObj(this.cardInfo)) {
        this.$message.error('无法获取卡片信息');
      }
      console.log('cardInfo', this.cardInfo);
      console.log('cardType', this.cardInfo.cardType);
      //校验是否符合换卡条件
      this.validate();
      //若是对公用户，对经办人证件拍照并上传存档
      //系统显示业务凭证，用户确认后进行电子签名，资料存档
      //收费
      //旧卡销卡，若用户可以提供旧卡，对旧卡洗卡；若用户不能提供旧卡，下发无卡注销状态名单。旧卡存在挂失状态名单的，需解除。
      //新卡发行
    },
    validate() {
      //储值卡提示卡类型变更
      //A类卡、A类联名卡提示注销重办
      //B类卡或B类联名卡可换卡
    },
    radioChange(label) {
      if (label === 'noCard') {
        this.readCardDisplay = 'none';
        this.form.oldCard = {
          cardNumber: '03222033334990321',
          cardType: '记账卡',
          cardVersion: '11',
        };
      } else {
        this.readCardDisplay = 'block';
        this.form.oldCard = {
          cardNumber: '',
          cardType: '',
          cardVersion: '',
        };
      }
    },
    oldCardNumberInputChange(value) {
      if (value !== this.cardInfo.cardID) {
        this.$message.warning('读取卡号与当前卡号不一致');
        this.jkhxDisabled = true;
      } else {
        this.jkhxDisabled = false;
      }
    },
    // 读旧卡
    readOldCard() {
      let failObj = {
        msg:
          '读卡失败。<br>点[重试]按钮重试，点[忽略]按钮手动输入卡号并回车，当坏卡处理。<br>提示信息：',
        confirmButtonText: '重试',
        cancelButtonText: '忽略',
        cancelCatch: this.$refs.oldCardNumberInput.focus,
      };
      let btnLoading = this.loadingReadCard;
      let successFunc = (res) => {
        //校验成功，可核销
        this.form.oldCard = {
          cardNumber: res.cardid,
          cardType: '',
          cardVersion: res.issueversion,
        };
        this.jkhxDisabled = false;
      };
      readCard(
        btnLoading,
        this.cardInfo,
        successFunc,
        this.readOldCard,
        failObj
      );
    },
    // 确认凭证
    async toConfirm() {
      this.jkhxDisabled = true;
      let userCertType = await getDicDesByCode(
        dicKeys.userCertType,
        this.userInfo.userCertType
      );
      this.voucherConfirmData = {
        businessType: '卡片核销',
        userName: this.userInfo.userName,
        userCertType,
        userCode: this.userInfo.userName,
        vehicleNumber: this.userInfo.userName,
        vehicleColor: this.userInfo.userName,
        vehicleType: this.userInfo.userName,
        vehicleClass: this.userInfo.userName,
        approvedAccount: this.userInfo.userName,
        viTotalMass: this.userInfo.userName,
        cardType: this.userInfo.userName,
        cardId: this.userInfo.userName,
        cardStatus: this.userInfo.userName,
        cardFreeEndDate: this.userInfo.userName,
      };
      this.voucherConfirmVisiable = true;
      this.$nextTick(() => {
        //执行调用手写板
        this.$refs.mychild1.sendpad();
      });
    },
    // 旧卡核销
    writeoff() {
      this.$alert('旧卡核销成功', '提示', {
        confirmButtonText: '确定',
        type: 'success',
      });
    },
    // 读新卡
    readNewCard() {
      let btnLoading = this.loadingReadNewCard;
      let successFunc = (res) => {
        //校验成功，可核销
        this.newCardNumber = res.cardid;
        this.issueCardDisabled = false;
      };
      readCard(btnLoading, '', successFunc, this.readNewCard);
    },
    //回执凭证
    async toReceipt() {
      let picUrls =
        'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fm.imeitou.com%2Fuploads%2Fallimg%2F2021020411%2Fzdr3raq3idh.jpg&refer=http%3A%2F%2Fm.imeitou.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1619686926&t=05c5181fe923a5d300891cd7baa7387d https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fm.imeitou.com%2Fuploads%2Fallimg%2F2021020411%2Fzdr3raq3idh.jpg&refer=http%3A%2F%2Fm.imeitou.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1619686926&t=05c5181fe923a5d300891cd7baa7387d';
      let picUrlArr = picUrls.split(' ');
      let qrCodes = '';
      picUrlArr.forEach((picUrl) => {
        let img = `<img src="${picUrl}" />`;
        qrCodes = qrCodes.concat(img);
      });
      let userCertType = await getDicDesByCode(
        dicKeys.userCertType,
        this.userInfo.userCertType
      );
      let completeTime = await systemTime();
      if (this.amount == 0) {
        // 当收费金额>0时，显示电子发票二维码，=0则不显示
        for (let i = 0; i < this.voucherKeys.length; i++) {
          for (let j = 0; j < this.voucherKeys[i].length; j++) {
            if (this.voucherKeys[i][j].key === 'qrCode') {
              this.voucherKeys[i][j].display = 'none';
            }
          }
        }
      }
      if (completeTime) {
        this.voucherData = {
          businessType: '换卡',
          userName: this.userInfo.userName,
          userCertType: 123,
          userCode: this.userInfo.userName,
          vehicleNumber: this.userInfo.userName,
          vehicleColor: this.userInfo.userName,
          vehicleType: this.userInfo.userName,
          vehicleClass: this.userInfo.userName,
          approvedAccount: this.userInfo.userName,
          viTotalMass: this.userInfo.userName,
          cardType: this.userInfo.userName,
          cardId: this.userInfo.userName,
          cardStatus: this.userInfo.userName,
          cardFreeEndDate: this.userInfo.userName,
          newCardType: 123,
          newCardId: 123,
          newCardStatus: 123,
          newCardFreeEndDate: 123,
          newCardDate: 123,
          amount: 123,
          // qrCode:
          //   '<img src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fm.imeitou.com%2Fuploads%2Fallimg%2F2021020411%2Fzdr3raq3idh.jpg&refer=http%3A%2F%2Fm.imeitou.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1619686926&t=05c5181fe923a5d300891cd7baa7387d"/><img src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fm.imeitou.com%2Fuploads%2Fallimg%2F2021020411%2Fzdr3raq3idh.jpg&refer=http%3A%2F%2Fm.imeitou.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1619686926&t=05c5181fe923a5d300891cd7baa7387d"/>',
          qrCode: qrCodes,
        };
        this.voucherFooter = {
          date: completeTime.systemTime,
          outletId: '1111111',
          operator: '龙傲天',
        };
        // self.workOrderIDReceipt = res0.workOrderID;
        // self.workOrderIDConfirm = res0.workOrderID;
        this.voucherVisiable = true;
        this.$nextTick(() => {
          //执行调用手写板
          this.$refs.mychild2.sendpad();
        });
      }

      this.voucherVisiable = true;
    },
    // 新卡发行
    issueNewCard() {},
    // 点击抽屉完成按钮
    receiptComplete() {
      // this.$router.push({
      //   path: '/menu',
      // });
    },
  },
};
</script>
