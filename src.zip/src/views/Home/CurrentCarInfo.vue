<!-- 当前车辆信息 -->
<template>
  <div class="offline_layout-main_current-car-info">
    <no-data message="当前未选择车辆" height="78" v-if="noData" simple />
    <div class="o-flex o-flex-align-center" v-else @click="visible = true">
      <div>
        <h4>当前办理车辆</h4>
        <div
          class="offline_layout-main_current-car-info_car-number"
          :class="[
            {
              'is-black': ['1', '3', '4', '5', '6'].some(
                (color) => color === carInfo.vehicleColor
              ),
            },
          ]"
          :style="{
            backgroundImage: `url(${require('../../assets/images/card/' +
              carInfo.vehicleColor +
              '.png')})`,
          }"
        >
          {{ carInfo.vehicleNumber }}
        </div>
        <div
          style="margin-top: 5px"
          v-if="
            this.$store.getters.searchUserInfo.userProperty == '2' &&
            this.carInfo
          "
        >
          <span>安装码</span>
          <span v-html="'&emsp;'"></span>
          <span>{{ installCode }}</span>
        </div>
      </div>
      <div class="o-flex-1 m20">
        <el-row>
          <el-col :md="11" class="offline_layout-main_current-car-info_block">
            <el-row>
              <el-col :lg="15">
                <div>
                  <span v-html="'卡种&emsp;&emsp;'"></span>
                  <type-text
                    type="cardType"
                    :value="cardInfo.cardType"
                  ></type-text>
                </div>
                <div>
                  <span>ETC卡号</span>
                  <!-- <br /> -->
                  <span>{{ strPadEnd(cardInfo.cardID, 2) | space4 }}</span>
                </div>
                <div>
                  <span>卡状态</span><span v-html="'&emsp;'"></span>
                  <type-text
                    type="cardStatus"
                    :value="cardInfo.cardStatus"
                  ></type-text>
                </div>
                <div>
                  <span>状态名单</span>
                  <type-text
                    type="blackStatus"
                    :value="cardInfo.blackStatus"
                  ></type-text>
                  <span v-html="'&emsp;'"></span>
                  <span v-if="cardInfo.blackStatus == '1'">
                    <el-button type="text" @click="cBlackStatus = true">
                      查看详情</el-button
                    >
                  </span>
                </div>
              </el-col>
              <el-col :lg="9">
                <div>
                  <span v-html="'版本号&emsp;'"></span>
                  <span>{{ cardInfo.versionNo }}</span>
                </div>
                <div>
                  <span>发行日期</span>
                  <span>{{ cardInfo.issueDate }}</span>
                </div>
                <div>
                  <span v-html="'保修期&emsp;'"></span>
                  <span>{{ cardInfo.freeEndDate }}</span>
                </div>
                <!-- <div>
                  <span>签约渠道</span>
                  <span>{{ carInfo.channelName }}</span>
                </div> -->
              </el-col>
            </el-row>
          </el-col>
          <el-col :md="13" class="offline_layout-main_current-car-info_block">
            <el-row>
              <el-col :lg="15">
                <div>
                  <span>标签厂商</span>
                  <span>{{ obuInfo.factoryID }}</span>
                </div>
                <div>
                  <span v-html="'标签号&emsp;'"></span>
                  <!-- <br /> -->
                  <span>{{ strPadEnd(obuInfo.obuID, 2) | space4 }}</span>
                </div>
                <div>
                  <span v-html="'表面号&emsp;'"></span>
                  <!-- <br /> -->
                  <span>{{ strPadEnd(obuInfo.printID, 2) | space42218 }}</span>
                </div>
                <div>
                  <span>标签状态</span>
                  <type-text
                    type="obuStatus"
                    :value="obuInfo.obuStatus"
                  ></type-text>
                </div>
                <div>
                  <span>状态名单</span>
                  <type-text
                    type="blackStatus"
                    :value="obuInfo.blackStatus"
                  ></type-text>
                  <span v-html="'&emsp;'"></span>
                  <span v-if="obuInfo.blackStatus == '1'">
                    <el-button type="text" @click="oBlackStatus = true">
                      查看详情</el-button
                    >
                  </span>
                </div>
              </el-col>
              <el-col :lg="9">
                <div>
                  <span v-html="'版本号&emsp;'"></span>
                  <span>{{ obuInfo.versionNo }}</span>
                </div>
                <div>
                  <span>设备型号</span>
                  <span>{{ obuInfo.productType }}</span>
                </div>
                <div>
                  <span>发行日期</span>
                  <span>{{ obuInfo.issueDate }}</span>
                </div>
                <div>
                  <span v-html="'保修期&emsp;'"></span>
                  <span>{{ obuInfo.freeEndDate }}</span>
                </div>

                <el-dialog
                  title="状态名单详情"
                  :visible.sync="cBlackStatus"
                  :close-on-click-modal="false"
                  v-dialogDrag
                >
                  <el-row>
                    <el-col :lg="12" v-if="status.cardBlackInfo">
                      <div><h3>卡片状态名单状态信息:</h3></div>
                      <div>
                        <span>入单时间</span>
                        <span>{{ cardOptime }}</span>
                        <!-- <span>{{ status.cardBlackInfo.optime }}</span> -->
                      </div>
                      <div>
                        <span>入单原因</span>
                        <span>{{ cardReason }}</span>
                        <!-- <span>{{ status.cardBlackInfo.reason }}</span> -->
                      </div>
                      <div>
                        <span>状态名单发布方</span>
                        <span>{{ cardNoteType }}</span>
                        <!-- <span>{{ status.cardBlackInfo.noteType }}</span> -->
                      </div>
                      <div>
                        <span>备注</span>
                        <span>{{ status.cardBlackInfo.note }}</span>
                      </div>
                    </el-col>
                  </el-row>

                  <div slot="footer" class="dialog-footer">
                    <el-button @click="cBlackStatus = false">取 消</el-button>
                    <el-button type="primary" @click="cBlackStatus = false"
                      >确 定</el-button
                    >
                  </div>
                </el-dialog>

                <el-dialog title="状态名单详情" :visible.sync="oBlackStatus">
                  <el-row>
                    <el-col :lg="12" v-if="status.obuBlackInfo">
                      <div>
                        <h3>标签状态名单状态信息:</h3>
                      </div>
                      <div>
                        <span>入单时间</span>
                        <span>{{ obuOptime }}</span>
                        <!-- <span>{{ status.obuBlackInfo.optime }}</span> -->
                      </div>
                      <div>
                        <span>入单原因</span>
                        <span>{{ obuReaeson }}</span>
                        <!-- <span>{{ status.obuBlackInfo.reason }}</span> -->
                      </div>
                      <div>
                        <span>状态名单发布方</span>
                        <span>{{ obuNoteType }}</span>
                        <!-- <span>{{ status.obuBlackInfo.noteType }}</span> -->
                      </div>
                      <div>
                        <span>备注</span>
                        <span>{{ status.obuBlackInfo.note }}</span>
                      </div>
                    </el-col>
                  </el-row>

                  <div slot="footer" class="dialog-footer">
                    <el-button @click="oBlackStatus = false">取 消</el-button>
                    <el-button type="primary" @click="oBlackStatus = false"
                      >确 定</el-button
                    >
                  </div>
                </el-dialog>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
      </div>
    </div>
    <!-- <complex-table
      title="分支机构"
      :visible.sync="visible"
      :columns="tables"
      requestListUrl="/queryUserAccountList"
      :requestListParam="{}"
      :responseListFormat="responseListFormat"
      @getSelected="getSelected"
      insertListUrl="/departmentAdd"
    /> -->
  </div>
</template>

<script>
import { NoData } from '@/components/NoData';
import { isEmptyObj } from '@/utils/validate';
import { statusQuery, queryInstallCode } from '@/api/common';
import { getTimePoint } from '@/utils/utils';
import { dicKeys, getDicDesByCode } from '@/methods/dics';
import ComplexTable from '@/components/ComplexTable';
import { strPadEnd } from '@/utils/utils';
export default {
  data() {
    return {
      flag: true,
      installCode: '',
      cardNoteType: '',
      cardReason: '',
      obuNoteType: '',
      obuReaeson: '',
      obuOptime: '',
      cardOptime: '',
      //blacklistflag: true,
      status: {},
      cBlackStatus: false,
      oBlackStatus: false,
      BlackStatus: false,
      visible: false,
      tables: [
        {
          name: '分支机构名称',
          filed: 'department',
          edit: true,
        },
        {
          name: '代理人姓名',
          filed: 'agentName',
          default: 0,
        },
      ],
    };
  },
  computed: {
    carInfo() {
      return this.$store.getters.searchCarInfo;
    },
    obuInfo() {
      // console.log(this.$store.getters.searchObuInfo);
      return this.$store.getters.searchObuInfo;
    },
    cardInfo() {
      // console.log(this.$store.getters.searchCardInfo);
      return this.$store.getters.searchCardInfo;
    },
    userInfo() {
      return this.$store.getters.searchUserInfo;
    },
    noData() {
      return isEmptyObj(this.carInfo);
    },
  },
  components: {
    NoData,
    ComplexTable,
  },
  watch: {
    carInfo() {
      if (this.cardInfo.blackStatus == '1' || this.obuInfo.blackStatus == '1') {
        this.showBlackStatus();
      }
    },
  },
  methods: {
    strPadEnd(str, num) {
      return strPadEnd(str, num);
    },
    async getcardnoteType() {
      if (this.status.cardBlackInfo) {
        const res = await getDicDesByCode(
          dicKeys.cardnoteType,
          this.status.cardBlackInfo.noteType
        );
        if (res) {
          this.cardNoteType = res;
        }
      }
    },
    async getobunoteType() {
      if (this.status.obuBlackInfo) {
        const res = await getDicDesByCode(
          dicKeys.obunoteType,
          this.status.obuBlackInfo.noteType
        );
        if (res) {
          this.obuNoteType = res;
        }
      }
    },
    async getobuStatusReason() {
      if (this.status.obuBlackInfo) {
        const res = await getDicDesByCode(
          dicKeys.obuStatusReason,
          this.status.obuBlackInfo.reason
        );
        if (res) {
          this.obuReaeson = res;
        }
      }
    },
    async getcardStatusReason() {
      if (this.status.cardBlackInfo) {
        const res = await getDicDesByCode(
          dicKeys.cardStatusReason,
          this.status.cardBlackInfo.reason
        );
        if (res) {
          this.cardReason = res;
        }
      }
    },
    async showBlackStatus() {
      if (this.cardInfo.blackStatus == '1' || this.obuInfo.blackStatus == '1') {
        if (this.cardInfo.cardID || this.obuInfo.obuID) {
          if (this.userInfo.etcUserId) {
            const res = await statusQuery({
              cardId: this.cardInfo.cardID,
              obuId: this.obuInfo.obuID,
              etcUserId: this.userInfo.etcUserId,
            });
            //   console.log(res);
            this.status = res;
          }
        }
      }
    },
    async getobuOptime() {
      if (this.status.obuBlackInfo) {
        const res = await getTimePoint(this.status.obuBlackInfo.optime);
        if (res) {
          this.obuOptime = res;
        }
      }
    },
    async getcardOptime() {
      if (this.status.cardBlackInfo) {
        const res = await getTimePoint(this.status.cardBlackInfo.optime);
        if (res) {
          this.cardOptime = res;
        }
      }
    },
    async code() {
      setTimeout(() => {
        this.flag = true;
      }, 8000);
      if (this.userInfo.userProperty == '2') {
        // console.log('etcuserid');
        // console.log(this.userInfo.etcUserId);
        if (this.flag == true) {
          this.flag = false;
          const resInstallCode = await queryInstallCode({
            etcUserId: this.userInfo.etcUserId,
          });
          if (resInstallCode) {
            this.installCode = resInstallCode.installCode;
          }
        }
      }

      // alert(this.$store.getters.registerUser.etcUserId);
    },
  },
  updated() {
    this.getcardOptime();
    this.getobuOptime();
    this.getobuStatusReason();
    this.getcardStatusReason();
    this.getobunoteType();
    this.getcardnoteType();
    this.code();
  },
};
</script>
