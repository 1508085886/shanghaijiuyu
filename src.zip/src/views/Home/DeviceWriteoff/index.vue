<!-- 首页 -->
<template>
  <div class="offline-devicewriteoff">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-devicewriteoff_title">设备注销</h4></h4>
      </div>
    </div>
    <div class="o-flex offline-devicewriteoff_step-block-wrap">
      <div class="offline-devicewriteoff_step-block">
        <div class="offline-devicewriteoff_step-title-wrap">
          <span class="offline-devicewriteoff_step-title-desc">卡片状态</span>
        </div>
        <img
          class="offline-devicewriteoff_step-pic"
          src="../../../assets/images/pic-clzc.png"
        />
        <div class="o-flex-column offline-devicewriteoff_step-content-wrap">
          <el-row :gutter="0" class="offline-devicewriteoff_step-content-select">
            <el-col :xl="12" :lg="12" :md="12">
              <el-radio v-model="radioCard" label="haveCard"
                >有卡</el-radio
              ></el-col
            >
            <el-col :xl="12" :lg="12" :md="12">
              <el-radio v-model="radioCard" label="noCard"
                >无卡</el-radio
              ></el-col
            >
          </el-row>
        </div>
      </div>
      <div class="offline-devicewriteoff_step-block">
        <div class="offline-devicewriteoff_step-title-wrap">
          <span class="offline-devicewriteoff_step-title-desc">标签状态</span>
        </div>
        <img
          class="offline-devicewriteoff_step-pic"
          src="../../../assets/images/pic-bq.png"
        />
        <div class="o-flex-column offline-devicewriteoff_step-content-wrap">
          <el-row :gutter="0" class="offline-devicewriteoff_step-content-select">
            <el-col :xl="12" :lg="12" :md="12">
              <el-radio v-model="radioOBU" label="haveOBU"
                >有签</el-radio
              ></el-col
            >
            <el-col :xl="12" :lg="12" :md="12">
              <el-radio v-model="radioOBU" label="noOBU"
                >无签</el-radio
              ></el-col
            >
          </el-row>
        </div>
      </div>
    </div>
    <div class="offline-devicewriteoff_bottom-wrap">
    <el-button
      class="offline-devicewriteoff_bottom-button"
      size="large"
      type="danger"
      @click="toConfirm" 
      :loading="loading"
      round
    >
    注销
    </el-button>
    <!-- @click="testDynamicLibrary" -->
  </div>
  <voucher-layer-confirm
      ref="mychild1"
      :column="2"
      :info="voucherConfirmData"
      :keys="voucherConfirmKeys"
      :visible.sync="voucherConfirmVisiable"
      :is-device-writeoff="true"
      @closed="voucherConfirmClosed"
      @complete="writeoff"
    ></voucher-layer-confirm>
    <voucher-layer
      ref="mychild2"
      :column="2"
      :info="voucherData"
      :footer="voucherFooter"
      :keys="voucherKeys"
      :visible.sync="voucherVisiable"
      :cancel-show="false"
      :has-footer="true"
      @complete="toAccountWriteoff"
    ></voucher-layer>
  </div>
</template>

<script>
import VoucherLayer from '@/components/VoucherLayer';
import VoucherLayerConfirm from '@/components/VoucherLayerConfirm';
import {
  deviceOutHandle,
  deviceOutQuery,
  changeValidityApply,
  changeValidityConfrim,
  renewalValidity,
  changeValidityRenewalConfrim,
  deviceQuery,
} from '@/api/writeoff';
import { createOrder, updateWorkOrder, systemTime } from '@/api/common';
import { etcAccountQuery } from '@/api/user';
import { getCpuIdFF, getObuIdFF, issueCard, issueOBU } from '@/utils/dynamic';
// import { getCpuId,getObuId,issueCard,issueOBU } from '@/utils/dynamic'
import { globalBus } from '@/utils/globalBus';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';
export default {
  data() {
    return {
      resCard: {},
      resOBU: {},
      strExpiryDate: '', // 有效期
      strCardType: '', // 卡片类型
      // regAPPId:'',// 渠道商编码
      // token:'',// 令牌
      // strRandom:'',// 操作员随机数
      radioCard: 'haveCard',
      radioOBU: 'haveOBU',
      verifyLicenseImageList: [], // 核验证件图片信息
      workOrderIDConfirm: '', // 确认凭证工单号
      workOrderIDReceipt: '', // 回执凭证工单号
      imgFrontIDConfirm: '', // 确认凭证前置图片id
      imgFrontIDReceipt: '', // 回执凭证前置图片id
      price: 0, // 费用
      ImageInfoConfirm: {},
      ImageInfoReceipt: {},
      voucherConfirmData: {},
      // voucherConfirmFooter:{},
      voucherConfirmKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [{ key: 'userName', label: '用户名称' }],
        [
          { key: 'vehicleNumber', label: '车牌号码' },
          { key: 'vehicleColor', label: '车牌颜色' },
        ],
        [
          { key: 'cardId', label: '卡号' },
          { key: 'cardType', label: '卡种' },
          { key: 'haveCard', label: '有卡', span: 2 },
          { key: 'obuPrintID', label: '标签表面号' },
          { key: 'obuID', label: '标签ID' },
          { key: 'haveOBU', label: '有签', span: 2 },
        ],
        // [
        //   { key: 'note', label: '备注' },
        // ],
      ],
      voucherData: {},
      voucherFooter: {},
      voucherKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [{ key: 'userName', label: '用户名称' }],
        [
          { key: 'vehicleNumber', label: '车牌号码' },
          { key: 'vehicleColor', label: '车牌颜色' },
        ],
        [
          { key: 'cardId', label: '卡号' },
          { key: 'cardType', label: '卡种' },
          { key: 'cardStatus', label: '卡状态' },
          { key: 'haveCard', label: '有卡' },
          { key: 'obuPrintID', label: '标签表面号' },
          { key: 'obuID', label: '标签ID' },
          { key: 'obuStatus', label: '标签状态' },
          { key: 'haveOBU', label: '有签' },
        ],
        // [
        //   { key: 'note', label: '备注' },
        // ],
      ],
      voucherConfirmVisiable: false,
      voucherVisiable: false,
      userAccountId: '', // 账户编号
      voucherConfirmFlag: false, // 确认凭证标志（已确认true,未确认false）
      voucherFlag: false, // 回执凭证标志（已确认true,未确认false）
      loading: false, //
      timer1: false, //
      timer2: false, //
      voucherConfirmConfirmFlag: false, //
    };
  },
  components: {
    VoucherLayer,
    VoucherLayerConfirm,
  },
  computed: {
    vehicleInfo() {
      return this.$store.getters.searchCarInfo;
    },
    obuInfo() {
      return this.$store.getters.searchObuInfo;
    },
    cardInfo() {
      return this.$store.getters.searchCardInfo;
    },
    userInfo() {
      return this.$store.getters.searchUserInfo;
    },
  },
  methods: {
    radioChange(label) {},
    // 点击回执凭证抽屉完成按钮
    async toAccountWriteoff(resUploadLayerPic) {
      this.voucherFlag = true; // 回执凭证已经点击确认
      if (resUploadLayerPic) {
        // 保存凭证图片
        this.imgFrontIDReceipt = resUploadLayerPic.frontImgid;
      }
      try {
        // 核验证件信息上传
        let self = this;
        const verifyLicenseMediaType = await getDicCodeByDes(
          dicKeys.mediaType,
          '其他'
        );
        const verifyLicenseImgType = await getDicCodeByDes(
          dicKeys.imgType,
          '其他'
        );
        if (verifyLicenseMediaType) {
          self.$store.getters.verifyLicenseImg.forEach((pic) => {
            self.verifyLicenseImageList.push({
              imgFrontID: pic.frontImgid,
              imgType: verifyLicenseImgType,
              mediaType: verifyLicenseMediaType,
            });
          });
          const res1 = await updateWorkOrder({
            workOrderID: self.workOrderIDReceipt,
            modifyInfo: { imagelist: self.verifyLicenseImageList },
          });
          if (!res1) {
            self.loading = false;
          }
        }
        // 业务凭证上传
        const mediaType = await getDicCodeByDes(dicKeys.mediaType, '业务凭证');
        const imgType = await getDicCodeByDes(dicKeys.imgType, '业务凭证');
        if (mediaType) {
          const ImageInfoConfirm = {
            mediaType,
            imgType,
            imgFrontID: this.imgFrontIDConfirm,
          };
          const ImageInfoReceipt = {
            mediaType,
            imgType,
            imgFrontID: this.imgFrontIDReceipt,
          };
          const res0 = await updateWorkOrder({
            workOrderID: this.workOrderIDConfirm,
            modifyInfo: { imagelist: [ImageInfoConfirm] },
          });
          if (!res0) {
            this.loading = false;
          }
          const res1 = await updateWorkOrder({
            workOrderID: this.workOrderIDReceipt,
            modifyInfo: { imagelist: [ImageInfoReceipt] },
          });
          if (!res1) {
            this.loading = false;
          }
          const res2 = await etcAccountQuery({
            // cardId:this.cardInfo.cardID,
            userAccountId: this.userAccountId,
            etcUserId: this.userInfo.etcUserId,
          });
          if (res2) {
            // globalBus.$emit('clickToSearch');
            if (resUploadLayerPic) {
              // 正常流程执行，如果中断后重复执行toAccountWriteoff，不需要执行
              if (res2.issueNum === 0) {
                this.$router.push({
                  path: '/accountwriteoff',
                  query: { userAccountId: this.userAccountId },
                });
              } else {
                this.$alert('注销成功', '提示', {
                  confirmButtonText: '确定',
                  type: 'success',
                  showClose: false,
                }).then(() => {
                  this.$router.push({
                    path: '/menu',
                  });
                });
              }
            }
          } else {
            this.loading = false;
          }
        }
      } catch (error) {
        this.loading = false;
      }
    },
    // 读卡
    readCard() {
      const res0 = getCpuIdFF();
      // const res0 = getCpuId();
      console.log('readCard:' + res0.code);
      if (res0) {
        if (res0.code != '0') {
          // 读卡失败
          this.$confirm('读卡失败，是否重试？提示信息：' + res0.msg, '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          })
            .then(() => {
              this.writeoff();
            })
            .catch(() => {
              this.loading = false;
            });
          return false;
        } else if (res0.code === '0') {
          // 读卡成功
          console.log('readCard:' + res0.cardid);
          const cardid = res0.cardid;
          if (cardid !== this.cardInfo.cardID) {
            console.log('this.cardInfo.cardID:' + this.cardInfo.cardID);
            // this.$message({
            //   type: 'warning',
            //   message: '读取卡号与当前卡号不一致'
            // });
            this.$alert('读取卡号与当前卡号不一致', '提示', {
              confirmButtonText: '确定',
              type: 'warning',
            });
            this.loading = false;
            return false;
          } else {
            return res0;
          }
        }
      } else {
        this.$confirm(
          '获取读卡接口失败，是否重试？提示信息：' + res0.msg,
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
        )
          .then(() => {
            this.writeoff();
          })
          .catch(() => {
            this.loading = false;
          });
        return false;
      }
    },
    // 读签
    readOBU() {
      const res1 = getObuIdFF();
      // const res1 = getObuId();
      // console.log('readOBU:'+res1.code);
      if (res1) {
        if (res1.code != '0') {
          // 读签失败
          this.$confirm('读签失败，是否重试？提示信息：' + res1.msg, '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          })
            .then(() => {
              this.writeoff();
            })
            .catch(() => {
              this.loading = false;
            });
          return false;
        } else if (res1.code === '0') {
          // 读签成功
          // console.log('readOBU:'+res1.obuid);
          const obuid = res1.obuid;
          if (obuid !== this.obuInfo.obuID) {
            console.log('this.obuInfo.obuID:' + this.obuInfo.obuID);
            // this.$message({
            //   type: 'warning',
            //   message: '读取OBU号与当前OBU号不一致'
            // });
            this.$alert('读取标签号与当前标签号不一致', '提示', {
              confirmButtonText: '确定',
              type: 'warning',
            });
            this.loading = false;
            return false;
          } else {
            return res1;
          }
        }
      } else {
        this.$confirm(
          '获取读签接口失败，是否重试？提示信息：' + res1.msg,
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
        )
          .then(() => {
            this.writeoff();
          })
          .catch(() => {
            this.loading = false;
          });
        return false;
      }
    },
    // 获取改有效期数据
    async getExpiryDate(res) {
      try {
        if (res && res.cardid) {
          // 入参传卡片信息
          // console.dir('getExpiryDate,card');
          const res2 = await changeValidityApply({
            vehicleNumber: this.vehicleInfo.vehicleNumber,
            vehicleColor: this.vehicleInfo.vehicleColor,
            cardId: res.cardid,
            cardVerNo: res.issueversion,
          });
          if (!res2) {
            // this.$confirm('获取改卡片有效期数据失败，是否重试？', '提示', {
            //   confirmButtonText: '确定',
            //   cancelButtonText: '取消',
            //   type: 'warning'
            // }).then(() => {
            //   this.writeoff();
            // })
            this.loading = false;
            return false;
          } else {
            let fileContent16 = {};
            fileContent16.fileContent = '';
            fileContent16.startIndex = '0';
            fileContent16.length = '0';
            res2.fileContent16 = fileContent16;
            // console.log('card,res2:')
            // console.log(res2);
            return res2;
          }
        } else if (res && res.obuid) {
          // 入参传标签信息
          const res4 = await changeValidityApply({
            vehicleNumber: this.vehicleInfo.vehicleNumber,
            vehicleColor: this.vehicleInfo.vehicleColor,
            obuId: res.obuid,
            obuVerNo: res.issueversion,
          });
          if (!res4) {
            // this.$confirm('获取改OBU有效期数据失败，是否重试？', '提示', {
            //   confirmButtonText: '确定',
            //   cancelButtonText: '取消',
            //   type: 'warning'
            // }).then(() => {
            //   this.writeoff();
            // });
            this.loading = false;
            return false;
          } else {
            let fileContentDFEF01 = {};
            fileContentDFEF01.fileContent = '';
            fileContentDFEF01.startIndex = '0';
            fileContentDFEF01.length = '0';
            res4.fileContentDFEF01 = fileContentDFEF01;
            // console.log('obu,res2:')
            // console.log(res4);
            return res4;
          }
        }
      } catch (error) {
        this.loading = false;
      }
    },
    // 有效期过期确认
    async changeExpiryDateConfrim(res) {
      try {
        if (res && res.cardid) {
          // 入参传卡片信息
          const res2 = await changeValidityConfrim({
            vehicleNumber: this.vehicleInfo.vehicleNumber,
            vehicleColor: this.vehicleInfo.vehicleColor,
            cardId: res.cardid,
          });
          if (!res2 || res2.result === '0') {
            // this.$confirm('卡片有效期过期确认失败，是否重试？', '提示', {
            //   confirmButtonText: '确定',
            //   cancelButtonText: '取消',
            //   type: 'warning'
            // }).then(() => {
            //   this.writeoff();
            // })
            this.loading = false;
            return false;
          } else {
            return res2;
          }
        } else if (res && res.obuid) {
          // 入参传标签信息
          const res4 = await changeValidityConfrim({
            vehicleNumber: this.vehicleInfo.vehicleNumber,
            vehicleColor: this.vehicleInfo.vehicleColor,
            obuId: res.obuid,
          });
          if (!res4 || res4.result === '0') {
            // this.$confirm('OBU有效期过期确认失败，是否重试？', '提示', {
            //   confirmButtonText: '确定',
            //   cancelButtonText: '取消',
            //   type: 'warning'
            // }).then(() => {
            //   this.writeoff();
            // });
            this.loading = false;
            return false;
          } else {
            return res4;
          }
        }
      } catch (error) {
        this.loading = false;
      }
    },

    // 调动态库的卡片发行接口
    async setCardExpiryDate(resCard, resExpiryDate, methodType) {
      // const res3 = JSON.parse(etcdev.issuecard(resCard.cardid,resCard.issueversion,'','0','0',resExpiryDate.fileContent15.fileContent,resExpiryDate.fileContent15.startIndex,resExpiryDate.fileContent15.length,this.regAPPId,this.token,this.strRandom));
      const res3 = await issueCard(resCard, resExpiryDate);
      // const res3 ={code:'0'};
      if (!res3 || res3.code != '0') {
        this.$confirm(
          '调卡片发行接口失败，是否重试？提示信息：' + res3.msg,
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
        )
          .then(() => {
            if (methodType === 'renewal') {
              this.renewal(resCard, this.resOBU);
            } else {
              this.writeoff();
            }
          })
          .catch(() => {
            this.loading = false;
          });
        return false;
      }
      return true;
    },
    // 调动态库的标签发行接口
    async setOBUExpiryDate(resOBU, resExpiryDate, methodType) {
      // const res5 = JSON.parse(etcdev.issueobu(resOBU.obuid,resExpiryDate.fileContentMFEF01.fileContent,resExpiryDate.fileContentMFEF01.startIndex,resExpiryDate.fileContentMFEF01.length,'','0','0',resOBU.issueversion,this.regAPPId,this.token,this.strRandom));
      const res5 = await issueOBU(resOBU, resExpiryDate);
      // const res5 ={code:'0'};
      if (!res5 || res5.code != '0') {
        this.$confirm(
          '调标签发行接口失败，是否重试？提示信息：' + res5.msg,
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
          }
        )
          .then(() => {
            if (methodType === 'renewal') {
              this.renewal(this.resCard, resOBU);
            } else {
              this.writeoff();
            }
          })
          .catch(() => {
            this.loading = false;
          });
        return false;
      }
      return true;
    },
    // 点击注销按钮，弹出确认凭证抽屉
    async toConfirm() {
      this.voucherConfirmConfirmFlag = false;
      if (!this.userInfo.userID) {
        this.$message({
          type: 'info',
          message: '无法获取当前车辆和车主信息,请查询！',
        });
        return;
      }
      if (!this.cardInfo.cardID) {
        this.$message({
          type: 'error',
          message: '无法获取当前卡片信息',
        });
        return;
      }
      if (!this.obuInfo.obuID) {
        this.$message({
          type: 'error',
          message: '无法获取当前标签信息',
        });
        return;
      }
      this.loading = true;
      let vm = this;
      // let toContinue = false;
      this.timer1 = setTimeout(async () => {
        if (!this.voucherConfirmFlag) {
          // 未确认
          // const bizCode = await getDicCodeByDes(
          //   dicKeys.bizCode,
          //   '设备注销工单'
          // );
          let vehicleColor = await getDicDesByCode(
            dicKeys.vehicleColor,
            this.vehicleInfo.vehicleColor
          );
          let cardType = await getDicDesByCode(
            dicKeys.cardType,
            this.cardInfo.cardType
          );
          let haveCard = this.radioCard === 'haveCard' ? '有' : '无';
          let haveOBU = this.radioOBU === 'haveOBU' ? '有' : '无';
          this.voucherConfirmData = {
            businessType: '设备注销',
            userName: this.userInfo.userName,
            vehicleNumber: this.vehicleInfo.vehicleNumber,
            vehicleColor,
            cardId: this.cardInfo.cardID,
            cardType,
            haveCard,
            obuPrintID: this.obuInfo.printID,
            obuID: this.obuInfo.obuID,
            haveOBU,
            // note:  res1.note,
          };
          this.voucherConfirmVisiable = true;
          this.$nextTick(() => {
            //执行调用手写板
            this.loading = true;
            this.timer2 = setTimeout(() => {
              vm.$refs.mychild1.sendpad();
            }, 1);
          });
        } else {
          // 已确认
          this.writeoff();
        }
      }, 1);
    },
    // 判断有效期是否已过期 expirydate:yyyymmdd
    async judgeExpirydate(expirydate) {
      try {
        console.log(expirydate);
        let _expirydate;
        _expirydate = expirydate.replace(/^(\d{4})(\d{2})(\d{2})$/, '$1-$2-$3');
        _expirydate = _expirydate + ' 23:59:59';
        const res = await systemTime();
        if (res) {
          let oDate = new Date(_expirydate);
          let oDateSystemTime = new Date(res.systemTime);
          if (oDate == 'Invalid Date') {
            // 不可识别日期判断为未过期
            console.log(oDate);
            return false;
          }
          if (oDate < oDateSystemTime) {
            // 已过期
            return true;
          } else {
            // 未过期
            return false;
          }
        } else {
          this.loading = false;
        }
      } catch (error) {
        this.loading = false;
      }
    },
    voucherConfirmClosed() {
      if (this.voucherConfirmConfirmFlag) {
        this.loading = true;
      } else {
        this.loading = false;
      }
    },
    // 注销
    async writeoff(resUploadLayerPic) {
      this.voucherConfirmConfirmFlag = true;
      this.loading = true;
      // 保存凭证图片
      if (resUploadLayerPic) {
        this.imgFrontIDConfirm = resUploadLayerPic.frontImgid;
      }
      this.voucherConfirmVisiable = false;
      this.voucherConfirmFlag = true;

      if (!this.cardInfo.cardID) {
        this.$message({
          type: 'error',
          message: '无法获取当前卡片信息',
        });
        this.loading = false;
        return;
      }
      if (!this.obuInfo.obuID) {
        this.$message({
          type: 'error',
          message: '无法获取当前标签信息',
        });
        this.loading = false;
        return;
      }
      let resCard = {};
      let resOBU = {};
      let resCardExpiryDate = {};
      let resOBUExpiryDate = {};
      let resCardExpiryDateConfrim = {};
      let resOBUExpiryDateConfrim = {};
      let haveCard = '0';
      let haveOBU = '0';

      // resCard = {code:"0",msg:"msg",cardid:"0131001105824433",issueversion:"10"};
      // resOBU = {code:"0",msg:"msg",obuid:"869D050122808220",issueversion:"25"};
      // haveCard = '1';
      // haveOBU = '1';
      if (this.radioCard === 'haveCard' && this.radioOBU === 'haveOBU') {
        // 有卡，有签
        haveCard = '1';
        haveOBU = '1';
        // 读卡
        resCard = this.readCard();
        // resCard = {
        //   code: '0',
        //   msg: '成功',
        //   cardid: '0531000079763915',
        //   issueversion: '10',
        //   expirydate: '20201010',
        // };
        if (!resCard) {
          this.loading = false;
          return;
        }
        this.resCard = resCard;
        // 读签
        resOBU = this.readOBU();
        // resOBU = {
        //   code: '0',
        //   msg: '成功',
        //   obuid: '860505006F9B51F5',
        //   issueversion: '25',
        //   expirydate: '20201010',
        // };
        if (!resOBU) {
          this.loading = false;
          return;
        }
        this.resOBU = resOBU;
        //----------------------------卡片改有效期操作-------------------------------
        // 判断有效期是否已过期
        let cardExpired = await this.judgeExpirydate(resCard.expirydate);
        if (!cardExpired) {
          // 未过期
          // 获取改有效期数据，入参传卡片信息
          resCardExpiryDate = await this.getExpiryDate(resCard);
          // 调动态库的改卡片有效期接口
          if (resCardExpiryDate) {
            let rtn = await this.setCardExpiryDate(resCard, resCardExpiryDate);
            if (!rtn) return;
          } else {
            return;
          }
          // 有效期过期确认
          resCardExpiryDateConfrim = await this.changeExpiryDateConfrim(
            resCard
          );
          if (!resCardExpiryDateConfrim) return;
        }
        // //----------------------------OBU改有效期操作-------------------------------
        // // 判断有效期是否已过期
        // let obuExpired = await this.judgeExpirydate(resOBU.expirydate);
        // if(!obuExpired){// 未过期
        //   //获取改有效期数据，入参传标签信息
        //   resOBUExpiryDate = await this.getExpiryDate(resOBU);
        //   // 调动态库的改标签有效期接口
        //   if(resOBUExpiryDate){
        //     let rtn = await this.setOBUExpiryDate(resOBU,resOBUExpiryDate);
        //     if(!rtn)return;
        //   }else{
        //     return;
        //   }
        //   // 有效期过期确认
        //   resOBUExpiryDateConfrim = await this.changeExpiryDateConfrim(resOBU);
        //   if(!resOBUExpiryDateConfrim)
        //   return;
        // }
      } else if (this.radioCard === 'haveCard' && this.radioOBU === 'noOBU') {
        // 有卡，无签
        haveCard = '1';
        haveOBU = '0';
        // 读卡
        resCard = this.readCard();
        // resCard = {code:"0",msg:"成功",cardid:"0531000079763915",issueversion:"10","expirydate":"20201010"};
        if (!resCard) return;
        this.resCard = resCard;
        //----------------------------卡片改有效期操作-------------------------------
        // 判断有效期是否已过期
        let cardExpired = await this.judgeExpirydate(resCard.expirydate);
        if (!cardExpired) {
          // 未过期
          // 获取改有效期数据，入参传卡片信息
          resCardExpiryDate = await this.getExpiryDate(resCard);
          // 调动态库的改卡片有效期接口
          if (resCardExpiryDate) {
            let rtn = await this.setCardExpiryDate(resCard, resCardExpiryDate);
            if (!rtn) return;
          } else {
            return;
          }
          // 有效期过期确认
          resCardExpiryDateConfrim = await this.changeExpiryDateConfrim(
            resCard
          );
          if (!resCardExpiryDateConfrim) return;
        }
      } else if (this.radioCard === 'noCard' && this.radioOBU === 'haveOBU') {
        // 无卡，有签
        haveCard = '0';
        haveOBU = '1';
        // 读签
        resOBU = this.readOBU();
        // resOBU = {code:"0",msg:"成功",obuid:"860505006F9B51F5",issueversion:"25","expirydate":"20201010"};
        console.log('readOBU');
        console.log(resOBU);
        if (!resOBU) return;
        this.resOBU = resOBU;
        // //----------------------------OBU改有效期操作-------------------------------
        // // 判断有效期是否已过期
        // let obuExpired = await this.judgeExpirydate(resOBU.expirydate);
        // if(!obuExpired){// 未过期
        //   //获取改有效期数据，入参传标签信息
        //   resOBUExpiryDate = await this.getExpiryDate(resOBU);
        //   // 调动态库的改标签有效期接口
        //   if(resOBUExpiryDate){
        //     let rtn = await this.setOBUExpiryDate(resOBU,resOBUExpiryDate);
        //     if(!rtn)return;
        //   }else{
        //     return;
        //   }
        //   // 有效期过期确认
        //   resOBUExpiryDateConfrim = await this.changeExpiryDateConfrim(resOBU);
        //   if(!resOBUExpiryDateConfrim)
        //   return;
        // }
      } else if (this.radioCard === 'noCard' && this.radioOBU === 'noOBU') {
        // 无卡，无签
        haveCard = '0';
        haveOBU = '0';
      }
      // 调13.17.查询注销资格
      const res9 = await deviceQuery({
        etcUserId: this.userInfo.etcUserId,
        vehicleNumber: this.vehicleInfo.vehicleNumber,
        vehicleColor: this.vehicleInfo.vehicleColor,
      });
      if (res9 && res9.status !== '0') {
        if (!this.cardInfo.userAcctId) {
          this.$message({
            type: 'error',
            message: '无法获取当前卡片和账户信息',
          });
          this.loading = false;
          return;
        }
        const res10 = await etcAccountQuery({
          // cardId:this.cardInfo.cardID,
          userAccountId: this.cardInfo.userAcctId,
          etcUserId: this.userInfo.etcUserId,
        });
        if (res10) {
          if (res10.issueNum === 0) {
            // 设备已注销（设备已注销，界面和签名版上没有取消）
            this.$alert('设备已注销，将跳转账户注销页', '提示', {
              confirmButtonText: '确定',
              type: 'info',
              showClose: false,
            }).then(() => {
              // globalBus.$emit('clickToSearch');
              if (this.voucherFlag) {
                // 回执凭证已点击确认，但确认过程中断
                this.toAccountWriteoff();
              }
              this.$router.push({
                path: '/accountwriteoff',
                query: { userAccountId: this.cardInfo.userAcctId },
              });
            });
          } else {
            this.$alert('设备已注销', '提示', {
              confirmButtonText: '确定',
              type: 'info',
              showClose: false,
            }).then(() => {
              if (this.voucherFlag) {
                // 回执凭证已点击确认，但确认过程中断
                this.toAccountWriteoff();
              }
              this.$router.push({
                path: '/menu',
              });
            });
          }
        } else {
          this.loading = false;
        }
        return;
      }
      if (!res9) {
        this.loading = false;
      }
      try {
        // 调13.10.设备注销业务办理（有卡/无卡，有签/无签传参进来）
        const res = await deviceOutHandle({
          etcUserId: this.userInfo.etcUserId,
          vehicleID: this.vehicleInfo.vehicleId,
          // vehicleID:'20230888',
          vehicleNumber: this.vehicleInfo.vehicleNumber,
          // vehicleNumber:'沪AEP626',
          vehicleColor: this.vehicleInfo.vehicleColor,
          // vehicleColor:'0',
          // cardID:resCard.cardid,
          cardID: this.cardInfo.cardID,
          haveCard,
          // obuID:resOBU.obuid,
          obuID: this.obuInfo.obuID,
          haveOBU,
          price: this.price,
        });
        //  const res = {workOrderID:"12345"};
        // const res = false;
        if (res) {
          let vehicleColor = await getDicDesByCode(
            dicKeys.vehicleColor,
            res.oldVehicleColor
          );
          let cardStatus = await getDicDesByCode(
            dicKeys.cardStatus,
            res.cardStatus
          );
          let cardType = await getDicDesByCode(dicKeys.cardType, res.cardType);
          let obuStatus = await getDicDesByCode(
            dicKeys.obuStatus,
            res.obuStatus
          );
          let haveCard = this.radioCard === 'haveCard' ? '有' : '无';
          let haveOBU = this.radioOBU === 'haveOBU' ? '有' : '无';
          let completeTime = await systemTime();
          if (completeTime) {
            this.voucherData = {
              businessType: '设备注销',
              userName: res.userName,
              vehicleNumber: res.oldVehicleNumber,
              vehicleColor,
              cardId: res.cardID,
              cardType,
              cardStatus,
              haveCard,
              obuPrintID: res.obuPrintID,
              obuID: res.obuID,
              obuStatus,
              haveOBU,
              // note:  res.note,
            };
            this.voucherFooter = {
              date: completeTime.systemTime,
              outletId: res.netID,
              operator: res.oprtID,
            };
            this.workOrderIDReceipt = res.workOrderID;
            this.workOrderIDConfirm = res.workOrderID;
            this.userAccountId = res.userAccountId; //账户编号
            this.voucherVisiable = true;
            this.$nextTick(() => {
              //执行调用手写板
              this.$refs.mychild2.sendpad();
            });
          }
        } else {
          this.renewal(resCard, resOBU);
        }
      } catch (e) {
        this.loading = false;
      }
    },
    async renewal(resCard, resOBU) {
      let resCardTip = '';
      let resOBUTip = '';
      let methodType = 'renewal';
      if (this.radioCard === 'haveCard') {
        // 有卡
        const resCardExpiryDate = await renewalValidity({
          vehicleNumber: this.vehicleInfo.vehicleNumber,
          vehicleColor: this.vehicleInfo.vehicleColor,
          cardId: resCard.cardid,
          cardVerNo: resCard.issueversion,
        });
        if (resCardExpiryDate) {
          let fileContent16 = {};
          fileContent16.fileContent = '';
          fileContent16.startIndex = '0';
          fileContent16.length = '0';
          resCardExpiryDate.fileContent16 = fileContent16;
          let rtn = this.setCardExpiryDate(
            resCard,
            resCardExpiryDate,
            methodType
          );
          if (!rtn) {
            this.loading = false;
            return;
          }
          const res1 = await changeValidityRenewalConfrim({
            vehicleNumber: this.vehicleInfo.vehicleNumber,
            vehicleColor: this.vehicleInfo.vehicleColor,
            cardId: resCard.cardid,
          });
          if (res1 && res1.result === '1') {
            resCardTip = '1';
          }
          if (!res1) {
            this.loading = false;
          }
        } else {
          this.loading = false;
        }
      }
      // if(this.radioOBU ==='haveOBU'){// 有签
      //   const resOBUExpiryDate = await renewalValidity({
      //     vehicleNumber:this.vehicleInfo.vehicleNumber,
      //     vehicleColor:this.vehicleInfo.vehicleColor,
      //     obuId:resOBU.obuid,
      //     obuVerNo:resOBU.issueversion,
      //   });
      //   if(resOBUExpiryDate){
      //     let fileContentDFEF01 = {};
      //     fileContentDFEF01.fileContent='';
      //     fileContentDFEF01.startIndex='0';
      //     fileContentDFEF01.length='0';
      //     resOBUExpiryDate.fileContentDFEF01 = fileContentDFEF01;
      //     let rtn = this.setOBUExpiryDate(resOBU,resOBUExpiryDate,methodType);
      //     if(!rtn){
      //       this.loading = false;
      //       return;
      //     }
      //     const res1 = await changeValidityRenewalConfrim({
      //       vehicleNumber:this.vehicleInfo.vehicleNumber,
      //       vehicleColor:this.vehicleInfo.vehicleColor,
      //       obuId:resOBU.obuid,
      //     });
      //     if(res1 && res1.result === '1'){
      //       resOBUTip ='1';
      //     }
      //     if(!res1){
      //       this.loading = false;
      //     }
      //   }else{
      //     this.loading = false;
      //   }
      // }
      if (resCardTip === '1' && resOBUTip === '1') {
        this.$alert('注销失败，卡片和标签有效期已恢复正常', '提示', {
          confirmButtonText: '确定',
          type: 'success',
        });
      } else if (resCardTip === '1' && resOBUTip === '') {
        this.$alert('注销失败，卡片有效期已恢复正常', '提示', {
          confirmButtonText: '确定',
          type: 'success',
        });
      } else if (resCardTip === '' && resOBUTip === '1') {
        this.$alert('注销失败，标签有效期已恢复正常', '提示', {
          confirmButtonText: '确定',
          type: 'success',
        });
      }
      this.loading = false;
    },
    // testDynamicLibrary(){
    //   // let ss = etcdev.setexpirydate('xxx','5','20301207','10','000001');
    //   let ss = etcdev.getopercardid();
    //   let ssObj = JSON.parse(ss);
    //   let ssMsg =  ssObj.msg|| "无数据";
    //   alert(ssMsg);
    // },
  },
  mounted() {
    //console.log(this.$route.query.data);
    // const res2 = changeValidityConfrim({
    //       vehicleNumber:'苏EMH468',
    //       vehicleColor:'0',
    //       cardId:'0531002761500107',
    //     });
  },
  destroyed() {
    clearTimeout(this.timer1);
    clearTimeout(this.timer2);
  },
};
</script>
