<!-- 用户注册 -->
<template>
  <div class="m20 mr20 mt40">
    <div class="o-flex">
      <photograph-block title="拍照识别证件正面"></photograph-block>
    </div>
    <el-form ref="form" :model="form" :rules="rules" class="mt30">
      <el-row :gutter="20">
        <el-col :md="12" :lg="8">
          <el-form-item label="用户名称" prop="userName">
            <el-input v-model="form.userName"></el-input>
          </el-form-item>
        </el-col>
        <el-col :md="12" :lg="8">
          <el-form-item label="用户类型" prop="userProperty">
            <type-select
              type="userType"
              v-model="form.userProperty"
              placeholder="请选择"
              class="o-width-full"
            />
          </el-form-item>
        </el-col>
        <el-col :md="12" :lg="8">
          <el-form-item label="证件类型" prop="userCertType">
            <type-select
              type="userCertType"
              v-model="form.userCertType"
              placeholder="请选择"
              class="o-width-full"
            />
            <!-- <el-select v-model="form.userCertType" placeholder="请选择" class="o-width-full">
              <el-option
                v-for="type in IDCardTypes"
                :key="type.value"
                :label="type.description"
                :value="type.value"
              />
            </el-select>-->
          </el-form-item>
        </el-col>
        <el-col :md="12" :lg="8">
          <el-form-item label="证件号码" prop="userCode">
            <!--            <el-input v-model="form.userCode"></el-input>-->
            <regex-input
              type="userCode"
              placeholder="请输入证件号码"
              :maxlength="32"
              v-model="form.userCode"
            ></regex-input>
          </el-form-item>
        </el-col>
        <el-col :md="12" :lg="8">
          <el-form-item label="联系地址" prop="address">
            <el-input v-model="form.address"></el-input>
          </el-form-item>
        </el-col>

        <el-col :md="12" :lg="8" v-if="userPhoneValidate">
          <el-form-item label="手机号" prop="userPhone">
            <el-input v-model="form.userPhone"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <div class="clearfix mt20">
        <el-button class="fr" type="primary" @click="onSubmit">提交</el-button>
      </div>
    </el-form>
    <voucher-layer
      :visible.sync="voucherVisible"
      :keys="voucherKeys"
      :info="voucherData"
      :column="2"
      :footer="voucherFooter"
      @complete="toRegister"
    />
  </div>
</template>

<script>
import { validPhone } from '@/utils/validate';
import PhotographBlock from '@/components/PhotographBlock';
import { IDCard1, IDCard2 } from '@/temp/base64';
//import {setTargetPublishData,getTargetPublishData,publishData,} from '../dataManage';
import VoucherLayer from '@/components/VoucherLayer';
//import { userRegister } from '@/api/newPublish';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
} from '@/methods/dics';
import RegexInput from '@/components/RegexInput';
export default {
  data() {
    return {
      form: {
        imagelist: [
          {
            mediaType: '1',
            fileType: '1',
            ownerImgid: '111',
            imageInfo: IDCard1,
          },
          {
            mediaType: '2',
            fileType: '1',
            ownerImgid: '12',
            imageInfo: IDCard2,
          },
        ], // 用户身份证照片
      },
      rules: {
        userName: [
          { required: true, message: '请输入用户名称', trigger: 'blur' },
          { max: 16, message: '长度不能超过16个字符', trigger: 'blur' },
        ],
        userProperty: [
          { required: true, message: '请选择用户类型', trigger: 'blur' },
        ],
        userCertType: [
          { required: true, message: '请选择证件类型', trigger: 'blur' },
        ],
        userCode: [
          { required: true, message: '请输入证件号码', trigger: 'blur' },
        ],
        address: [
          { required: true, message: '请输入联系地址', trigger: 'blur' },
        ],
        zipCode: [
          { required: true, message: '请输入邮政编码', trigger: 'blur' },
        ],
        userPhone: [
          { required: true, message: '请输入固定联系电话', trigger: 'blur' },
        ],
        userPhone2: [
          { required: true, message: '请输入手机号', trigger: 'blur' },
          {
            validator(rule, value, callback) {
              if (validPhone(value)) {
                callback();
              } else {
                callback(new Error('手机号码格式有误'));
              }
            },
            trigger: 'blur',
          },
        ],
      },
      IDCardTypes: [], // 所有证件类型
      userPhoneValidate: true, // 根据用户类型改变验证状态
      voucherKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '用户名称' },
          { key: 'userProperty', label: '用户类型' },
          { key: 'userCode', label: '证件号码' },
          { key: 'userCertType', label: '证件类型' },
          { key: 'address', label: '联系地址' },
          { key: 'zipCode', label: '邮政编码' },
          { key: 'userPhone', label: '固定电话' },
          { key: 'userPhone2', label: '手机号码' },
          { key: 'note', label: '备注' },
        ],
      ],
      voucherData: {
        businessType: '用户注册',
        userName: '',
        userProperty: '',
        userCode: '',
        userCertType: '',
        address: '',
        zipCode: '',
        userPhone: '',
        userPhone2: '',
        note: '',
      },
      voucherFooter: {
        date: '2020/9/12',
        outletId: '10001',
        operator: '龙傲天',
      },
      voucherVisible: false,
      userTypes: [], //所有用户类型
    };
  },
  components: {
    PhotographBlock,
    VoucherLayer,
    RegexInput,
  },
  watch: {
    'form.userProperty'(val) {
      if (val === '2') {
        this.userPhoneValidate = 'userPhone';
      } else {
        // this.userPhoneValidate = false;
        this.userPhoneValidate = true;
      }
    },
  },
  methods: {
    onSubmit() {
      const self = this;
      // 表单验证
      self.$refs.form.validate(async (valid) => {
        if (valid) {
          self.voucherData = {
            ...self.voucherData,
            ...self.form,
            userCertType: await getDicDesByCode(
              dicKeys.userCertType,
              self.form.userCertType
            ),
            userProperty: await getDicDesByCode(
              dicKeys.userType,
              self.form.userProperty
            ),
          };

          //用户注册
          //const a = await query(this.idtype, this.idnumber);

          self.voucherVisible = true;
        } else {
          return false;
        }
      });
    },
    // 点击凭证提交按钮
    async toRegister(voucherPic) {
      //debugger;
      const self = this;
      const param = {
        ...self.form,
        voucherInfo: {
          imageInfo: voucherPic,
        },
      };
      //const res = await userRegister(param);
      if (true) {
        // 保存此次操作数据
        this.$store.dispatch('GetRegisterUser', param);
        let newPath;
        if (
          'newpublishperson' === self.$router.currentRoute.path.split('/')[1]
        ) {
          newPath = '/newpublishperson/carregisterinput';
        } else {
          newPath = '/newpublish/carregisterinput';
        }
        this.$router.push({
          // path: '/newpublish/carregisterinput',
          path: newPath,
          query: {
            uct: self.form.userCertType,
            // uc: self.form.userCode,
            uc: self.$trim(self.form.userCode),
            euid: res.etcUserId,
          },
        });
      }
    },
    // 获取所有证件类型
    async getUserCertTypes() {
      this.IDCardTypes = await getAllDics(dicKeys.userCertType);
    },
    // 获取本地保存的输入数据
    getLocalData() {
      const formData = getTargetPublishData(publishData.userRegister);
      if (formData) {
        this.form = formData;
      }
    },
    // 获取所有用户类型
    async getUserTypes() {
      this.userTypes = await getAllDics(dicKeys.userType);
    },
    // 回显保存的数据
    reshow() {
      this.form = {
        ...this.form,
        ...this.$store.getters.registerUser,
      };
    },
  },
  mounted() {
    // 回显数据
    this.reshow();
    // 获取所有用户类型
    this.getUserTypes();
    // 获取所有证件类型
    this.getUserCertTypes();
    // 获取本地保存的输入数据
    this.getLocalData();
  },
};
</script>
