<!-- 补卡 -->
<template>
  <div class="offline-cardreplacement">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-cardreplacementindex_title">补卡（证件上传）</h4>
      </div>
    </div>
    <template v-if="userUploadShow">
      <div class="offline-cardreplacementdocupload_subtitle mt23">用户证件</div>
      <div class="o-flex">
        <photograph-block
          @complete="userPhotosComplete"
          width="104"
          height="104"
          type="userCertType"
          :defaultPics="imageInfoUser"
          :picsMaxLength="2"
          :append-to-body="true"
          :no-edit="view"
          class="mt12"
        ></photograph-block>
      </div>
    </template>
    <template v-if="agentUploadShow">
      <div class="offline-cardreplacementdocupload_subtitle mt23">
        上传经办人证件
      </div>
      <div class="o-flex">
        <photograph-block
          @complete="agentPhotosComplete"
          width="104"
          height="104"
          type="agentCertType"
          :defaultPics="imageInfoAgent"
          :picsMaxLength="2"
          :append-to-body="true"
          :no-edit="view"
          class="mt12"
        ></photograph-block>
      </div>
    </template>
    <template v-if="otherUploadShow">
      <div class="offline-cardreplacementdocupload_subtitle">
        上传其他证件资料
      </div>
      <div class="o-flex">
        <photograph-block
          @complete="otherPhotosComplete"
          width="104"
          height="104"
          type="agentCertType"
          :defaultPics="imageInfoOther"
          :append-to-body="true"
          :no-edit="view"
          class="mt12"
        ></photograph-block>
      </div>
    </template>
    <div class="o-flex offline-cardreplacementdocupload_rtn-button-wrap">
      <loading-button
        type="primary"
        class="offline-cardreplacementdocupload_rtn-button"
        @click="view ? back() : submit()"
        >确定
      </loading-button>
    </div>
  </div>
</template>
<script>
import { createOrderv, updateWorkOrder, startTblWork } from '@/api/common';
import PhotographBlock from '@/components/PhotographBlock';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';
import { orderImg } from '@/api/order';
export default {
  data() {
    return {
      step: '',
      imageInfoUser: [],
      imageInfoAgent: [],
      imageInfoOther: [],
      userUploadShow: false,
      agentUploadShow: false,
      otherUploadShow: false,
      isCompany: false,
      workOrderID: '', // 工单号
      cdif: '',
      isContinue: '',
      changeCardData: '',
      payFlag: '',
      price: '',
      payMode: '',
      etcUserId: '',
      newVehicleNumber: '',
      newVehicleColor: '',
    };
  },
  components: {
    PhotographBlock,
  },
  computed: {
    vehicleInfo() {
      return this.$store.getters.searchCarInfo;
    },
    obuInfo() {
      return this.$store.getters.searchObuInfo;
    },
    cardInfo() {
      return this.$store.getters.searchCardInfo;
    },
    userInfo() {
      return this.$store.getters.searchUserInfo;
    },
    accountInfo() {
      return this.$store.getters.searchAccountInfo;
    },
    departmentInfo() {
      return this.$store.getters.searchDepartmentInfo;
    },
    view() {
      return !!this.$route.query.view;
    },
    userCertType() {
      //用户证件上传为单位/个人
      if (this.userInfo.userProperty === '2') {
        // 单位
        return 'userCertTypeC';
      } else if (this.userInfo.userProperty === '1') {
        // 个人
        return 'userCertTypeP';
      } else {
        return 'userCertType';
      }
    },
  },
  methods: {
    userPhotosComplete(imgs) {
      this.imageInfoUser = imgs;
    },
    agentPhotosComplete(imgs) {
      this.imageInfoAgent = imgs;
      console.log('imgs', this.imageInfoAgent);
    },
    otherPhotosComplete(imgs) {
      this.imageInfoOther = imgs;
    },
    // 编辑状态，点击【确定】即提交
    async submit() {
      if (!this.isCompany && !this.imageInfoUser.length) {
        this.$alert('请上传用户证件', '提示', {
          confirmButtonText: '确定',
          type: 'warning',
        });
        return;
      }
      if (this.isCompany && !this.imageInfoAgent.length) {
        this.$alert('请上传经办人证件', '提示', {
          confirmButtonText: '确定',
          type: 'warning',
        });
        return;
      }
      // 照片数据保存在idb
      // this.$store.dispatch('idbCardReplacement/ClearAgentImg');
      this.$store.dispatch('idbCardReplacement/GetUserImg', this.imageInfoUser);
      this.$store.dispatch(
        'idbCardReplacement/GetAgentImg',
        this.imageInfoAgent
      );
      this.$store.dispatch(
        'idbCardReplacement/GetOtherImg',
        this.imageInfoOther
      );
      // 上传的图片，自动保存到主页的证件上传区域。
      this.$store.dispatch('ClearSearchAgentImg');
      this.$store.dispatch('ClearSearchUserImg');
      this.$store.dispatch('ClearSearchOtherImg');
      this.$store.dispatch('GetSearchUserImg', this.imageInfoUser);
      this.$store.dispatch('GetSearchAgentImg', this.imageInfoAgent);
      this.$store.dispatch('GetSearchOtherImg', this.imageInfoOther);
      // // TODO
      // this.$store.dispatch('ClearSearchAgentImg');
      // this.$store.dispatch('GetSearchAgentImg', this.imageInfoAgent);
      // // 首先调后台12.13.创建工单接口，此时工单状态为0-预处理。
      const bizCode = await getDicCodeByDes(dicKeys.bizCode, '补卡');
      const res0 = await createOrderv({
        bizCode,
        oldUserId: this.userInfo.userID,
        oldUserAcctId: this.accountInfo.userAcctId,
        oldDepartmentName: this.departmentInfo.department,
        oldBuyId: this.accountInfo.signOrderNo,
        oldVehicleId: this.vehicleInfo.vehicleId,
        oldVehicleNumber: this.vehicleInfo.vehicleNumber,
        oldVehicleColor: this.vehicleInfo.vehicleColor,
        oldCardId: this.cardInfo.cardID,
        oldObuysId: this.obuInfo.printID,
        oldObuId: this.obuInfo.obuID,
        oldEtcUserId: this.userInfo.etcUserId,
        oldUsername: this.userInfo.userName,
        oldPayChannelName: this.accountInfo.paychannelName,
        oldSubPayChannelName: this.accountInfo.subPaychannelName,
      }); // TODO 缺少bizCode
      if (res0) {
        // 然后调后台12.9.修改工单接口将上传的图片id和工单进行绑定，绑定时后台接口自动将工单状态变更为1-进行中
        // let allImgs = [...this.imageInfoAgent, ...this.imageInfoOther];
        // let imagelist = [];
        // allImgs.forEach((pic) => {
        //   imagelist.push({
        //     imgFrontID: pic.frontImgid,
        //     imgType: '1011',
        //     mediaType: '4',
        //   });
        // });
        // 改为经办人证件上传代码为4/1011，其他证件上传代码为10/8011
        let imagelist = [];
        this.imageInfoUser.forEach((pic) => {
          console.log('imageInfoUser:', pic.type);
          imagelist.push({
            imgFrontID: pic.frontImgid,
            imgType: pic.type.replace('-', ''),
            mediaType: '4',
          });
        });
        this.imageInfoAgent.forEach((pic) => {
          imagelist.push({
            imgFrontID: pic.frontImgid,
            imgType: '1011',
            mediaType: '4',
          });
        });
        this.imageInfoOther.forEach((pic) => {
          imagelist.push({
            imgFrontID: pic.frontImgid,
            imgType: '8011',
            mediaType: '10',
          });
        });
        this.workOrderID = res0.workOrderID;
        const resStartWork = await startTblWork({
          workOrderId: this.workOrderID,
        });
        if (resStartWork) {
          const res2 = await updateWorkOrder({
            workOrderID: this.workOrderID,
            modifyInfo: { imagelist },
          });
          if (res2) {
            this.$router.push({
              path: '/cardReplacement',
              query: {
                rtn: 'docupload',
                step: this.step,
                cardId: this.cardId,
                workOrderID: this.workOrderID,
                specialfree: this.$route.query.specialfree,
              },
            });
          }
        }
      }
    },
    // 查看状态，点击【确定】即返回
    back() {
      this.$router.push({
        path: '/cardReplacement',
        query: {
          rtn: 'docupload',
          step: this.step,
          cardId: this.cardId,
          workOrderID: this.workOrderID,
          cdif: this.cdif,
          isContinue: this.isContinue,
          payFlag: this.payFlag,
          payMode: this.payMode,
          price: this.price,
          changeCardData: this.changeCardData,
          etcUserId: this.etcUserId,
          newVehicleNumber: this.newVehicleNumber,
          newVehicleColor: this.newVehicleColor,
          specialfree: this.$route.query.specialfree,
        },
      });
    },
  },
  async mounted() {
    if (this.isEmptyObj(this.userInfo)) {
      this.$message.error('无法获取用户信息');
    } else {
      this.step = this.$route.query.step;
      this.cardId = this.$route.query.cardId;
      this.workOrderID = this.$route.query.workOrderID;
      this.cdif = this.$route.query.cdif;
      this.isContinue = this.$route.query.isContinue;
      this.changeCardData = this.$route.query.changeCardData;
      console.log('继续办理数据：', this.changeCardData);
      this.price = this.$route.query.price;
      this.payFlag = this.$route.query.payFlag;
      this.payMode = this.$route.query.payMode;
      this.etcUserId = this.$route.query.etcUserId;
      this.newVehicleNumber = this.$route.query.newVehicleNumber;
      this.newVehicleColor = this.$route.query.newVehicleColor;
      if (this.$route.query.view) {
        // 工单号存在，是通过‘已完成’进来的
        this.imageInfoOther = this.$store.getters.cardReplacementOtherImg;
        this.imageInfoAgent = this.$store.getters.cardReplacementAgentImg;
        this.imageInfoUser = this.$store.getters.cardReplacementUserImg;
        // 调用工单图片查询接口
        const res = await orderImg({
          workOrderID: this.workOrderID,
        });
        const imgInfoList = res.imageList;
        // console.log('imglist:' + imgInfoList[0].mediaType);
        if (imgInfoList) {
          let imageUList = [];
          let imageAlist = [];
          let imageOList = [];
          imgInfoList.forEach((pic) => {
            let imgeUserStr = {
              frontImgid: '',
              ocr: '',
              type: '',
              url: '',
            };
            let imgeAgentStr = {
              frontImgid: '',
              ocr: '',
              type: '',
              url: '',
            };
            let imgeOtherStr = {
              frontImgid: '',
              ocr: '',
              type: '',
              url: '',
            };
            // console.log("pic.mediaType:" + pic.mediaType);
            // console.log("pic.eVoucherType:" + pic.eVoucherType);
            if (pic.eVoucherType === '4') {
              imgeAgentStr.url = 'data:image/png;base64,' + pic.imageInfo;
              imageAlist.push(imgeAgentStr);
            } else if (pic.eVoucherType === '10') {
              imgeOtherStr.url = 'data:image/png;base64,' + pic.imageInfo;
              imageOList.push(imgeOtherStr);
            } else if (pic.eVoucherType === '1') {
              imgeUserStr.url = 'data:image/png;base64,' + pic.imageInfo;
              imageUList.push(imgeUserStr);
            }
          });
          console.log('imageAlist:', imageAlist);
          console.log('imageOList:', imageOList);
          this.imageInfoAgent = imageAlist;
          this.imageInfoOther = imageOList;
          this.imageInfoUser = imageUList;
        }
      } else {
        // 工单号不存在，是从主页进来的，办理新业务
        // 清除数据
        this.$store.dispatch('idbCardReplacement/ClearUserImg');
        this.$store.dispatch('idbCardReplacement/ClearAgentImg');
        this.$store.dispatch('idbCardReplacement/ClearOtherImg');
        this.imageInfoOther = [];
        this.imageInfoAgent = [];
        this.imageInfoUser = [];
        // 加载主页上传的用户证件图片
        let userImgs = JSON.parse(
          JSON.stringify(this.$store.getters.searchUserImg)
        );
        this.$store.dispatch('idbCardReplacement/GetUserImg', userImgs);
        this.imageInfoUser = userImgs;

        // 加载主页上传的经办人证件图片
        let agentImgs = JSON.parse(
          JSON.stringify(this.$store.getters.searchAgentImg)
        );
        this.$store.dispatch('idbCardReplacement/GetAgentImg', agentImgs);
        this.imageInfoAgent = agentImgs;

        // 加载主页上传的其他证件图片
        let otherImgs = JSON.parse(
          JSON.stringify(this.$store.getters.searchOtherImg)
        );
        this.$store.dispatch('idbCardReplacement/GetOtherImg', otherImgs);
        this.imageInfoOther = otherImgs;
      }
      const person = await getDicCodeByDes(dicKeys.userType, '个人');
      const company = await getDicCodeByDes(dicKeys.userType, '单位');
      if (this.userInfo.userProperty == person) {
        // 对私用户，可上传的证件类型为其他证件资料
        this.isCompany = false;
      } else if (this.userInfo.userProperty == company) {
        // 对公用户，可上传的证件类型为经办人证件和其他证件资料
        this.isCompany = true;
      }
      this.userUploadShow = true;
      this.agentUploadShow = true;
      this.otherUploadShow = true;
    }
  },
};
</script>