<!-- 补卡 -->
<template>
  <div class="offline-changecardindex">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-changecardindex_title">补卡</h4>
      </div>
    </div>
    <drawer
      :order="1"
      title="证件上传"
      note="需要上传的证件：用户证件、经办人证件、其他证件资料"
      :btnState="btnState1"
      :btnDesc="btnDescDocupload"
      @btnClick="to('/cardReplacement/doUpload')"
    >
    </drawer>
    <drawer
      :order="2"
      title="补卡"
      note="补卡"
      :btnState="btnState2"
      btnDesc="补卡"
      @btnClick="to('/cardReplacement/cardReplacementMain')"
    >
    </drawer>
    <drawer
      :order="3"
      title="回执签名"
      note="回执签名"
      :btnState="btnState3"
      btnDesc="回执签名"
      @btnClick="toReceipt"
    >
    </drawer>
    <!-- <drawer
      :order="4"
      title="开具发票"
      note="开具发票"
      :btnDesc="btnDescInvoice"
      :btnState="btnState4"
      @btnClick="toInvoice"
    >
    </drawer> -->
    <el-button
      type="primary"
      :disabled="rtnDisabled"
      icon="el-icon-refresh-left"
      class="offline-changecardindex_rtn-button"
      @click="backHome"
      >返回主页
    </el-button>
    <voucher-layer
      ref="mychild2"
      :column="2"
      :info="voucherData"
      :footer="voucherFooter"
      :keys="voucherKeys"
      :visible.sync="voucherVisiable"
      :confirmFlag.sync="confirmFlag"
      :cancel-show="false"
      @complete="receiptComplete"
    ></voucher-layer>
  </div>
</template>
<script>
import VoucherLayer from '@/components/VoucherLayer';
import Drawer from '@/components/Drawer';
import { updateWorkOrder, systemTime, addBranch } from '@/api/common';
import showQrcode from '@/utils/qrcode';
import { globalBus } from '@/utils/globalBus';
import {
  strPadEnd,
  getFormatAmount,
  getQueryStringByName,
  getFormatCardIdw,
} from '@/utils/utils';
import {
  queryCardReplacement,
  queryCardReissue,
  queryReissueCard,
} from '@/api/equipment';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';
import { queryChangeCard, tblStatusQuery } from '@/api/order';
export default {
  data() {
    return {
      cardId: '',
      newCard: {},
      // amount: '',
      // payMode: '',
      // newCardType: '',
      // newCardStatus: '',
      // newCardFreeEndDate: '',
      // newCardDate: '',
      note2: '',
      btnDescDocupload: '证件上传',
      btnDescInvoice: '开具发票',
      btnState1: 'usable',
      btnState2: 'disable',
      btnState3: 'disable',
      btnState4: 'disable',
      rtnDisabled: true,
      workOrderID: '', // 工单号
      voucherData: {},
      voucherFooter: {},
      voucherKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '用户名称' },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
        [
          { key: 'vehicleNumber', label: '车牌号码' },
          { key: 'vehicleColor', label: '车牌颜色' },
          { key: 'vehicleType', label: '车辆用户类型' },
          { key: 'vehicleClass', label: '收费车型' },
          { key: 'approvedAccount', label: '核定载人数' },
          { key: 'viTotalMass', label: '总质量' },
        ],
        [
          { key: 'cardType', label: '旧卡卡种' },
          { key: 'cardId', label: '旧卡号' },
          { key: 'cardStatus', label: '旧卡状态' },
          { key: 'cardFreeEndDate', label: '旧卡保修期' },
        ],
        [
          { key: 'newCardType', label: '新卡卡种' },
          { key: 'newCardId', label: '新卡号' },
          { key: 'newCardStatus', label: '新卡状态' },
          { key: 'newCardFreeEndDate', label: '新卡保修期' },
          { key: 'newCardDate', label: '新卡有效期' },
        ],
        [
          { key: 'amount', label: '收费金额' },
          { key: 'payMode', label: '支付方式' },
        ],
      ],
      voucherVisiable: false,
      confirmFlag: false,
      invoiceUrl: '',
      invoiceOpened: false,
      step: '',
      changeCardData: {},
      payFlag: '',
      price: '',
      payMode: '',
      cdif: '',
      // isChangeCard: '',
      isContinue: '',
      etcUserId: '',
      newVehicleNumber: '',
      newVehicleColor: '',
    };
  },
  components: {
    Drawer,
    VoucherLayer,
  },
  computed: {
    vehicleInfo() {
      return this.$store.getters.searchCarInfo;
    },
    // obuInfo() {
    //   return this.$store.getters.searchObuInfo;
    // },
    cardInfo() {
      return this.$store.getters.searchCardInfo;
    },
    userInfo() {
      return this.$store.getters.searchUserInfo;
    },
  },
  methods: {
    backHome() {
      let form = {
        cardId: this.cardId,
        // cardId: '0131002714297278',
      };
      globalBus.$emit('clickToSearch', form);
      this.$router.push('/menu');
      // 跳转到工单管理
      if (this.changeCardData) {
        console.log('跳转工单:' + this.cdif);
        let rtn = etcdev.predisplay(
          this.cdif,
          'vueEmit(\'{"type":"refreshTable1","param":{}}\')'
        );
      }
    },
    async to(path) {
      let canAccess = false;
      if (this.workOrderID) {
        const res = await tblStatusQuery({ tblWorkOrderId: this.workOrderID });
        if (res) {
          if (res.status == '1') {
            canAccess = true;
          } else {
            // 工单已完成/已关闭，不能操作
            canAccess = false;
            this.$alert('工单已完成/已关闭', '提示', {
              confirmButtonText: '确定',
              type: 'success',
            });
            return;
          }
        }
      } else {
        canAccess = true;
      }
      if (canAccess) {
        let view = '';
        if (path === '/cardReplacement/doUpload') {
          if (this.btnState1 === 'complete2use') {
            // 查看
            view = true;
          }
        }
        this.$router.push({
          path,
          query: {
            view,
            step: this.step,
            cardId: this.cardId,
            workOrderID: this.workOrderID,
            changeCardData: this.changeCardData,
            payFlag: this.payFlag,
            price: this.price,
            payMode: this.payMode,
            cdif: this.cdif,
            isContinue: this.isContinue,
            etcUserId: this.etcUserId,
            newVehicleNumber: this.newVehicleNumber,
            newVehicleColor: this.newVehicleColor,
            specialfree: this.$route.query.specialfree,
          },
        });
      }
    },
    // 回执签名
    async toReceipt() {
      const resQuery = await queryCardReissue({
        etcUserId: this.userInfo.etcUserId,
        workOrderId: this.workOrderID,
      });
      if (resQuery) {
        let completeTime = await systemTime();
        let userCertType = await getDicDesByCode(
          dicKeys.userCertType,
          resQuery.userInfo.userCertType
        );
        let vehicleColor = await getDicDesByCode(
          dicKeys.vehicleColor,
          resQuery.vehicleInfo.vehicleColor
        );
        let vehicleType = await getDicDesByCode(
          dicKeys.vehicleUserClass,
          resQuery.vehicleInfo.vehicleType
        );
        if (vehicleType) {
          if (vehicleType === '0 - 普通客车/普通货车') {
            if (this.vehicleInfo.vehicleCategory == '1') {
              vehicleType = '0 - 普通客车';
            } else if (this.vehicleInfo.vehicleCategory == '') {
              vehicleType = '';
            } else {
              vehicleType = '0 - 普通货车';
            }
          }
        }
        let vehicleClass = await getDicDesByCode(
          dicKeys.vehicleClass,
          resQuery.vehicleInfo.vehicleClass
        );
        let cardType = await getDicDesByCode(
          dicKeys.cardType,
          resQuery.oldCardInfo.cardType
        );
        let cardStatus = await getDicDesByCode(
          dicKeys.cardStatus,
          resQuery.oldCardInfo.status
        );
        let newCardType = await getDicDesByCode(
          dicKeys.cardType,
          resQuery.newCardInfo.cardType
        );
        let newCardStatus = await getDicDesByCode(
          dicKeys.cardStatus,
          resQuery.newCardInfo.status
        );
        let payMode = await getDicDesByCode(
          dicKeys.payMode,
          resQuery.chargeInfo.payMode
        );
        // 本地模式字典显示
        // let newCardStatus = '新卡';
        // let payMode = '支付方式';
        if (completeTime) {
          this.voucherData = {
            businessType: '补卡',
            userName: resQuery.userInfo.userName,
            userCertType,
            userCode: resQuery.userInfo.userCode,
            vehicleNumber: resQuery.vehicleInfo.vehicleNumber,
            vehicleColor,
            vehicleType,
            vehicleClass,
            approvedAccount: resQuery.vehicleInfo.approvedAccount,
            viTotalMass: resQuery.vehicleInfo.viTotalMass,
            cardType,
            cardId: resQuery.oldCardInfo.cardId,
            cardStatus,
            cardFreeEndDate: resQuery.oldCardInfo.freeEndDate,
            newCardType,
            newCardId: resQuery.newCardInfo.cardId,
            newCardStatus,
            newCardFreeEndDate: resQuery.newCardInfo.freeEndDate,
            newCardDate: resQuery.newCardInfo.expiryDate,
            amount: getFormatAmount(resQuery.chargeInfo.price) + '元',
            payMode,
          };
          this.voucherFooter = {
            date: completeTime.systemTime,
            outletId: this.$store.getters.netid,
            operator: this.$store.getters.userName,
          };
          this.voucherVisiable = true;
          this.$nextTick(() => {
            //执行调用手写板
            this.$refs.mychild2.sendpad();
          });
        }
      }
    },
    // 回执签名确认
    async receiptComplete(resUploadLayerPic) {
      // 回执签名完成后，调用后台12.9.修改工单接口，上传签名图片
      let imgFrontIDConfirm = resUploadLayerPic.frontImgid;
      // 保存凭证图片
      const mediaType = await getDicCodeByDes(dicKeys.mediaType, '回执凭证');
      const imgType = await getDicCodeByDes(dicKeys.imgType, '回执凭证');
      const ImageInfoConfirm = {
        mediaType,
        imgType,
        imgFrontID: imgFrontIDConfirm,
      };
      const res0 = await updateWorkOrder({
        workOrderID: this.workOrderID,
        modifyInfo: { imagelist: [ImageInfoConfirm] },
      });
      // 设置按钮状态
      this.btnState1 = 'complete2use';
      this.btnState2 = 'complete';
      this.btnState3 = 'complete';
      this.btnState4 = 'usable';
      this.btnDescDocupload = '已完成';
      this.rtnDisabled = false;
      this.step = 'receipt';
    },
    // 开具发票
    async toInvoice() {
      if (!this.invoiceOpened) {
        // 没开发票
        //点击开具发票按钮，调12.18开票申请接口，
        //后台对该工单的收费开具电子发票，一个工单一张电子发票。根据12.18接口返回的url，在电子签名板上展示发票二维码。
        const res = await addBranch({ etcUserId: this.userInfo.etcUserId });
        //如果收费成功、开票失败，操作员可重试，也可在工单管理功能里补开发票。
        if (res) {
          this.invoiceUrl = 'http://www.baidu.com';
          this.invoiceOpened = true;
          showQrcode(this, this.invoiceUrl)
            .then(() => {})
            .catch(() => {});
          this.btnState1 = 'complete2use';
          this.btnState2 = 'complete';
          this.btnState3 = 'complete';
          this.btnState4 = 'complete2use';
          this.btnDescDocupload = '已完成';
          this.btnDescInvoice = '查看发票';
          this.rtnDisabled = false;
          this.step = 'invoice';
        }
      } else {
        // 查看发票
        showQrcode(this, this.invoiceUrl)
          .then(() => {})
          .catch(() => {});
      }
    },
    async initContinueChangeCard() {
      // 初始化继续办理-补卡数据
      // 调用补卡查询接口
      const res = await queryReissueCard({
        etcUserId: this.etcUserId,
        workOrderId: this.workOrderID,
        vehicleNumber: this.newVehicleNumber,
        vehicleColor: this.newVehicleColor,
      });
      this.changeCardData = res;
      console.log('查询补卡数据：', this.changeCardData.oldCardInfo.status);
      if (res) {
        // 是否证件上传
        if (res.workOrderInfo.isUploadCert === '1') {
          // this.btnState1 = 'complete2use';
          // this.btnDescDocupload = '已完成';
          this.step = 'docupload';
        }
        // 是否收费
        if (res.workOrderInfo.isCharge === '1') {
          this.payFlag = this.$route.query.payFlag;
          this.price = this.$route.query.price;
          this.payMode = this.$route.query.payMode;

          if (
            res.oldCardInfo.status === '2' &&
            res.newCardInfo.status === '1'
          ) {
            this.step = 'main';
            // 获取新卡cardid
            if (res.newCardInfo.cardId) {
              this.cardId = res.newCardInfo.cardId;
            }
          }
          // this.cardId = res.newCardInfo.cardId;
        }
        // 是否回执上传
        if (res.workOrderInfo.isUploadReceipt === '1') {
          this.step = 'receipt';
        } else {
        }
        // 是否开票
        // if(res.workOrderInfo.isInvoice === '1') {
        //  this.step = 'invoice';
        // }

        // 更新userinfo 等信息
        let form = {
          // cardId: this.cardId,
          vehicleNumber: this.newVehicleNumber,
          vehicleColor: this.newVehicleColor,
        };
        await globalBus.$emit('clickToSearch', form);
      } else {
        this.$message.error(res.message || '查询失败!');
      }
    },
  },
  async mounted() {
    console.log(
      '补卡-elementPermission.permissions.specialfree:',
      this.$route.query.specialfree
    );
    this.workOrderID = this.$route.query.workOrderID;
    // this.isChangeCard = this.$route.query.isChangeCard;
    this.isContinue = this.$route.query.isContinue;
    this.cdif = this.$route.query.cdif;
    console.log('cdif:' + this.cdif);
    const cstep = this.$route.query.step;
    console.log('cstep:', cstep);
    this.etcUserId = this.$route.query.etcUserId;
    this.newVehicleNumber = this.$route.query.newVehicleNumber;
    this.newVehicleColor = this.$route.query.newVehicleColor;
    console.log('newVehicleColor:', this.newVehicleColor);
    this.cardId = this.$route.query.cardId;
    // 继续办理补卡处理
    if (this.isContinue) {
      console.log('继续办理');
      await this.initContinueChangeCard();
      // this.note2 = `旧卡卡号：${getFormatCardIdw(
      //   strPadEnd(this.cardInfo.cardID, 2)
      // )}`;
      if (this.step === 'docupload') {
        this.btnState1 = 'complete2use';
        this.btnState2 = 'usable';
        this.btnDescDocupload = '已完成';
      } else if (this.step === 'main') {
        console.log('step:' + this.step);
        this.btnState1 = 'complete2use';
        this.btnState2 = 'complete';
        this.btnState3 = 'usable';
        this.btnDescDocupload = '已完成';
        // this.note2 += `<br>新卡卡号：${getFormatCardIdw(
        //   strPadEnd(this.cardId, 2)
        // )}`;
      } else if (this.step === 'receipt') {
        this.btnState1 = 'complete2use';
        this.btnState2 = 'complete';
        this.btnState3 = 'complete';
        this.btnState4 = 'usable';
        this.rtnDisabled = false;
      }
      // else if (this.step === 'invoice') {
      //  this.btnState1 = 'complete2use';
      //  this.btnState2 = 'complete';
      //  this.btnState3 = 'complete';
      //  this.btnState4 = 'complete2use';
      //  this.btnDescInvoice = '查看发票';
      //  this.rtnDisabled = false;
      // }
    } else {
      // this.timer = setTimeout(() => {
      //   console.log('延迟器');

      if (this.isEmptyObj(this.userInfo)) {
        this.$message.error('无法获取用户信息');
        this.btnState1 = 'disable';
        this.btnState2 = 'disable';
        this.btnState3 = 'disable';
        this.btnState4 = 'disable';
        this.rtnDisabled = true;
      } else {
        // 按钮初始化
        this.btnState1 = 'usable';
        this.btnState2 = 'disable';
        this.btnState3 = 'disable';
        this.btnState4 = 'disable';
        this.rtnDisabled = true;
        // this.rtnDisabled = false;
        this.step = this.$route.query.step;
        this.cardId = this.$route.query.cardId;
        this.workOrderID = this.$route.query.workOrderID;
        // this.note2 = `旧卡卡号：${getFormatCardIdw(
        //   strPadEnd(this.cardInfo.cardID, 2)
        // )}`;
        // // 获取新卡数据
        // if (!this.step) {
        //   await this.$store.dispatch('idbChangeCard/GetNewCard', []);
        // }
        // this.newCard = this.$store.getters.changeCardNewCard;
        // this.amount = this.$route.query.amount;
        // this.payMode = this.$route.query.payMode;
        // 按钮状态切换
        if (this.$route.query.rtn === 'docupload') {
          this.btnState1 = 'complete2use';
          this.btnState2 = 'usable';
          this.btnDescDocupload = '已完成';
        }
        // 由步骤决定抽屉按钮最终状态
        if (this.step === 'docupload') {
          this.btnState1 = 'complete2use';
          this.btnState2 = 'usable';
          this.btnDescDocupload = '已完成';
        } else if (this.step === 'main') {
          this.btnState1 = 'complete2use';
          this.btnState2 = 'complete';
          this.btnState3 = 'usable';
          this.btnDescDocupload = '已完成';
        } else if (this.step === 'receipt') {
          this.btnState1 = 'complete2use';
          this.btnState2 = 'complete';
          this.btnState3 = 'complete';
          this.btnState4 = 'usable';
          this.rtnDisabled = false;
        }
        // else if (this.step === 'invoice') {
        //   this.btnState1 = 'complete2use';
        //   this.btnState2 = 'complete';
        //   this.btnState3 = 'complete';
        //   this.btnState4 = 'complete2use';
        //   this.btnDescInvoice = '查看发票';
        //   this.rtnDisabled = false;
        // }
        // if (this.step) {
        //   // changecardmain已完成
        //   this.note2 += `<br>新卡卡号：${getFormatCardIdw(
        //     strPadEnd(this.cardId, 2)
        //   )}`;
        // }
      }
      // }, 300);
    }
  },
};
</script>