<!-- 登录界面 -->
<template>
  <div class="offline-login">
    <div class="offline-login_main o-flex o-flex-align-center">
      <img src="../../assets/images/mainpic_left.png" />
      <form class="offline-login_form">
        <h3>ETC网点营业厅系统</h3>
        <div class="offline-login_form-item o-flex o-flex-align-center">
          <img src="../../assets/images/user.png" alt />
          <input
            v-model="admin"
            class="o-flex-1"
            type="text"
            placeholder="用户名"
            id="inputid"
            spellcheck="false"
            @keyup.enter="onSubmit"
          />
        </div>
        <div class="offline-login_form-item o-flex o-flex-align-center">
          <img src="../../assets/images/password.png" alt />
          <input
            v-model="password"
            class="o-flex-1"
            type="password"
            placeholder="密码"
            @keyup.enter="onSubmit"
          />
        </div>
        <el-button
          :loading="loading"
          class="offline-login_login-btn"
          type="primary"
          round
          @click="submitHandle"
          >登 录</el-button
        >
      </form>
    </div>
  </div>
</template>

<script>
import { Message } from 'element-ui';
import md5 from 'blueimp-md5';
import { getMenuItems, getElementPermissions } from '@/methods/account';

export default {
  data() {
    return {
      admin: '',
      password: '',
      loading: false,
      radio1: '',
    };
  },
  methods: {
    onSubmit() {
      this.submitHandle();
    },
    async submitHandle() {
      const self = this;
      // 验证输入值
      const admin = self.admin;
      if (admin === '') {
        Message.error('请输入用户名');
        return;
      }
      if (self.password === '') {
        Message.error('请输入密码');
        return;
      }
      const password = md5(self.password);
      self.loading = true;
      try {
        const a = await self.$store.dispatch('Login', {
          admin,
          password,
        });
        console.log(a);
        //-------------------------------
        // if (a) {
        //   // const geturl = await getProgramDownloadUrl();
        //   // if (geturl) {
        //   //   const c = etcdev.upload(
        //   //     geturl.softListUrl,
        //   //     geturl.softDownloadUrl,
        //   //     geturl.authCode,
        //   //     geturl.softVersion
        //   //   );
        //   // }
        // }
        await getMenuItems(); // 获取菜单权限
        await getElementPermissions(); // 获取元素权限

        // self.$store.dispatch('GetMenuid', a.menuIds);
        // alert(self.$store.getters.menuIds);
        // 清空数据
        // 用户注册
        self.$store.dispatch('ClearRegisterUser');
        // 经办人证件
        self.$store.dispatch('ClearTransactorImg');
        // 清空注册车辆信息
        self.$store.dispatch('ClearRegisterVehicle');
        self.$store.dispatch('GetSearchCardInfo', {});
        self.$store.dispatch('GetSearchUserInfo', {});
        self.$store.dispatch('GetSearchCarInfo', {});
        self.$store.dispatch('GetSearchUserInfo', {});
        self.$store.dispatch('GetSearchObuInfo', {});

        self.$router.push({ path: this.redirect || '/' });
      } catch (e) {
        const rs0 = JSON.parse(etcdev.getopercardid());
        if (rs0.code == '1') {
          //读操作员卡失败
          this.$message({
            message: rs0.msg,
            type: 'error',
          });
        }
        // this.$message.error(e);
      }
      self.loading = false;
    },
  },
  watch: {
    $route: {
      handler: function (route) {
        this.redirect = route.query && route.query.redirect;
      },
      immediate: true,
    },
  },
  mounted() {
    // this.$refs.opr.focus();
    document.getElementById('inputid').focus();
  },
};
</script>
<style lang='scss'>
@import '@/assets/styles/variables.scss';
$placeholderColor: #cdcfd6;

.offline-login {
  height: 100%;
  background-image: url('../../assets/images/login_bg.png');
  background-size: 100% 100%;
  position: relative;
}
.offline-login_main {
  max-width: 100%;
  max-height: 100%;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
.offline-login_form {
  width: 415px;
  padding: 25px 30px 50px;
  background: #fff;
  border-radius: 12px;
  margin-left: 150px;
  h3 {
    text-align: center;
    color: #666b6a;
    font-size: 25px;
  }
}
.offline-login_form-item {
  height: 50px;
  padding: 0 25px;
  border: 1px solid $offlineBorderColor;
  border-radius: 50px;
  margin-top: 21px;
  input {
    border: none;
    outline: none;
    background: transparent;
    margin-left: 5px;
    color: $offlineGrayNormal;
  }
  input::-webkit-input-placeholder {
    color: $placeholderColor;
  }
  input:-moz-placeholder {
    color: $placeholderColor;
  }
  input::-moz-placeholder {
    color: $placeholderColor;
  }
  input:-ms-input-placeholder {
    color: $placeholderColor;
  }
}
.offline-login_login-btn {
  width: 100%;
  height: 46px;
  margin-top: 50px;
  font-size: 18px;
  font-weight: 800;
}
</style>