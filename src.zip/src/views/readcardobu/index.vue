<!--沪通卡查询-->
<template>
  <div class="offline-equipmentissuance">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-devicewriteoff_title">发行信息核对</h4>
      </div>
    </div>
    <div class="mt40 offline-systemInfoChecked">
      <div class="check-box">
        <el-checkbox v-model="systemInfoChecked">系统信息比对</el-checkbox>
      </div>
      <div class="ml762 o-flex">
        <el-button
          type="primary"
          size="medium"
          @click="
            clear();
            getmf01df01();
          "
          >测试OBU</el-button
        >
        <el-button
          type="primary"
          size="medium"
          @click="
            clear();
            get0015info();
          "
          >测试CPU卡</el-button
        >
        <el-button
          type="primary"
          size="medium"
          @click="
            clear();
            get0015info();
            getmf01df01();
          "
          >完全测试</el-button
        >
      </div>
    </div>

    <div class="obuResult">
      <div v-if="mf01info == '' && df01info == ''">
        <span class="obuempty">OBU测试结果</span>
        <img class="obuimg" src="@/assets/images/null1.png" />
      </div>
      <div v-if="mf01info != '' && mf01info != ''">
        <div class="getcpuinfo">OBU测试结果</div>
        <div class="cpulabel_item">
          <div class="cpulabel" style="margin-left: 36px">信息类型</div>
          <div class="cpulabel">OBU信息</div>
          <div class="cpulabel">数据库信息</div>
        </div>
        <!-- <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="obuVersionNo0" class="cpuvalue">服务提供商编码</div>
            <div id="obuVersionNo1" class="cpuvalue">
              {{ mf01info.obuVersionNoplateDecoded }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="procotolType0" class="cpuvalue">协约类型</div>
            <div id="procotolType1" class="cpuvalue">
              {{ mf01info.procotolType }}
            </div>
          </div>
        </div> -->
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="obuVersion0" class="cpuvalue">合同版本</div>
            <div id="obuVersion1" class="cpuvalue">
              {{ mf01info.obuVersion }}
            </div>
            <div
              id="obuVersion2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ obuInfo.versionNo }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="obuNo0" class="cpuvalue">合同序列号</div>
            <div id="obuNo1" class="cpuvalue">
              {{ mf01info.obuNo }}
            </div>
            <div id="obuNo2" class="cpuvalue" v-if="systemInfoChecked == true">
              {{ obuInfo.obuID }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="startDate0" class="cpuvalue">启用时间</div>
            <div id="startDate1" class="cpuvalue">
              {{ mf01info.startDate }}
            </div>
            <div
              id="startDate2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ cardissueDate }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="dfVehicleNumber0" class="cpuvalue">车牌号码</div>
            <div id="dfVehicleNumber1" class="cpuvalue">
              {{ df01info.dfVehicleNumberDecoded }}
            </div>
            <div
              id="dfVehicleNumber2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ carInfo.vehicleNumber }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="dfVehicleColor0" class="cpuvalue">车牌颜色</div>
            <div id="dfVehicleColor1" class="cpuvalue">
              {{ df01info.dfVehicleColor }}
            </div>
            <div
              id="dfVehicleColor2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ carInfovehicleColor2 }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="dfVehicleClass0" class="cpuvalue">收费车型</div>
            <div id="dfVehicleClass1" class="cpuvalue">
              {{ df01info.dfVehicleClass }}
            </div>
            <div
              id="dfVehicleClass2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ carInfovehicleClass }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="dfVehicleType0" class="cpuvalue">车辆用户类型</div>
            <div id="dfVehicleType1" class="cpuvalue">
              {{ df01info.dfVehicleType }}
            </div>
            <div
              id="dfVehicleType2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ carInfoVehicleType }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="note0" class="cpuvalue">车身尺寸</div>
            <div id="note1" class="cpuvalue" style="font-size: 12px">
              {{ df01info.note }}
            </div>
            <div
              id="note2"
              class="cpuvalue"
              style="font-size: 12px"
              v-if="systemInfoChecked == true"
            >
              {{ vinote }}
            </div>
          </div>
        </div>
        <!-- 48/ 49 4x货车 -->
        <div v-if="mf01info.obuVersion == '49'">
          <div class="cpulabel_item">
            <div
              style="
                margin-left: 36px;
                height: 28px;
                border-bottom: 1px solid #c7cacf;
              "
            >
              <div id="permittedWeight0" class="cpuvalue">额定载质量</div>
              <div id="permittedWeight1" class="cpuvalue">
                {{ df01info.permittedWeight }}
              </div>
              <div
                id="permittedWeight2"
                class="cpuvalue"
                v-if="systemInfoChecked == true"
              >
                {{ this.carInfo.permittedWeight }}kg
              </div>
            </div>
          </div>
          <div class="cpulabel_item">
            <div
              style="
                margin-left: 36px;
                height: 28px;
                border-bottom: 1px solid #c7cacf;
              "
            >
              <div id="maintenaceMass0" class="cpuvalue">整备质量</div>
              <div id="maintenaceMass1" class="cpuvalue">
                {{ df01info.maintenaceMass }}
              </div>
              <div
                id="maintenaceMass2"
                class="cpuvalue"
                v-if="systemInfoChecked == true"
              >
                {{ this.carInfo.maintenaceMass }}kg
              </div>
            </div>
          </div>
          <div class="cpulabel_item">
            <div
              style="
                margin-left: 36px;
                height: 28px;
                border-bottom: 1px solid #c7cacf;
              "
            >
              <div id="viTotalMass0" class="cpuvalue">总质量</div>
              <div id="viTotalMass1" class="cpuvalue">
                {{ df01info.viTotalMass }}
              </div>
              <div
                id="viTotalMass2"
                class="cpuvalue"
                v-if="systemInfoChecked == true"
              >
                {{ this.carInfo.viTotalMass }}kg
              </div>
            </div>
          </div>
          <div class="cpulabel_item">
            <div
              style="
                margin-left: 36px;
                height: 28px;
                border-bottom: 1px solid #c7cacf;
              "
            >
              <div id="approvedAccount0" class="cpuvalue">载人数</div>
              <div id="approvedAccount1" class="cpuvalue">
                {{ df01info.approvedAccount }}
              </div>
              <div
                id="approvedAccount2"
                class="cpuvalue"
                v-if="systemInfoChecked == true"
              >
                {{ this.carInfo.approvedAccount }}
              </div>
            </div>
          </div>
          <div class="cpulabel_item">
            <div
              style="
                margin-left: 36px;
                height: 28px;
                border-bottom: 1px solid #c7cacf;
              "
            >
              <div id="vin0" class="cpuvalue">车辆识别代码</div>
              <div id="vin1" class="cpuvalue">
                {{ df01info.vin }}
              </div>
              <div id="vin2" class="cpuvalue" v-if="systemInfoChecked == true">
                {{ this.carInfo.vin }}
              </div>
            </div>
          </div>
          <div class="cpulabel_item">
            <div
              style="
                margin-left: 36px;
                height: 28px;
                border-bottom: 1px solid #c7cacf;
              "
            >
              <div id="describe0" class="cpuvalue">车辆特征描述</div>
              <div id="describe1" class="cpuvalue">
                {{ df01info.describe }}
              </div>
              <div
                id="describe2"
                class="cpuvalue"
                v-if="systemInfoChecked == true"
              >
                {{ this.carInfo.viModelName }}}
              </div>
            </div>
          </div>
        </div>
        <!-- 1x 4x客车 -->
        <div v-else>
          <div class="cpulabel_item">
            <div
              style="
                margin-left: 36px;
                height: 28px;
                border-bottom: 1px solid #c7cacf;
              "
            >
              <div id="wheelCount0" class="cpuvalue">车轮数</div>
              <div id="wheelCount1" class="cpuvalue">
                {{ df01info.wheelCount }}
              </div>
              <div
                id="wheelCount2"
                class="cpuvalue"
                v-if="systemInfoChecked == true"
              >
                {{ this.carInfo.wheelCount }}
              </div>
            </div>
          </div>
          <div class="cpulabel_item">
            <div
              style="
                margin-left: 36px;
                height: 28px;
                border-bottom: 1px solid #c7cacf;
              "
            >
              <div id="axleCount0" class="cpuvalue">车轴数</div>
              <div id="axleCount1" class="cpuvalue">
                {{ df01info.axleCount }}
              </div>
              <div
                id="axleCount2"
                class="cpuvalue"
                v-if="systemInfoChecked == true"
              >
                {{ this.carInfo.axleCount }}
              </div>
            </div>
          </div>
          <div class="cpulabel_item">
            <div
              style="
                margin-left: 36px;
                height: 28px;
                border-bottom: 1px solid #c7cacf;
              "
            >
              <div id="axleDistance0" class="cpuvalue">轴距</div>
              <div id="axleDistance1" class="cpuvalue">
                {{ df01info.axleDistance }}
              </div>
              <div
                id="axleDistance2"
                class="cpuvalue"
                v-if="systemInfoChecked == true"
              >
                {{ axleDistance }}
              </div>
            </div>
          </div>
          <div class="cpulabel_item">
            <div
              style="
                margin-left: 36px;
                height: 28px;
                border-bottom: 1px solid #c7cacf;
              "
            >
              <div id="permittedseat0" class="cpuvalue">座位数</div>
              <div id="permittedseat1" class="cpuvalue">
                {{ df01info.permittedWeight }}
              </div>
              <div
                id="permittedseat2"
                class="cpuvalue"
                v-if="systemInfoChecked == true"
              >
                {{ this.carInfo.approvedAccount }}
              </div>
            </div>
          </div>
          <div class="cpulabel_item">
            <div
              style="
                margin-left: 36px;
                height: 28px;
                border-bottom: 1px solid #c7cacf;
              "
            >
              <div id="describe0" class="cpuvalue">车辆特征描述</div>
              <div id="describe1" class="cpuvalue">
                {{ df01info.describe }}
              </div>
              <div
                id="describe2"
                class="cpuvalue"
                v-if="systemInfoChecked == true"
              >
                {{ this.carInfo.viModelName }}
              </div>
            </div>
          </div>
          <div class="cpulabel_item">
            <div
              style="
                margin-left: 36px;
                height: 28px;
                border-bottom: 1px solid #c7cacf;
              "
            >
              <div id="engineNum0" class="cpuvalue">发动机号</div>
              <div
                id="engineNum1"
                class="cpuvalue"
                style="word-break: break-all; white-space: normal"
              >
                {{ df01info.engineNum }}
              </div>
              <div
                id="engineNum2"
                class="cpuvalue"
                v-if="systemInfoChecked == true"
              >
                {{ this.carInfo.engineNum }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="cpuResult">
      <div v-if="info0015 == '' || info0016 == ''">
        <span class="cpuempty">CPU测试结果</span>
        <img class="cpuimg" src="@/assets/images/null1.png" />
      </div>
      <div v-if="info0015 != '' && info0016 != ''">
        <div class="getcpuinfo">CPU测试结果</div>
        <div class="cpulabel_item">
          <div class="cpulabel" style="margin-left: 36px">信息类型</div>
          <div class="cpulabel">卡内信息</div>
          <div class="cpulabel">数据库信息</div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="ownerFlag0" class="cpuvalue">持卡人身份标识</div>
            <div id="ownerFlag1" class="cpuvalue">
              {{ info0016.ownerFlag }}
            </div>
            <div
              id="ownerFlag2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ flaginfo.sfbs }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="employeeFlag0" class="cpuvalue">本系统职工标识</div>
            <div id="employeeFlag1" class="cpuvalue">
              {{ info0016.employeeFlag }}
            </div>
            <div
              id="employeeFlag2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ flaginfo.zgbs }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="ownerName0" class="cpuvalue">持卡人签名</div>
            <div id="ownerName1" class="cpuvalue">
              {{ info0016.ownerNameplateDecoded }}
            </div>
            <div
              id="ownerName2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ this.userInfo.userName }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="ownerIdNum0" class="cpuvalue">持卡人证件号码</div>
            <div id="ownerIdNum1" class="cpuvalue">
              {{ info0016.ownerIdNumplateDecoded }}
            </div>
            <div
              id="ownerIdNum2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ this.userInfo.userCode }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="ownerCardType0" class="cpuvalue">持卡人证件类型</div>
            <div id="ownerCardType1" class="cpuvalue">
              {{ info0016.ownerCardType }}
            </div>
            <div
              id="ownerCardType2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ userCertType }}
            </div>
          </div>
        </div>
        <!-- <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="issueFlag0" class="cpuvalue">发卡方标识</div>
            <div id="issueFlag1" class="cpuvalue">
              {{ info0015.issueFlag }}
            </div>
          </div>
        </div> -->
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="cardType0" class="cpuvalue">卡片类型</div>
            <div id="cardType1" class="cpuvalue">
              {{ info0015.cardType }}
            </div>
            <div
              id="cardType2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ cardInfo.cardType }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="versionNo0" class="cpuvalue">卡片版本号</div>
            <div id="versionNo1" class="cpuvalue">
              {{ info0015.versionNo0015 }}
            </div>
            <div
              id="versionNo2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ cardInfo.versionNo }}
            </div>
          </div>
        </div>
        <!-- <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="cardNetId0" class="cpuvalue">卡片网络编号</div>
            <div id="cardNetId1" class="cpuvalue">
              {{ info0015.cardNetId }}
            </div>
          </div>
        </div> -->
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="cpuCardId0" class="cpuvalue">卡片内部编号</div>
            <div id="cpuCardId1" class="cpuvalue">
              {{ info0015.cpuCardId }}
            </div>
            <div
              id="cpuCardId2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ cardInfo.cardID }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="startDate0" class="cpuvalue">启用时间</div>
            <div id="startDate1" class="cpuvalue">
              {{ info0015.startDate }}
            </div>
            <div
              id="startDate2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ cardissueDate }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="endDate0" class="cpuvalue">到期时间</div>
            <div id="endDate1" class="cpuvalue">
              {{ info0015.endDate }}
            </div>
            <div
              id="endDate2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ expiryDate }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="vehicleNumber0" class="cpuvalue">车牌号码</div>
            <div id="vehicleNumber1" class="cpuvalue">
              {{ info0015.vehicleNumber }}
            </div>
            <div
              id="vehicleNumber2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ carInfo.vehicleNumber }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="userType0" class="cpuvalue">用户类型</div>
            <div id="userType1" class="cpuvalue">
              {{ info0015.userType }}
            </div>
            <div
              id="userType2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ userType }}
            </div>
          </div>
        </div>
        <div class="cpulabel_item">
          <div
            style="
              margin-left: 36px;
              height: 28px;
              border-bottom: 1px solid #c7cacf;
            "
          >
            <div id="vehicleColor0" class="cpuvalue">车牌颜色</div>
            <div id="vehicleColor1" class="cpuvalue">
              {{ info0015.vehicleColor }}
            </div>
            <div
              id="vehicleColor2"
              class="cpuvalue"
              v-if="systemInfoChecked == true"
            >
              {{ carInfovehicleColor }}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {
  get15info,
  get16info,
  getmf01info,
  purchaserecord,
  getdf01Info,
} from '@/utils/readcardobu';
import { query } from '@/api/pidchange';
import { dicKeys, getAllDics, getDicDesByCode } from '@/methods/dics';
export default {
  data() {
    return {
      systemInfoChecked: true,
      info0015: '',
      info0016: '',
      mf01info: '',
      df01info: '',
      carInfo: '',
      obuInfo: '',
      cardInfo: '',
      userInfo: '',
      registerVehicle: '',
      flaginfo: '',
      userCertType: '',
      cardissueDate: '',
      obuIssueDate: '',
      userType: '',
      carInfovehicleColor: '',
      carInfovehicleColor2: '',
      carInfovehicleClass: '',
      carInfoVehicleType: '',
      vinote: '',
      axleDistance: '',
      expiryDate: '',
    };
  },
  watch: {
    systemInfoChecked() {
      setTimeout(() => {
        // var mychar = document.getElementById('employeeFlag1');
        // console.log(mychar);
        for (let i = 0; i < 3; i++) {
          if (this.info0016.ownerFlag != this.flaginfo.sfbs) {
            document.getElementById('ownerFlag' + i).style.color = '#ff1717';
          }
          if (this.info0016.employeeFlag != this.flaginfo.zgbs) {
            document.getElementById('employeeFlag' + i).style.color = '#ff1717';
          }
          if (this.info0016.ownerNameplateDecoded != this.userInfo.userName) {
            document.getElementById('ownerName' + i).style.color = '#ff1717';
          }
          if (this.info0016.ownerIdNumplateDecoded != this.userInfo.userCode) {
            document.getElementById('ownerIdNum' + i).style.color = '#ff1717';
          }
          if (this.info0016.ownerCardType != this.userCertType) {
            document.getElementById('ownerCardType' + i).style.color =
              '#ff1717';
          }

          if (this.info0015.cardType != this.cardInfo.cardType) {
            document.getElementById('cardType' + i).style.color = '#ff1717';
          }
          if (this.info0015.versionNo0015 != this.cardInfo.versionNo) {
            document.getElementById('versionNo' + i).style.color = '#ff1717';
          }

          if (this.info0015.cpuCardId != this.cardInfo.cardID) {
            document.getElementById('cpuCardId' + i).style.color = '#ff1717';
          }
          if (this.info0015.startDate != this.cardissueDate) {
            document.getElementById('startDate' + i).style.color = '#ff1717';
          }
          if (this.info0015.endDate != this.expiryDate) {
            document.getElementById('endDate' + i).style.color = '#ff1717';
          }
          if (this.info0015.vehicleNumber != this.carInfo.vehicleNumber) {
            document.getElementById('vehicleNumber' + i).style.color =
              '#ff1717';
          }
          if (this.info0015.userType != this.userType) {
            document.getElementById('userType' + i).style.color = '#ff1717';
          }
          if (this.info0015.vehicleColor != this.carInfovehicleColor) {
            document.getElementById('vehicleColor' + i).style.color = '#ff1717';
          }
        }
      }, 10);

      setTimeout(() => {
        for (let i = 0; i < 3; i++) {
          if (this.mf01info.obuVersion != this.obuInfo.versionNo) {
            document.getElementById('obuVersion' + i).style.color = '#ff1717';
          }
          if (this.mf01info.obuNo != this.obuInfo.obuID) {
            document.getElementById('obuNo' + i).style.color = '#ff1717';
          }
          if (this.mf01info.startDate != this.cardissueDate) {
            document.getElementById('startDate' + i).style.color = '#ff1717';
          }
          if (
            this.df01info.dfVehicleNumberDecoded != this.carInfo.vehicleNumber
          ) {
            document.getElementById('dfVehicleNumber' + i).style.color =
              '#ff1717';
          }
          if (this.df01info.dfVehicleColor != this.carInfovehicleColor2) {
            document.getElementById('dfVehicleColor' + i).style.color =
              '#ff1717';
          }
          if (this.df01info.dfVehicleClass != this.carInfovehicleClass) {
            document.getElementById('dfVehicleClass' + i).style.color =
              '#ff1717';
          }
          if (this.df01info.dfVehicleType != this.carInfoVehicleType) {
            document.getElementById('dfVehicleType' + i).style.color =
              '#ff1717';
          }
          if (this.df01info.note != this.vinote) {
            document.getElementById('note' + i).style.color = '#ff1717';
          }
          ////////////////48 49 4x货车
          if (this.mf01info.obuVersion == '49') {
            if (
              this.df01info.permittedWeight !=
              this.carInfo.permittedWeight + 'kg'
            ) {
              document.getElementById('permittedWeight' + i).style.color =
                '#ff1717';
            }
            if (
              this.df01info.maintenaceMass !=
              this.carInfo.maintenaceMass + 'kg'
            ) {
              document.getElementById('maintenaceMass' + i).style.color =
                '#ff1717';
            }
            if (this.df01info.viTotalMass != this.carInfo.viTotalMass + 'kg') {
              document.getElementById('viTotalMass' + i).style.color =
                '#ff1717';
            }
            if (this.df01info.approvedAccount != this.carInfo.approvedAccount) {
              document.getElementById('approvedAccount' + i).style.color =
                '#ff1717';
            }
            if (this.df01info.vin != this.carInfo.vin) {
              document.getElementById('vin' + i).style.color = '#ff1717';
            }
            if (this.df01info.describe != this.carInfo.viModelName) {
              document.getElementById('describe' + i).style.color = '#ff1717';
            }
          }
          //////////// 1x 4x客车
          else {
            if (this.df01info.wheelCount != this.carInfo.wheelCount) {
              document.getElementById('wheelCount' + i).style.color = '#ff1717';
            }
            if (this.df01info.axleCount != this.carInfo.axleCount) {
              document.getElementById('axleCount' + i).style.color = '#ff1717';
            }
            if (this.df01info.axleDistance != this.axleDistance) {
              document.getElementById('axleDistance' + i).style.color =
                '#ff1717';
            }
            if (this.df01info.permittedWeight != this.carInfo.approvedAccount) {
              document.getElementById('permittedseat' + i).style.color =
                '#ff1717';
            }
            if (this.df01info.describe != this.carInfo.viModelName) {
              document.getElementById('describe' + i).style.color = '#ff1717';
            }
            if (this.df01info.engineNum != this.carInfo.engineNum) {
              document.getElementById('engineNum' + i).style.color = '#ff1717';
            }
          }
        }
      }, 10);
    },
  },
  components: {},
  computed: {},

  methods: {
    clear() {
      this.info0015 = '';
      this.info0016 = '';
      this.mf01info = '';
      this.df01info = '';
    },
    async get0015info() {
      const res0015 = get15info();
      if (res0015) {
        if (this.cardInfo.cardType == '1' || this.cardInfo.cardType == '2') {
          this.cardInfo.cardType = '记账卡';
        }
        if (this.cardInfo.cardType == '0') {
          this.cardInfo.cardType = '储值卡';
        }
        const yy = this.$store.getters.searchCardInfo.issueDate.substring(0, 4);
        const mm = this.$store.getters.searchCardInfo.issueDate.substring(4, 6);
        const dd = this.$store.getters.searchCardInfo.issueDate.substring(6, 8);
        this.cardissueDate = yy + '年' + mm + '月' + dd + '日';
        const y1 = this.$store.getters.searchCardInfo.expiryDate.substring(
          0,
          4
        );
        const m1 = this.$store.getters.searchCardInfo.expiryDate.substring(
          4,
          6
        );
        const d1 = this.$store.getters.searchCardInfo.expiryDate.substring(
          6,
          8
        );
        this.expiryDate = y1 + '年' + m1 + '月' + d1 + '日';
        this.info0015 = res0015;
        this.flaginfo = await query(this.userInfo.etcUserId);
        const res = await getDicDesByCode(
          dicKeys.userCertType,
          this.userInfo.userCertType
        );
        if (res) {
          this.userCertType = res;
        }
        let res0 = await getDicDesByCode(
          dicKeys.vehicleUserClass,
          this.carInfo.vehicleType
        );
        if (res0) {
          if (res0 == '0 - 普通客车/普通货车') {
            res0 = '0 - 普通用户';
          }
          this.userType = res0;
        }
        const res1 = await getDicDesByCode(
          dicKeys.vehicleColor,
          this.carInfo.vehicleColor
        );
        if (res1) {
          this.carInfovehicleColor = res1;
        }
      }
      this.get0016info();
    },
    get0016info() {
      const res0016 = get16info();
      if (res0016) {
        this.info0016 = res0016;
        console.log('info0016');
        console.log(this.info0016);
      }
      setTimeout(() => {
        // var mychar = document.getElementById('employeeFlag1');
        // console.log(mychar);
        for (let i = 0; i < 3; i++) {
          if (this.info0016.ownerFlag != this.flaginfo.sfbs) {
            document.getElementById('ownerFlag' + i).style.color = '#ff1717';
          }
          if (this.info0016.employeeFlag != this.flaginfo.zgbs) {
            document.getElementById('employeeFlag' + i).style.color = '#ff1717';
          }
          if (this.info0016.ownerNameplateDecoded != this.userInfo.userName) {
            document.getElementById('ownerName' + i).style.color = '#ff1717';
          }
          if (this.info0016.ownerIdNumplateDecoded != this.userInfo.userCode) {
            document.getElementById('ownerIdNum' + i).style.color = '#ff1717';
          }
          if (this.info0016.ownerCardType != this.userCertType) {
            document.getElementById('ownerCardType' + i).style.color =
              '#ff1717';
          }
          if (this.info0015.cardType != this.cardInfo.cardType) {
            document.getElementById('cardType' + i).style.color = '#ff1717';
          }
          if (this.info0015.versionNo0015 != this.cardInfo.versionNo) {
            document.getElementById('versionNo' + i).style.color = '#ff1717';
          }

          if (this.info0015.cpuCardId != this.cardInfo.cardID) {
            document.getElementById('cpuCardId' + i).style.color = '#ff1717';
          }
          if (this.info0015.startDate != this.cardissueDate) {
            document.getElementById('startDate' + i).style.color = '#ff1717';
          }
          if (this.info0015.endDate != this.expiryDate) {
            document.getElementById('endDate' + i).style.color = '#ff1717';
          }
          if (this.info0015.vehicleNumber != this.carInfo.vehicleNumber) {
            document.getElementById('vehicleNumber' + i).style.color =
              '#ff1717';
          }
          if (this.info0015.userType != this.userType) {
            document.getElementById('userType' + i).style.color = '#ff1717';
          }
          if (this.info0015.vehicleColor != this.carInfovehicleColor) {
            document.getElementById('vehicleColor' + i).style.color = '#ff1717';
          }
        }
      }, 10);
    },
    getmf01df01() {
      this.translate();
      let aa = this.mf01info;
      let bb = this.df01info;
      new Promise(function (resolve, reject) {
        var resmf01 = getmf01info();
        if (resmf01) {
          aa = resmf01;
        }
        resolve();
      }).then(function () {
        setTimeout(() => {
          var res2df01 = getdf01Info();
          if (res2df01) {
            //console.log(res2df01);
            bb = res2df01;
          }
          if (!res2df01) {
            console.log('null');
          }
        }, 500);
      });
      setTimeout(() => {
        this.mf01info = aa;
        this.df01info = bb;
        ///////////////////////////////////////////
        //this.mf01info.obuVersion = '49';
        ///////////////////////////////////////////
        this.obuInfoColorCg();
        console.log('mf01info');
        console.log(this.mf01info);
        console.log('df01info');
        console.log(this.df01info);
      }, 1000);
    },
    obuInfoColorCg() {
      setTimeout(() => {
        for (let i = 0; i < 3; i++) {
          if (this.mf01info.obuVersion != this.obuInfo.versionNo) {
            document.getElementById('obuVersion' + i).style.color = '#ff1717';
          }
          if (this.mf01info.obuNo != this.obuInfo.obuID) {
            document.getElementById('obuNo' + i).style.color = '#ff1717';
          }
          if (this.mf01info.startDate != this.cardissueDate) {
            document.getElementById('startDate' + i).style.color = '#ff1717';
          }
          if (
            this.df01info.dfVehicleNumberDecoded != this.carInfo.vehicleNumber
          ) {
            document.getElementById('dfVehicleNumber' + i).style.color =
              '#ff1717';
          }
          if (this.df01info.dfVehicleColor != this.carInfovehicleColor2) {
            document.getElementById('dfVehicleColor' + i).style.color =
              '#ff1717';
          }
          if (this.df01info.dfVehicleClass != this.carInfovehicleClass) {
            document.getElementById('dfVehicleClass' + i).style.color =
              '#ff1717';
          }
          if (this.df01info.dfVehicleType != this.carInfoVehicleType) {
            document.getElementById('dfVehicleType' + i).style.color =
              '#ff1717';
          }
          if (this.df01info.note != this.vinote) {
            document.getElementById('note' + i).style.color = '#ff1717';
          }
          ////////////////48 49 4x货车
          if (this.mf01info.obuVersion == '49') {
            if (
              this.df01info.permittedWeight !=
              this.carInfo.permittedWeight + 'kg'
            ) {
              document.getElementById('permittedWeight' + i).style.color =
                '#ff1717';
            }
            if (
              this.df01info.maintenaceMass !=
              this.carInfo.maintenaceMass + 'kg'
            ) {
              document.getElementById('maintenaceMass' + i).style.color =
                '#ff1717';
            }
            if (this.df01info.viTotalMass != this.carInfo.viTotalMass + 'kg') {
              document.getElementById('viTotalMass' + i).style.color =
                '#ff1717';
            }
            if (this.df01info.approvedAccount != this.carInfo.approvedAccount) {
              document.getElementById('approvedAccount' + i).style.color =
                '#ff1717';
            }
            if (this.df01info.vin != this.carInfo.vin) {
              document.getElementById('vin' + i).style.color = '#ff1717';
            }
            if (this.df01info.describe != this.carInfo.viModelName) {
              document.getElementById('describe' + i).style.color = '#ff1717';
            }
          }
          //////////// 1x 4x客车
          else {
            if (this.df01info.wheelCount != this.carInfo.wheelCount) {
              document.getElementById('wheelCount' + i).style.color = '#ff1717';
            }
            if (this.df01info.axleCount != this.carInfo.axleCount) {
              document.getElementById('axleCount' + i).style.color = '#ff1717';
            }
            if (this.df01info.axleDistance != this.axleDistance) {
              document.getElementById('axleDistance' + i).style.color =
                '#ff1717';
            }
            if (this.df01info.permittedWeight != this.carInfo.approvedAccount) {
              document.getElementById('permittedseat' + i).style.color =
                '#ff1717';
            }
            if (this.df01info.describe != this.carInfo.viModelName) {
              document.getElementById('describe' + i).style.color = '#ff1717';
            }
            if (this.df01info.engineNum != this.carInfo.engineNum) {
              document.getElementById('engineNum' + i).style.color = '#ff1717';
            }
          }
        }
      }, 10);
    },
    async translate() {
      const yy = this.$store.getters.searchObuInfo.issueDate.substring(0, 4);
      const mm = this.$store.getters.searchObuInfo.issueDate.substring(4, 6);
      const dd = this.$store.getters.searchObuInfo.issueDate.substring(6, 8);
      this.cardissueDate = yy + '年' + mm + '月' + dd + '日';
      const res2 = await getDicDesByCode(
        dicKeys.vehicleColor,
        this.carInfo.vehicleColor
      );
      if (res2) {
        this.carInfovehicleColor2 = res2;
      }
      const res3 = await getDicDesByCode(
        dicKeys.vehicleClass,
        this.carInfo.vehicleClass
      );
      if (res3) {
        this.carInfovehicleClass = res3;
      }
      let res4 = await getDicDesByCode(
        dicKeys.vehicleUserClass,
        this.carInfo.vehicleType
      );
      if (res4) {
        if (res4 == '0 - 普通客车/普通货车') {
          res4 = '0 - 普通用户';
        }
        this.carInfoVehicleType = res4;
      }
      if (this.obuInfo.versionNo.substring(0, 1) == '1') {
        this.vinote =
          this.carInfo.viLength.toString().substring(0, 2) +
          'dm x ' +
          this.carInfo.viWidth.toString().substring(0, 2) +
          'dm x ' +
          this.carInfo.viHeight.toString().substring(0, 2) +
          'dm';

        this.axleDistance =
          this.carInfo.axleDistance.toString().substring(0, 2) + 'dm';
      } else if (
        this.obuInfo.versionNo.substring(0, 1) == '4' &&
        this.carInfo.vehicleCategory == '1'
      ) {
        this.vinote =
          this.carInfo.viLength.toString().substring(0, 2) +
          'dm x ' +
          this.carInfo.viWidth.toString().substring(0, 2) +
          'dm x ' +
          this.carInfo.viHeight.toString().substring(0, 2) +
          'dm';

        this.axleDistance =
          this.carInfo.axleDistance.toString().substring(0, 2) + 'dm';
      } else {
        this.vinote =
          this.carInfo.viLength +
          'mm x ' +
          this.carInfo.viWidth +
          'mm x ' +
          this.carInfo.viHeight +
          'mm';
      }
    },
    getpurchaserecord() {
      const res = purchaserecord();
      if (res) {
        console.log('最近五十条记录');
        console.log(res);
      }
    },
  },

  mounted() {
    this.carInfo = this.$store.getters.searchCarInfo;
    this.obuInfo = this.$store.getters.searchObuInfo;
    this.cardInfo = this.$store.getters.searchCardInfo;
    this.userInfo = this.$store.getters.searchUserInfo;
    this.registerVehicle = this.$store.getters.registerVehicle;
    // this.get0015info();
    // this.get0016info();
    // this.getmf01df01();
    // this.getpurchaserecord();
  },
};
</script>