export const dbclick = {
  install(Vue) {
    // 防重复点击(指令实现)
    Vue.directive('dbclick', {
      inserted(el, binding) {
        const { timer } = binding.value
        el.addEventListener('click', () => {
          if (!el.disabled) {
            console.log('防重复点击')
            console.log(timer)
            el.disabled = true
            el.style.cursor = 'not-allowed'
            setTimeout(() => {
              el.style.cursor = 'pointer'
              el.disabled = false
            }, timer)
            console.log('防重复点击')
          }
        })
      }
    })
  }
}
// export default {
//   install(Vue) {
//     // 防重复点击(指令实现)
//     Vue.directive('dbclick', {
//       inserted(el, binding) {
//         el.addEventListener('click', () => {
//           alert('111')
//           if (!el.disabled) {
//             el.disabled = true
//             setTimeout(() => {
//               el.disabled = false
//             }, binding.value || 1500)
//           }
//         })
//       }
//     })
//   }
// }
