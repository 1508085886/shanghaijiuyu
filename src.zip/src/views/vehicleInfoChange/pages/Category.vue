<!-- 车牌 车型 变更 -->
<template>
  <div class="offline-changeobu offline-changeobumain">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-changeobuindex_title">车辆信息变更</h4>
      </div>
    </div>

    <el-row :gutter="90" class="mt20">
      <el-col :span="12"
        ><div
          class="offline-changeobumain_block c-center offline-changeobumain_bottom"
        >
          <el-button
            type="primary"
            disabled
            class="offline-changeobumain_bottom-btn"
            @click="() => {}"
            round
            >变更车牌
          </el-button>
        </div></el-col
      >
      <el-col :span="12">
        <div
          class="offline-changeobumain_block c-center offline-changeobumain_bottom"
        >
          <el-button
            type="primary"
            class="offline-changeobumain_bottom-btn"
            @click="$router.push('/vehicleinfochange/changeType')"
            round
            >变更车型
          </el-button>
        </div></el-col
      >
    </el-row>

    <el-row class="offline-changeobumain_bottom">
      <el-col>
        <el-button
          type="primary"
          icon="el-icon-refresh-left"
          class="offline-vehicleinfochangeindex_rtn-button offline-changeobumain_bottom-btn"
          @click="$router.push('/menu')"
          >返回主页
        </el-button>
      </el-col>
    </el-row>
  </div>
</template>
<script>
export default {};
</script>

<style scoped>
.c-center {
  display: flex;
  justify-content: center;
  align-items: center;
}

.offline-changeobumain {
  height: 100%;
}
.offline-vehicleinfochangeindex_rtn-button {
  margin-top: 100px;
}

.offline-changeobumain {
  padding: 30px 92px;
}
</style>
