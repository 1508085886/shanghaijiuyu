<!-- 证件上传 - 继续办理 图片仅仅支持查看 -->
<template>
  <div class="offline-changeobu c-box" style="height:100%">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-changeobuindex_title">变更车型</h4>
      </div>
    </div>
    <template v-if="imgsUploaded.car.length > 0">
      <div class="offline-changeobudocupload_subtitle mt23">车辆证件</div>
      <div class="o-flex">
        <photograph-block
          width="104"
          height="104"
          type="vehicleCertType"
          :defaultPics="imgsUploaded.car"
          :append-to-body="true"
          class="mt12"
          :noEdit="true"
        ></photograph-block>
      </div>
    </template>
    <!-- 对公用户，还需上传经办人证件。对私用户，可以上传经办人证件，非必须。 -->
    <template v-if="imgsUploaded.operator.length > 0">
      <div class="offline-changeobudocupload_subtitle mt23">经办人证件</div>
      <div class="o-flex">
        <photograph-block
          width="104"
          height="104"
          type="agentCertType"
          :picsMaxLength="2"
          :defaultPics="imgsUploaded.operator"
          :append-to-body="true"
          class="mt12"
          :noEdit="true"
        ></photograph-block>
      </div>
    </template>
    <!-- 其它证件信息 -->
    <template v-if="imgsUploaded.other.length > 0">
      <div class="offline-changeobudocupload_subtitle">其他证件资料</div>
      <div class="o-flex">
        <photograph-block
          width="104"
          height="104"
          type="agentCertType"
          :defaultPics="imgsUploaded.other"
          :append-to-body="true"
          class="mt12"
          :noEdit="true"
        ></photograph-block>
      </div>
    </template>
    <div class="o-flex offline-changeobudocupload_rtn-button-wrap">
      <loading-button
        type="primary"
        class="offline-changeobudocupload_rtn-button"
        @click="handleConfirm"
        >确定
      </loading-button>
    </div>
  </div>
</template>
<script>
import PhotographBlock from '@/components/PhotographBlock';
import { orderImg } from '@/api/order';

export default {
  data() {
    return {
      // 上传的图片
      imgsUploaded: {
        car: [],
        operator: [],
        other: [],
      },

      orderData: {}, // 工单数据
    };
  },
  components: {
    PhotographBlock,
  },

  methods: {
    handleConfirm() {
      // 直接返回流程页面，带参数rowData
      this.$router.push({
        path: '/convehiclechange',
        query: {
          rowData: this.orderData,
        },
      });
    },

    //获取工单图片
    getPics(workOrderId) {
      orderImg({ workOrderID: workOrderId }).then(res => {
        if (res) {
          const imageList = res.imageList || [];
          // 图片筛选分类 mediaType依据需求文档
          imageList.forEach(img => {
            if (
              img.mediaType == 3011 ||
              img.mediaType == 3012 ||
              img.mediaType == 3021
            ) {
              this.imgsUploaded.car.push({
                ...img,
                url: `data:image${img.fileType == 1 ? 'jpg' : 'png'};base64,${
                  img.imageInfo
                }`,
              });
            }

            //经办人图片
            if (img.mediaType == 1011) {
              this.imgsUploaded.operator.push({
                url: `data:image/${img.fileType == 1 ? 'jpg' : 'png'};base64,${
                  img.imageInfo
                }`,
              });
            }

            //其它证件
            if (img.mediaType == 8011) {
              this.imgsUploaded.other.push({
                url: `data:image/${img.fileType == 1 ? 'jpg' : 'png'};base64,${
                  img.imageInfo
                }`,
              });
            }
          });
        }
      });
    },

    // 获取路由参数
    getRouteParams() {
      // 工单管理 传过来的工单数据
      const orderData = this.$route.query.rowData;
      this.orderData = orderData;
      this.getPics(orderData.workOrderId);
    },
  },

  mounted() {
    this.getRouteParams();
  },
};
</script>

<style scoped>
.c-box {
  height: 100%;
}
</style>
