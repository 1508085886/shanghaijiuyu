<!-- 车型变更 -->
<template>
  <div class="offline-changeobu offline-changeobumain" style="height:100%">
    <div class="clearfix">
      <div class="fl" style="padding-bottom: 10px">
        <h4 class="offline-changeobuindex_title">变更车型</h4>
      </div>
    </div>

    <div class="offline-changeobumain_block j-scrollbar">
      <div class="title">
        <el-row>
          <el-col :span="12">
            <span>原车辆信息</span>
          </el-col>
          <el-col :span="12">
            <span style="padding-left: 20px">新车辆信息</span>
          </el-col>
        </el-row>
      </div>
      <div class="content-form" style="flex: 1; background-color: #DCDDE2">
        <el-scrollbar style="height: 100%">
          <el-row :gutter="20">
            <!-- 老信息 -->
            <el-col :span="12">
              <el-form
                style="padding:10px;background:#E5E5EA"
                :model="prevCarInfo"
                ref="prevCarInfo"
                class="demo-prevCarInfo"
                label-position="left"
                label-width="95px"
              >
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item
                      label="号牌号码"
                      prop="vehicleNumber"
                      class="required"
                    >
                      <el-input
                        v-model="prevCarInfo.vehicleNumber"
                        disabled
                      ></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item
                      label="车辆类型"
                      prop="dzfpVehicleType"
                      class="required"
                    >
                      <el-input
                        v-model="prevCarInfo.dzfpVehicleType"
                        disabled
                      ></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="24">
                    <el-form-item
                      label="所有人"
                      prop="viOwnerName"
                      class="required"
                    >
                      <el-input
                        v-model="prevCarInfo.viOwnerName"
                        disabled
                      ></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>

                <!-- 后端接口字段ownerAddress 拼写错误，这里配合修改 -->
                <el-row>
                  <el-col :span="24">
                    <el-form-item
                      label="住址"
                      prop="ownerAdderss"
                      class="required"
                    >
                      <el-input
                        v-model="prevCarInfo.ownerAdderss"
                        disabled
                      ></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item
                      label="使用性质"
                      prop="vehicleSpecies"
                      class="required"
                    >
                      <el-input
                        v-model="prevCarInfo.vehicleSpecies"
                        disabled
                      ></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item
                      label="品牌型号"
                      prop="viModelName"
                      class="required"
                    >
                      <el-input
                        v-model="prevCarInfo.viModelName"
                        disabled
                      ></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="24">
                    <el-form-item
                      label="车辆识别代号"
                      prop="vin"
                      class="required"
                    >
                      <el-input v-model="prevCarInfo.vin" disabled></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="24">
                    <el-form-item
                      label="发动机号码"
                      prop="engineNum"
                      class="required"
                    >
                      <el-input
                        v-model="prevCarInfo.engineNum"
                        disabled
                      ></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item
                      label="注册时间"
                      prop="viRegisterDate"
                      class="required"
                    >
                      <el-date-picker
                        type="date"
                        placeholder="选择日期"
                        v-model="prevCarInfo.viRegisterDate"
                        style="width: 100%"
                        disabled
                      ></el-date-picker>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item
                      label="发证时间"
                      prop="viIssueDate"
                      class="required"
                    >
                      <el-date-picker
                        type="date"
                        placeholder="选择日期"
                        v-model="prevCarInfo.viIssueDate"
                        style="width: 100%"
                        disabled
                      ></el-date-picker>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item
                      label="号牌号码"
                      prop="vehicleNumber"
                      class="required"
                    >
                      <el-input
                        v-model="prevCarInfo.vehicleNumber"
                        disabled
                      ></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="档案编号" prop="viFileNum">
                      <el-input
                        v-model="prevCarInfo.viFileNum"
                        disabled
                      ></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item
                      label="核定载人数"
                      prop="approvedAccount"
                      class="required c-blue"
                    >
                      <div class="flex">
                        <el-input
                          v-model="prevCarInfo.approvedAccount"
                          disabled
                        >
                        </el-input>
                        <span>人</span>
                      </div>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item
                      label="总质量"
                      prop="viTotalMass"
                      :class="{
                        required: true,
                        'c-blue': prevCarInfo.vehicleCategory != 1,
                      }"
                    >
                      <div class="flex">
                        <el-input v-model="prevCarInfo.viTotalMass" disabled>
                        </el-input>
                        <span>kg</span>
                      </div>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item
                      label="整备质量"
                      prop="maintenanceMass"
                      class="required"
                    >
                      <div class="flex">
                        <el-input v-model="prevCarInfo.maintenaceMass" disabled>
                        </el-input>
                        <span>kg</span>
                      </div>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item
                      label="核定载质量"
                      prop="permittedWeight"
                      :class="{
                        required: true,
                        'c-blue': prevCarInfo.vehicleCategory == 2,
                      }"
                    >
                      <div class="flex">
                        <el-input
                          v-model="prevCarInfo.permittedWeight"
                          disabled
                        >
                        </el-input>
                        <span>kg</span>
                      </div>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row :gutter="20">
                  <el-col :span="15">
                    <el-form-item
                      label="外廓尺寸"
                      props="size"
                      class="c-blue required"
                    >
                      <div class="flex car-size">
                        <el-input v-model="prevCarInfo.viLength" disabled>
                        </el-input>
                        <span style="padding: 0 3px">X</span>
                        <el-input v-model="prevCarInfo.viWidth" disabled>
                        </el-input>
                        <span style="padding: 0 3px">X</span>
                        <el-input v-model="prevCarInfo.viHeight" disabled>
                        </el-input>
                        <span>mm</span>
                      </div>
                    </el-form-item>
                  </el-col>
                  <el-col :span="9">
                    <el-form-item
                      label="准牵引总质量"
                      prop="permittedTowWeight"
                      class="required"
                      :class="{ 'c-blue': prevCarInfo.vehicleCategory == 3 }"
                    >
                      <div class="flex">
                        <el-input
                          v-model="prevCarInfo.permittedTowWeight"
                          disabled
                        >
                        </el-input>
                        <span>kg</span>
                      </div>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="24">
                    <el-form-item label="备注" prop="note">
                      <el-input v-model="prevCarInfo.note" disabled></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="24">
                    <el-form-item label="检验记录" prop="testRecord">
                      <el-input
                        v-model="prevCarInfo.testRecord"
                        type="textarea"
                        disabled
                      ></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>

              <el-form
                style="padding: 10px; "
                :model="prevCarInfo"
                ref="prevCarInfo"
                class="demo-prevCarInfo"
                label-position="left"
                label-width="95px"
              >
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item
                      label="车牌颜色"
                      prop="vehicleColor"
                      class="selection-full required"
                    >
                      <type-select
                        type="vehicleColor"
                        v-model="prevCarInfo.vehicleColor"
                        disabled
                        placeholder="请选择"
                        class="offline-changeobumain_feeblock-paymode-select"
                      />
                    </el-form-item>
                  </el-col>
                  <!-- 车种 -->
                  <el-col :span="12">
                    <el-form-item
                      label="车种"
                      prop="vehicleCategory"
                      class="selection-full required"
                    >
                      <type-select
                        disabled
                        type="vehicleCategory"
                        v-model="prevCarInfo.vehicleCategory"
                        placeholder="请选择"
                        class="offline-changeobumain_feeblock-paymode-select"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row :gutter="30">
                  <el-col :span="8">
                    <el-form-item
                      label="车轴数"
                      prop="axleCount"
                      :class="{
                        required: true,
                        'c-blue': prevCarInfo.vehicleCategory != 1,
                      }"
                    >
                      <el-input
                        v-model="prevCarInfo.axleCount"
                        disabled
                      ></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8">
                    <el-form-item
                      label="轮胎数"
                      prop="wheelCount"
                      class="required"
                    >
                      <el-input
                        v-model="prevCarInfo.wheelCount"
                        disabled
                      ></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" class="large-axleDistance">
                    <el-form-item
                      label="轴距"
                      prop="axleDistance"
                      class="required"
                    >
                      <div class="flex">
                        <el-input
                          v-model="prevCarInfo.axleDistance"
                          disabled
                        ></el-input>
                        <span>mm</span>
                      </div>
                    </el-form-item>
                  </el-col>
                </el-row>

                <!-- 车辆用户类型 -->
                <el-row>
                  <el-col :span="24">
                    <el-form-item
                      label="车辆用户类型"
                      prop="vehicleType"
                      class="selection-full c-blue required"
                    >
                      <type-select
                        disabled
                        type="vehicleUserClass"
                        v-model="prevCarInfo.vehicleType"
                        placeholder="请选择"
                        class="offline-changeobumain_feeblock-paymode-select"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="24">
                    <el-form-item
                      label="收费车型"
                      required
                      prop="vehicleClass"
                      class="selection-full c-blue required"
                    >
                      <type-select
                        disabled
                        type="vehicleClass"
                        v-model="prevCarInfo.vehicleClass"
                        placeholder="请选择"
                        class="offline-changeobumain_feeblock-paymode-select"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col>
                    <el-form-item label="分支机构" prop="department">
                      <el-input
                        v-model="prevCarInfo.department"
                        disabled
                      ></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>
            </el-col>

            <!-- 新车的信息 -->
            <el-col :span="12">
              <el-form
                style="padding:10px;background:#E5E5EA"
                :model="nextCarInfo"
                :rules="nextCarRules"
                ref="nextCarRef1"
                class="demo-prevCarInfo"
                label-position="left"
                label-width="100px"
              >
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item
                      label="号牌号码"
                      prop="vehicleNumber"
                      class="required"
                    >
                      <el-input
                        v-model="nextCarInfo.vehicleNumber"
                        disabled
                      ></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item
                      label="车辆类型"
                      prop="dzfpVehicleType"
                      class="required"
                      :class="{
                        'c-red':
                          nextCarInfo.dzfpVehicleType !=
                          prevCarInfo.dzfpVehicleType,
                      }"
                    >
                      <el-input
                        v-model="nextCarInfo.dzfpVehicleType"
                      ></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="24">
                    <el-form-item
                      label="所有人"
                      prop="ownerName"
                      class="required"
                      :class="{
                        'c-red': nextCarInfo.ownerName != prevCarInfo.ownerName,
                      }"
                    >
                      <el-input v-model="nextCarInfo.ownerName"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="24">
                    <el-form-item
                      label="住址"
                      prop="ownerAddress"
                      class="required"
                      :class="{
                        'c-red':
                          nextCarInfo.ownerAddress != prevCarInfo.ownerAddress,
                      }"
                    >
                      <el-input v-model="nextCarInfo.ownerAddress"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item
                      label="使用性质"
                      prop="vehicleSpecies"
                      class="required"
                      :class="{
                        'c-red':
                          nextCarInfo.vehicleSpecies !=
                          prevCarInfo.vehicleSpecies,
                      }"
                    >
                      <el-input v-model="nextCarInfo.vehicleSpecies"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item
                      label="品牌型号"
                      prop="vehicleNote"
                      class="required"
                      :class="{
                        'c-red':
                          nextCarInfo.vehicleNote != prevCarInfo.vehicleNote,
                      }"
                    >
                      <el-input v-model="nextCarInfo.vehicleNote"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="24">
                    <el-form-item
                      label="车辆识别代号"
                      prop="vin"
                      class="required"
                      :class="{
                        'c-red': nextCarInfo.vin != prevCarInfo.vin,
                      }"
                    >
                      <el-input v-model="nextCarInfo.vin"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="24">
                    <el-form-item
                      label="发动机号码"
                      prop="engineNum"
                      class="required"
                      :class="{
                        'c-red': nextCarInfo.engineNum != prevCarInfo.engineNum,
                      }"
                    >
                      <el-input v-model="nextCarInfo.engineNum"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item
                      label="注册时间"
                      prop="registerDate"
                      class="required"
                      :class="{
                        'c-red':
                          nextCarInfo.registerDate !=
                          prevCarInfo.viRegisterDate,
                      }"
                    >
                      <el-date-picker
                        value-format="yyyy-MM-dd"
                        type="date"
                        placeholder="选择日期"
                        v-model="nextCarInfo.registerDate"
                        style="width: 100%"
                      ></el-date-picker>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item
                      label="发证时间"
                      prop="issueDate"
                      class="required"
                      :class="{
                        'c-red':
                          nextCarInfo.issueDate != prevCarInfo.viIssueDate,
                      }"
                    >
                      <el-date-picker
                        value-format="yyyy-MM-dd"
                        type="date"
                        placeholder="选择日期"
                        v-model="nextCarInfo.issueDate"
                        style="width: 100%"
                      ></el-date-picker>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item
                      label="号牌号码"
                      prop="vehicleNumber"
                      class="required"
                    >
                      <el-input
                        v-model="nextCarInfo.vehicleNumber"
                        disabled
                      ></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item
                      label="档案编号"
                      prop="fileNum"
                      :class="{
                        'c-red': nextCarInfo.fileNum != prevCarInfo.viFileNum,
                      }"
                    >
                      <el-input v-model="nextCarInfo.fileNum"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row :gutter="20">
                  <el-col :span="13">
                    <el-form-item
                      label="核定载人数"
                      prop="approvedCount"
                      class="c-blue required"
                      :class="{
                        'c-red':
                          nextCarInfo.approvedCount !=
                          prevCarInfo.approvedAccount,
                      }"
                    >
                      <div class="flex">
                        <custom-input v-model="nextCarInfo.approvedCount">
                        </custom-input>
                        <span>人</span>
                      </div>
                    </el-form-item>
                  </el-col>
                  <el-col :span="11">
                    <el-form-item
                      label="总质量"
                      prop="vehicleTotalMass"
                      class="required"
                      :class="{
                        'c-blue': nextCarInfo.vehicleCategory != 1,
                        'c-red':
                          nextCarInfo.vehicleTotalMass !=
                          prevCarInfo.viTotalMass,
                      }"
                    >
                      <div class="flex">
                        <custom-input v-model="nextCarInfo.vehicleTotalMass">
                        </custom-input>
                        <span>kg</span>
                      </div>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row :gutter="20">
                  <el-col :span="13">
                    <el-form-item
                      label="整备质量"
                      prop="maintenanceMass"
                      class="required"
                      :class="{
                        'c-red':
                          nextCarInfo.maintenanceMass !=
                          prevCarInfo.maintenaceMass,
                      }"
                    >
                      <div class="flex">
                        <custom-input v-model="nextCarInfo.maintenanceMass">
                        </custom-input>
                        <span>kg</span>
                      </div>
                    </el-form-item>
                  </el-col>
                  <el-col :span="11">
                    <el-form-item
                      label="核定载质量"
                      prop="vehicleMaxLadenWeight"
                      class="required"
                      :class="{
                        'c-blue': prevCarInfo.vehicleCategory == 2,
                        'c-red':
                          nextCarInfo.vehicleMaxLadenWeight !=
                          prevCarInfo.permittedWeight,
                      }"
                    >
                      <div class="flex">
                        <custom-input
                          v-model="nextCarInfo.vehicleMaxLadenWeight"
                        >
                        </custom-input>
                        <span>kg</span>
                      </div>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row :gutter="20">
                  <el-col :span="15">
                    <el-form-item
                      label="外廓尺寸"
                      prop="outlineDimension"
                      class="c-blue required"
                      :class="{
                        'c-red': !(
                          nextCarInfo.viLength == prevCarInfo.viLength &&
                          nextCarInfo.viWidth == prevCarInfo.viWidth &&
                          nextCarInfo.viHeight == prevCarInfo.viHeight
                        ),
                      }"
                    >
                      <div class="flex car-size">
                        <custom-input
                          :reg="/[^0-9]/g"
                          v-model="nextCarInfo.viLength"
                        >
                        </custom-input>
                        <span style="padding: 0 3px">X</span>
                        <custom-input
                          :reg="/[^0-9]/g"
                          v-model="nextCarInfo.viWidth"
                        >
                        </custom-input>
                        <span style="padding: 0 3px">X</span>
                        <custom-input
                          :reg="/[^0-9]/g"
                          v-model="nextCarInfo.viHeight"
                        >
                        </custom-input>
                        <span>mm</span>
                      </div>
                    </el-form-item>
                  </el-col>
                  <el-col :span="9">
                    <el-form-item
                      label="准牵引总质量"
                      prop="permittedTowWeight"
                      class="required"
                      :class="{
                        'c-blue': prevCarInfo.vehicleCategory == 3,
                        'c-red':
                          nextCarInfo.permittedTowWeight !=
                          prevCarInfo.permittedTowWeight,
                      }"
                    >
                      <div class="flex custom-permittedTowWeight">
                        <!-- <el-input v-model="nextCarInfo.permittedTowWeight">
                        </el-input> -->
                        <custom-input v-model="nextCarInfo.permittedTowWeight">
                        </custom-input>
                        <span>kg</span>
                      </div>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="24">
                    <el-form-item
                      label="备注"
                      prop="note"
                      :class="{
                        'c-red': nextCarInfo.note != prevCarInfo.note,
                      }"
                    >
                      <el-input v-model="nextCarInfo.note"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="24">
                    <el-form-item
                      label="检验记录"
                      prop="testrecord"
                      :class="{
                        'c-red':
                          nextCarInfo.testrecord != prevCarInfo.testRecord,
                      }"
                    >
                      <el-input
                        v-model="nextCarInfo.testrecord"
                        type="textarea"
                      ></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>

              <el-form
                style="padding: 10px; "
                :model="nextCarInfo"
                :rules="nextCarRules"
                ref="nextCarRef2"
                class="demo-prevCarInfo"
                label-position="left"
                label-width="95px"
              >
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item
                      label="车牌颜色"
                      prop="vehicleColor"
                      class="selection-full required"
                    >
                      <type-select
                        type="vehicleColor"
                        v-model="prevCarInfo.vehicleColor"
                        disabled
                        placeholder="请选择"
                        class="offline-changeobumain_feeblock-paymode-select"
                      />
                    </el-form-item>
                  </el-col>
                  <!-- 车种 -->
                  <el-col :span="12">
                    <el-form-item
                      label="车种"
                      prop="vehicleCategory"
                      class="selection-full required"
                      :class="{
                        'c-red':
                          nextCarInfo.vehicleCategory !=
                          prevCarInfo.vehicleCategory,
                      }"
                    >
                      <type-select
                        type="vehicleCategory"
                        v-model="nextCarInfo.vehicleCategory"
                        placeholder="请选择"
                        :disabled="!vehicleCategoryFlag"
                        class="offline-changeobumain_feeblock-paymode-select"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row :gutter="30">
                  <el-col :span="8">
                    <el-form-item
                      label="车轴数"
                      prop="axleCount"
                      class="required"
                      :class="{
                        'c-blue': nextCarInfo.vehicleCategory != 1,
                        'c-red': nextCarInfo.axleCount != prevCarInfo.axleCount,
                      }"
                    >
                      <el-input v-model="nextCarInfo.axleCount"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8">
                    <el-form-item
                      label="轮胎数"
                      prop="wheelCount"
                      class="required"
                      :class="{
                        'c-red':
                          nextCarInfo.wheelCount != prevCarInfo.wheelCount,
                      }"
                    >
                      <el-input v-model="nextCarInfo.wheelCount"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="8" class="large-axleDistance">
                    <el-form-item
                      label="轴距"
                      prop="axleDistance"
                      class="required"
                      :class="{
                        'c-red':
                          nextCarInfo.axleDistance != prevCarInfo.axleDistance,
                      }"
                    >
                      <div class="flex">
                        <el-input v-model="nextCarInfo.axleDistance"></el-input>
                        <span>mm</span>
                      </div>
                    </el-form-item>
                  </el-col>
                </el-row>

                <!-- 车辆用户类型 -->
                <el-row>
                  <el-col :span="24">
                    <el-form-item
                      label="车辆用户类型"
                      prop="vehicleType"
                      class="selection-full c-blue required"
                      :class="{
                        'c-red':
                          nextCarInfo.vehicleType != prevCarInfo.vehicleType,
                      }"
                    >
                      <type-select
                        type="vehicleUserClass"
                        v-model="nextCarInfo.vehicleType"
                        placeholder="请选择"
                        :disabled="!vehicleTypeFlag"
                        class="offline-changeobumain_feeblock-paymode-select"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col :span="24">
                    <el-form-item
                      label="收费车型"
                      prop="vehicleClass"
                      class="selection-full c-blue required"
                      :class="{
                        'c-red':
                          nextCarInfo.vehicleClass != prevCarInfo.vehicleClass,
                      }"
                    >
                      <type-select
                        :disabled="!vehicleClassFlag"
                        type="vehicleClass"
                        v-model="nextCarInfo.vehicleClass"
                        placeholder="请选择"
                        class="offline-changeobumain_feeblock-paymode-select"
                      />
                    </el-form-item>
                  </el-col>
                </el-row>

                <el-row>
                  <el-col>
                    <el-form-item label="分支机构" prop="department">
                      <el-input
                        disabled
                        v-model="prevCarInfo.department"
                      ></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>
            </el-col>
          </el-row>
        </el-scrollbar>
      </div>
    </div>

    <div class="offline-changeobumain_feeblock">
      <el-row :gutter="10">
        <el-col :span="12"
          ><div class="offline-changeobumain_feeblock-due">
            <div
              class="offline-changeobumain_feeblock-desc"
              style="font-size:18px;"
            >
              信息变更（元）
            </div>
            <div
              class="offline-changeobumain_feeblock-amount"
              style="font-size: 36px"
            >
              {{ isFree ? '0.00' : parseFloat(charge / 100).toFixed(2) }}
            </div>
          </div>
        </el-col>
        <el-col
          :span="12"
          class="o-flex o-flex-space-between"
          style="align-items: center"
        >
          <div class="sele">
            <div
              class="o-flex o-flex-align-baseline offline-changeobumain_feeblock-paymode"
            >
              <div class="offline-changeobumain_feeblock-paymode-desc">
                支付方式：
              </div>
              <type-select
                type="payMode"
                v-model="payMode"
                placeholder="请选择"
                class="offline-changeobumain_feeblock-paymode-select"
              />
            </div>
            <div class="priviledge" style="padding-top: 15px">
              <el-checkbox
                v-model="isFree"
                @change="hanleFreeCharge"
                :disabled="priviledgeFlag"
                v-if="hasFreePriviledge"
                ><span style="color: #707070">特许免费</span></el-checkbox
              >
            </div>
          </div>
          <loading-button
            :disabled="chargeFlag"
            type="primary"
            class="offline-changeobumain_feeblock-btn"
            @click="handleCharge"
            >收费
          </loading-button>
        </el-col>
      </el-row>
    </div>

    <!-- :disabled="changeFlag" -->
    <el-row :gutter="10" class="offline-changeobumain_bottom">
      <el-col>
        <el-button
          type="primary"
          class="offline-changeobumain_bottom-btn"
          round
          :disabled="changeFlag"
          :loading="changeInfoBtnStatus"
          @click="handleConfirm"
          >信息变更
        </el-button>
      </el-col>
    </el-row>

    <!-- 回执凭证 -->
    <voucher-layer-confirm
      ref="mychild1"
      :info="infoData"
      :keys="voucherConfirmKeys"
      :visible.sync="voucherConfirmVisiable"
      @complete="subConfirm"
    ></voucher-layer-confirm>

    <!-- 完善分支机构 -->
    <addbranch-block
      :visible.sync="addvisble"
      :append-to-body="true"
      popuptype="addbranch"
      :showclose="false"
      @addbranchs="handleBranchAddComplete"
    ></addbranch-block>
  </div>
</template>
<script>
import VoucherLayerConfirm from '../components/VoucherLayerConfirmCustom';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
} from '@/methods/dics';
import {
  getVehicleClassByVehicleType,
  getVehicleType,
  getVehicleUserType,
  calculateChangeVehInfo,
  changeVehicle,
  getVehicleClassByVehicleType2,
} from '@/api/vehicle';

import { orderCharges } from '@/api/equipment';
import { updateWorkOrder } from '@/api/common';
import { perfectVehicleDepartment } from '@/api/branch';

import AddbranchBlock from '@/components/AddbranchBlock';

import { mapGetters } from 'vuex';

import { vehicleModelQuery } from '@/api/newPublish';
import CustomInput from '../components/custom-input.vue';

export default {
  data() {
    return {
      changeInfoBtnStatus: false, // 信息变更按钮的loading状态
      chargeFlag: false, //收费按钮可用
      addvisble: false, // 新建分支 弹窗控制
      workOrderId: '', // 工单号
      payMode: '', // 支付方式
      prevCarInfo: {},
      nextCarInfo: {
        permittedTowWeight: '',
        dzfpVehicleType: '',
      },
      nextCarRules: {
        dzfpVehicleType: [
          { required: true, message: '请输入车辆类型', trigger: 'blur' },
        ],
        ownerName: [
          { required: true, message: '请输入所有人姓名', trigger: 'blur' },
        ],
        ownerAddress: [
          { required: true, message: '请输入所有人地址', trigger: 'blur' },
        ],
        approvedCount: [
          { required: true, message: '请输入核定载人数', trigger: 'blur' },
          { max: 4, message: '长度不能超过4个字符', trigger: 'blur' },
        ],
        engineNum: [
          { required: true, message: '请输入发动机号码', trigger: 'blur' },
        ],
        // fileNum: [
        //   { required: true, message: '请输入档案编号', trigger: 'blur' },
        // ],
        issueDate: [
          { required: true, message: '请选择发证日期', trigger: 'blur' },
        ],
        registerDate: [
          { required: true, message: '请选择注册日期', trigger: 'blur' },
        ],
        maintenanceMass: [
          { required: true, message: '请输入整备质量', trigger: 'blur' },
        ],
        vehicleCategory: [
          { required: true, message: '请选择车种', trigger: 'blur' },
        ],

        vehicleMaxLadenWeight: [
          // 货车必填
          { required: true, message: '请输入核定载质量', trigger: 'blur' },
        ],
        // 外廓尺寸的校验，校验实际字段 viHeight, viLength,viWidth
        outlineDimension: [
          { validator: this.validateDimension, trigger: 'blur' },
        ],

        vin: [
          { required: true, message: '请输入车辆识别代码', trigger: 'blur' },
        ],
        permittedTowWeight: [
          // 牵引车必填
          { required: true, message: '准牵引总质量', trigger: 'blur' },
        ],
        vehicleTotalMass: [
          // 货车必填
          { required: true, message: '请输入总质量', trigger: 'blur' },
        ],
        axleCount: [{ required: true, message: '车轴数', trigger: 'blur' }],
        wheelCount: [{ required: true, message: '轮胎数', trigger: 'blur' }],
        axleDistance: [
          { required: true, message: '请输入轴距', trigger: 'blur' },
        ],
      },

      changeFlag: true, // 信息变更 按钮 默认不可用， 收费完成后才可用
      priviledgeFlag: false, // 特许免费按钮 可用状态
      isFree: false, // 特许免费
      price: '', // 收费
      // 回执凭证
      voucherConfirmVisiable: false,
      voucherConfirmKeys: [
        //业务类型
        [{ key: 'businessType', label: '业务类型' }],

        //用户信息
        [
          { key: 'userName', label: '用户名称' },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],

        //etc卡
        [{ key: 'cardId', label: '卡号' }],

        // obu信息
        [
          { key: 'obuId', label: '标签ID' },
          { key: 'printId', label: '标签表面号' },
        ],

        // 车辆信息（原车， 新车， 间隔显示）
        [
          { key: 'vehicleNumber', label: '车牌号码' },
          { key: 'vehicleColor', label: '车牌颜色' },
          { key: 'vehicleNumber2', label: '车牌号码' },
          { key: 'vehicleColor2', label: '车牌颜色' },

          { key: 'vehicleSize', label: '原车身尺寸' },
          { key: 'vehicleType', label: '原车辆用户类型' },
          { key: 'vehicleSize2', label: '新车身尺寸' },
          { key: 'vehicleType2', label: '新车辆用户类型' },

          { key: 'vehicleClass', label: '原收费车型' },
          { key: 'approvedAccount', label: '原核定载人数' },
          { key: 'vehicleClass2', label: '新收费车型' },
          { key: 'approvedAccount2', label: '新核定载人数' },

          // // 非客车 显示
          // { key: 'axleCount', label: '原轴数' },
          // { key: 'permittedTowWeight', label: '原准牵引总质量' },
        ],

        // 支付信息
        [
          { key: 'charge', label: '收费金额' },
          { key: 'payMode', label: '支付方式' },
        ],
      ],
      infoData: {},

      // 下拉框 禁用控制 默认可用
      vehicleTypeFlag: true, // 车辆用户类型
      vehicleCategoryFlag: true, // 车种
      vehicleClassFlag: true, // 收费车型
    };
  },
  components: {
    VoucherLayerConfirm,
    AddbranchBlock,
    CustomInput,
  },
  computed: {
    ...mapGetters([
      'searchUserInfo',
      'searchCarInfo',
      'searchObuInfo',
      'searchCardInfo',
      'searchAccountInfo',
      'elementPermissions',
      'menuIds',
      'searchDepartmentInfo',
    ]),

    // 操作员是否有特许免费的权限
    hasFreePriviledge() {
      // return this.elementPermissions
      //   .filter(ele => ele.menu === '/vehicleinfochange')
      //   .some(ele => ele.permissions.specialfree === true);
      let child = this.menuIds.filter(item => item.title == '车辆业务')[0];
      let child2 = child.children.filter(
        item => item.title == '车辆信息变更'
      )[0];
      let endchild = child2.endchildren;
      return endchild.some(item => item.title == '变更车型特许免费');
    },

    //收费
    charge() {
      return this.isFree ? 0 : this.price;
    },
  },

  methods: {
    // 校验车身尺寸长，宽，高
    validateDimension(rule, value, callback) {
      if (!this.nextCarInfo.viLength) {
        callback(new Error('请输入车长'));
      }
      if (!this.nextCarInfo.viWidth) {
        callback(new Error('请输入车宽'));
      }
      if (!this.nextCarInfo.viHeight) {
        callback(new Error('请输入车高'));
      }
      if (this.nextCarInfo.viLength > 65535) {
        callback(new Error('车长小于65535'));
      }
      callback();
    },

    //接受路由参数carInfo, 上一步ocr识别的结果
    getNextCarInfo() {
      const { carInfo = [], workOrderID = '' } = this.$route.query;
      this.workOrderId = workOrderID;

      // 301-1 是行驶证第一页，301-2是第二页
      carInfo
        .filter(
          info =>
            info.type == '301-1' || info.type == '301-2' || info.type == '302-1'
        )
        .forEach(info => {
          // 车辆登记证，OCR识别只取axleCount, axleDistance, wheelCount，这三个字段
          if (info.type == '302-1') {
            this.nextCarInfo = {
              ...this.nextCarInfo,
              axleCount: info.ocr.axleCount,
              axleDistance: info.ocr.axleDistance,
              wheelCount: info.ocr.wheelCount,
            };
          } else {
            this.nextCarInfo = {
              ...this.nextCarInfo,
              ...info.ocr,
            };
          }
        });

      this.handleOCR();

      // 302-1 是机动车登记证(货车需要上传)，ocr识别获取 axleCount, axleDistance, wheelCount，（合法性判断，必须是数字类型）
      // var numExp = /^\d+$/g;
      // carInfo
      //   .filter(info => info.type == '302-1')
      //   .forEach(info => {
      //     this.nextCarInfo = {
      //       ...this.nextCarInfo,
      //       axleCount: numExp.test(info.ocr.axleCount)
      //         ? info.ocr.axleCount
      //         : '',
      //       axleDistance: numExp.test(info.ocr.axleDistance)
      //         ? info.ocr.axleDistance
      //         : '',
      //       wheelCount: numExp.test(info.ocr.wheelCount)
      //         ? info.ocr.wheelCount
      //         : '',
      //     };
      //   });

      //  车种来自ocr识别后调后台的5.11.车种查询接口
      if (this.nextCarInfo.dzfpVehicleType) {
        getVehicleClassByVehicleType(this.nextCarInfo.dzfpVehicleType).then(
          res => {
            if (res && res.vehicleCategory) {
              // 车种
              this.$set(
                this.nextCarInfo,
                'vehicleCategory',
                res.vehicleCategory
              );

              // 调接口5.6 查询收费车型 接口参数货车需要车轴数, 货车车轴数在车辆登记证上有
              getVehicleType({
                approvedAccount: this.nextCarInfo.approvedCount,
                vehicleCategory: res.vehicleCategory,
                viLength: this.nextCarInfo.viLength,
                axleCount: this.nextCarInfo.axleCount,
                viTotalMass: this.getViTotalMass(),
              }).then(res => {
                if (res) {
                  // 收费车型
                  this.$set(this.nextCarInfo, 'vehicleClass', res.vehicleClass);
                }

                // 车轴信息
                if (
                  this.nextCarInfo.vehicleCategory == '1' &&
                  this.nextCarInfo.vehicleClass
                ) {
                  vehicleModelQuery({
                    //vehicleType: self.form.dzfpVehicleType,
                    vehicleCategory: this.nextCarInfo.vehicleCategory,
                    vehicleClass: this.nextCarInfo.vehicleClass,
                  }).then(res => {
                    if (res) {
                      this.$set(this.nextCarInfo, 'axleCount', res.axleCount);
                      this.$set(this.nextCarInfo, 'wheelCount', res.wheelCount);
                      this.$set(
                        this.nextCarInfo,
                        'axleDistance',
                        res.axleDistance
                      );
                    }
                  });
                }

                if (res.vehicleClass == '' || res.vehicleClass == null) {
                  // 没查到 车种 下拉框可用
                  this.vehicleClassFlag = true;
                } else {
                  this.vehicleClassFlag = false;
                }
              });
            }

            if (res.vehicleCategory == '' || res.vehicleCategory == null) {
              // 没查到 车种 下拉框可用
              this.vehicleCategoryFlag = true;
            } else {
              this.vehicleCategoryFlag = false;
            }
          }
        );

        // 车辆用户类型 查询接口 5.7
        getVehicleUserType({
          vehicleType: this.nextCarInfo.dzfpVehicleType,
          vehicleNumber: this.nextCarInfo.vehicleNumber,
          vehicleColor: this.nextCarInfo.vehicleColor,
        }).then(res => {
          if (res) {
            // 车辆用户类型
            this.$set(this.nextCarInfo, 'vehicleType', res.vehicleClass);
          }

          if (res.vehicleClass == '' || res.vehicleClass == null) {
            // 没查到 车辆用户类型 下拉框可用
            this.vehicleTypeFlag = true;
          } else {
            this.vehicleTypeFlag = false;
          }
        });
      } else {
        this.vehicleTypeFlag = true;
        this.vehicleCategoryFlag = true;
      }
    },

    // 处理OCR识别中字段新
    getNum(val) {
      if (/\d+/g.test(val)) {
        return val.match(/(\d+)/g)[0];
      } else {
        return val;
      }
    },

    // 收费车型总质量参数
    getViTotalMass() {
      let result = 0,
        numReg = /^\d+$/g;
      const { vehicleTotalMass, maintenanceMass } = this.nextCarInfo;
      if (numReg.test(vehicleTotalMass)) {
        result = vehicleTotalMass;
        return result;
      }

      if (numReg.test(maintenanceMass)) {
        result = maintenanceMass;
        return result;
      }
      return result;
    },

    handleOCR() {
      // ocr识别数据处理,核定载人数, 整备质量，总质量 取数字
      // 外廓尺寸
      let match = [];
      if (this.nextCarInfo.outlineDimension) {
        match = this.nextCarInfo.outlineDimension.match(/(\d+)/gi);
      }

      // 车牌号，车牌颜色 取老车信息，不可更改
      this.nextCarInfo = {
        ...this.nextCarInfo,
        // 去除单位kg 人
        approvedCount: this.getNum(this.nextCarInfo.approvedCount), // 核定载人数
        maintenanceMass: this.getNum(this.nextCarInfo.maintenanceMass), // 整备质量
        vehicleTotalMass: this.getNum(this.nextCarInfo.vehicleTotalMass), // 总质量
        permittedTowWeight: this.getNum(
          this.nextCarInfo.vehicleTrainMaxImuweight
        ), // 准牵引总质量
        vehicleMaxLadenWeight: this.getNum(
          this.nextCarInfo.vehicleMaxLadenWeight
        ), // 核定载质量

        viLength: match[0] || '',
        viWidth: match[1] || '',
        viHeight: match[2] || '',

        vehicleNumber: this.prevCarInfo.vehicleNumber,
        vehicleColor: this.prevCarInfo.vehicleColor,
        vehicleClass: '', // 收费车型
        dzfpVehicleType: this.nextCarInfo.vehicleType, // 行驶证上描述的车辆类型
        vehicleType: '', // 车辆用户类型

        axleCount: this.nextCarInfo.axleCount || '',
        axleDistance: this.getNum(this.nextCarInfo.axleDistance) || '',
        wheelCount: this.nextCarInfo.wheelCount || '',
      };

      //核定载人数 总质量，整备质量， 准牵引总质量 核定载质量 vehicleMaxLadenWeight （数字类型或者--）
    },

    //处理收费
    handleCharge() {
      if (this.payMode == '') {
        this.$message.warning('请选择支付方式');
        return false;
      }

      let params = {
        etcUserId: this.searchUserInfo.etcUserId,
        workOrderId: this.workOrderId,
        vehicleNumber: this.nextCarInfo.vehicleNumber,
        vehicleColor: this.nextCarInfo.vehicleColor,
        orderType: 2,
        price: this.charge,
        payMode: this.payMode,
        isFree: this.isFree ? 1 : 0,
      };

      orderCharges(params).then(res => {
        if (res) {
          // 收费业务完成
          this.chargeFlag = true;
          this.changeFlag = false; //1. 信息变更 功能按钮可用 2. 特许免费不可用
          if (this.hasFreePriviledge) {
            this.priviledgeFlag = true;
          }
          // this.$message.success('收费成功'); //  不需要提示
        }
      });
    },

    // 车型变更费用
    getCharge() {
      calculateChangeVehInfo({
        etcUserId: this.searchUserInfo.etcUserId,
        vehicleNumber: this.searchCarInfo.vehicleNumber,
        vehicleColor: this.searchCarInfo.vehicleColor,
      }).then(res => {
        if (res) {
          this.price = res.price;
        }
      });
    },

    // 凭证数据
    async carInfoVoucher() {
      let result = {};

      // 业务类型
      result = {
        ...result,
        businessType: '变更车型',
      };

      // 用户信息
      result = {
        ...result,
        userName: this.searchUserInfo.userName,
        userCertType: await getDicDesByCode(
          'userCertType',
          this.searchUserInfo.userCertType
        ),
        userCode: this.searchUserInfo.userCode,
      };

      // 卡号
      result = {
        ...result,
        cardId: this.searchCardInfo.cardID,
      };

      // 标签id, 表面号
      result = {
        ...result,
        obuId: this.searchObuInfo.obuID,
        printId: this.searchObuInfo.printID,
      };

      // 车辆信息 车牌号 车牌颜色  车身尺寸 车辆用户类型 收费车型 核定载人数
      result = {
        ...result,
        vehicleNumber: this.searchCarInfo.vehicleNumber,
        vehicleColor: await getDicDesByCode(
          'vehicleColor',
          this.searchCarInfo.vehicleColor
        ),
        vehicleNumber2: this.searchCarInfo.vehicleNumber,
        vehicleColor2: await getDicDesByCode(
          'vehicleColor',
          this.searchCarInfo.vehicleColor
        ),
        vehicleSize: `${this.searchCarInfo.viLength} X ${this.searchCarInfo.viWidth} X ${this.searchCarInfo.viHeight}mm`,
        vehicleSize2: `${this.nextCarInfo.viLength} X ${this.nextCarInfo.viWidth} X ${this.nextCarInfo.viHeight}mm`,

        vehicleType: await getDicDesByCode(
          'vehicleUserClass',
          this.searchCarInfo.vehicleType
        ),
        vehicleType2: await getDicDesByCode(
          'vehicleUserClass',
          this.nextCarInfo.vehicleType
        ),

        vehicleClass: await getDicDesByCode(
          'vehicleClass',
          this.searchCarInfo.vehicleClass
        ),
        vehicleClass2: await getDicDesByCode(
          'vehicleClass',
          this.nextCarInfo.vehicleClass
        ),
        approvedAccount: `${this.searchCarInfo.approvedAccount}人`,
        approvedAccount2: `${this.nextCarInfo.approvedCount}人`,
      };

      // 非客车(车种)显示 车轴数 总质量
      if (this.searchCarInfo.vehicleCategory != 1) {
        this.voucherConfirmKeys[4].push({
          key: 'axleCount',
          label: '原车轴数',
        });
        this.voucherConfirmKeys[4].push({
          key: 'axleCount2',
          label: '新车轴数',
        });
        this.voucherConfirmKeys[4].push({
          key: 'viTotalMass',
          label: '原总质量',
        });
        this.voucherConfirmKeys[4].push({
          key: 'viTotalMass2',
          label: '新总质量',
        });

        result.axleCount = this.searchCarInfo.axleCount;
        result.axleCount2 = this.nextCarInfo.axleCount;
        result.viTotalMass = `${this.searchCarInfo.viTotalMass}kg`;
        result.viTotalMass2 = `${this.nextCarInfo.vehicleTotalMass}kg`;
      }

      // 货车 核定载质量
      if (this.searchCarInfo.vehicleCategory == 2) {
        this.voucherConfirmKeys[4].push({
          key: 'permittedWeight',
          label: '原核定载质量',
        });

        this.voucherConfirmKeys[4].push({
          key: 'placeholder',
          label: '',
        });
        this.voucherConfirmKeys[4].push({
          key: 'permittedWeight2',
          label: '新核定载质量',
        });
        this.voucherConfirmKeys[4].push({
          key: 'placeholder2',
          label: '',
        });
        result.permittedWeight = this.searchCarInfo.permittedWeight + 'kg';
        result.permittedWeight2 = this.nextCarInfo.vehicleMaxLadenWeight + 'kg';
      }

      //牵引车 准牵引总质量
      if (this.searchCarInfo.vehicleCategory == 3) {
        this.voucherConfirmKeys[4].push({
          key: 'permittedTowWeight',
          label: '原准牵引总质量',
        });

        this.voucherConfirmKeys[4].push({
          key: 'placeholder',
          label: '',
        });

        this.voucherConfirmKeys[4].push({
          key: 'permittedTowWeight2',
          label: '新准牵引总质量',
        });
        this.voucherConfirmKeys[4].push({
          key: 'placeholder2',
          label: '',
        });
        result.permittedTowWeight =
          this.searchCarInfo.permittedTowWeight + 'kg';
        result.permittedTowWeight2 = this.nextCarInfo.permittedTowWeight + 'kg';
      }

      // 收费信息
      // console.log('charge', this.charge)
      result.charge = parseFloat(this.charge / 100).toFixed(2) + '元'; // charge单位是分
      result.payMode = await getDicDesByCode('payMode', this.payMode);

      this.infoData = { ...result };

      this.$nextTick(() => {
        //执行调用手写板
        this.$refs.mychild1.sendpad();
      });
    },

    // 信息变更 回执凭证
    handleConfirm(callback) {
      // 这里进行表单的参数校验，校验后显示回执凭证信息
      this.$refs['nextCarRef1'].validate(flag => {
        if (flag) {
          this.$refs['nextCarRef2'].validate(flag2 => {
            if (flag2) {
              this.voucherConfirmVisiable = true;

              this.carInfoVoucher();
            }
          });
        }
      });
    },

    // 代客户确认
    subConfirm(data) {
      // 调用12.9 上传回执图片，更新工单
      this.changeFlag = true; //信息变更暂时不可用， loading状态
      this.changeInfoBtnStatus = true;

      console.log('data', data);

      let imagelist = [];

      imagelist.push({
        imgFrontID: data.frontImgid,
        imgType: 9011,
        mediaType: 5,
      });

      updateWorkOrder({
        workOrderID: this.workOrderId,
        modifyInfo: { imagelist },
      })
        .then(res => {
          if (res) {
            this.updateVehicleInfo();
          }
          // this.changeFlag = false;
        })
        .catch(() => {
          // this.changeFlag = false;
        });
    },

    //validte
    validateForm() {},

    // 变更车型
    updateVehicleInfo() {
      //表单的参数校验

      let params = {
        etcUserId: this.searchUserInfo.etcUserId,
        workOrderId: this.workOrderId,
        vehicleId: this.searchCarInfo.vehicleId,
        vehicleNumber: this.nextCarInfo.vehicleNumber,
        vehicleColor: this.nextCarInfo.vehicleColor,
        viRegisterDate: this.nextCarInfo.registerDate,
        viIssueDate: this.nextCarInfo.issueDate,
        dzfpVehicleType: this.nextCarInfo.dzfpVehicleType,
        vehicleSpecies: this.nextCarInfo.vehicleSpecies,
        viModelName: this.nextCarInfo.vehicleNote,
        vin: this.nextCarInfo.vin,
        engineNum: this.nextCarInfo.engineNum,
        approvedAccount: this.nextCarInfo.approvedCount,
        maintenaceMass: this.nextCarInfo.maintenanceMass,
        viLength: this.nextCarInfo.viLength,
        viWidth: this.nextCarInfo.viWidth,
        viHeight: this.nextCarInfo.viHeight,
        wheelCount: this.nextCarInfo.wheelCount,
        axleCount: this.nextCarInfo.axleCount,
        axleDistance: this.nextCarInfo.axleDistance,
        vehicleType: this.nextCarInfo.vehicleType,
        vehicleClass: this.nextCarInfo.vehicleClass,
        viownerInfo: {
          ownerName: this.nextCarInfo.ownerName,
          ownerphoneNum: this.searchUserInfo.userPhone,
        },
        isNowReset: '0', // TODO 暂时写死
      };

      // 货车
      if (this.nextCarInfo.vehicleCategory == 2) {
        params.viTotalMass = this.nextCarInfo.vehicleTotalMass;
        params.permittedWeight = this.nextCarInfo.vehicleMaxLadenWeight;
      }

      // 牵引车
      if (this.nextCarInfo.vehicleCategory == 3) {
        params.permittedTowWeight = this.nextCarInfo.permittedTowWeight;
      }

      // 对公业务
      if (this.searchUserInfo.userProperty == 2) {
        params.department = this.nextCarInfo.department;
      }

      // 14.21 	变更车型申请
      changeVehicle(params)
        .then(res => {
          if (res.exCode == 9001) {
            // 完善分支机构
            // 如果14.3 换卡业务申请接口返回9001
            this.$alert('代理人信息异常，正在完善分支机构，请稍等', '提示', {
              confirmButtonText: '确定',
              showClose: false,
              type: 'warning',
            })
              .then(async () => {
                // 点击确定后调用后台4.12.完善分支机构接口，由系统自动进行完善处理

                let resPer, loading;
                try {
                  loading = this.$loading();
                  resPer = await perfectVehicleDepartment({
                    etcUserId: this.searchUserInfo.etcUserId,
                    vehicleId: this.searchCarInfo.vehicleId,
                  });

                  loading.close();
                  this.changeFlag = false;
                  this.changeInfoBtnStatus = false;
                } catch (error) {
                  loading.close();
                  this.changeFlag = false;
                  this.changeInfoBtnStatus = false;
                }

                if (resPer) {
                  if (resPer.exCode == '9002') {
                    // 如果4.12.完善分支机构接口返回9002，前端提示“该用户名下无有效默认分支机构，请新建”
                    this.$alert(
                      '该用户名下无有效默认分支机构，请新建',
                      '提示',
                      {
                        confirmButtonText: '确定',
                        showClose: false,
                        type: 'warning',
                      }
                    ).then(() => {
                      // 自动弹出新建分支机构的页面
                      this.addvisble = true;
                    });
                  }

                  if (!resPer.exCode) {
                    // 继续取执行14.21 	变更车型申请
                    this.updateVehicleInfo();
                  }
                }
              })
              .catch(() => {
                this.changeFlag = false;
                this.changeInfoBtnStatus = false;
              });
          } else {
            // 修改成功，返回流程页面,带参数过去，车种信息带过去，方便业务判断
            this.changeFlag = false;
            this.changeInfoBtnStatus = false; //
            this.$router.push({
              path: '/vehicleinfochange/changeType',
              query: {
                nextCarInfo: this.nextCarInfo,
                workOrderId: this.workOrderId,
                vehicleCategory: {
                  prev: this.prevCarInfo.vehicleCategory,
                  next: this.nextCarInfo.vehicleCategory,
                },
              },
            });
          }
        })
        .catch(() => {
          this.changeFlag = false;
          this.changeInfoBtnStatus = false;
        });
    },

    // 新建分支机构完成后
    async handleBranchAddComplete() {
      // 完善分支机构（默认分支机构）
      let resPer, loading;
      try {
        loading = this.$loading();
        resPer = await perfectVehicleDepartment({
          etcUserId: this.searchUserInfo.etcUserId,
          vehicleId: this.searchCarInfo.vehicleId,
        });
        loading.close();
      } catch (error) {
        loading.close();
      }

      if (resPer) {
        if (resPer.exCode == '9002') {
          // 如果4.12.完善分支机构接口返回9002，前端提示“该用户名下无有效默认分支机构，请新建”
          this.$alert('该用户名下无有效默认分支机构，请新建', '提示', {
            confirmButtonText: '确定',
            showClose: false,
            type: 'warning',
          }).then(() => {
            // 自动弹出新建分支机构的页面
            this.addvisble = true;
          });
        }

        if (!resPer.exCode) {
          // 继续取执行14.21 	变更车型申请
          this.updateVehicleInfo();
        }
      }
    },

    //特许免费
    hanleFreeCharge(val) {
      this.isFree = val;
    },

    // 根据行驶证车辆类型查询车种
    async getVehicleClassByVehicleType() {
      this.vehicleClassFlag = true;
      this.vehicleCategoryFlag = true;
      if (!this.nextCarInfo.dzfpVehicleType) {
        return;
      }
      const res = await getVehicleClassByVehicleType2({
        vehicleType: this.nextCarInfo.dzfpVehicleType,
        permittedTowWeight: this.nextCarInfo.permittedTowWeight,
      });
      if (res) {
        this.$set(this.nextCarInfo, 'vehicleCategory', res.vehicleCategory);
        // this.form.vehicleCategory = res.vehicleCategory;
        if (!res.vehicleCategory) {
          this.vehicleCategoryFlag = true;
          this.vehicleClassFlag = true;
          this.$set(this.nextCarInfo, 'vehicleClass', '');
        } else {
          getVehicleType({
            approvedAccount: this.nextCarInfo.approvedCount,
            vehicleCategory: res.vehicleCategory,
            viLength: this.nextCarInfo.viLength,
            axleCount: this.nextCarInfo.axleCount,
            viTotalMass: this.getViTotalMass(),
          }).then(res => {
            if (res) {
              this.$set(this.nextCarInfo, 'vehicleClass', res.vehicleClass);
            }

            // 车轴信息
            if (
              this.nextCarInfo.vehicleCategory == '1' &&
              this.nextCarInfo.vehicleClass
            ) {
              vehicleModelQuery({
                //vehicleType: self.form.dzfpVehicleType,
                vehicleCategory: this.nextCarInfo.vehicleCategory,
                vehicleClass: this.nextCarInfo.vehicleClass,
              }).then(res => {
                if (res) {
                  this.$set(this.nextCarInfo, 'axleCount', res.axleCount);
                  this.$set(this.nextCarInfo, 'wheelCount', res.wheelCount);
                  this.$set(this.nextCarInfo, 'axleDistance', res.axleDistance);
                }
              });
            }

            if (res.vehicleClass == '' || res.vehicleClass == null) {
              // 没查到 车种 下拉框可用
              this.vehicleClassFlag = true;
            } else {
              this.vehicleClassFlag = false;
            }
          });
        }
      }

      if (res.vehicleCategory == '' || res.vehicleCategory == null) {
        // 没查到 车种 下拉框可用
        this.vehicleCategoryFlag = true;
        this.vehicleClassFlag = true;
        this.$set(this.nextCarInfo, 'vehicleClass', '');
      } else {
        this.vehicleCategoryFlag = false;
      }
    },

    // 查询车辆用户类型
    async getVehicleUserType() {
      const self = this;
      if (!self.nextCarInfo.dzfpVehicleType) return;
      // if (!self.form.vehicleColor) return;
      // if (!self.form.vehicleNumber) return;
      const colorCode = await getDicCodeByDes(
        dicKeys.vehicleColor,
        self.nextCarInfo.vehicleColor
      );
      const res = await getVehicleUserType({
        vehicleType: self.nextCarInfo.dzfpVehicleType,
        vehicleNumber: self.nextCarInfo.vehicleNumber,
        vehicleColor: self.nextCarInfo.vehicleColor,
        permittedTowWeight: self.nextCarInfo.permittedTowWeight,
      });
      if (res) {
        self.$set(self.nextCarInfo, 'vehicleType', res.vehicleClass);
      }

      if (res.vehicleClass == '' || res.vehicleClass == null) {
        // 没查到 车辆用户类型 下拉框可用
        this.vehicleTypeFlag = true;
      } else {
        this.vehicleTypeFlag = false;
      }
    },
  },

  watch: {
    'nextCarInfo.dzfpVehicleType'() {
      // 查询车种
      this.getVehicleClassByVehicleType();
      this.getVehicleUserType();
    },

    'nextCarInfo.permittedTowWeight'() {
      // 当准牵引总质量发生变化时，需要触发再次识别车种和车辆用户类型
      // 查询车种
      console.log('watch');
      this.getVehicleClassByVehicleType();
      this.getVehicleUserType();
    },
  },

  mounted() {
    // 老车的信息
    let result = {};
    Object.keys(this.searchCarInfo).map(key => {
      result[key] =
        this.searchCarInfo[key] == null ? '' : this.searchCarInfo[key];
    });
    this.prevCarInfo = {
      ...result, // null字段转为''
      department: this.searchDepartmentInfo.department,
    };
    // 新车的信息
    this.getNextCarInfo();

    // 收费价格14.22
    this.getCharge();
  },

  updated() {
    console.log('nextCarInfo', this.nextCarInfo);
    console.log('prevCarInfo', this.prevCarInfo);
  },
};
</script>

<style lang="scss" scoped>
::v-deep .large-axleDistance {
  .el-form-item__label {
    width: 40px !important;
  }
  .el-form-item__content {
    margin-left: 40px !important;
  }
}

::v-deep .custom-permittedTowWeight {
  .el-input__inner {
    padding: 0;
  }
}
</style>
