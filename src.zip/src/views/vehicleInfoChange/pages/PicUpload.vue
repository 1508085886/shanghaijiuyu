<!-- 证件上传 -->
<template>
  <div class="offline-changeobu c-box" style="height:100%">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-changeobuindex_title">变更车型</h4>
      </div>
    </div>
    <template>
      <div class="offline-changeobudocupload_subtitle mt23">车辆证件</div>
      <div class="o-flex">
        <photograph-block
          @complete="imgs => (imgsUploaded.car = [...imgs])"
          width="104"
          height="104"
          ocr
          type="vehicleCertType"
          :defaultPics="imgsUploaded.car"
          :append-to-body="true"
          class="mt12"
        ></photograph-block>
      </div>
    </template>
    <!-- 对公用户，还需上传经办人证件。对私用户，可以上传经办人证件，非必须。 -->
    <template>
      <div class="offline-changeobudocupload_subtitle mt23">经办人证件</div>
      <div class="o-flex">
        <photograph-block
          @complete="imgs => (imgsUploaded.operator = [...imgs])"
          width="104"
          height="104"
          type="agentCertType"
          :picsMaxLength="2"
          :defaultPics="imgsUploaded.operator"
          :append-to-body="true"
          class="mt12"
        ></photograph-block>
      </div>
    </template>
    <!-- 其它证件信息 -->
    <template>
      <div class="offline-changeobudocupload_subtitle">其他证件资料</div>
      <div class="o-flex">
        <photograph-block
          @complete="imgs => (imgsUploaded.other = [...imgs])"
          width="104"
          height="104"
          type="agentCertType"
          :defaultPics="imgsUploaded.other"
          :append-to-body="true"
          class="mt12"
        ></photograph-block>
      </div>
    </template>
    <div class="o-flex offline-changeobudocupload_rtn-button-wrap">
      <loading-button
        type="primary"
        class="offline-changeobudocupload_rtn-button"
        @click="handleConfirm"
        >确定
      </loading-button>
    </div>
  </div>
</template>
<script>
import PhotographBlock from '@/components/PhotographBlock';
import { mapGetters, mapActions } from 'vuex';
import { createOrderv, updateWorkOrder, startTblWork } from '@/api/common';

export default {
  data() {
    return {
      // 上传的图片
      imgsUploaded: {
        car: [],
        operator: [],
        other: [],
      },
    };
  },
  components: {
    PhotographBlock,
  },
  computed: {
    ...mapGetters([
      'searchUserInfo',
      'searchCarInfo',
      'searchObuInfo',
      'searchCardInfo',
      'searchAccountInfo',
      'searchAgentImg', // 主页经办人证件
      'searchOtherImg', // 其它证件
    ]),
    userProperty() {
      return this.searchUserInfo.userProperty; // 1 个人 2 单位
    },
  },
  methods: {
    ...mapActions({
      clearSearchAgentImg: 'ClearSearchAgentImg',
      setSearchAgentImg: 'GetSearchAgentImg',
      clearSearchOtherImg: 'ClearSearchOtherImg',
      setSearchOtherImg: 'GetSearchOtherImg',
    }),

    validateParams() {
      // 车辆证件 必传
      if (this.imgsUploaded.car.length < 1) {
        this.$message.warning('请上传车辆证件');
        return false;
      }
      // 对公用户(单位) 需 经办人证件
      if (this.imgsUploaded.operator.length < 1 && this.userProperty == 2) {
        this.$message.warning('对公业务请上传经办人证件');
        return false;
      }
      return true;
    },

    // 同步主页的用户证件区域
    syncHomePagePic() {
      //1. 上传的图片要展示在主页的证件区域, 经办人证件信息，其它证件, 车辆证件不需要

      // this.clearSearchAgentImg();
      this.setSearchAgentImg(this.imgsUploaded.operator);

      // this.clearSearchOtherImg();
      this.setSearchOtherImg(this.imgsUploaded.other);
    },

    async handleConfirm() {
      if (!this.validateParams()) return;

      this.syncHomePagePic();

      let params = {
        bizCode: '13',
        oldUserId: this.searchUserInfo.userID,
        oldUserAcctId: this.searchAccountInfo.userAcctId,
        oldDepartmentName: this.searchAccountInfo.department,
        oldVehicleId: this.searchCarInfo.vehicleId,
        oldVehicleNumber: this.searchCarInfo.vehicleNumber,
        oldVehicleColor: this.searchCarInfo.vehicleColor,
        oldBuyId: this.searchAccountInfo.signOrderNo,
        oldCardId: this.searchCardInfo.cardID,
        oldObuysId: this.searchObuInfo.printID,
        oldObuId: this.searchObuInfo.obuID,
        oldEtcUserId: this.searchUserInfo.etcUserId,
        oldUsername: this.searchUserInfo.userName,
        oldPayChannelName: this.searchAccountInfo.payChannelName,
        oldSubPayChannelName: this.searchAccountInfo.subPayChannelName,
      };

      //#1  调用接口 12.13 创建工单
      const { workOrderID } = await createOrderv(params);

      //#2  14.11启用工单
      await startTblWork({ workOrderId: workOrderID });

      //#3  上传图片和工单绑定
      let imagelist = this.handleImagesUpload();
      updateWorkOrder({
        workOrderID,
        modifyInfo: { imagelist },
      }).then(res => {
        if (res) {
          // 跳转到车型变更页： 车型变更, 携带ocr识别的车辆信息参数
          this.$router.push({
            path: '/vehicleinfochange/changeinfo',
            query: {
              carInfo: this.imgsUploaded.car,
              workOrderID,
            },
          });
        }
      });
    },

    // 处理图片参数
    handleImagesUpload() {
      let imagelist = [];
      this.imgsUploaded.car.forEach(pic => {
        imagelist.push({
          imgFrontID: pic.frontImgid,
          imgType: pic.type.replace('-', ''),
          mediaType: '3',
        });
      });
      this.imgsUploaded.operator.forEach(pic => {
        imagelist.push({
          imgFrontID: pic.frontImgid,
          imgType: '1011',
          mediaType: '4',
        });
      });
      this.imgsUploaded.other.forEach(pic => {
        imagelist.push({
          imgFrontID: pic.frontImgid,
          imgType: '8011',
          mediaType: '10',
        });
      });
      return imagelist;
    },

    // 获取主页图片上传的数据
    getMainPagePic() {
      if (this.searchAgentImg && this.searchAgentImg.length > 0) {
        this.imgsUploaded.operator = [
          ...this.searchAgentImg,
          ...this.imgsUploaded.operator,
        ];
      }

      if (this.searchOtherImg && this.searchOtherImg.length > 0) {
        this.imgsUploaded.other = [
          ...this.searchOtherImg,
          ...this.imgsUploaded.other,
        ];
      }
    },
  },
  mounted() {
    this.getMainPagePic();
  },
};
</script>

<style scoped>
.c-box {
  height: 100%;
}
</style>
