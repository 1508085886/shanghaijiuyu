<template>
  <el-input :value="value" @input="handleChange"> </el-input>
</template>

<script>
const regExp = /[^0-9\-]/g;
export default {
  model: {
    prop: 'value',
    event: 'input',
  },
  props: {
    value: {},
    reg: {
      type: RegExp,
      default: () => regExp,
    },
  },

  methods: {
    handleChange(val) {
      val = val.toString().trim();
      this.$emit('input', val.replace(this.reg, ''));
    },
  },
};
</script>

<style></style>
