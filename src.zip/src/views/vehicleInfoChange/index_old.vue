<!-- 车辆信息变更 -->
<template>
  <div class="offline-car-register-form vehicleInfoChange">
    <v-info-change-form ref="form" />
    <transactor-dialog
      :visible.sync="transactorDialogVisible"
      :append-to-body="true"
      @transactorDialogComplete="transactorDialogComplete"
    />
    <div class="clearfix mt20">
      <div class="fr">
        <!-- <el-button @click="$router.back()">上一步</el-button> -->
        <el-button
          type="primary"
          @click="showVoucher"
          v-dbclick="{ timer: '1100' }"
          :loading="loading"
          :disabled="isButtonDisabled"
          >下一步</el-button
        >
      </div>
    </div>

    <voucher-layer
      ref="mychild"
      :visible.sync="voucherVisible"
      :keys="voucherKeys"
      :info="voucherData"
      :column="2"
      :footer="voucherFooter"
      @complete="complete"
      @cancel="clearForm"
    />
  </div>
</template>

<script>
import VInfoChangeForm from '@/views/VInfoChangeForm';
import TransactorDialog from '@/components/TransactorDialog';
import { registerVehicle } from '@/api/vehicle';
import VoucherLayer from '@/components/VoucherLayerConfirm';
import { dicKeys, getDicDesByCode } from '@/methods/dics';
let voucherPic = null;

export default {
  data() {
    return {
      message: '本次车辆信息变更的内容：</br></br>',
      // keyucArr: [],
      keycArr: [],
      // valueucArr: [],
      valuecArr: [],
      formUC: {},
      flagg: true,
      registerFlag: true,
      newForm: {},
      isButtonDisabled: false,
      loading: false,
      loading1: false,
      voucherKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          {
            key: 'vehicleNumber',
            label: '车牌号码',
            color: 'blue',
            fontWeight: 'bold',
          },
          {
            key: 'vehicleColor',
            label: '车牌颜色',
            color: 'blue',
            fontWeight: 'bold',
          },
          {
            key: 'dzfpVehicleType',
            label: '车辆类型',
            color: 'blue',
            fontWeight: 'bold',
          },
          {
            key: 'vehicleType',
            label: '车辆用户类型',
            color: 'blue',
            fontWeight: 'bold',
          },
          {
            key: 'vehicleClass',
            label: '收费车型',
            color: 'blue',
            fontWeight: 'bold',
          },
          { key: 'ownerName', label: '车辆所有人' },
          { key: 'vehicleSpecies', label: '使用性质' },
          { key: 'viModelName', label: '品牌型号' },
          { key: 'vin', label: '车辆识别代码' },
          { key: 'engineNum', label: '发动机号码' },
          { key: 'approvedAccount', label: '核定载人数' },
          { key: 'viTotalMass', label: '总质量' },
          { key: 'maintenaceMass', label: '整备质量' },
          { key: 'permittedWeight', label: '核定载质量' },
          { key: 'permittedTowWeight', label: '准牵引总质量' },
          { key: 'note', label: '外廓尺寸', color: 'blue', fontWeight: 'bold' },
          { key: 'axleCount', label: '车轴数' },
          { key: 'wheelCount', label: '车轮数' },
          { key: 'axleDistance', label: '轴距' },
          { key: 'department', label: '分支机构' },
        ],
      ],
      voucherData: {},
      voucherFooter: {
        date: '2020/9/12',
        outletId: '10001',
        operator: '龙傲天',
      },
      voucherVisible: false,
      transactorDialogVisible: false,
    };
  },
  components: {
    VInfoChangeForm,
    VoucherLayer,

    TransactorDialog,
  },
  methods: {
    async delimageList(pic) {},

    async showVoucher() {
      this.keycArr = [];
      this.valuecArr = [];
      this.message = '本次车辆信息变更的内容：</br></br>';
      //debugger;
      // console.log('123');
      const self = this;
      this.isButtonDisabled = true;
      setTimeout(() => {
        this.isButtonDisabled = false;
      }, 3000);
      const formData = await self.$refs.form.getFormData();

      // console.log(formData.etcUserId);
      if (this.formUC.vehicleNumber != formData.vehicleNumber) {
        this.$message({
          message: '车牌号码与数据库信息不同',
          type: 'error',
        });
        return;
      }
      if (formData.vehicleNumber != formData.vehicleNumber2) {
        this.$message({
          message: '印章页车牌号与条码页车牌号不同',
          type: 'error',
        });
        return;
      }
      let vmass = formData.viTotalMass;
      let mmass = formData.maintenaceMass;

      let pmass = formData.permittedTowWeight;
      if (!/^[0-9]+$/.test(vmass)) {
        vmass = '0';
      }
      if (!/^[0-9]+$/.test(mmass)) {
        mmass = '0';
      }
      if (!/^[0-9]+$/.test(pmass)) {
        pmass = '0';
      }

      // if (!Number.isInteger(formData.viTotalMass)) {
      //   formData.viTotalMass = 0;
      // }
      // if (!Number.isInteger(formData.maintenaceMass)) {
      //   formData.maintenaceMass = 0;
      // }

      if (pmass <= '0' && formData.vehicleCategory === '3') {
        this.$message({
          message: '牵引车准牵引总质量必须大于0',
          type: 'warning',
        });

        return;
      }

      if (
        formData.vehicleCategory === '2' ||
        formData.vehicleCategory === '3' ||
        formData.vehicleCategory === '4'
      ) {
        if (mmass <= 0 && vmass <= 0) {
          this.$message({
            message: '非客车整备质量、总质量必须有一个大于0',
            type: 'warning',
          });

          return;
        }
      }
      if (formData.viownerInfo) {
        if (!formData.viownerInfo.ownerName) {
          this.$message({
            message: '请完善车主信息',
            type: 'warning',
          });

          return;
        }

        // alert(formData.viownerInfo.ownerImageList.length);
        if (formData.viownerInfo.ownerImageList.length < 1) {
          this.$message({
            message: '请完善车主信息图片',
            type: 'warning',
          });

          return;
        }
      }

      /////////////////////////////////////////////////////////////////

      /////////////////////////////////////////////////////////////////
      let oldForm = JSON.stringify(formData);
      console.log('oldForm:' + oldForm);
      let newCarForm = JSON.stringify(self.newForm);
      console.log('newForm:' + newCarForm);
      //alert(newForm === oldForm);
      if (newCarForm === oldForm) {
        //console.log(voucherPic);
        let vp = voucherPic;
        this.complete(vp);
        return;
      }
      //self.newForm = { ...formData };
      //console.log('newForm:' + JSON.stringify(self.newForm));

      if (formData.vehicleCategory === '1') {
        for (let i = 0; i < self.voucherKeys[1].length; i++) {
          if (self.voucherKeys[1][i].key === 'approvedAccount') {
            self.voucherKeys[1][i].color = 'blue';
            self.voucherKeys[1][i].fontWeight = 'bold';
          }
          if (
            self.voucherKeys[1][i].key === 'axleCount' ||
            self.voucherKeys[1][i].key === 'viTotalMass'
          ) {
            self.voucherKeys[1][i].color = '#8B8C8F';
          }
        }
      } else {
        for (let i = 0; i < self.voucherKeys[1].length; i++) {
          if (
            self.voucherKeys[1][i].key === 'axleCount' ||
            self.voucherKeys[1][i].key === 'viTotalMass'
          ) {
            self.voucherKeys[1][i].color = 'blue';
            self.voucherKeys[1][i].fontWeight = 'bold';
          }
          if (self.voucherKeys[1][i].key === 'approvedAccount') {
            self.voucherKeys[1][i].color = '#8B8C8F';
          }
        }
      }

      //-----------
      let v = '';
      if (formData.vehicleType === '0') {
        if (formData.vehicleCategory === '1') {
          //console.log(formData.vehicleCategory);

          v = '0 - 普通客车';
        }
        if (formData.vehicleCategory === '2') {
          v = '0 - 普通货车';
        }
        if (formData.vehicleCategory === '3') {
          v = '0 - 普通货车';
        }
        if (formData.vehicleCategory === '4') {
          v = '0 - 普通货车';
        }
      } else {
        // alert(formData.vehicleType);
        v = await getDicDesByCode(
          dicKeys.vehicleUserClass,
          formData.vehicleType
        );
      }

      //------------
      self.voucherData = {
        businessType: '车辆注册',
        ...formData,

        vehicleColor: await getDicDesByCode(
          dicKeys.vehicleColor,
          formData.vehicleColor
        ),

        vehicleType: v,
        vehicleClass: await getDicDesByCode(
          dicKeys.vehicleClass,
          formData.vehicleClass
        ),

        note:
          formData.viLength +
          'x' +
          formData.viWidth +
          'x' +
          formData.viHeight +
          'mm',
        // note: formData.outlineDimension + 'mm',
        approvedAccount: formData.approvedAccount + '人',
        maintenaceMass: formData.maintenaceMass + '   KG',
        permittedTowWeight: formData.permittedTowWeight + '   KG',
        viTotalMass: formData.viTotalMass + '   KG',
        permittedWeight: formData.permittedWeight + '   KG',
        axleDistance: formData.axleDistance + '   mm',
      };

      for (var keyuc in this.formUC) {
        for (var key in formData) {
          if (keyuc === key) {
            if (this.formUC[keyuc] != formData[key]) {
              this.keycArr.push(key);
              this.valuecArr.push(formData[key]);
            }
          }
        }
      }
      // console.log('keycarr');
      // console.log(this.keycArr);
      // console.log('valuecarr');
      // console.log(this.valuecArr);
      if (this.keycArr.length != '0') {
        for (let i = 0; i < this.keycArr.length; i++) {
          this.message =
            this.message +
            this.keycArr[i] +
            ':&nbsp&nbsp' +
            this.valuecArr[i] +
            ' </br></br>';
        }
        self
          .$confirm(this.message, '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
            dangerouslyUseHTMLString: true,
          })
          .then(() => {
            this.voucherVisible = true;
          })
          .catch(() => {});
      } else {
        this.voucherVisible = true;
      }

      this.isButtonDisabled = false;
      self.$nextTick(() => {
        //执行调用
        self.$refs.mychild.sendpad();
      });
    },
    // 点击凭证取消按钮
    clearForm() {
      this.newForm = {};
    },
    async complete(vp) {
      setTimeout(() => {
        this.flagg = true;
      }, 8000);
      const self = this;
      voucherPic = vp;
      const formData = await self.$refs.form.getFormData();
      const registerUser = self.$store.getters.registerUser;
      if (
        registerUser.userProperty === '2' &&
        this.$store.getters.transactorImg.length === 0
      ) {
        self.transactorDialogVisible = true;
        // self.$nextTick(() => {
        //   //执行调用
        //   self.$refs.mychild.sendpad();
        // });
        // self.vehicleNumber = formData.vehicleNumber;
        // self.vehicleId = res.vehicleId;
      } else {
        if (this.flagg == true) {
          this.flagg = false;
          self.doRegister();
        }
      }
      //console.log(voucherPic);
      return voucherPic;
    },
    // 执行注册
    async doRegister() {
      const self = this;
      self.loading = true;
      self.loading1 = true;
      let timer = setTimeout(() => {
        self.loading = false;
      }, 60000);
      setTimeout(() => {
        self.loading1 = false;
      }, 1100);
      const formData = await self.$refs.form.getFormData();
      formData.etcUserId = self.$store.getters.registerUser.etcUserId;
      self.newForm = { ...formData };
      //alert(formData.etcUserId);

      if (!formData.imageList) {
        formData.imageList = [];
      }

      if (!/^[0-9]+$/.test(formData.viTotalMass)) {
        formData.viTotalMass = '0';
      }
      if (!/^[0-9]+$/.test(formData.maintenaceMass)) {
        formData.maintenaceMass = '0';
      }

      if (formData.vehicleCategory !== '1') {
        if (formData.viTotalMass <= 0 && formData.maintenaceMass > 0) {
          formData.viTotalMass = formData.maintenaceMass;
        } else if (formData.maintenaceMass <= 0 && formData.viTotalMass > 0) {
          formData.maintenaceMass = formData.viTotalMass;
        }
      }
      // 上传用户凭证图片
      const a = [
        ...formData.imageList,
        { imgFrontID: voucherPic.frontImgid, imgType: '4011', mediaType: '5' },
      ];
      //console.log(a);
      const pzpic = {
        imgFrontID: voucherPic.frontImgid,
        imgType: '4011',
        mediaType: '5',
        url: voucherPic.img,
      };
      // formData.imageList.push({
      //   imgFrontID: voucherPic.frontImgid,
      //   imgType: '4011',
      //   mediaType: '5',
      // });
      setTimeout(() => {
        this.registerFlag = true;
      }, 5000);
      if (this.registerFlag == true) {
        this.registerFlag = false;
        const res = await registerVehicle({
          ...formData,
          workOrderID: self.$route.query.woid,
          imageList: a,
        });
        // 保存注册信息
        if (res) {
          self.$store.dispatch('GetRegisterVehicle', {
            ...formData,
            vehicleId: res.vehicleId,
            vehicleClass: res.vehicleClass,
            carpzpic: pzpic,
          });
          let newPath;
          if (
            'newpublishperson' === self.$router.currentRoute.path.split('/')[1]
          ) {
            newPath = '/newpublishperson/banksign';
          } else {
            newPath = '/newpublish/banksign';
          }
          self.$router.push({
            // path: '/newpublish/banksign',
            path: newPath,
            query: {
              ...self.$route.query,
              vn: formData.vehicleNumber,
              vid: res.vehicleId,
            },
          });
        }
      }
      clearTimeout(timer);
      self.loading = false;
    },
    // 点击上传经办人证件提交按钮
    transactorDialogComplete(transactorImg) {
      const self = this;
      //保存经办人信息图片
      self.$store.dispatch('GetTransactorImg', transactorImg);
      self.doRegister();
    },
  },
  mounted() {
    this.formUC = {
      ...this.$store.getters.searchCarInfo,
      vehicleNumber2: this.$store.getters.searchCarInfo.vehicleNumber,
      ownerName: this.$store.getters.registerUser.userName,
      address: this.$store.getters.registerUser.address,
    };
  },
};
</script>
