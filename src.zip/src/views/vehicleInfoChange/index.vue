<!-- 变更车型 -->
<template>
  <div class="offline-vehicleinfochangeindex">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-vehicleinfochangeindex_title">变更车型</h4>
      </div>
    </div>
    <drawer
      :order="1"
      title="证件上传"
      note="需要上传的证件：经办人证件、其他证件资料"
      :btnState="process.step1"
      btnDesc="证件上传"
      @btnClick="$router.push('/vehicleinfochange/picupload')"
    >
    </drawer>
    <drawer
      :order="2"
      title="变更车型"
      note="变更车型"
      btnDesc="变更车型"
      :btnState="process.step2"
      class="custom_step"
    >
    </drawer>

    <!-- <drawer
      :order="3"
      title="重写设备"
      note="重写设备"
      btnDesc="重写设备"
      :btnState="process.step3"
      @btnClick="reWriteDevice"
    >
    </drawer> -->

    <custom-drawer
      :order="3"
      title="重写设备"
      note="重写设备"
      btnDesc="重写设备"
      :btnState="process.step3"
      @btnClick="reWriteDevice"
      :loading="loading"
    >
    </custom-drawer>

    <drawer
      :order="4"
      title="回执签名"
      note="回执签名"
      :btnState="process.step4"
      btnDesc="回执签名"
      @btnClick="showVoucher"
    >
    </drawer>

    <!-- <drawer
      :order="5"
      title="开具发票"
      note="开具发票"
      :btnState="process.step5"
      btnDesc="开具发票"
      @btnClick="invoice"
    >
    </drawer> -->

    <div class="c-center">
      <el-button
        type="primary"
        :disabled="rtnDisabled"
        icon="el-icon-refresh-left"
        class="offline-vehicleinfochangeindex_rtn-button"
        @click="$router.push('/menu')"
        >返回主页
      </el-button>
    </div>

    <!-- 回执凭证 -->
    <voucher-layer-confirm
      sign
      ref="mychild1"
      :info="infoData"
      :keys="voucherConfirmKeys"
      :visible.sync="voucherConfirmVisiable"
      @complete="subConfirm"
    ></voucher-layer-confirm>
  </div>
</template>
<script>
import VoucherLayerConfirm from './components/VoucherLayerConfirmCustom';
import Drawer from '@/components/Drawer';
import CustomDrawer from '@/components/CustomDrawer';
import { updateWorkOrder } from '@/api/common';
import showQrcode from '@/utils/qrcode';
import { globalBus } from '@/utils/globalBus';
import {
  strPadEnd,
  getFormatAmount,
  getFormatOBUFrontIdw,
} from '@/utils/utils';
import { queryReceiptChange } from '@/api/equipment';
import {
  dicKeys,
  getAllDics,
  getDicDesByCode,
  getDicCodeByDes,
  getDicCodeByAll,
  getDicDesByAll,
} from '@/methods/dics';

import {
  devReset,
  devResetConfirm,
  queryReceiptChangeVehInfo,
} from '@/api/vehicle';

import { getCpuId, getObuId, issueCard, issueOBU } from '@/utils/dynamic';
import { mapGetters } from 'vuex';

export default {
  data() {
    return {
      loading: false, // 重置设备
      // 流程状态 // 可用：usable，不可用：disable，已完成：complete
      process: {
        step1: 'usable',
        step2: 'disable',
        step3: 'disable',
        step4: 'disable',
        step5: 'disable',
      },

      // 工单号
      workOrderId: '',

      // 车种信息
      vehicleCategory: {
        prev: '1',
        next: '1',
      },

      // 回执凭证
      voucherConfirmVisiable: false,
      voucherConfirmKeys: [
        //业务类型
        [{ key: 'businessType', label: '业务类型' }],

        //用户信息
        [
          { key: 'userName', label: '用户名称' },
          { key: 'userCertType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],

        //etc卡
        [{ key: 'cardId', label: '卡号' }],

        // obu信息
        [
          { key: 'obuId', label: '标签ID' },
          { key: 'printId', label: '标签表面号' },
        ],

        // 车辆信息（原车， 新车， 间隔显示）
        [
          { key: 'vehicleNumber', label: '车牌号码' },
          { key: 'vehicleColor', label: '车牌颜色' },
          { key: 'vehicleNumber2', label: '车牌号码' },
          { key: 'vehicleColor2', label: '车牌颜色' },

          { key: 'vehicleSize', label: '原车身尺寸' },
          { key: 'vehicleType', label: '原车辆用户类型' },
          { key: 'vehicleSize2', label: '新车身尺寸' },
          { key: 'vehicleType2', label: '新车辆用户类型' },

          { key: 'vehicleClass', label: '原收费车型' },
          { key: 'approvedAccount', label: '原核定载人数' },
          { key: 'vehicleClass2', label: '新收费车型' },
          { key: 'approvedAccount2', label: '新核定载人数' },

          { key: 'viTotalMass', label: '原总质量' },
          { key: 'placeholder', label: '' }, // 站位，每行保证4个
          { key: 'viTotalMass2', label: '新总质量' },
          { key: 'placeholder2', label: '' },
        ],

        // 支付信息
        [
          { key: 'charge', label: '收费金额' },
          { key: 'payMode', label: '支付方式' },
        ],
      ],
      infoData: {},

      // 返回主页按钮 状态
      rtnDisabled: true,
    };
  },
  components: {
    CustomDrawer,
    Drawer,
    VoucherLayerConfirm,
  },
  computed: {
    ...mapGetters([
      'searchUserInfo',
      'searchCarInfo',
      'searchObuInfo',
      'searchCardInfo',
      'searchAccountInfo',
      'elementPermissions',
    ]),
  },
  methods: {
    //显示回执确认
    showVoucher() {
      // 查接口 14.23
      queryReceiptChangeVehInfo({
        etcUserId: this.searchUserInfo.etcUserId,
        workOrderId: this.workOrderId,
        vehicleNumber: this.searchCarInfo.vehicleNumber,
        vehicleColor: this.searchCarInfo.vehicleColor,
      }).then(res => {
        this.voucherConfirmVisiable = true;
        this.carInfoVoucher(res);
      });
    },

    // 凭证数据
    async carInfoVoucher(data) {
      const { userInfo, vehicleInfo, oldVehicleInfo, chargeInfo } = data;

      let result = {};

      // 业务类型
      result = {
        ...result,
        businessType: '变更车型',
      };

      // 用户信息
      result = {
        ...result,
        userName: userInfo.userName,
        userCertType: await getDicDesByCode(
          'userCertType',
          userInfo.userCertType
        ),
        userCode: userInfo.userCode,
      };

      // 卡号
      result = {
        ...result,
        cardId: this.searchCardInfo.cardID,
      };

      // 标签id, 表面号
      result = {
        ...result,
        obuId: this.searchObuInfo.obuID,
        printId: this.searchObuInfo.printID,
      };

      // 车辆信息 车牌号 车牌颜色  车身尺寸 车辆用户类型 收费车型 核定载人数 总质量
      result = {
        ...result,
        vehicleNumber: oldVehicleInfo.vehicleNumber,
        vehicleColor: await getDicDesByCode(
          'vehicleColor',
          oldVehicleInfo.vehicleColor
        ),
        vehicleNumber2: vehicleInfo.vehicleNumber,
        vehicleColor2: await getDicDesByCode(
          'vehicleColor',
          vehicleInfo.vehicleColor
        ),

        vehicleSize: `${oldVehicleInfo.viLength} X ${oldVehicleInfo.viWidth} X ${oldVehicleInfo.viHeight}mm`,
        vehicleSize2: `${vehicleInfo.viLength} X ${vehicleInfo.viWidth} X ${vehicleInfo.viHeight}mm`,

        vehicleType: await getDicDesByCode(
          'vehicleUserClass',
          oldVehicleInfo.vehicleType
        ),
        vehicleType2: await getDicDesByCode(
          'vehicleUserClass',
          vehicleInfo.vehicleType
        ),

        vehicleClass: await getDicDesByCode(
          'vehicleClass',
          oldVehicleInfo.vehicleClass
        ),
        vehicleClass2: await getDicDesByCode(
          'vehicleClass',
          vehicleInfo.vehicleClass
        ),

        approvedAccount: `${oldVehicleInfo.approvedAccount}人`,
        approvedAccount2: `${vehicleInfo.approvedAccount}人`,

        viTotalMass: oldVehicleInfo.viTotalMass + 'kg',
        viTotalMass2: vehicleInfo.viTotalMass + 'kg',
      };

      // 非客车(车种)显示 车轴数
      if (this.vehicleCategory.prev != 1 && this.vehicleCategory.next != 1) {
        // 寻找站位符号
        const dest = this.voucherConfirmKeys[4];
        let idx = dest.findIndex(item => item.key == 'placeholder');
        this.voucherConfirmKeys[4].splice(idx, 1, {
          key: 'axleCount',
          label: '原车轴数',
        });

        idx = dest.findIndex(item => item.key == 'placeholder2');
        this.voucherConfirmKeys[4].splice(idx, 1, {
          key: 'axleCount2',
          label: '新车轴数',
        });

        result.axleCount = oldVehicleInfo.axleCount;
        result.axleCount2 = vehicleInfo.axleCount;
      }

      // 货车 核定载质量
      // if (this.searchCarInfo.vehicleCategory == 2) {
      //   this.voucherConfirmKeys[4].push({
      //     key: 'permittedWeight',
      //     label: '原核定载质量',
      //   });
      //   this.voucherConfirmKeys[4].push({
      //     key: 'permittedWeight2',
      //     label: '新核定载质量',
      //   });
      //   result.permittedWeight = this.searchCarInfo.permittedWeight + 'kg';
      //   result.permittedWeight2 = this.nextCarInfo.vehicleMaxLadenWeight + 'kg';
      // }

      //牵引车 准牵引总质量
      if (this.vehicleCategory.prev == 3 && this.vehicleCategory.next == 3) {
        this.voucherConfirmKeys[4].push({
          key: 'permittedTowWeight',
          label: '原准牵引总质量',
        });
        this.voucherConfirmKeys[4].push({
          key: 'placeholder',
          label: '',
        });
        this.voucherConfirmKeys[4].push({
          key: 'permittedTowWeight2',
          label: '新准牵引总质量',
        });
        this.voucherConfirmKeys[4].push({
          key: 'placeholder2',
          label: '',
        });

        result.permittedTowWeight = oldVehicleInfo.permittedTowWeight + 'kg';
        result.permittedTowWeight2 = vehicleInfo.permittedTowWeight + 'kg';
      }

      // 收费信息
      result.charge = parseFloat(chargeInfo.price / 100).toFixed(2) + '元';
      result.payMode = await getDicDesByCode('payMode', chargeInfo.payMode);

      this.infoData = { ...result };
      this.$nextTick(() => {
        //执行调用手写板
        this.$refs.mychild1.sendpad();
      });
    },

    //带客户确认
    subConfirm(data) {
      // 调用12.9 上传回执图片，更新工单

      let imagelist = [];

      imagelist.push({
        imgFrontID: data.frontImgid,
        imgType: 9011,
        mediaType: 5,
      });

      updateWorkOrder({
        workOrderID: this.workOrderId,
        modifyInfo: { imagelist },
      }).then(res => {
        if (res) {
          //更新流程
          this.process.step4 = 'complete';
          // this.process.step5 = 'usable';
          // 暂时略过第5步
          this.rtnDisabled = false;
        }
      });
    },

    // 重写设备
    reWriteDevice() {
      this.loading = true;
      // 1. 读标签、卡片 2.接口7.7  3.框架api 2.7 2.6 接口7.8
      const cardInfo = getCpuId();
      const obuInfo = getObuId();
      console.log(cardInfo, obuInfo);
      if (cardInfo.code != 0) {
        this.$message.error(cardInfo.msg);
        this.loading = false;
        return;
      }
      if (obuInfo.code != 0) {
        this.$message.error(obuInfo.msg);
        this.loading = false;
        return;
      }

      if (cardInfo.cardid && obuInfo.obuid) {
        // 接口7.7
        devReset({
          etcUserId: this.searchUserInfo.etcUserId,
          workOrderId: this.workOrderId,
          vehicleId: this.searchCarInfo.vehicleId,
          obuSign: 2,
          cardId: cardInfo.cardid,
          cardVersion: cardInfo.issueversion,
          obuId: obuInfo.obuid,
          obuVersion: obuInfo.issueversion,
        })
          .then(res => {
            if (res) {
              //卡而发，Obu 二发
              issueCard(cardInfo, res);
              issueOBU(obuInfo, res);

              //接口7.8
              devResetConfirm({
                etcUserId: this.searchUserInfo.etcUserId,
                workOrderId: this.workOrderId,
                vehicleId: this.searchCarInfo.vehicleId,
              })
                .then(res => {
                  this.loading = false;
                  if (res) {
                    // 重置成功
                    // this.$message({
                    //   type: 'success',
                    //   message: '重置成功',
                    // });
                    this.$alert('重置成功', '提示', {
                      confirmButtonText: '确定',
                      type: 'success',
                    });
                    this.process.step3 = 'complete';
                    this.process.step4 = 'usable';
                  }
                })
                .catch(() => {
                  this.loading = false;
                });
            }
          })
          .catch(() => {
            this.loading = false;
          });
      }
    },

    //开具发票 暂时不做
    invoice() {
      this.$message({
        type: 'success',
        message: '暂不提供',
      });
      this.process.step5 = 'complete';
      this.rtnDisabled = false;
    },

    // 获取路由参数
    getRouteParams() {
      const { workOrderId, nextCarInfo, vehicleCategory } = this.$route.query;
      this.workOrderId = workOrderId; // 工单号
      this.vehicleCategory = vehicleCategory;
      if (nextCarInfo) {
        // 车型变更已经完成，流程走到step3
        this.process.step1 = 'complete';
        this.process.step2 = 'complete';
        this.process.step3 = 'usable';
      }
    },
  },

  mounted() {
    // 车型变更页面step2 变更操作成功后 跳转到该页面
    this.getRouteParams();
  },
};
</script>

<style scoped lang="scss">
.c-center {
  display: flex;
  align-items: center;
  justify-content: center;
  padding-top: 50px;
}
.offline-vehicleinfochangeindex_rtn-button {
  margin: 0;
}

.offline-vehicleinfochangeindex {
  ::v-deep .custom_step {
    .el-button {
      padding: 0;
    }
  }
}
</style>
