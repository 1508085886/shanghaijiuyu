<!-- 用户注册凭证 -->
<template>
  <div class="offline-registry-voucher">
    <div>
      <!-- <el-form ref="form" label-width="80px">
        <el-row :gutter="20">
          <el-col :md="8" :xl="6">
            <el-form-item label="证件类型：">
              <type-select
                type="userCertType"
                v-model="idtype"
                placeholder="证件类型"
              ></type-select>
            
            </el-form-item>
          </el-col>

          <el-col :md="8" :xl="6">
            <el-form-item label="证件号码：">
              <div class="grid-content bg-purple" prop="cid">
                <el-input
                  v-model="idnumber"
                  placeholder="请输入证件号码"
                ></el-input>
              </div>
            </el-form-item>
          </el-col>
          <el-col :md="8" :xl="6">
            <div class="grid-content bg-purple-light">
              <el-button
                type="primary"
                icon="el-icon-search"
                @click="userquery"
                style="margin-left: 10px"
                >搜索</el-button
              >
            </div>
          </el-col>
        </el-row>
      </el-form> -->
    </div>
    <h4 class="offline-registry-voucher_title">用户信息</h4>
    <o-table :info="tables" />
    <h4 class="offline-registry-voucher_title">信息变更</h4>
    <el-form label-width="80px" label-position="left">
      <el-row>
        <el-col :md="12" :xl="8">
          <el-form-item label="用户名称">
            <el-input
              class="textarea"
              v-model="cid"
              placeholder="请输入用户名称"
              clearable
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :md="12" :xl="8">
          <el-form-item label="手机号">
            <el-input
              class="textarea"
              v-model="phonenum"
              placeholder="请输入手机号"
              clearable
            ></el-input>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :md="9" :xl="5">
          <el-form-item label="验证码">
            <el-input
              class="textarea"
              v-model="ifcode"
              placeholder="请输入验证码"
              clearable
            ></el-input>
          </el-form-item>
        </el-col>
        <el-col :md="2" :xl="2">
          <el-button type="info" @click="sendifcode">发送验证码</el-button>
        </el-col>
      </el-row>
      <!-- <el-row style="padding-top:8px;">
        <el-col :span="3">
          <div class="grid-content bg-purple">
            <label class="el-form-item__label">用户名称：</label>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content bg-purple">
            <el-input v-model="cid" placeholder="请输入用户名称" clearable></el-input>
          </div>
        </el-col>
      </el-row>-->
      <!-- <el-row style="padding-top:8px;">
        <el-col :span="3">
          <div class="grid-content bg-purple">
            <label class="el-form-item__label">手机号：</label>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content bg-purple">
            <el-input v-model="phonenum" placeholder="请输入手机号" clearable></el-input>
          </div>
        </el-col>
      </el-row>
      <el-row style="padding-top:8px;">
        <el-col :span="3">
          <div class="grid-content bg-purple">
            <label class="el-form-item__label">验证码：</label>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="grid-content bg-purple">
            <el-input v-model="ifcode" placeholder="请输入验证码" clearable></el-input>
          </div>
        </el-col>
        <el-col :span="4">
          <div class="grid-content bg-purple-light">
            <el-button type="info" @click="sendifcode">发送验证码</el-button>
          </div>
        </el-col>
      </el-row>-->
    </el-form>

    <el-row style="padding-top: 18px">
      <!--
      <el-col :span="3">
        <div class="grid-content bg-purple-light">
          <el-button>重置</el-button>
        </div>
      </el-col>-->
      <el-col :span="3">
        <div class="grid-content bg-purple-light">
          <el-button type="primary" @click="change" :loading="loading"
            >修改</el-button
          >
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import OTable from '@/components/Table';
import { getifcode } from '@/api/pidchange';
import { query } from '@/api/pidchange';
import { usernamechange } from '@/api/pidchange';
import { Link } from 'element-ui';
export default {
  data() {
    return {
      loading: false,
      input: '',
      ifcode: '',
      idtype: '',
      idnumber: '',
      idCardType: '',
      cid: '',
      etcuserid: null,
      phonenum: null,
      uinfo: {},
      tables: [
        { label: '用户ID', value: '' },
        { label: '用户名称', value: '' },
        { label: '用户类型', value: '' },
        //{ label: '证件类别', value: '身份证' },
        { label: '证件号码', value: '' },
        { label: '联系地址', value: '' },
        //{ label: '邮政编码', value: '200023' },
        //{ label: '固定联系电话', value: '021-53003928' },
        { label: '联系方式', value: '' },
        //{ label: '账户联系人', value: '周峰' },
        //{ label: '电子邮箱', value: '4510099@qq.com' },
      ],
    };
  },
  components: {
    OTable,
  },
  // mounted() {
  //   this.judge();
  // },
  mounted() {
    if (this.$store.getters.registerUser.etcUserId) {
      this.userquery();
    }
  },
  methods: {
    // judge() {
    //   if (
    //     this.$store.getters.registerUser.etcUserId &&
    //     this.$store.getters.registerUser.userProperty !== '1'
    //   ) {
    //     this.$router.push({ path: '../../../cidchange/cchange' });
    //     return;
    //   }
    //   if (this.$store.getters.registerUser.etcUserId) {
    //     this.userquery();
    //   }
    // },
    async change() {
      const self = this;
      self.loading = true;
      let timer = setTimeout(() => {
        self.loading = false;
      }, 10000);
      if (this.phonenum.length < 11) {
        this.$alert('手机号码格式错误', '提示', {
          confirmButtonText: '确定',
          type: 'info',
        });
        // alert('手机号码格式错误');
        return;
      }

      const req = await usernamechange(
        this.tables[0].value,
        '1',
        '',
        this.cid.trim(),
        this.phonenum,
        this.ifcode,
        '1'
      );
      if (req) {
        this.$alert('修改成功', '提示', {
          confirmButtonText: '确定',
          type: 'info',
        });
        // alert('修改成功');
      }
      clearTimeout(timer);
      self.loading = false;
      this.ifcode = '';
      this.cid = '';
      this.userquery();
    },
    async userquery() {
      // if (this.idtype == null || this.idtype.length == 0) {
      //   alert('请填写证件类型');
      //   return;
      // }

      // if (this.idnumber == null || this.idnumber.length == 0) {
      //   alert('请填写证件号');
      //   return;
      // }

      // const a = await query(this.idtype, this.idnumber);
      const a = await query(this.$store.getters.registerUser.etcUserId);
      // console.log(a);
      // console.log(this.$store.getters.registerUser);
      this.tables[0].value = a.etcUserId;
      this.tables[1].value = a.userName;
      //this.tables[1].value = a.userProperty;

      switch (a.userProperty) {
        case '1':
          this.tables[2].value = '个人用户';
          break;
        case '2':
          this.tables[2].value = '单位用户';
          break;
      }
      //his.tables[1].value = a.userProperty;
      this.tables[3].value = a.userCode;
      this.tables[4].value = a.address;
      this.tables[5].value = a.userPhone2;

      //this.tables[1].value = 'hzw';
      this.phonenum = a.userPhone2;
      //alert(1);
    },

    async sendifcode() {
      //this.$store.dispatch('GetChaennelId', 'phone_front_system');

      if (this.phonenum.length < 11) {
        this.$alert('手机号码格式错误', '提示', {
          confirmButtonText: '确定',
          type: 'info',
        });
        // alert('手机号码格式错误');
        return;
      }

      const a = await getifcode(
        this.tables[0].value,
        '1',
        '',
        '',
        this.phonenum,
        '',
        '',
        ''
      );
      if (a) {
        this.$alert('发送成功', '提示', {
          confirmButtonText: '确定',
          type: 'info',
        });
        // alert('发送成功');
      }
    },
  },
};
</script>
<style lang='scss' scoped>
@import '@/assets/styles/variables.scss';
.offline-registry-voucher_title {
  color: $offlineGrayBold;
  font-size: 18px;
}
</style>
<style scoped>
.textarea >>> .el-input__inner {
  font-size: 15px !important;
  /* color: #80b127 !important; */
  font-family: '黑体' !important;
}
</style>