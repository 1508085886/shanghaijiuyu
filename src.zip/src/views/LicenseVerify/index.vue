<!--  -->
<template>
  <el-container class="offline_layout o-font-family is-vertical">
    <layout-header  :link-show="false" :avatar-show="false" :logout-show="false" />
    <el-container style="height: 0">
      <el-main class="o-height-full offline_layout-main o-flex o-flex-column">
        <div class="offline_layout-main-scroll">
          <div
            class="offline-licenseverify_wrapper offline-licenseverify_block"
          >
            <h3 class="ml35">车牌验证</h3>
            <el-form
              ref="form"
              :model="form"
              :rules="rules"
              class="offline-licenseverify_form"
              >
              <!-- label-position="right"
              label-width="auto" -->
            <div class="mb20 offline-licenseverify_form-title">用户信息</div>
              <el-row class="mt10 mb20" :gutter="0">
                <el-col :md="12" :lg="8">
                  <el-form-item label="用户名称" prop="userName">
                    <el-input
                      :disabled="true"
                      v-model="form.userName"
                    ></el-input>
                  </el-form-item>
                </el-col>
                <el-col :md="12" :lg="8">
                  <el-form-item label="证件类型" prop="userCertType">
                    <type-select
                      :disabled="true"
                      type="userCertType"
                      v-model="form.userCertType"
                      placeholder="请选择"
                      class="o-width-full"
                    />
                  </el-form-item>
                </el-col>
                <el-col :md="12" :lg="8">
                  <el-form-item label="证件号码" prop="userCode">
                    <el-input :disabled="true" v-model="form.userCode"></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <!-- <el-row class="mt10 mb20" :gutter="0">
                <el-col :md="12" :lg="8">
                  <el-form-item label="分支机构" prop="department">
                    <el-input
                      readonly
                      v-model="form.department"
                      class="offline-licenseverify_form-department-input"
                    >
                    <el-button
                    slot="append"
                    @click="organizationVisible = true"
                    >选择</el-button
                  >
                  </el-input>
                  </el-form-item>
                </el-col>
              </el-row> -->
              <div class="mb20 offline-licenseverify_form-title">车辆信息</div>
              <el-row class="mb20">
                <el-col :md="12" :lg="8">
                  <el-form-item label="车牌号码" prop="vehicleNumber">
                    <regex-input v-model="form.vehicleNumber" type="vehicleNumber" :maxlength="12"></regex-input>
                  </el-form-item>
                </el-col>
                <el-col :md="12" :lg="8">
                  <el-form-item label="车牌颜色" prop="vehicleColor">
                    <type-select
                      type="vehicleColor"
                      v-model="form.vehicleColor"
                      class="o-width-full"
                    ></type-select>
                  </el-form-item>
                </el-col>
              </el-row>
              <div class="mb20 offline-licenseverify_form-title">签约渠道</div>
              <!-- v-else-if="dialog === 'bankSign'" -->
              <!-- :p-vehicle-id="pVehicleId" -->
              <bank-sign
                :title-show="false"
                ref="banksign"
                :is-component="true"
                :xl="6"
                :lg="6"
              />
              
            </el-form>
            
            <!-- v-if="$store.getters.registerUser.userProperty === '2'" -->
            <!-- <complex-table
              title="分支机构"
              :visible.sync="organizationVisible"
              :columns="tables"
              requestListUrl="/branchQuery"
              :requestListParam="{
                etcUserId:
                  this.$store.getters.registerUser.etcUserId || this.$route.query.euid,
                pageNo: 1,
                pageSize: 100,
              }"
              :responseListFormat="responseListFormat"
              @getSelected="selectOrganization"
              insertListUrl="/departmentAdd"
              :append-to-body="true"
              :defaultValue="[]"
            /> -->
            <div class="offline-licenseverify_block-button">
              <el-button class="" size="small" type="primary" @click="toVerify">车牌验证</el-button>
            </div>
          </div>
        </div>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import LayoutHeader from '../../layout/components/LayoutHeader';
import { dicKeys, getDicDesByCode,getDicCodeByDes } from '@/methods/dics';
import ComplexTable from '@/components/ComplexTable';
import BankSign from '../NewPublish/BankSign';
import {queryVehicleQualification} from '@/api/vehicle';
import {recoveryRegisterUser} from '@/methods/recoveryLocalData';
import RegexInput from '@/components/RegexInput';
// import { getCpuId } from '@/utils/dynamic'
export default {
  data() {
    return {
      form:{
        etcUserId:'',
        userName:'',
        userCertType:'',
        userCode:'',
      },
      rules:{
        vehicleNumber: [
           { required: true, message: '请输入车牌号码', trigger: 'blur' },
        ],
        vehicleColor: [
           { required: true, message: '请选择车牌颜色', trigger: 'change' },
        ],
      },
      organizationVisible: false,
      // pVehicleId: '',
    };
  },
  components: {
    LayoutHeader,
    ComplexTable,
    BankSign,
    RegexInput,
  },
  computed: {
  },
  methods: {
    async toVerify() {
      let self = this;
      let promise  = self.$refs.form.validate();
      promise.then(function() {
        if(self.$refs.banksign.channelselect.subChannelId === ''){
          self.$message.info('请选择签约渠道');
          return;
        }
        self.verify();
      }).catch(function(error) {
        console.log('发生错误！', error);
      });
        
    },
    async verify(){
      // alert('payChannel:'+this.$refs.banksign.channelselect.subChannelId);
      // alert('this.form.etcUserId:'+this.form.etcUserId);
      // let payChannel = '1111';
      const res = await queryVehicleQualification({
        etcUserId:this.form.etcUserId,
        vehicleNumber:this.form.vehicleNumber,
        vehicleColor:this.form.vehicleColor,
        payChannel:this.$refs.banksign.channelselect.subChannelId,
        // payChannel:payChannel,
      });
      if(res){
        this.$alert('当前车牌可办理新办发行业务', '提示', {
            confirmButtonText: '确定',
            type: 'success',
          });
      }
    },
  },
  mounted() {
    // this.form.etcUserId = 'U202010150000010671';
    // this.form.userName = '上海临港经济发展(集团)有限公司';
    // this.form.userCertType = '203';
    // this.form.userCode = '913100007547623351';
    // this.$store.dispatch('GetJumpData', {
    //       oprtId: 'wjq',
    //       token: 'bbb',
    //     });

    this.form.etcUserId = this.$route.query.etcUserId;
    this.form.userName = this.$route.query.userName;
    this.form.userCertType = this.$route.query.userCertType;
    this.form.userCode = this.$route.query.userCode;
    this.$store.dispatch('GetJumpData', {
          oprtId: this.$route.query.oprtId,
          token: this.$route.query.token,
        });
    
    // const res0 = getCpuId();
    // alert('readCard:'+res0.code);
    //test
    // this.form.etcUserId = 'U202010130000010321';
    // this.form.userName = '公司六七';
    // this.form.userCertType = '201';
    // this.form.userCode = '310762800036735';
  },
};
</script>
