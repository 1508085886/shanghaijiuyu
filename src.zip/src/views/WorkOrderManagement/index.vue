<!--  -->
<template>
  <el-container class="offline_layout o-font-family is-vertical">
    <layout-header
      :link-show="false"
      :avatar-show="false"
      :logout-show="false"
    />
    <el-container style="height: 0">
      <el-main class="o-height-full offline_layout-main o-flex o-flex-column">
        <div class="offline_layout-main-scroll">
          <div
            class="offline-workordermanagement_wrapper offline-workordermanagement_searchblock"
          >
            <h3 class="ml35">工单管理</h3>
            <el-form
              ref="form"
              :model="form"
              :rules="rules"
              :inline="true"
              label-position="right"
              label-width="auto"
              class="offline-workordermanagement_searchblock-form"
            >
              <el-row class="mt10" :gutter="0">
                <!--  <el-col :md="8" :lg="6">
                  <el-form-item label="工单号：" prop="userName">
                    <el-input
                      v-model="form.userName"
                      class="offline-workordermanagement_searchblock-form-input"
                    ></el-input>
                  </el-form-item>
                </el-col>  -->
                <!--  <el-col :md="8" :lg="6">
                  <el-form-item label="网点：" prop="localNetFlag">
                    <type-select
                      type="vehicleColor"
                      v-model="form.localNetFlag"
                      placeholder="请选择"
                      class="offline-workordermanagement_searchblock-form-input"
                    />
                  </el-form-item>
                </el-col> -->
                <!--  <el-col :md="8" :lg="6">
                  <el-form-item label="操作员：" prop="userName">
                    <type-select
                      type="vehicleColor"
                      v-model="form.userName"
                      placeholder="请选择"
                      class="offline-workordermanagement_searchblock-form-input"
                    />
                  </el-form-item>
                </el-col> -->
                <el-col :md="8" :lg="8">
                  <el-form-item label="业务类型：" prop="bizCode">
                    <type-select
                      type="bizCode"
                      v-model="form.bizCode"
                      placeholder="请选择"
                      class="offline-workordermanagement_searchblock-form-input"
                    />
                  </el-form-item>
                </el-col>
                <el-col :md="8" :lg="8">
                  <el-form-item label="创建日期：" prop="orderDate">
                    <el-date-picker
                      v-model="orderDate"
                      type="daterange"
                      range-separator="至"
                      start-placeholder="开始日期"
                      end-placeholder="结束日期"
                      @change="datePickerChange"
                      :clearable="false"
                      class="offline-workordermanagement_searchblock-form-input"
                    >
                    </el-date-picker>
                  </el-form-item>
                </el-col>
                <el-col :md="8" :lg="8">
                  <el-form-item label="车牌：" prop="vehicleNumber">
                    <regex-input
                      type="vehicleNumber"
                      placeholder="请输入车牌号"
                      :maxlength="12"
                      v-model="form.vehicleNumber"
                      class="input-with-select offline-workordermanagement_searchblock-form-input"
                    >
                      <type-select
                        type="vehicleColor"
                        v-model="form.vehicleColor"
                        slot="prependSelect"
                        placeholder="车牌颜色"
                        class="offline-workordermanagement_searchblock-form-input-prependselect"
                      >
                      </type-select>
                    </regex-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row class="mt10" :gutter="0">
                <el-col :md="8" :lg="8">
                  <el-form-item label="卡号：" prop="cardId">
                    <regex-input
                      type="cardId"
                      placeholder="请输入ETC卡号"
                      :maxlength="16"
                      v-model="form.cardId"
                      class="offline-workordermanagement_searchblock-form-input"
                    >
                    </regex-input>
                  </el-form-item>
                </el-col>
                <el-col :md="8" :lg="8">
                  <el-form-item label="标签号：" prop="obuId">
                    <regex-input
                      type="obuId"
                      placeholder="请输入标签号"
                      :maxlength="16"
                      v-model="form.obuId"
                      class="offline-workordermanagement_searchblock-form-input"
                    ></regex-input>
                  </el-form-item>
                </el-col>
                <el-col :md="8" :lg="8">
                  <el-form-item label="修改日期：" prop="modifyOrderDate">
                    <el-date-picker
                      v-model="modifyOrderDate"
                      type="daterange"
                      range-separator="至"
                      start-placeholder="开始日期"
                      end-placeholder="结束日期"
                      @change="datePickerChange"
                      :clearable="false"
                      class="offline-workordermanagement_searchblock-form-input"
                    >
                    </el-date-picker>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row class="mt10" :gutter="0">
                <el-col :md="8" :lg="8">
                  <el-form-item label="证件类型：" prop="userCodeType">
                    <type-select
                      type="userCertType"
                      v-model="form.userCodeType"
                      placeholder="请选择"
                      class="offline-workordermanagement_searchblock-form-input"
                    />
                  </el-form-item>
                </el-col>
                <el-col :md="8" :lg="8">
                  <el-form-item label="证件号码：" prop="userCode">
                    <regex-input
                      type="userCode"
                      placeholder="请输入证件号码"
                      :maxlength="32"
                      v-model="form.userCode"
                      class="offline-workordermanagement_searchblock-form-input"
                    ></regex-input>
                  </el-form-item>
                </el-col>
                <el-col :md="8" :lg="8">
                  <el-form-item label="网点：" prop="netId">
                    <el-select
                      filterable
                      v-model="form.netId"
                      placeholder="请选择"
                      class="offline-select offline-workordermanagement_searchblock-form-input"
                      :disabled="netIdDisabled"
                    >
                      <el-option
                        v-for="item in netIdOptions"
                        :key="'netId' + item.value"
                        :label="
                          !item.value
                            ? item.label
                            : item.value + '-' + item.label
                        "
                        :value="item.value"
                      >
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <!-- <el-col :md="8" :lg="8">
                  <el-form-item label="网点：" prop="netId">
                    <type-select
                      type="netId"
                      :all-option="true"
                      v-model="form.netId"
                      placeholder="请选择"
                      class="offline-workordermanagement_searchblock-form-input"
                    />
                  </el-form-item>
                </el-col> -->
              </el-row>
              <el-row class="mt10" :gutter="0">
                <el-col :md="8" :lg="8">
                  <el-form-item label="操作员ID：" prop="oprtId">
                    <el-select
                      filterable
                      v-model="form.oprtId"
                      placeholder="请选择"
                      class="offline-select offline-workordermanagement_searchblock-form-input"
                      :disabled="oprtIdDisabled"
                    >
                      <el-option
                        v-for="item in oprtIdOptions"
                        :key="'oprtId' + item.value"
                        :label="
                          !item.value
                            ? item.label
                            : item.value + '-' + item.label
                        "
                        :value="item.value"
                      >
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <!-- <el-col :md="8" :lg="8">
                  <el-form-item label="操作员ID：" prop="oprtId">
                    <type-select
                      ref="oprtIdSelect"
                      :netid="netid"
                      type="oprtId"
                      :all-option="true"
                      v-model="form.oprtId"
                      placeholder="请选择"
                      class="offline-workordermanagement_searchblock-form-input"
                    />
                  </el-form-item>
                </el-col> -->
                <el-col :md="8" :lg="8">
                  <el-button
                    :loading="tableLoading"
                    class="offline-workordermanagement_searchblock-search"
                    size="small"
                    type="primary"
                    icon="el-icon-search"
                    @click="onSearch"
                    round
                    >搜索</el-button
                  >
                  <el-button
                    :loading="tableLoading"
                    class="offline-workordermanagement_searchblock-refresh"
                    size="small"
                    icon="el-icon-refresh-left"
                    @click="refresh"
                    round
                    >重置</el-button
                  >
                </el-col>
              </el-row>
              <!-- <div class="fr mt10 mr70">
                <el-button class="" size="small" type="primary" icon="el-icon-search" @click="onSearch" round>搜索</el-button>
                <el-button class="offline-workordermanagement_searchblock-refresh" size="small" icon="el-icon-refresh-left" @click="refresh" round>重置</el-button>
              </div> -->
            </el-form>
          </div>
          <div
            class="mt10 offline-workordermanagement_wrapper offline-workordermanagement_tableblock"
          >
            <div class="mb5 offline-workordermanagement_tableblock-getdevice">
              <el-button
                :loading="tableLoading"
                size="medium"
                type="primary"
                :disabled="getDeviceBtnDisabled"
                @click="showGetDeviceVoucher"
                >设备领取</el-button
              >
              <el-button
                :loading="tableLoading"
                size="medium"
                type="primary"
                :disabled="suppleOrderBtnDisabled"
                @click="suppleOrder"
                >补充资料</el-button
              >
              <el-button
                :loading="tableLoading"
                size="medium"
                type="primary"
                :disabled="closeBtnDisabled"
                @click="closeOrder"
                >关闭工单</el-button
              >
              <el-button
                :loading="tableLoading"
                size="medium"
                type="primary"
                :disabled="closeBtnDisabled"
                @click="closeOrder"
                v-if="show"
                >补开发票</el-button
              >
            </div>
            <div class="offline-workordermanagement_tableblock-table">
              <el-table
                v-loading="tableLoading"
                :data="tableData"
                style="width: 100%"
                header-cell-class-name="offline-workordermanagement_tableblock-header"
                cell-class-name="offline-workordermanagement_tableblock-cell"
                @selection-change="handleSelectionChange"
              >
                <el-table-column type="selection" width="42"> </el-table-column>
                <el-table-column type="expand">
                  <template slot-scope="props">
                    <!-- 补卡 工单明细标签内容 -->
                    <div
                      v-if="props.row.bizCode === '08'"
                      class="offline-workordermanagement_tableblock-detail"
                    >
                      <el-form
                        label-position="left"
                        inline
                        class="demo-table-expand"
                      >
                        <el-row class="mt10" :gutter="0">
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户编号：">
                              <span>{{ props.row.newUserId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户名称：">
                              <span>{{ props.row.userName }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="旧卡号：">
                              <span>{{ props.row.oldCardId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="新卡号：">
                              <span>{{ props.row.cardId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="签约银行：">
                              <span>{{ props.row.paychannelName }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="账户编号：">
                              <span>{{ props.row.newUserAcctId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改时间：">
                              <span>{{ props.row.modifyTime }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改操作员：">
                              <span>{{ props.row.modifyOprtID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改网点代码：">
                              <span>{{ props.row.modifyNetID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="业务报错：">
                              <span>{{ props.row.errorMsg }}</span>
                            </el-form-item>
                          </el-col>
                          <!-- <el-col :md="12" :lg="8">
                            <el-form-item label="支付方式:">
                              <span>{{
                                props.row.payMode | payModeFilter
                              }}</span>
                            </el-form-item>
                          </el-col> -->
                        </el-row>
                      </el-form>
                    </div>
                    <!-- 换签工单明细标签内容 -->
                    <div
                      v-if="props.row.bizCode === '11'"
                      class="offline-workordermanagement_tableblock-detail"
                    >
                      <el-form
                        label-position="left"
                        inline
                        class="demo-table-expand"
                      >
                        <el-row class="mt10" :gutter="0">
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户编号：">
                              <span>{{ props.row.newUserId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户名称：">
                              <span>{{ props.row.userName }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="旧标签ID：">
                              <span>{{ props.row.oldObuID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="旧标签表面号：">
                              <span>{{ props.row.oldObuysId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="新标签ID：">
                              <span>{{ props.row.obuId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="新标签表面号：">
                              <span>{{ props.row.obuysId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="签约银行：">
                              <span>{{ props.row.paychannelName }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="账户编号：">
                              <span>{{ props.row.newUserAcctId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改时间：">
                              <span>{{ props.row.modifyTime }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改操作员：">
                              <span>{{ props.row.modifyOprtID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改网点代码：">
                              <span>{{ props.row.modifyNetID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="业务报错：">
                              <span>{{ props.row.errorMsg }}</span>
                            </el-form-item>
                          </el-col>
                          <!-- <el-col :md="12" :lg="8">
                            <el-form-item label="支付方式:">
                              <span>{{
                                props.row.payMode | payModeFilter
                              }}</span>
                            </el-form-item>
                          </el-col> -->
                        </el-row>
                      </el-form>
                    </div>
                    <!-- 卡片挂失 工单明细标签内容 -->
                    <div
                      v-if="props.row.bizCode === '06'"
                      class="offline-workordermanagement_tableblock-detail"
                    >
                      <el-form
                        label-position="left"
                        inline
                        class="demo-table-expand"
                      >
                        <el-row class="mt10" :gutter="0">
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户编号：">
                              <span>{{ props.row.newUserId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户名称：">
                              <span>{{ props.row.userName }}</span>
                            </el-form-item>
                          </el-col>
                          <!-- <el-col :md="12" :lg="8">
                            <el-form-item label="旧卡号：">
                              <span>{{ props.row.oldCardId }}</span>
                            </el-form-item>
                          </el-col> -->
                          <el-col :md="12" :lg="8">
                            <el-form-item label="卡号：">
                              <span>{{ props.row.cardId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="签约银行：">
                              <span>{{ props.row.paychannelName }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="账户编号：">
                              <span>{{ props.row.newUserAcctId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改时间：">
                              <span>{{ props.row.modifyTime }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改操作员：">
                              <span>{{ props.row.modifyOprtID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改网点代码：">
                              <span>{{ props.row.modifyNetID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="业务报错：">
                              <span>{{ props.row.errorMsg }}</span>
                            </el-form-item>
                          </el-col>
                        </el-row>
                      </el-form>
                    </div>
                    <!-- 卡片解挂 工单明细标签内容 -->
                    <div
                      v-if="props.row.bizCode === '07'"
                      class="offline-workordermanagement_tableblock-detail"
                    >
                      <el-form
                        label-position="left"
                        inline
                        class="demo-table-expand"
                      >
                        <el-row class="mt10" :gutter="0">
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户编号：">
                              <span>{{ props.row.newUserId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户名称：">
                              <span>{{ props.row.userName }}</span>
                            </el-form-item>
                          </el-col>
                          <!-- <el-col :md="12" :lg="8">
                            <el-form-item label="旧卡号：">
                              <span>{{ props.row.oldCardId }}</span>
                            </el-form-item>
                          </el-col> -->
                          <el-col :md="12" :lg="8">
                            <el-form-item label="卡号：">
                              <span>{{ props.row.cardId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="签约银行：">
                              <span>{{ props.row.paychannelName }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="账户编号：">
                              <span>{{ props.row.newUserAcctId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改时间：">
                              <span>{{ props.row.modifyTime }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改操作员：">
                              <span>{{ props.row.modifyOprtID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改网点代码：">
                              <span>{{ props.row.modifyNetID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="业务报错：">
                              <span>{{ props.row.errorMsg }}</span>
                            </el-form-item>
                          </el-col>
                        </el-row>
                      </el-form>
                    </div>
                    <!-- 标签挂失 明细标签内容 -->
                    <div
                      v-if="props.row.bizCode === '25'"
                      class="offline-workordermanagement_tableblock-detail"
                    >
                      <el-form
                        label-position="left"
                        inline
                        class="demo-table-expand"
                      >
                        <el-row class="mt10" :gutter="0">
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户编号：">
                              <span>{{ props.row.newUserId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户名称：">
                              <span>{{ props.row.userName }}</span>
                            </el-form-item>
                          </el-col>
                          <!-- <el-col :md="12" :lg="8">
                            <el-form-item label="旧标签ID：">
                              <span>{{ props.row.oldObuID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="旧标签表面号：">
                              <span>{{ props.row.oldObuysId }}</span>
                            </el-form-item>
                          </el-col> -->
                          <el-col :md="12" :lg="8">
                            <el-form-item label="标签ID：">
                              <span>{{ props.row.obuId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="标签表面号：">
                              <span>{{ props.row.obuysId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="签约银行：">
                              <span>{{ props.row.paychannelName }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="账户编号：">
                              <span>{{ props.row.newUserAcctId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改时间：">
                              <span>{{ props.row.modifyTime }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改操作员：">
                              <span>{{ props.row.modifyOprtID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改网点代码：">
                              <span>{{ props.row.modifyNetID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="业务报错：">
                              <span>{{ props.row.errorMsg }}</span>
                            </el-form-item>
                          </el-col>
                        </el-row>
                      </el-form>
                    </div>
                    <!-- 标签解挂 明细标签内容 -->
                    <div
                      v-if="props.row.bizCode === '26'"
                      class="offline-workordermanagement_tableblock-detail"
                    >
                      <el-form
                        label-position="left"
                        inline
                        class="demo-table-expand"
                      >
                        <el-row class="mt10" :gutter="0">
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户编号：">
                              <span>{{ props.row.newUserId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户名称：">
                              <span>{{ props.row.userName }}</span>
                            </el-form-item>
                          </el-col>
                          <!-- <el-col :md="12" :lg="8">
                            <el-form-item label="旧标签ID：">
                              <span>{{ props.row.oldObuID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="旧标签表面号：">
                              <span>{{ props.row.oldObuysId }}</span>
                            </el-form-item>
                          </el-col> -->
                          <el-col :md="12" :lg="8">
                            <el-form-item label="标签ID：">
                              <span>{{ props.row.obuId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="标签表面号：">
                              <span>{{ props.row.obuysId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="签约银行：">
                              <span>{{ props.row.paychannelName }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="账户编号：">
                              <span>{{ props.row.newUserAcctId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改时间：">
                              <span>{{ props.row.modifyTime }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改操作员：">
                              <span>{{ props.row.modifyOprtID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改网点代码：">
                              <span>{{ props.row.modifyNetID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="业务报错：">
                              <span>{{ props.row.errorMsg }}</span>
                            </el-form-item>
                          </el-col>
                        </el-row>
                      </el-form>
                    </div>
                    <!-- 换卡 工单明细标签内容 -->
                    <div
                      v-if="props.row.bizCode === '09'"
                      class="offline-workordermanagement_tableblock-detail"
                    >
                      <el-form
                        label-position="left"
                        inline
                        class="demo-table-expand"
                      >
                        <el-row class="mt10" :gutter="0">
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户编号：">
                              <span>{{ props.row.newUserId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户名称：">
                              <span>{{ props.row.userName }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="旧卡号：">
                              <span>{{ props.row.oldCardId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="新卡号：">
                              <span>{{ props.row.cardId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="签约银行：">
                              <span>{{ props.row.paychannelName }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="账户编号：">
                              <span>{{ props.row.newUserAcctId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改时间：">
                              <span>{{ props.row.modifyTime }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改操作员：">
                              <span>{{ props.row.modifyOprtID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改网点代码：">
                              <span>{{ props.row.modifyNetID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="业务报错：">
                              <span>{{ props.row.errorMsg }}</span>
                            </el-form-item>
                          </el-col>
                          <!-- <el-col :md="12" :lg="8">
                            <el-form-item label="支付方式:">
                              <span>{{
                                props.row.payMode | payModeFilter
                              }}</span>
                            </el-form-item>
                          </el-col> -->
                        </el-row>
                      </el-form>
                    </div>
                    <!-- 换签工单明细标签内容 -->
                    <div
                      v-if="props.row.bizCode === '12'"
                      class="offline-workordermanagement_tableblock-detail"
                    >
                      <el-form
                        label-position="left"
                        inline
                        class="demo-table-expand"
                      >
                        <el-row class="mt10" :gutter="0">
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户编号：">
                              <span>{{ props.row.newUserId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户名称：">
                              <span>{{ props.row.userName }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="旧标签ID：">
                              <span>{{ props.row.oldObuID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="旧标签表面号：">
                              <span>{{ props.row.oldObuysId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="新标签ID：">
                              <span>{{ props.row.obuId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="新标签表面号：">
                              <span>{{ props.row.obuysId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="签约银行：">
                              <span>{{ props.row.paychannelName }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="账户编号：">
                              <span>{{ props.row.newUserAcctId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改时间：">
                              <span>{{ props.row.modifyTime }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改操作员：">
                              <span>{{ props.row.modifyOprtID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改网点代码：">
                              <span>{{ props.row.modifyNetID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="业务报错：">
                              <span>{{ props.row.errorMsg }}</span>
                            </el-form-item>
                          </el-col>
                          <!-- <el-col :md="12" :lg="8">
                            <el-form-item label="支付方式:">
                              <span>{{
                                props.row.payMode | payModeFilter
                              }}</span>
                            </el-form-item>
                          </el-col> -->
                        </el-row>
                      </el-form>
                    </div>
                    <!-- 新办发行 工单明细标签内容 -->
                    <div
                      v-if="props.row.bizCode === '05'"
                      class="offline-workordermanagement_tableblock-detail"
                    >
                      <el-form
                        label-position="left"
                        inline
                        class="demo-table-expand"
                      >
                        <el-row class="mt10" :gutter="0">
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户编号：">
                              <span>{{ props.row.newUserId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户名称：">
                              <span>{{ props.row.userName }}</span>
                            </el-form-item>
                          </el-col>
                          <!-- <el-col :md="12" :lg="8">
                            <el-form-item label="车牌号码：">
                              <span>{{ props.row.newVehicleNumber }}</span>
                            </el-form-item>
                          </el-col> -->
                          <!-- </el-row> -->
                          <!-- <el-row class="mt10" :gutter="0"> -->
                          <!-- <el-col :md="12" :lg="8">
                            <el-form-item label="车牌颜色：">
                              <span>{{ props.row.newVehicleColor }}</span>
                            </el-form-item>
                          </el-col> -->
                          <el-col :md="12" :lg="8">
                            <el-form-item label="签约银行：">
                              <span>{{ props.row.paychannelName }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="分支机构：">
                              <span>{{ props.row.newDepartmentName }}</span>
                            </el-form-item>
                          </el-col>
                          <!-- </el-row> -->
                          <!-- <el-row class="mt10" :gutter="0"> -->
                          <el-col :md="12" :lg="8">
                            <el-form-item label="标签号：">
                              <span>{{ props.row.obuId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="标签表面号：">
                              <span>{{ props.row.obuysId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="卡号：">
                              <span>{{ props.row.cardId }}</span>
                            </el-form-item>
                          </el-col>
                          <!-- </el-row> -->
                          <!-- <el-row class="mt10" :gutter="0"> -->
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改时间：">
                              <span>{{ props.row.modifyTime }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改操作员：">
                              <span>{{ props.row.modifyOprtID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改网点代码：">
                              <span>{{ props.row.modifyNetID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="支付方式:">
                              <span>{{
                                props.row.payMode | payModeFilter
                              }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="业务报错：">
                              <span>{{ props.row.errorMsg }}</span>
                            </el-form-item>
                          </el-col>
                        </el-row>
                      </el-form>
                    </div>
                    <!-- 设备注销 工单明细标签内容 -->
                    <div
                      v-if="props.row.bizCode === '20'"
                      class="offline-workordermanagement_tableblock-detail"
                    >
                      <el-form
                        label-position="left"
                        inline
                        class="demo-table-expand"
                      >
                        <el-row class="mt10" :gutter="0">
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户编号：">
                              <span>{{ props.row.newUserId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户名称：">
                              <span>{{ props.row.userName }}</span>
                            </el-form-item>
                          </el-col>
                          <!-- <el-col :md="12" :lg="8">
                            <el-form-item label="车牌号码：">
                              <span>{{ props.row.newVehicleNumber }}</span>
                            </el-form-item>
                          </el-col> -->
                          <!-- </el-row> -->
                          <!-- <el-row class="mt10" :gutter="0"> -->
                          <!-- <el-col :md="12" :lg="8">
                            <el-form-item label="车牌颜色：">
                              <span>{{ props.row.newVehicleColor }}</span>
                            </el-form-item>
                          </el-col> -->
                          <el-col :md="12" :lg="8">
                            <el-form-item label="签约银行：">
                              <span>{{ props.row.paychannelName }}</span>
                            </el-form-item>
                          </el-col>
                          <!-- <el-col :md="12" :lg="8">
                          <el-form-item label="分支机构：">
                            <span>{{ props.row.newDepartmentName }}</span>
                          </el-form-item>
                        </el-col> -->
                          <el-col :md="12" :lg="8">
                            <el-form-item label="标签号：">
                              <span>{{ props.row.obuId }}</span>
                            </el-form-item>
                          </el-col>
                          <!-- </el-row> -->
                          <!-- <el-row class="mt10" :gutter="0"> -->
                          <el-col :md="12" :lg="8">
                            <el-form-item label="标签表面号：">
                              <span>{{ props.row.obuysId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="卡号：">
                              <span>{{ props.row.cardId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="账户编号：">
                              <span>{{ props.row.newUserAcctId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改时间：">
                              <span>{{ props.row.modifyTime }}</span>
                            </el-form-item>
                          </el-col>
                          <!-- </el-row> -->
                          <!-- <el-row class="mt10" :gutter="0"> -->
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改操作员：">
                              <span>{{ props.row.modifyOprtID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改网点代码：">
                              <span>{{ props.row.modifyNetID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="业务报错：">
                              <span>{{ props.row.errorMsg }}</span>
                            </el-form-item>
                          </el-col>
                        </el-row>
                      </el-form>
                    </div>
                    <!-- 账户注销 工单明细标签内容 -->
                    <div
                      v-if="props.row.bizCode === '21'"
                      class="offline-workordermanagement_tableblock-detail"
                    >
                      <el-form
                        label-position="left"
                        inline
                        class="demo-table-expand"
                      >
                        <el-row class="mt10" :gutter="0">
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户编号：">
                              <span>{{ props.row.newUserId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户名称：">
                              <span>{{ props.row.userName }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="账户编号：">
                              <span>{{ props.row.newUserAcctId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="签约银行：">
                              <span>{{ props.row.paychannelName }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改时间：">
                              <span>{{ props.row.modifyTime }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改操作员：">
                              <span>{{ props.row.modifyOprtID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改网点代码：">
                              <span>{{ props.row.modifyNetID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="业务报错：">
                              <span>{{ props.row.errorMsg }}</span>
                            </el-form-item>
                          </el-col>
                        </el-row>
                      </el-form>
                    </div>
                    <!-- 车型变更 工单明细标签内容 -->
                    <div
                      v-if="props.row.bizCode === '13'"
                      class="offline-workordermanagement_tableblock-detail"
                    >
                      <el-form
                        label-position="left"
                        inline
                        class="demo-table-expand"
                      >
                        <el-row class="mt10" :gutter="0">
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户编号：">
                              <span>{{ props.row.newUserId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="用户名称：">
                              <span>{{ props.row.userName }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="标签ID：">
                              <span>{{ props.row.obuId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="标签表面号：">
                              <span>{{ props.row.obuysId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="卡号：">
                              <span>{{ props.row.cardId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="签约银行：">
                              <span>{{ props.row.paychannelName }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="账户编号：">
                              <span>{{ props.row.newUserAcctId }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改时间：">
                              <span>{{ props.row.modifyTime }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改操作员：">
                              <span>{{ props.row.modifyOprtID }}</span>
                            </el-form-item>
                          </el-col>
                          <el-col :md="12" :lg="8">
                            <el-form-item label="修改网点代码：">
                              <span>{{ props.row.modifyNetID }}</span>
                            </el-form-item>
                          </el-col>
                        </el-row>
                      </el-form>
                    </div>
                  </template>
                </el-table-column>
                <el-table-column label="工单号" prop="workOrderId">
                </el-table-column>
                <el-table-column label="创建时间" prop="registerDate">
                </el-table-column>
                <el-table-column label="创建操作员" prop="oprtId" width="75">
                </el-table-column>
                <el-table-column label="创建网点代码" prop="netId">
                </el-table-column>
                <el-table-column
                  label="车牌号码"
                  prop="newVehicleNumber"
                ></el-table-column>
                <el-table-column
                  label="车牌颜色"
                  prop="newVehicleColor"
                ></el-table-column>
                <el-table-column label="业务类型" prop="bizCodeDesc">
                </el-table-column>
                <el-table-column label="设备销售标志" prop="saleFlag">
                </el-table-column>
                <el-table-column label="费用" prop="fmprice"> </el-table-column>
                <el-table-column label="收讫标志" prop="payFlag">
                </el-table-column>
                <el-table-column label="完成状态" prop="status">
                </el-table-column>
                <el-table-column
                  label="设备领取状态"
                  prop="deviceRecieveStatus"
                >
                </el-table-column>
                <!-- <el-table-column label="修改时间" prop="modifyTime">
                </el-table-column>
                <el-table-column
                  label="修改操作员"
                  prop="modifyOprtID"
                  width="75"
                >
                </el-table-column>
                <el-table-column label="修改网点代码" prop="modifyNetID">
                </el-table-column> -->
                <el-table-column
                  label="原收讫标志"
                  prop="oldPayFlag"
                  v-if="show"
                >
                </el-table-column>
                <el-table-column label="ETC用户ID" prop="etcUserId" v-if="show">
                </el-table-column>
                <el-table-column
                  label="车牌颜色"
                  prop="oldNewVehicleColor"
                  v-if="show"
                >
                </el-table-column>
                <el-table-column label="未格式化费用" prop="price" v-if="show">
                </el-table-column>
                <el-table-column
                  label="电子图片"
                  :header-align="tableHeaderAlign"
                >
                  <template slot-scope="scope">
                    <el-button
                      size="mini"
                      type="primary"
                      @click="view(scope.$index, scope.row)"
                      >查看</el-button
                    >
                  </template>
                </el-table-column>
                <el-table-column
                  label="继续办理"
                  :header-align="tableHeaderAlign"
                >
                  <template slot-scope="scope">
                    <el-button
                      size="mini"
                      type="primary"
                      :disabled="scope.row.continueWorkBtnDisabled"
                      @click="continueHandleBus(scope.$index, scope.row)"
                      >继续办理</el-button
                    >
                  </template>
                </el-table-column>
                <!-- 支付方式修改 -->
                <el-table-column
                  label="修改支付方式"
                  :header-align="tableHeaderAlign"
                  align="center"
                >
                  <template slot-scope="scope">
                    <el-button
                      size="mini"
                      type="primary"
                      @click="changePayment(scope.$index, scope.row)"
                      >修改</el-button
                    >
                  </template>
                </el-table-column>
                <el-table-column label="退单" :header-align="tableHeaderAlign">
                  <template slot-scope="scope">
                    <el-button
                      size="mini"
                      type="primary"
                      :disabled="scope.row.chargebackBtnDisabled"
                      @click="chargeback(scope.$index, scope.row)"
                      >退单</el-button
                    >
                  </template>
                </el-table-column>
                <!-- <el-table-column label="操作" :header-align="tableHeaderAlign">
                  <template slot-scope="scope">
                    <el-button
                      size="mini"
                      type="primary"
                      :disabled="scope.row.closeBtnDisabled"
                      @click="closeOrder2(scope.$index, scope.row)"
                      >关闭工单</el-button
                    > -->
                <!-- <el-button
                      class="mt5 offline-workordermanagement_tableblock-table-morelinebtn"
                      size="mini"
                      type="primary"
                      @click="suppleOrder(scope.$index, scope.row)"
                      >补充资料</el-button
                    >  -->
                <!-- </template>
                </el-table-column> -->
              </el-table>
            </div>
            <div
              class="clearfix offline-workordermanagement_tableblock-pagination"
            >
              <div
                class="fl offline-workordermanagement_tableblock-pagination-desc"
                v-if="total"
              >
                第{{ startRecords }}到{{ currentSize }}条，
              </div>
              <el-pagination
                background
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="currentPage"
                :page-size="pageSize"
                layout="total,->,prev, pager, next,slot"
                :total="total"
              >
              </el-pagination>
            </div>
          </div>
        </div>
      </el-main>
      <el-dialog
        :title="dialogTitle"
        class="offline-dialog"
        custom-class="offline-workordermanagement_dialog"
        :visible.sync="dialogVisible"
        :append-to-body="true"
      >
        <!-- @open="clearFormSettle" -->
        <div class="o-flex offline-workordermanagement_dialog-content-wrap">
          <el-table
            ref="dialogTable"
            :data="dialogTableData"
            height="400"
            style="width: 100%"
            border
            v-show="tableShow"
          >
            <!-- 3333 -->
            <!--  <el-table-column v-for="(item, index) in eVoucherTypeDescArr" :key="index" prop="item.imageInfo" :label="item">
            <template slot-scope="scope">
              <el-image
                :preview-src-list="[scope.row.imageInfo]"
                :src="scope.row.imageInfo"
                width="100"
                height="100"
                class="offline-workordermanagement_dialog-content-pic"
              />
            </template>
          </el-table-column> -->
            <!-- 2222 -->
            <!-- <el-table-column v-for="(item, index) in dialogTableData" :key="index" prop="item.imageInfo" :label="item.eVoucherTypeDesc">
              <template slot-scope="scope">
                <el-image
                  :preview-src-list="[item.imageInfo]"
                  :src="item.imageInfo"
                  width="100"
                  height="100"
                  class="offline-workordermanagement_dialog-content-pic"
                />
              </template>
            </el-table-column> -->
            <!-- 11111 -->
            <el-table-column
              prop="imageInfo1"
              label="用户证件"
              :resizable="false"
            >
              <template slot-scope="scope">
                <!-- :preview-src-list="[item]" -->
                <!-- <cus-image
                  :hasAuth="hasAuth"
                  v-for="(item, index) in scope.row.imageInfo1"
                  :src="item"
                  :preview-src-list="scope.row.imageInfo1"
                  class="offline-workordermanagement_dialog-content-pic"
                >
                </cus-image> -->
                <el-image
                  :preview-src-list="scope.row.imageInfo1"
                  v-for="(item, index) in scope.row.imageInfo1"
                  :key="index"
                  :src="item"
                  class="offline-workordermanagement_dialog-content-pic"
                />
              </template>
            </el-table-column>
            <el-table-column
              prop="imageInfo2"
              label="车主证件"
              :resizable="false"
            >
              <template slot-scope="scope">
                <el-image
                  :preview-src-list="scope.row.imageInfo2"
                  v-for="(item, index) in scope.row.imageInfo2"
                  :key="index"
                  :src="item"
                  class="offline-workordermanagement_dialog-content-pic"
                />
              </template>
            </el-table-column>
            <el-table-column
              prop="imageInfo3"
              label="车辆证件"
              :resizable="false"
            >
              <template slot-scope="scope">
                <el-image
                  :preview-src-list="scope.row.imageInfo3"
                  v-for="(item, index) in scope.row.imageInfo3"
                  :key="index"
                  :src="item"
                  class="offline-workordermanagement_dialog-content-pic"
                />
                <!-- <cus-image
                  :hasAuth="hasAuth"
                  v-for="(item, index) in scope.row.imageInfo3"
                  :src="item"
                  :preview-src-list="scope.row.imageInfo3"
                  class="offline-workordermanagement_dialog-content-pic"
                >
                </cus-image> -->
                <!-- <el-button
                  v-if="downloadImg3.length > 0"
                  size="mini"
                  round
                  @click="downloadImgInfo3"
                  >图片下载</el-button
                > -->
              </template>
            </el-table-column>
            <!-- label="经办人及其他业务资料" -->
            <el-table-column
              prop="imageInfo4"
              label="经办人证件"
              :resizable="false"
            >
              <template slot-scope="scope">
                <el-image
                  :preview-src-list="scope.row.imageInfo4"
                  v-for="(item, index) in scope.row.imageInfo4"
                  :key="index"
                  :src="item"
                  class="offline-workordermanagement_dialog-content-pic"
                />
              </template>
            </el-table-column>
            <el-table-column
              prop="imageInfo5"
              label="业务凭证"
              :resizable="false"
            >
              <template slot-scope="scope">
                <el-image
                  :preview-src-list="scope.row.imageInfo5"
                  v-for="(item, index) in scope.row.imageInfo5"
                  :key="index"
                  :src="item"
                  class="offline-workordermanagement_dialog-content-pic"
                />
              </template>
            </el-table-column>
            <el-table-column
              prop="imageInfo6"
              label="业务核验资料"
              :resizable="false"
            >
              <template slot-scope="scope">
                <el-image
                  :preview-src-list="scope.row.imageInfo6"
                  v-for="(item, index) in scope.row.imageInfo6"
                  :key="index"
                  :src="item"
                  class="offline-workordermanagement_dialog-content-pic"
                />
              </template>
            </el-table-column>
            <el-table-column
              prop="imageInfo7"
              label="银行卡"
              :resizable="false"
            >
              <template slot-scope="scope">
                <el-image
                  :preview-src-list="scope.row.imageInfo7"
                  v-for="(item, index) in scope.row.imageInfo7"
                  :key="index"
                  :src="item"
                  class="offline-workordermanagement_dialog-content-pic"
                />
              </template>
            </el-table-column>
            <el-table-column
              prop="imageInfo8"
              label="代理人证件"
              :resizable="false"
            >
              <template slot-scope="scope">
                <el-image
                  :preview-src-list="scope.row.imageInfo8"
                  v-for="(item, index) in scope.row.imageInfo8"
                  :key="index"
                  :src="item"
                  class="offline-workordermanagement_dialog-content-pic"
                />
              </template>
            </el-table-column>
            <el-table-column
              prop="imageInfo9"
              label="补充资料"
              :resizable="false"
            >
              <template slot-scope="scope">
                <el-image
                  :preview-src-list="scope.row.imageInfo9"
                  v-for="(item, index) in scope.row.imageInfo9"
                  :key="index"
                  :src="item"
                  class="offline-workordermanagement_dialog-content-pic"
                />
              </template>
            </el-table-column>
            <!-- <el-table-column
              prop="imageInfo9"
              label="电子发票"
              :resizable="false"
            >
              <template slot-scope="scope">
                <el-image
                  :preview-src-list="scope.row.imageInfo9"
                  v-for="(item, index) in scope.row.imageInfo9"
                  :key="index"
                  :src="item"
                  class="offline-workordermanagement_dialog-content-pic"
                />
              </template>
            </el-table-column> -->
            <el-table-column
              prop="imageInfo10"
              label="其他证件资料"
              :resizable="false"
            >
              <template slot-scope="scope">
                <el-image
                  :preview-src-list="scope.row.imageInfo10"
                  v-for="(item, index) in scope.row.imageInfo10"
                  :key="index"
                  :src="item"
                  class="offline-workordermanagement_dialog-content-pic"
                />
              </template>
            </el-table-column>
            <el-table-column
              prop="imageInfo11"
              label="回执凭证"
              :resizable="false"
            >
              <template slot-scope="scope">
                <el-image
                  :preview-src-list="scope.row.imageInfo11"
                  v-for="(item, index) in scope.row.imageInfo11"
                  :key="index"
                  :src="item"
                  class="offline-workordermanagement_dialog-content-pic"
                />
              </template>
            </el-table-column>
          </el-table>
        </div>
        <span slot="footer" class="dialog-footer">
          <!-- <el-button @click="dialogVisible = false">取 消</el-button> -->
          <el-button type="primary" @click="closeDialog">确 定</el-button>
        </span>
      </el-dialog>
      <!-- 修改支付方式的dialog -->
      <el-dialog
        :visible.sync="changePaymentShow"
        title="修改支付方式"
        :append-to-body="true"
        width="30%"
        :close-on-click-modal="false"
        :before-close="closePaymentDialog"
      >
        <div class="pay" style="height: 300px">
          <label for=""> 支付方式: </label>
          <el-select v-model="payment" placeholder="请选择">
            <el-option
              v-for="item in paymentOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </div>

        <span slot="footer" class="dialog-footer">
          <el-button @click="closePaymentDialog">取 消</el-button>
          <el-button type="primary" @click="confirmChangePayment"
            >确 定</el-button
          >
        </span>
      </el-dialog>
    </el-container>
    <voucher-layer
      ref="mychild2"
      :column="3"
      :info="voucherData"
      :footer="voucherFooter"
      :keys="voucherKeys"
      :circleColumn="4"
      :circleInfo="voucherCircleData"
      :circleKeys="voucherCircleKeys"
      :visible.sync="voucherVisiable"
      :cancel-show="true"
      :complete-show="false"
      @complete="receiptComplete"
    ></voucher-layer>
    <supple-info-dialog
      :visible.sync="suppleInfoDialogVisible"
      :append-to-body="true"
      :loading.sync="suppleInfoLoading"
      @complete="saveSuppleInfo"
    >
    </supple-info-dialog>
    <!-- <el-button type="text" @click="jumpTo">jumpTo</el-button> -->
  </el-container>
</template>

<script>
import CusImage from '@/components/CusImage';
import LayoutHeader from '../../layout/components/LayoutHeader';
import { orderQuery, orderImg, cancelWorkOrder } from '@/api/order';
import { invoice, addBranch, refund } from '@/api/invoice';

import {
  systemParameterQuery,
  updateWorkOrder,
  systemTime,
} from '@/api/common';
import { formatDate } from '@/utils/format';
import {
  openWindow,
  getQueryStringByName,
  getFormatAmount,
} from '@/utils/utils';
import { globalBus } from '@/utils/globalBus';
import { dicKeys, getDicDesByCode, getDicCodeByDes } from '@/methods/dics';
import RegexInput from '@/components/RegexInput';
import VoucherLayer from '@/components/VoucherLayer';
import SuppleInfoDialog from '@/components/SuppleInfoDialog';
import {
  getNetInfoList,
  getOprtInfoList,
  queryInstallCode,
} from '@/api/common';
import { changePayment as changePaymentApi } from '@/api/payment';
import emit from '@/utils/emit';
export default {
  data() {
    return {
      elementPermissions: [], //元素权限
      hasAuth: true, //图片下载权限
      installCode: '',
      loginName: '',
      netid: '',
      allOption: {
        value: '',
        label: '全部',
      },
      downloadImg3: [],
      tableLoading: false,
      suppleInfoLoading: false,
      netIdOptions: [], // 网点选项
      netIdDisabled: false, // 网点选项禁用
      oprtIdOptions: [], // 操作员选项
      oprtIdDisabled: false, // 操作员选项禁用
      suppleInfoWorkOrderId: '', // 补充资料对应的工单号
      suppleInfoDialogVisible: false,
      getDeviceBtnDisabled: true,
      suppleOrderBtnDisabled: true,
      closeBtnDisabled: true,
      continueWorkBtnDisabled: true, //继续办理按钮显示
      chargebackBtnDisabled: true, //退单按钮显示
      imgFrontIDReceipt: '', // 设备领取凭证前置图片id
      multipleSelection: [], // 表格选项
      workOrderSelection: [], // 表格选项工单Id
      voucherVisiable: false, // 显示设备领取凭证
      voucherData: {},
      voucherFooter: {},
      voucherKeys: [
        [{ key: 'businessType', label: '业务类型' }],
        [
          { key: 'userName', label: '用户名称' },
          { key: 'userCodeType', label: '证件类型' },
          { key: 'userCode', label: '证件号码' },
        ],
      ],
      voucherKeysInstallCode: [{ key: 'installCode', label: '安装码' }],
      voucherCircleData: [],
      voucherCircleKeys: [
        { key: 'newVehicleNumber', label: '车牌号码' },
        { key: 'newVehicleColor', label: '车牌颜色' },
      ],
      timer: 0,
      imgTitle: 'data:image/jpg;base64,',
      // imgWidth:'1',
      // imgHeight:'1',
      currentPage: 1,
      total: 0, //总条数
      page: 1, //初始显示第几页
      pageSize: 20, //每页显示多少数据
      // rowNumber: 0, //本次获取记录数
      currentSize: 0, // 当前页条数
      tableShow: false,
      orderDate: [],
      modifyOrderDate: [],
      form: {
        bizCode: '',
        vehicleColor: '',
        vehicleNumber: '',
        cardId: '',
        obuId: '',
        netId: '',
        oprtId: '',
        userCode: '',
        userCodeType: '',
      },
      rules: {
        // bizCode: [
        //   { required: false, message: '请选择所属省', trigger: 'blur' },
        // ],
        // city: [
        //   { required: false, message: '请输入所属市', trigger: 'blur' },
        // ],
      },
      tableHeaderAlign: 'center',
      tableData: [
        // {
        //   bizCode: "05",
        //   buyId: "04072384826252857396619891040077",
        //   cardId: "0131001375568820",
        //   deviceRecieveStatus: "1",
        //   hasCard: null,
        //   hasOBU: null,
        //   modifyDate: "20201217",
        //   modifyNetID: "100001",
        //   modifyOprtID: "ly       ",
        //   modifyTime: "2020-12-17 12:20:33",
        //   netId: "100001",
        //   newDepartmentName: "",
        //   newUserAcctId: "15409211",
        //   newUserId: "15404327",
        //   newVehicleColor: "0",
        //   newVehicleId: "20231245",
        //   newVehicleNumber: "沪AES903",
        //   note: null,
        //   obuId: "869D4E00F0DED927",
        //   obuysId: "8888022006100082",
        //   oldBuyId: null,
        //   oldCardId: null,
        //   oldDepartmentName: null,
        //   oldObuID: null,
        //   oldObuysId: null,
        //   oldPaychannelName: null,
        //   oldSubpaychannelName: "建行线下对公",
        //   oldUserAcctId: "null",
        //   oldUserId: "null",
        //   oldUserName: null,
        //   oldVehicleColor: null,
        //   oldVehicleId: "null",
        //   oldVehicleNumber: null,
        //   oprtId: "ly       ",
        //   payFlag: "1",
        //   paychannelName: "建行线下对公",
        //   price: "0",
        //   registerDate: "2020-12-16 16:42:40",
        //   registerTime: "20201216",
        //   saleFlag: "3",
        //   status: "2",
        //   subpaychannelName: "建行线下对公",
        //   userCode: "91110108563658011H",
        //   userCodeType: "203",
        //   userName: "北京收到的盛智振通科技有限公司",
        //   workOrderId: "8569",
        // },
      ],
      dialogTitle: '电子图片',
      dialogVisible: false,
      dialogTableData: [],
      eVoucherTypeDescArr: [],
      // 工单的支付修改
      changePaymentShow: false, // 修改支付方式对话框显示控制
      payment: '', // 初始支付方式
      paymentOptions: [
        { label: '现金', value: '1' },
        { label: '银联卡', value: '2' },
        { label: '赠送', value: '6' },
        { label: '补款', value: '7' },
        { label: '银行代收', value: '9' },
        { label: '银行代扣', value: '0' },
        { label: '冲正', value: 'B' },
        { label: '卡账互转', value: 'C' },
        { label: '支付宝', value: 'D' },
      ],
      rowData: {}, // 缓存某一行的的工单数据
      show: false,
    };
  },
  filters: {
    payModeFilter(mode) {
      const paymentOptions = [
        { label: '现金', value: '1' },
        { label: '银联卡', value: '2' },
        { label: '赠送', value: '6' },
        { label: '补款', value: '7' },
        { label: '银行代收', value: '9' },
        { label: '银行代扣', value: '0' },
        { label: '冲正', value: 'B' },
        { label: '卡账互转', value: 'C' },
        { label: '支付宝', value: 'D' },
      ];
      return paymentOptions.filter(item => item.value == mode).label || '';
    },
  },
  components: {
    CusImage,
    LayoutHeader,
    RegexInput,
    VoucherLayer,
    SuppleInfoDialog,
  },
  computed: {
    //起始记录
    startRecords() {
      return (this.page - 1) * this.pageSize + 1;
    },
    // //每页显示多少数据
    // rowNumber(){
    //   return this.pageSize;
    // }
  },
  watch: {
    'form.netId'(val) {
      console.log('watch netId');
      this.setOprIdSelect(val);
    },
  },
  created() {
    this.refreshTable1();
  },
  methods: {
    jumpTo() {
      let rtn = etcdev.predisplay(
        '0',
        'vueEmit(\'{"type":"abc","param":{"a":1,"b":2}}\')'
      );
    },
    downloadImgInfo3() {
      for (let i = 0; i < this.downloadImg3.length; i++) {
        let a = document.createElement('a'); // 生成一个a元素
        let event = new MouseEvent('click'); // 创建一个单击事件
        a.download = '车辆证件' + i; // 设置图片名称
        a.href = this.downloadImg3[i]; // 将生成的URL设置为a.href属性,url可以是base64
        a.dispatchEvent(event); // 触发a的单击事件
      }
    },
    async setNetIdSelect() {
      this.netIdOptions = [];
      let res = await getNetInfoList({ loginName: this.loginName });
      if (res) {
        this.netIdOptions = [];
        this.netIdOptions.push(this.allOption); // 选项：全部
        res.netInfoList.forEach(element => {
          let value = element.netId;
          let label = element.netName;
          this.netIdOptions.push({ value, label });
        });
        if (res.netInfoList.length === 0) {
          //无网点，选中全部
          this.form.netId = '';
          this.netIdDisabled = false;
        } else if (res.netInfoList.length === 1) {
          //仅本网点，选择器只读
          this.form.netId = res.netInfoList[0].netId;
          this.netIdDisabled = true;
        } else {
          //有多个操作员，选中全部
          this.form.netId = '';
          this.netIdDisabled = false;
        }
      }
    },
    async setOprIdSelect(netId = this.form.netId) {
      console.log('netId ' + netId);
      this.oprtIdOptions = [];
      let res = await getOprtInfoList({ netId, loginName: this.loginName });
      if (res) {
        this.oprtIdOptions = [];
        this.oprtIdOptions.push(this.allOption); // 选项：全部
        res.oprtInfoList.forEach(element => {
          let value = element.oprtId;
          let label = element.oprtName;
          this.oprtIdOptions.push({ value, label });
        });
        if (res.oprtInfoList.length === 0) {
          //无操作员，选中全部
          this.form.oprtId = '';
          this.oprtIdDisabled = false;
        } else if (res.oprtInfoList.length === 1) {
          //仅本操作员，选择器只读
          this.form.oprtId = res.oprtInfoList[0].oprtId;
          this.oprtIdDisabled = true;
        } else {
          //有多个操作员，选中全部
          this.form.oprtId = '';
          this.oprtIdDisabled = false;
        }
      }
      if (this.form.netId === '') {
        // 网点选中“全部”，操作员初始化选中全部且只读
        this.form.oprtId = '';
        this.oprtIdDisabled = true;
      }
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
      if (this.multipleSelection.length !== 0) {
        this.getDeviceBtnDisabled = false;
        this.suppleOrderBtnDisabled = false;
        this.closeBtnDisabled = false;
      } else {
        this.getDeviceBtnDisabled = true;
        this.suppleOrderBtnDisabled = true;
        this.closeBtnDisabled = true;
      }
    },
    async showGetDeviceVoucher() {
      // 判断是否符合设备领取条件
      let isSameUser = true; // 是属于同一用户
      let isNoDevice = false; // 是无设备销售
      let noDeviceWorkOrders = []; // 无设备销售工单
      let isNoDeviceDesc = await getDicDesByCode(dicKeys.saleFlag, '0'); //'0-无设备销售'
      let isCompleted = true; // 是已完成
      let unCompletedWorkOrders = []; // 未完成工单
      let completedDesc = await getDicDesByCode(dicKeys.status, '2'); //'2-业务已完成'
      let isNotGetted = true; // 是未领取
      let gettedWorkOrders = []; // 已领取工单

      // let notGettedDesc = await getDicDesByCode(
      //   dicKeys.deviceRecieveStatus,
      //   '1'
      // ); //'1-未领取'
      let firstUserId = '';

      this.multipleSelection.forEach((element, index, array) => {
        // debugger;
        // 通过用户编码一致判断是否属于同一用户
        if (index === 0) {
          firstUserId = element.newUserId;
        }
        if (element.newUserId !== firstUserId) {
          isSameUser = false;
        }
        //判断是无设备销售
        if (element.saleFlag === isNoDeviceDesc) {
          isNoDevice = true;
          noDeviceWorkOrders.push(element.workOrderId);
        }
        //判断是已完成
        if (element.status !== completedDesc) {
          isCompleted = false;
          unCompletedWorkOrders.push(element.workOrderId);
        }
        //判断是未领取
        if (element.deviceRecieveStatus != '') {
          isNotGetted = false;
          gettedWorkOrders.push(element.workOrderId);
        }
      });
      if (!isSameUser || isNoDevice || !isCompleted || !isNotGetted) {
        // 不是同一用户/无设备销售/未完成/已领取 不符合设备领取条件
        let alertDesc = '不符合设备领取条件，原因：';
        if (!isSameUser) {
          alertDesc = alertDesc + '不是同一用户！';
        }
        if (isNoDevice) {
          alertDesc =
            alertDesc + '工单号：' + noDeviceWorkOrders + '无设备销售！';
        }
        if (!isCompleted) {
          alertDesc =
            alertDesc + '工单号：' + unCompletedWorkOrders + '未完成！';
        }
        if (!isNotGetted) {
          alertDesc =
            alertDesc + '工单号：' + gettedWorkOrders + '不是未领取状态！';
        }
        // console.log('gettedWorkOrders', gettedWorkOrders);
        this.$alert(alertDesc, '提示', {
          confirmButtonText: '确定',
          type: 'warning',
          customClass: 'workordermanagement-message-box-alert',
        });
        return;
      }
      console.log('this.multipleSelection');
      console.log(this.multipleSelection);
      this.workOrderSelection = this.multipleSelection.map(
        ({ workOrderId, deviceRecieveStatus }) => ({
          workOrderId,
          deviceRecieveStatus,
        })
      );
      console.log('this.workOrderSelection');
      console.log(this.workOrderSelection);
      console.log('usercodetype');
      ///////////////////////////////////////////////
      console.log(this.multipleSelection[0].userCodeType);
      if (this.multipleSelection[0].userCodeType.slice(0, 1) == '2') {
        const resInstallCode = await queryInstallCode({
          etcUserId: this.multipleSelection[0].etcUserId,
        });
        console.log(resInstallCode);
        if (resInstallCode) {
          this.installCode = resInstallCode.installCode;
        }

        this.voucherKeys.push(
          this.voucherKeysInstallCode.map(base => {
            return {
              key: base.key,
              label: base.label,
              span: base.span,
              color: base.color,
              fontWeight: base.fontWeight,
            };
          })
        );
      }
      ///////////////////////////////////////////////
      let partSelection = this.multipleSelection.map(
        ({
          userCode,
          userCodeType,
          userName,
          newVehicleNumber,
          newVehicleColor,
        }) => ({
          userCode,
          userCodeType,
          userName,
          newVehicleNumber,
          newVehicleColor,
        })
      );
      this.voucherData = {
        businessType: '设备领取',
        userName: partSelection[0].userName,
        userCode: partSelection[0].userCode,
        userCodeType: partSelection[0].userCodeType,
        installCode: this.installCode,
      };
      this.voucherCircleData = partSelection;
      console.log('this.voucherCircleData');
      console.log(this.voucherCircleData);
      let completeTime = await systemTime();
      if (completeTime) {
        this.voucherFooter = {
          date: completeTime.systemTime,
          outletId: this.netid,
          operator: this.loginName,
        };
      }
      this.voucherVisiable = true;
      this.$nextTick(() => {
        //执行调用手写板
        this.$refs.mychild2.sendpad();
      });
    },
    async receiptComplete(resUploadLayerPic) {
      // alert('jinru');
      let isError = false;
      try {
        if (resUploadLayerPic) {
          this.imgFrontIDReceipt = resUploadLayerPic.frontImgid;
        }
        // 保存凭证图片
        const mediaType = await getDicCodeByDes(dicKeys.mediaType, '补充资料');
        const imgType = await getDicCodeByDes(dicKeys.imgType, '补充资料');
        const deviceRecieveStatus = await getDicCodeByDes(
          dicKeys.deviceRecieveStatus,
          '已领取'
        );
        if (mediaType) {
          const ImageInfoReceipt = {
            mediaType,
            imgType,
            imgFrontID: this.imgFrontIDReceipt,
          };
          this.workOrderSelection.forEach(async element => {
            await updateWorkOrder({
              workOrderID: element.workOrderId,
              deviceRecieveStatus,
              modifyInfo: { imagelist: [ImageInfoReceipt] },
            });
          });
        }
      } catch (e) {
        isError = true;
        this.$message.error(e);
      }
      if (!isError) {
        this.voucherVisiable = false;
        this.$alert('领取成功', '提示', {
          confirmButtonText: '确定',
          type: 'success',
        }).then(() => {
          this.getTabelInfo();
        });
      }
    },
    async onSearch() {
      this.page = 1;
      this.currentPage = 1;
      this.getTabelInfo();
    },
    async closeOrder() {
      let closeBtnDisabledTrueWorkOrders = [];
      this.multipleSelection.forEach(element => {
        if (element.closeBtnDisabled === true) {
          closeBtnDisabledTrueWorkOrders.push(element.workOrderId);
        }
      });
      if (closeBtnDisabledTrueWorkOrders.length !== 0) {
        let alertDesc =
          '存在不可关闭工单，工单号为：' + closeBtnDisabledTrueWorkOrders;
        console.log('alertDesc', alertDesc);
        this.$alert(alertDesc, '提示', {
          confirmButtonText: '确定',
          type: 'success',
          customClass: 'workordermanagement-message-box-alert',
        }).then(() => {
          this.getTabelInfo();
        });
        return;
      } else {
        this.tableLoading = true;
        this.workOrderSelection = this.multipleSelection.map(
          ({ workOrderId }) => ({ workOrderId })
        );
        let errorWorkOrderIds = [];
        new Promise(async (resolve, reject) => {
          // this.workOrderSelection.forEach(async (element) => {
          for (const element of this.workOrderSelection) {
            let res = await cancelWorkOrder({
              workOrderID: element.workOrderId,
            });
            if (!res) {
              console.log('error', res);
              console.log(element.workOrderId);
              errorWorkOrderIds.push(element.workOrderId);
            } else {
              console.log('success', res);
            }
          }
          resolve(errorWorkOrderIds);
        }).then(errorWorkOrderIds => {
          this.tableLoading = false;
          if (errorWorkOrderIds.length === 0) {
            this.$alert('关闭工单成功', '提示', {
              confirmButtonText: '确定',
              type: 'success',
            }).then(() => {
              this.getTabelInfo();
            });
          } else {
            console.log('errorWorkOrderIds', errorWorkOrderIds);
            let alertDesc = '存在关闭失败工单，工单号为：' + errorWorkOrderIds;
            console.log('alertDesc', alertDesc);
            this.$alert(alertDesc, '提示', {
              confirmButtonText: '确定',
              type: 'success',
              customClass: 'workordermanagement-message-box-alert',
            }).then(() => {
              this.getTabelInfo();
            });
          }
        });
      }
      // const res = await cancelWorkOrder({ workOrderID: row.workOrderId });
      // if (res) {
      //   this.getTabelInfo();
      // }
    },
    // 补开发票
    async reissueInvoice() {
      let reissueInvoiceDisableWorkOrders = [];
      this.multipleSelection.forEach(element => {
        // 费用大于0，且开票标志为0-未开 可补开发票
        if (element.price > 0 && element.payFlag === '0') {
          reissueInvoiceDisableWorkOrders.push(element.workOrderId);
        }
      });
      if (reissueInvoiceDisableWorkOrders.length !== 0) {
        let alertDesc =
          '存在不可补开发票工单，工单号为：' + reissueInvoiceDisableWorkOrders;
        console.log('alertDesc', alertDesc);
        this.$alert(alertDesc, '提示', {
          confirmButtonText: '确定',
          type: 'success',
          customClass: 'workordermanagement-message-box-alert',
        }).then(() => {
          this.getTabelInfo();
        });
        return;
      } else {
        this.tableLoading = true;
        this.workOrderSelection = this.multipleSelection.map(
          ({ workOrderId }) => ({ workOrderId })
        );
        let errorWorkOrderIds = [];
        new Promise(async (resolve, reject) => {
          for (const element of this.workOrderSelection) {
            let res = await addBranch({
              workOrderList: [{ workOrderId: element.workOrderId }],
            });
            if (!res) {
              console.log('error', res);
              console.log(element.workOrderId);
              errorWorkOrderIds.push(element.workOrderId);
            } else {
              console.log('success', res);
            }
          }
          resolve(errorWorkOrderIds);
        }).then(errorWorkOrderIds => {
          this.tableLoading = false;
          if (errorWorkOrderIds.length === 0) {
            this.$alert('补开发票成功', '提示', {
              confirmButtonText: '确定',
              type: 'success',
            }).then(() => {
              this.getTabelInfo();
            });
          } else {
            console.log('errorWorkOrderIds', errorWorkOrderIds);
            let alertDesc =
              '存在开具发票失败工单，工单号为：' + errorWorkOrderIds;
            console.log('alertDesc', alertDesc);
            this.$alert(alertDesc, '提示', {
              confirmButtonText: '确定',
              type: 'success',
              customClass: 'workordermanagement-message-box-alert',
            }).then(() => {
              this.getTabelInfo();
            });
          }
        });
      }
    },
    // 退单
    async chargeback(index, row) {
      this.tableLoading = true;
      new Promise(async (resolve, reject) => {
        let res = await refund({
          etcUserId: row.etcUserId,
          workOrderId: row.workOrderId,
          price: Number.parseInt(row.price),
          payMode: row.payMode,
        });
        resolve(res);
      }).then(res => {
        this.tableLoading = false;
        if (res) {
          this.$alert('退单成功', '提示', {
            confirmButtonText: '确定',
            type: 'success',
          }).then(() => {
            this.getTabelInfo();
          });
        } else {
          let alertDesc = '退单失败';
          console.log('alertDesc', alertDesc);
          this.$alert(alertDesc, '提示', {
            confirmButtonText: '确定',
            type: 'success',
            customClass: 'workordermanagement-message-box-alert',
          }).then(() => {
            this.getTabelInfo();
          });
        }
      });
    },
    async suppleOrder() {
      // this.suppleInfoWorkOrderId = row.workOrderId;
      this.workOrderSelection = this.multipleSelection.map(
        ({ workOrderId }) => ({ workOrderId })
      );
      this.suppleInfoDialogVisible = true;
    },
    async saveSuppleInfo(imageInfo) {
      let imageList = [];
      if (imageInfo.length === 0) {
        this.$message.info('请上传补充资料');
      } else {
        this.suppleInfoLoading = true;
        //保存补充资料图片
        console.log(imageInfo);
        const mediaType = await getDicCodeByDes(dicKeys.mediaType, '补充资料');
        const imgType = await getDicCodeByDes(dicKeys.imgType, '补充资料');
        imageInfo.forEach(pic => {
          imageList.push({
            imgFrontID: pic.frontImgid,
            imgType: imgType,
            mediaType: mediaType,
          });
        });
        let errorWorkOrderIds = [];
        new Promise(async (resolve, reject) => {
          // this.workOrderSelection.forEach(async (element) => {
          for (const element of this.workOrderSelection) {
            let res = await updateWorkOrder({
              workOrderID: element.workOrderId,
              modifyInfo: { imagelist: imageList },
            });
            if (!res) {
              console.log('error', res);
              console.log(element.workOrderId);
              errorWorkOrderIds.push(element.workOrderId);
            } else {
              console.log('success', res);
            }
          }
          resolve(errorWorkOrderIds);
        }).then(errorWorkOrderIds => {
          this.suppleInfoLoading = false;
          this.suppleInfoDialogVisible = false;
          if (errorWorkOrderIds.length === 0) {
            this.$alert('补充资料成功', '提示', {
              confirmButtonText: '确定',
              type: 'success',
            }).then(() => {
              this.getTabelInfo();
            });
          } else {
            console.log('errorWorkOrderIds', errorWorkOrderIds);
            let alertDesc =
              '存在补充资料失败工单，工单号为：' + errorWorkOrderIds;
            console.log('alertDesc', alertDesc);
            this.$alert(alertDesc, '提示', {
              confirmButtonText: '确定',
              type: 'success',
              customClass: 'workordermanagement-message-box-alert',
            }).then(() => {
              this.getTabelInfo();
            });
          }
        });
      }
    },
    // 关闭图片查看对话框
    closeDialog() {
      clearTimeout(this.timer);
      this.dialogVisible = false;
    },
    // 图片查看
    async view(index, row) {
      // this.dialogVisible = true;
      const res = await orderImg({ workOrderID: row.workOrderId });
      // const res = await orderImg({ workOrderID: '118' });
      if (res) {
        // this.dialogTableData = res.imageList;
        // console.log('res.imageList:'+res.imageList);
        let imgTitle = this.imgTitle;
        let dialogTableDataObj = {};
        // 开户人基本信息证件
        let imageInfo1 = [];
        res.imageList
          .filter(item => item.eVoucherType === '1')
          .forEach(item => {
            imageInfo1.push(imgTitle + item.imageInfo);
          });
        dialogTableDataObj.imageInfo1 = imageInfo1;
        console.log('imageInfo1');
        console.log(imageInfo1);
        // 车主基本信息证件
        let imageInfo2 = [];
        res.imageList
          .filter(item => item.eVoucherType === '2')
          .forEach(item => {
            imageInfo2.push(imgTitle + item.imageInfo);
          });
        dialogTableDataObj.imageInfo2 = imageInfo2;

        // 车辆证件
        let imageInfo3 = [];
        res.imageList
          .filter(item => item.eVoucherType === '3')
          .forEach(item => {
            imageInfo3.push(imgTitle + item.imageInfo);
          });
        dialogTableDataObj.imageInfo3 = imageInfo3;
        this.downloadImg3 = imageInfo3;
        console.log('this.downloadImg3');
        console.log(this.downloadImg3);
        // 经办人证件类型
        let imageInfo4 = [];
        res.imageList
          .filter(item => item.eVoucherType === '4')
          .forEach(item => {
            imageInfo4.push(imgTitle + item.imageInfo);
          });
        dialogTableDataObj.imageInfo4 = imageInfo4;
        // 业务凭证
        let imageInfo5 = [];
        res.imageList
          .filter(item => item.eVoucherType === '5')
          .forEach(item => {
            imageInfo5.push(imgTitle + item.imageInfo);
          });
        dialogTableDataObj.imageInfo5 = imageInfo5;
        // 其他（证明/授权）
        let imageInfo6 = [];
        res.imageList
          .filter(item => item.eVoucherType === '6')
          .forEach(item => {
            imageInfo6.push(imgTitle + item.imageInfo);
          });
        dialogTableDataObj.imageInfo6 = imageInfo6;
        // 银行卡
        let imageInfo7 = [];
        res.imageList
          .filter(item => item.eVoucherType === '7')
          .forEach(item => {
            imageInfo7.push(imgTitle + item.imageInfo);
          });
        dialogTableDataObj.imageInfo7 = imageInfo7;
        // 代理人证件
        let imageInfo8 = [];
        res.imageList
          .filter(item => item.eVoucherType === '8')
          .forEach(item => {
            imageInfo8.push(imgTitle + item.imageInfo);
          });
        dialogTableDataObj.imageInfo8 = imageInfo8;
        // 补充资料
        let imageInfo9 = [];
        res.imageList
          .filter(item => item.eVoucherType === '9')
          .forEach(item => {
            imageInfo9.push(imgTitle + item.imageInfo);
          });
        dialogTableDataObj.imageInfo9 = imageInfo9;
        // 其他证件资料
        let imageInfo10 = [];
        res.imageList
          .filter(item => item.eVoucherType === '10')
          .forEach(item => {
            imageInfo10.push(imgTitle + item.imageInfo);
          });
        dialogTableDataObj.imageInfo10 = imageInfo10;
        // 回执凭证
        let imageInfo11 = [];
        res.imageList
          .filter(item => item.eVoucherType === '11')
          .forEach(item => {
            imageInfo11.push(imgTitle + item.imageInfo);
          });
        dialogTableDataObj.imageInfo11 = imageInfo11;
        // // ```````````````````````
        // res.imageList.forEach((item) => {
        //   alert('item.eVoucherType:' + item.eVoucherType);
        // });
        if (this.dialogTableData.length >= 1) {
          // 防止每次添加子元素
          this.dialogTableData.pop();
        }
        this.dialogTableData.push(dialogTableDataObj);
        // console.log('dialogTableData:' + JSON.stringify(this.dialogTableData));
        this.dialogVisible = true;

        this.tableShow = false;
        this.timer = setTimeout(() => {
          this.tableShow = true;
          this.$refs.dialogTable.doLayout(); // 解决el-table中表头和内容错位
        }, 10);
      }
    },
    handleSizeChange(val) {
      this.pageSize = val;
      this.getTabelInfo();
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      // 当前为第几页时调用getTabelInfo()显示第几页数据
      this.page = val;
      this.currentPage = val;
      this.getTabelInfo();
      console.log(`当前页: ${val}`);
      // this.pageSize = 5;
    },
    async getTabelInfo() {
      let beginDate = formatDate(
        'YYYYMMDD',
        new Date(this.orderDate[0].toDateString())
      );
      let endDate = formatDate(
        'YYYYMMDD',
        new Date(this.orderDate[1].toDateString())
      );
      let modifyBeginDate = '';
      let modifyEndDate = '';
      if (this.modifyOrderDate.length !== 0) {
        modifyBeginDate = formatDate(
          'YYYYMMDD',
          new Date(this.modifyOrderDate[0].toDateString())
        );
        modifyEndDate = formatDate(
          'YYYYMMDD',
          new Date(this.modifyOrderDate[1].toDateString())
        );
      }
      const res = await orderQuery({
        ...this.form,
        vehicleColor: this.form.vehicleColor,
        beginDate,
        endDate,
        modifyBeginDate,
        modifyEndDate,
        startRecords: this.startRecords,
        rowNumber: this.pageSize,
        userCode: this.$trim(this.form.userCode),
      });
      if (res) {
        console.log('res');
        console.log(res);
        let recordListArr = res.recordList;
        for (let i = 0; i < recordListArr.length; i++) {
          if (
            recordListArr[i].status ===
              (await getDicCodeByDes(dicKeys.status, '已关闭')) ||
            recordListArr[i].status ===
              (await getDicCodeByDes(dicKeys.status, '已完成'))
          ) {
            // 工单已关闭
            recordListArr[i].closeBtnDisabled = true;
          }
          // 退单按钮显示判断
          if (
            recordListArr[i].status === '1' &&
            recordListArr[i].payFlag === '1'
          ) {
            res.recordList[i].chargebackBtnDisabled = false;
          } else {
            res.recordList[i].chargebackBtnDisabled = true;
          }
          // // 继续办理显示判断
          // if (
          //   (recordListArr[i].bizCode === '09' ||
          //     recordListArr[i].bizCode === '12') &&
          //   recordListArr[i].status !== '3'
          // ) {
          //   res.recordList[i].continueWorkBtnDisabled = false;
          // } else {
          //   res.recordList[i].continueWorkBtnDisabled = true;
          // }
          // 继续办理显示判断 其他售后业务
          if (
            recordListArr[i].bizCode !== '05' &&
            recordListArr[i].bizCode !== '20' &&
            recordListArr[i].bizCode !== '21' &&
            recordListArr[i].status !== '3' &&
            recordListArr[i].status !== '08' &&
            recordListArr[i].status !== '11'
          ) {
            res.recordList[i].continueWorkBtnDisabled = false;
          } else {
            res.recordList[i].continueWorkBtnDisabled = true;
          }
          recordListArr[i].paychannelName = recordListArr[i].subpaychannelName
            ? recordListArr[i].subpaychannelName
            : recordListArr[i].paychannelName; //签约银行
          recordListArr[i].status = await getDicDesByCode(
            dicKeys.status,
            recordListArr[i].status
          );
          recordListArr[i].bizCodeDesc = await getDicDesByCode(
            dicKeys.bizCode,
            recordListArr[i].bizCode
          );
          recordListArr[i].oldNewVehicleColor =
            recordListArr[i].newVehicleColor;
          recordListArr[i].newVehicleColor = await getDicDesByCode(
            dicKeys.vehicleColor,
            recordListArr[i].newVehicleColor
          );
          recordListArr[i].oldVehicleColor = await getDicDesByCode(
            dicKeys.vehicleColor,
            recordListArr[i].oldVehicleColor
          );
          recordListArr[i].saleFlag = await getDicDesByCode(
            dicKeys.saleFlag,
            recordListArr[i].saleFlag
          );
          recordListArr[i].oldPayFlag = recordListArr[i].payFlag;
          recordListArr[i].payFlag = await getDicDesByCode(
            dicKeys.payFlag,
            recordListArr[i].payFlag
          );
          recordListArr[i].deviceRecieveStatus = await getDicDesByCode(
            dicKeys.deviceRecieveStatus,
            recordListArr[i].deviceRecieveStatus
          );
          recordListArr[i].fmprice = getFormatAmount(recordListArr[i].price);
        }
        // this.tableData = res.recordList;
        this.tableData = recordListArr;
        this.total = res.totalNumber;
        this.currentSize =
          this.pageSize * this.page >= this.total
            ? this.total
            : this.page * this.pageSize;
        // this.rowNumber = this.pageSize * this.page > this.total ? (this.total- this.startRecords + 1) :this.pageSize;
        console.log(`this.total: ${this.total}`);
      }
    },
    datePickerChange() {},
    refresh() {
      this.setDate();
      this.setNetIdSelect();
      this.setOprIdSelect();
      this.form.vehicleColor = '';
      this.$refs.form.resetFields();
    },
    async setDate() {
      this.orderDate = [];
      this.modifyOrderDate = [];
      //用后台接口返回的时间
      const res = await systemParameterQuery({ requestType: '00' });
      let dateString =
        res.value.substring(0, 4) +
        '-' +
        res.value.substring(4, 6) +
        '-' +
        res.value.substring(6, 8);
      console.log(dateString);
      let date1 = new Date(dateString);
      this.orderDate.push(date1);
      this.orderDate.unshift(date1);
      // this.modifyOrderDate.push(date1);
      // this.modifyOrderDate.unshift(date1);
      console.log(this.orderDate);
      return true;

      // // 不能用前端时间
      // //当前设定的日期时间
      // let d = new Date();
      // let year1, month1, day1;
      // [year1, month1, day1] = [d.getFullYear(), d.getMonth(), d.getDate()];
      // let date1 = new Date(year1, month1, day1, 7);
      // this.orderDate.push(date1);
      // this.orderDate.unshift(date1);

      // // 前一天设定的日期时间;
      // let year2, month2, day2;
      // d.setTime(d.getTime() - 24 * 60 * 60 * 1000);
      // [year2, month2, day2] = [d.getFullYear(), d.getMonth(), d.getDate()];
      // let date2 = new Date(year2, month2, day2, 7);
      // this.orderDate.unshift(date2);
      // return true;
    },

    // 修改付款方式
    changePayment(idx, row) {
      this.changePaymentShow = true;
      this.rowData = row;
      this.payment = row.payMode; // 支付方式
    },
    // 确定修改支付方式
    confirmChangePayment() {
      // 后台接口数据交互 payMode
      //etcUserId, workOrderID, payMode, payChannelId, subPayChannelId

      const { etcUserId, workOrderId, payMode } = {
        ...this.rowData,
        payMode: this.payment,
      };

      changePaymentApi({
        etcUserId,
        workOrderId,
        payMode: this.payment,
      }).then(data => {
        // alert(JSON.stringify(data))
        if (data) {
          // 成功
          this.changePaymentShow = false;
          this.payment = '';
          this.getTabelInfo();
        }
      });
    },

    closePaymentDialog() {
      this.changePaymentShow = false;
      this.payment = '';
    },
    async continueHandleBus(index, row) {
      // 车型变更 - 跳转到继续办理页面
      if (row.bizCode == 13) {
        etcdev.predisplay(
          '0',
          'vueEmit(\'{"type":"ev-vehiclechange", "param":{"rowData":' +
            JSON.stringify(row) +
            "}}')"
        );
        return;
      }

      // 需要判断是换卡还是换签业务
      const orderid = row.workOrderId;
      const payFlag = row.oldPayFlag;
      const price = row.price;
      const payMode = row.payMode;
      const etcUserId = row.etcUserId;
      const newVehicleNumber = row.newVehicleNumber;
      const newVehicleColor = row.oldNewVehicleColor;
      const oldObuysId = row.oldObuysId;

      let cdif = await getQueryStringByName('dif', window.location.href);
      if (row.bizCode === '12') {
        let continueType = 'changeobu';
        let elementPermission = this.elementPermissions.find(
          obj => obj.menu == '/' + continueType
        );
        let elementPermissionStr = JSON.stringify(
          elementPermission.permissions
        );
        elementPermissionStr = elementPermissionStr.replace(/\"/g, '');
        // 跳转到换签主窗口
        let rtn = etcdev.predisplay(
          '0',
          'vueEmit(\'{"type":"toChangeOBU","param":{"workOrderID":"' +
            orderid +
            '","elementPermission":"' +
            elementPermissionStr +
            '","payFlag":"' +
            payFlag +
            '","price":"' +
            price +
            '","payMode":"' +
            payMode +
            '","cdif":"' +
            cdif +
            '","etcUserId":"' +
            etcUserId +
            '","newVehicleNumber":"' +
            newVehicleNumber +
            '","newVehicleColor":"' +
            newVehicleColor +
            '","oldObuysId":"' +
            oldObuysId +
            '"}}\')'
        );
      } else if (row.bizCode === '09') {
        let continueType = 'changecard';
        let elementPermission = this.elementPermissions.find(
          obj => obj.menu == '/' + continueType
        );
        let elementPermissionStr = JSON.stringify(
          elementPermission.permissions
        );
        elementPermissionStr = elementPermissionStr.replace(/\"/g, '');
        // 跳转到换卡主窗口
        let rtn = etcdev.predisplay(
          '0',
          'vueEmit(\'{"type":"toChangeCard","param":{"workOrderID":"' +
            orderid +
            '","elementPermission":"' +
            elementPermissionStr +
            '","payFlag":"' +
            payFlag +
            '","price":"' +
            price +
            '","payMode":"' +
            payMode +
            '","cdif":"' +
            cdif +
            '","etcUserId":"' +
            etcUserId +
            '","newVehicleNumber":"' +
            newVehicleNumber +
            '","newVehicleColor":"' +
            newVehicleColor +
            '"}}\')'
        );
      } else if (row.bizCode != '09' && row.bizCode != '12') {
        let continueType = '';
        const bizCodeArr = [];
        bizCodeArr.push({
          continueType: 'reportloss', // 此处配置业务路由
          bizCode: await getDicCodeByDes(dicKeys.bizCode, '卡片挂失'),
        });
        bizCodeArr.push({
          continueType: 'untiedhang', // 此处配置业务路由
          bizCode: await getDicCodeByDes(dicKeys.bizCode, '卡片解挂'),
        });
        bizCodeArr.push({
          continueType: 'obureportloss', // 此处配置业务路由
          bizCode: await getDicCodeByDes(dicKeys.bizCode, '标签挂失'),
        });
        bizCodeArr.push({
          continueType: 'obuuntiedhang', // 此处配置业务路由
          bizCode: await getDicCodeByDes(dicKeys.bizCode, '标签解挂'),
        });
        bizCodeArr.push({
          continueType: 'cardReplacement', // 此处配置业务路由
          bizCode: await getDicCodeByDes(dicKeys.bizCode, '补卡'),
        });
        bizCodeArr.push({
          continueType: 'obuReplacement', // 此处配置业务路由
          bizCode: await getDicCodeByDes(dicKeys.bizCode, '补签'),
        });
        bizCodeArr.forEach(element => {
          if (element.bizCode === row.bizCode) {
            continueType = element.continueType;
          }
        });
        let elementPermission = this.elementPermissions.find(
          obj => obj.menu == '/' + continueType
        );
        let elementPermissionStr = JSON.stringify(
          elementPermission.permissions
        );
        elementPermissionStr = elementPermissionStr.replace(/\"/g, '');
        // 跳转到其他售后业务
        let rtn = etcdev.predisplay(
          '0',
          'vueEmit(\'{"type":"handleContinue","param":{"workOrderID":"' +
            orderid +
            '","elementPermission":"' +
            elementPermissionStr +
            '","continueType":"' +
            continueType +
            '","payFlag":"' +
            payFlag +
            '","price":"' +
            price +
            '","payMode":"' +
            payMode +
            '","cdif":"' +
            cdif +
            '","etcUserId":"' +
            etcUserId +
            '","newVehicleNumber":"' +
            newVehicleNumber +
            '","newVehicleColor":"' +
            newVehicleColor +
            '"}}\')'
        );
      }
    },
    refreshTable1() {
      // 刷新表格
      emit.on('refreshTable1', p => {
        console.log('刷新表格');
        //this.getTabelInfo();
      });
    },
  },

  async mounted() {
    // alert('oprtId:'+this.$route.query.oprtId);
    // alert('token:'+this.$route.query.token);
    // this.form.etcUserId = this.$route.query.etcUserId;

    this.elementPermissions = JSON.parse(this.$route.query.elementPermissions);
    // this.elementPermissions = [
    //   {
    //     menu: '/changecard',
    //     permissions: { specialfree: true },
    //   },
    // ];

    // alert('elementPermissions:' + this.elementPermissions[0].menu);
    this.$store.dispatch('GetJumpData', {
      oprtId: this.$route.query.oprtId,
      token: this.$route.query.token,
    });
    // const res0 = await this.$store.dispatch('GetJumpData', {
    //   oprtId: 'wyd', //'lgl'//'wjx'//'ly'
    //   token: '1376808959788187648',
    // });

    this.loginName = this.$route.query.oprtId;
    this.netid = this.$route.query.netid;
    // this.loginName = 'wyd';
    // this.netid = '12345';

    // if (res0) {
    await this.setDate();
    await this.setNetIdSelect();
    await this.setOprIdSelect();
    this.getTabelInfo();
    // }
  },
};
</script>
