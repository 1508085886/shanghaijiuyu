<!--50条记录查询-->
<template>
  <div class="offline-equipmentissuance">
    <div class="clearfix">
      <div class="fl">
        <h4 class="offline-devicewriteoff_title">卡内交易查询</h4>
      </div>
    </div>
    <div class="mt40 offline-systemInfoChecked">
      <div class="kahao">卡号：</div>
      <el-input class="input" v-model="cardId" readonly></el-input>
      <div class="btn">
        <el-button
          class="btn1"
          type="primary"
          @click="readcard"
          icon="el-icon-caret-right"
          size="small"
          round
          >读卡</el-button
        >
      </div>
    </div>
    <!-- //////////////////////////////// -->

    <div style="margin-top: 31px">
      <el-table
        :data="tableData"
        :header-cell-style="{
          width: '1074px',
          height: '41px',
          background: '#D3D6DF',

          opacity: '1',
          'border-radius': '4px 4px 0px 0px',
        }"
        :row-style="{
          width: '1074px',
          height: '38px',
          background: '#E5E5EA',
          border: '1px solid #C0C4C9',
          opacity: '1',
        }"
      >
        <el-table-column label="联机交易序号" prop="transactionNo">
        </el-table-column>
        <el-table-column label="透支限额" prop="overdraftLimit">
        </el-table-column>
        <el-table-column label="交易金额" prop="transactionAmount">
        </el-table-column>
        <el-table-column label="交易类型标识" prop="transactionType">
        </el-table-column>
        <el-table-column label="终端机编号" prop="terminalNo">
        </el-table-column>
        <el-table-column label="交易日期" prop="transactionDate">
        </el-table-column>
        <el-table-column label="交易时间" prop="transactionTime">
        </el-table-column>
      </el-table>
    </div>

    <div
      class="fl offline-workordermanagement_tableblock-pagination-desc"
      v-if="total != 0"
    >
      第{{ startRecords }}到{{ currentSize }}条，
    </div>
    <el-pagination
      background
      @current-change="handleCurrentChange"
      :current-page.sync="currentPage"
      :page-size="pageSize"
      layout="total,->,prev, pager, next,slot"
      :total="total"
    >
    </el-pagination>
  </div>
</template>

<script>
import { purchaserecord } from '@/utils/readcardobu';
import { getCpuId } from '@/utils/dynamic';
export default {
  data() {
    return {
      startRecords: 1,
      currentSize: '',
      currentPage: 1,
      tableData: [],
      cardId: '',
      total: 0,
      page: 1,
      pageSize: 25,
      systemInfoChecked: true,
    };
  },
  watch: {},
  components: {},
  computed: {},

  methods: {
    clear() {
      (this.startRecords = 1), (this.currentSize = '');
      (this.currentPage = 1),
        (this.tableData = []),
        (this.cardId = ''),
        (this.total = 0),
        (this.page = 1),
        (this.pageSize = 25),
        (this.systemInfoChecked = true);
    },
    headerStyle({ row, rowIndex }) {
      return 'headerColor';
    },
    handleCurrentChange(val) {
      // 当前为第几页时调用getTabelInfo()显示第几页数据
      this.page = val;
      this.currentPage = val;
      this.getpurchaserecord();
    },
    async readcard() {
      const cardInfo = getCpuId();
      console.log('cardInfo');
      console.log(cardInfo);
      if (cardInfo.cardid != '') {
        this.cardId = cardInfo.cardid;
        this.getpurchaserecord();
      } else {
        this.$message.error({
          message: '卡内交易查询失败',
          dangerouslyUseHTMLString: true,
          center: true,
        });
        this.clear();
        return;
      }
    },
    getpurchaserecord() {
      const res = purchaserecord();
      console.log('res');
      console.log(res);
      if (res[0].transactionDate == '年月日') {
        this.$message.error({
          message: '卡内交易查询失败',
          dangerouslyUseHTMLString: true,
          center: true,
        });
        this.clear();
        return;
      }
      if (res) {
        this.total = res.length;
        if (res.length < 26) {
          this.tableData = res.slice(0, res.length);
          this.startRecords = 1;
          this.currentSize = res.length;
        } else {
          if (this.currentPage == 1) {
            this.tableData = res.slice(0, 25);
            this.startRecords = 1;
            this.currentSize = 25;
          }
          if (this.currentPage == 2) {
            this.tableData = res.slice(25, res.length);
            this.startRecords = 26;
            this.currentSize = res.length;
          }
        }
      }
    },
  },
  mounted() {
    console.log(this.cardId);
  },
};
</script>
