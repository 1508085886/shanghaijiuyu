<!--  -->
<template>
  <el-container class="offline_layout o-font-family is-vertical">
    <layout-header :link-show="false" :avatar-show="false" :logout-show="false"/>
    <el-container style="height: 0">
      <el-main class="o-height-full offline_layout-main o-flex o-flex-column">
        <div class="offline_layout-main-scroll">
          <div
            class="offline-allaccountinfo_wrapper offline-allaccountinfo_searchblock"
          >
            <h3 class="ml35">账户信息</h3>
            <el-form
              ref="form"
              :model="form"
              :rules="rules"
              :inline="true"
              label-position="right"
              label-width="auto"
              class="offline-allaccountinfo_searchblock-form"
            >
              <el-row class="mt10" :gutter="0">
                <!--  <el-col :md="8" :lg="6">
                  <el-form-item label="工单号：" prop="userName">
                    <el-input
                      v-model="form.userName"
                      class="offline-allaccountinfo_searchblock-form-input"
                    ></el-input>
                  </el-form-item>
                </el-col>  -->
                <!--  <el-col :md="8" :lg="6">
                  <el-form-item label="网点：" prop="localNetFlag">
                    <type-select
                      type="vehicleColor"
                      v-model="form.localNetFlag"
                      placeholder="请选择"
                      class="offline-allaccountinfo_searchblock-form-input"
                    />
                  </el-form-item>
                </el-col> -->
                <!--  <el-col :md="8" :lg="6">
                  <el-form-item label="操作员：" prop="userName">
                    <type-select
                      type="vehicleColor"
                      v-model="form.userName"
                      placeholder="请选择"
                      class="offline-allaccountinfo_searchblock-form-input"
                    />
                  </el-form-item>
                </el-col> -->
                <el-col :md="8" :lg="8">
                  <el-form-item label="业务类型：" prop="bizCode">
                    <type-select
                      type="bizCode"
                      v-model="form.bizCode"
                      placeholder="请选择"
                      class="offline-allaccountinfo_searchblock-form-input"
                    />
                  </el-form-item>
                </el-col>
                <el-col :md="8" :lg="8">
                  <el-form-item label="创建日期：" prop="orderDate">
                    <el-date-picker
                      v-model="orderDate"
                      type="daterange"
                      range-separator="至"
                      start-placeholder="开始日期"
                      end-placeholder="结束日期"
                      @change="datePickerChange"
                      :clearable="false"
                      class="offline-allaccountinfo_searchblock-form-input"
                    >
                    </el-date-picker>
                  </el-form-item>
                </el-col>
                <el-col :md="8" :lg="8">
                  <el-form-item label="车牌：" prop="vehicleNumber">
                    <el-input
                      placeholder="请输入内容"
                      v-model="form.vehicleNumber"
                      class="input-with-select offline-allaccountinfo_searchblock-form-input"
                    >
                      <type-select
                        type="vehicleColor"
                        v-model="form.vehicleColor"
                        slot="prepend"
                        placeholder="请选择"
                      >
                      </type-select>
                    </el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row class="mt10" :gutter="0">
                <el-col :md="8" :lg="8">
                  <el-form-item label="卡号：" prop="cardId">
                    <el-input
                      v-model="form.cardId"
                      class="offline-allaccountinfo_searchblock-form-input"
                    ></el-input>
                  </el-form-item>
                </el-col>
                <el-col :md="8" :lg="8">
                  <el-form-item label="标签号：" prop="obuId">
                    <el-input
                      v-model="form.obuId"
                      class="offline-allaccountinfo_searchblock-form-input"
                    ></el-input>
                  </el-form-item>
                </el-col>
                <el-col :md="8" :lg="8">
                  <el-button
                    class="offline-allaccountinfo_searchblock-search"
                    size="small"
                    type="primary"
                    icon="el-icon-search"
                    @click="onSearch"
                    round
                    >搜索</el-button
                  >
                  <el-button
                    class="offline-allaccountinfo_searchblock-refresh"
                    size="small"
                    icon="el-icon-refresh-left"
                    @click="refresh"
                    round
                    >重置</el-button
                  >
                </el-col>
              </el-row>
              <!-- <div class="fr mt10 mr70">
                <el-button class="" size="small" type="primary" icon="el-icon-search" @click="onSearch" round>搜索</el-button>
                <el-button class="offline-allaccountinfo_searchblock-refresh" size="small" icon="el-icon-refresh-left" @click="refresh" round>重置</el-button>
              </div> -->
            </el-form>
          </div>
          <div
            class="mt10 offline-allaccountinfo_wrapper offline-allaccountinfo_tableblock"
          >
            <div class="offline-allaccountinfo_tableblock-table">
              <el-table
                :data="tableData"
                style="width: 100%"
                header-cell-class-name="offline-allaccountinfo_tableblock-header"
              >
                <el-table-column label="账户编号" prop="userAcctId">
                </el-table-column>
                <!-- <el-table-column label="创建时间" prop="registerTime">
                </el-table-column>
                <el-table-column label="创建操作员" prop="oprtId">
                </el-table-column>
                <el-table-column label="创建网点代码" prop="netId">
                </el-table-column> -->
                <el-table-column label="账户类型" prop="userAcctType">
                </el-table-column>
                <el-table-column label="部门名称" prop="department">
                </el-table-column>
                <el-table-column label="代理人姓名" prop="agentName">
                </el-table-column>
                <el-table-column label="代理人证件类型" prop="agentIdType">
                </el-table-column>
                <el-table-column label="代理人证件号码" prop="agentIdNum">
                </el-table-column>
                <el-table-column label="代理人手机" prop="tel">
                </el-table-column>
                <el-table-column label="操作" :header-align="tableHeaderAlign" v-if="visibleHandle">
                  <template slot-scope="scope">
                    <el-button
                      size="mini"
                      type="primary"
                      :disabled = scope.row.btnDisabled
                      @click="accountWriteoff(scope.$index, scope.row)"
                      >账户注销</el-button
                    >
                  </template>
                </el-table-column>
              </el-table>
            </div>
            <div
              class="clearfix offline-allaccountinfo_tableblock-pagination"
            >
              <div
                class="fl offline-allaccountinfo_tableblock-pagination-desc"
                v-if="total"
              >
                第{{ startRecords }}到{{ currentSize }}条，
              </div>
              <el-pagination
                background
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page.sync="currentPage"
                :page-size="pageSize"
                layout="total,->,prev, pager, next,slot"
                :total="total"
              >
              </el-pagination>
            </div>
          </div>
        </div>
      </el-main>
    
    </el-container>
  </el-container>
</template>

<script>
import LayoutHeader from '../../layout/components/LayoutHeader';
import { queryUserAccountList } from '@/api/user';
import { systemParameterQuery } from '@/api/common';
import { formatDate } from '@/utils/format';
import { dicKeys, getDicDesByCode,getDicCodeByDes } from '@/methods/dics';
export default {
  data() {
    return {
      // timer:0 ,
      // imgTitle:'data:image/jpg;base64,',
      currentPage: 1,
      total: 0, //总条数
      page: 1, //初始显示第几页
      pageSize: 10, //每页显示多少数据
      currentSize:0,// 当前页条数
      // tableShow:false,
      orderDate: [],
      form: {
        bizCode: '',
        vehicleColor: '',
        vehicleNumber: '',
        cardId: '',
        obuId: '',
      },
      rules: {
        // bizCode: [
        //   { required: false, message: '请选择所属省', trigger: 'blur' },
        // ],
      },
      tableHeaderAlign: 'left',
      tableData: [],
      visibleHandle:true,
    };
  },
  components: {
    LayoutHeader,
  },
  computed: {
    //起始记录
    startRecords() {
      return (this.page - 1) * this.pageSize + 1;
    },
  },
  methods: {
    async onSearch() {
      this.page =1;
      this.currentPage = 1;
      this.getTabelInfo();
    },
    async accountWriteoff(index, row) {
      const res = await cancelWorkOrder({ workOrderID: row.workOrderId });
      if (res) {
        this.getTabelInfo();
      }
    },

    handleSizeChange(val) {
      this.pageSize = val;
      this.getTabelInfo();
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      // 当前为第几页时调用getTabelInfo()显示第几页数据
      this.page = val;
      this.currentPage = val;
      this.getTabelInfo();
      console.log(`当前页: ${val}`);
      // this.pageSize = 5;
    },
    async getTabelInfo() {
      let beginDate = formatDate(
        'YYYYMMDD',
        new Date(this.orderDate[0].toDateString())
      );
      let endDate = formatDate(
        'YYYYMMDD',
        new Date(this.orderDate[1].toDateString())
      );
      const res = await queryUserAccountList({
        ...this.form,
        beginDate,
        endDate,
        startRecords: this.startRecords,
        rowNumber: this.pageSize,
      });
      if (res) {
        let recordListArr = res.userAcctList || [];
        for (let i = 0; i < recordListArr.length; i++) {
          // if(recordListArr[i].status === await getDicCodeByDes(dicKeys.status,'已关闭')){// 工单已关闭
          //   recordListArr[i].btnDisabled = true;
          // }
          // recordListArr[i].status = await getDicDesByCode(
          //   dicKeys.status,
          //   recordListArr[i].status
          // );
        }
        this.tableData = res.userAcctList || [];
        this.total = res.totalNumber;
        this.currentSize =  this.pageSize * this.page >= this.total ? this.total : this.page * this.pageSize;
        // this.rowNumber = this.pageSize * this.page > this.total ? (this.total- this.startRecords + 1) :this.pageSize;
        console.log(`this.total: ${this.total}`);
        console.log(`this.rowNumber: ${this.rowNumber}`);
      } 
    },
    datePickerChange() {},
    refresh() {
      this.setDate();
      this.form.vehicleColor = '';
      this.$refs.form.resetFields();
    },
    async setDate() {
      this.orderDate = [];
      //用后台接口返回的时间
      const res = await systemParameterQuery({requestType:'00'});
      let dateString = res.value.substring(0, 4)+'-'+res.value.substring(4, 6)+'-'+res.value.substring(6, 8)
      console.log(dateString);
      let date1 = new Date(dateString);
      this.orderDate.push(date1);
      this.orderDate.unshift(date1);
      console.log(this.orderDate);
      return true;
      // 不能用前端时间
      //当前设定的日期时间
      // let d = new Date();
      // let year1, month1, day1;
      // [year1, month1, day1] = [d.getFullYear(), d.getMonth(), d.getDate()];
      // let date1 = new Date(year1, month1, day1, 7);
      // this.orderDate.push(date1);
      // this.orderDate.unshift(date1);
    
      //前一天设定的日期时间
      // let year2,month2,day2
      // d.setTime(d.getTime()-24*60*60*1000);
      // [year2,month2,day2] = [d.getFullYear(),d.getMonth(),d.getDate()]
      // let date2 = new Date(year2,month2,day2,7)
      // this.orderDate.unshift(date2)
    },
  },

  async mounted() {
    // alert('oprtId:'+this.$route.query.oprtId);
    // alert('token:'+this.$route.query.token);
    
    // this.form.etcUserId = this.$route.query.etcUserId;
    // this.$store.dispatch('GetJumpData', {
      //       oprtId: this.$route.query.oprtId,
      //       token: this.$route.query.token,
      //     });
    this.form.etcUserId = 'U202010150000010671';
    const res0 = await this.$store.dispatch('GetJumpData', {
      oprtId: 'lgl',
      token: 'bbb',
    });
    // alert(res0);
    const res = await this.setDate();
    if(res){
      this.getTabelInfo();
    }
  },
};
</script>
